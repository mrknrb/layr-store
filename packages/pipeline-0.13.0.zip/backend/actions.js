// What you (the panels) and agents (the tools) do with tasks. Each checks that the task is where the board offers
// the button, changes the task, and wakes the scheduler: the gate still decides when anything reaches a thread.
import { approvable, heldWaiting, isActive, landQueued, retryFailed, waitsForAnswer } from "./columns.js";
import { releaseLane } from "./lane.js";
import { parseBackAt, SIZE_PCT_MAX } from "./pacing.js";
import { goAheadText, startText } from "./prompts.js";
import { DRAFT_FIELDS } from "./store.js";
import { EFFORTS, newTaskDefaults, PERMISSION_MODES } from "./settings.js";
import { firstLineTitle } from "./titles.js";
import { nowIso } from "./util.js";

/** Who starts it. "plan" is still taken (agents and old panels send it): it means Plan on (the `plan` toggle). */
export const START_MODES = ["either", "agents", "plan", "manual"];
export const SIZES = ["S", "M", "L"];

export function createActions(p) {
  const { store } = p;
  const now = nowIso;
  const done = (id) => {
    p.wake();
    return p.view(id);
  };

  /** `start: "plan"` (the old way to say Plan) as the `plan` toggle. */
  function planFromStart(d) {
    if (d.start !== "plan") return d;
    const { start: _s, ...rest } = d;
    return { ...rest, plan: true };
  }

  function checkDraft(d, task = null) {
    if (d.projectId !== undefined) {
      if (!p.projectInfo(d.projectId)) throw new Error(`There is no project ${d.projectId}: see projects`);
      if (task?.threadId) throw new Error("A started task stays in its project");
    }
    if (d.start !== undefined && !START_MODES.includes(d.start)) throw new Error(`start is one of ${START_MODES.join(", ")}`);
    if (d.size !== undefined && d.size !== null && !SIZES.includes(d.size)) throw new Error("size is S, M or L");
    if (d.sizePct !== undefined && d.sizePct !== null && !(Number(d.sizePct) >= 1 && Number(d.sizePct) <= SIZE_PCT_MAX)) {
      throw new Error(`sizePct is the percent of a 5-hour window the task needs, 1 to ${SIZE_PCT_MAX}`);
    }
    if (d.effort && !EFFORTS.includes(d.effort)) throw new Error(`effort is one of ${EFFORTS.join(", ")}`);
    if (d.permissionMode && !PERMISSION_MODES.includes(d.permissionMode)) {
      throw new Error(`permissionMode is one of ${PERMISSION_MODES.join(", ")}`);
    }
    if (d.noWorktree !== undefined && task?.threadId && !!d.noWorktree !== !!task.noWorktree) {
      throw new Error("Own worktree or not can't change once the thread exists");
    }
    if (d.after !== undefined && d.after !== null) {
      const parent = store.get(store.idOf(d.after));
      const projectId = d.projectId ?? task?.projectId;
      if (!parent || parent.projectId !== projectId) throw new Error(`There is no task #${d.after} in this project`);
      for (let at = parent, hops = 0; at && hops < 100; at = at.after ? store.get(at.after) : null, hops++) {
        if (task && String(at.number) === String(task.number)) throw new Error("That would make a loop of tasks");
      }
    }
  }

  /**
   * A new task: a proposal, run at once with `run`. `away`: its When away toggle (a proposal that doesn't plan first
   * then waits in Ready for Away). `batch`: made in a batch, as its sub-task (true or "open": the project's newest open
   * batch, "new": a new one, a number: that batch). `tasks` [{title, prompt}]: it is a batch, and these are made as its
   * sub-tasks, numbered in it (#84-1, #84-2…).
   */
  function create(input, { source = { kind: "you" }, run = input.run ?? false, batch = input.batch ?? false, by = "you", away = input.whenAway ?? false } = {}) {
    const { run: _r, batch: _b, whenAway: _w, tasks: subtasks, ...given } = input;
    const draft = planFromStart(given);
    if (!draft.projectId) throw new Error("Which project? Give projectId (projects lists them)");
    checkDraft(draft);
    // No title: the description's first line for now, and a small model writes a short one (titles.js).
    const autoTitle = !String(draft.title ?? "").trim();
    if (autoTitle) draft.title = firstLineTitle(draft.prompt);
    if (!draft.title) throw new Error("A task needs a title or a description");
    const subs = subTasks(subtasks);
    if (subs.length && batch) throw new Error("A batch can't join another batch");
    if (subs.length && (draft.after != null || draft.noWorktree)) throw new Error("A batch has no `after` and always has a worktree");
    const settings = store.project(draft.projectId);
    const fields = { ...draft, after: draft.after != null ? store.idOf(draft.after) : undefined, plan: draft.plan ? true : undefined };
    fields.attachments = draft.attachments?.length ? p.attachments.check(draft.attachments) : undefined;
    // The project's (else the global) auto-merge and agent lands; the dialog's other defaults are only its own.
    const defaults = newTaskDefaults(settings, store.global());
    if (fields.autoMerge === undefined && defaults.autoMerge) fields.autoMerge = true;
    if (fields.agentLands === undefined && defaults.agentLands) fields.agentLands = true;
    if (batch) {
      // A sub-task from the start: Plan and When away are its batch's.
      const inBatch = batchFor({ ...fields, plan: undefined, projectId: draft.projectId }, batch === true ? "open" : batch, !!fields.plan);
      const [id] = store.create({ ...fields, plan: undefined }, source, { inBatch });
      if (autoTitle) autoTitled(id);
      return done(id);
    }
    const [id] = store.create(fields, source);
    if (autoTitle) autoTitled(id);
    if (subs.length) addSubTasks(id, subs, source);
    if (away) setAway(id, true);
    if (run) runTask(id, { by });
    else if (draft.startAt) setStart(id, draft.startAt);
    return done(id);
  }

  /**
   * The batch a new sub-task goes into (`ref`: "open", the project's newest open batch, made when there is none; "new":
   * a new batch; a batch's number), after checking `task`, the sub-task's fields, may go into a batch at all.
   */
  function batchFor(task, ref, plans = false) {
    let batchId = ref === "open" ? p.openBatch(task.projectId)?.[0] : ref === "new" ? null : store.idOf(ref);
    const existing = batchId ? store.get(batchId) : null;
    if (ref !== "open" && ref !== "new" && (!existing?.batch || existing.threadId || existing.held?.length)) {
      throw new Error(`#${ref} isn't an open batch`);
    }
    const why = p.cannotJoin({ ...task, plan: plans || undefined }, existing ?? { projectId: task.projectId });
    if (why) throw new Error(`It can't be made in a batch: ${why}`);
    if (!batchId) [batchId] = store.create({ projectId: task.projectId, title: "Small changes", prompt: "" }, { kind: "batch" });
    store.mutate(batchId, () => ({ batch: true }));
    return batchId;
  }

  /**
   * Sub-tasks as given ({title, prompt} or {title, description}): one with only a description takes its first line as
   * its title; empty ones go. None is dropped silently for want of a title.
   */
  function subTasks(list) {
    return (list ?? []).flatMap((x) => {
      const prompt = String(x?.prompt ?? x?.description ?? "");
      const given = String(x?.title ?? "").trim();
      const title = given || firstLineTitle(prompt);
      return title ? [{ title, prompt, auto: !given }] : [];
    });
  }

  /** Make `subs` the tasks of batch `id` (a batch from here on), numbered in it (#84-1, #84-2…). */
  function addSubTasks(id, subs, source = { kind: "you" }) {
    const batch = store.get(id);
    store.mutate(id, () => ({ batch: true }));
    for (const x of subs) {
      const [sid] = store.create({ projectId: batch.projectId, title: x.title, prompt: x.prompt }, source, { inBatch: id });
      if (x.auto) autoTitled(sid);
    }
  }

  /** Task `id` took its description's first line as its title: a small model writes it a short one (titles.js). */
  function autoTitled(id) {
    store.mutate(id, () => ({ titleAuto: true }));
    void p.titles?.write(id);
  }

  /**
   * The When away toggle. On: the work waits for Away (a proposal that doesn't plan first waits in Ready; your
   * messages, answers, Approve and Land wait too, and yours already waiting for a slot move to Ready, a land that
   * hasn't begun too). Agents' messages go as ever. Off: a proposal goes back to Proposed; a started task's messages
   * that waited for Away go back, unsent, into its thread's text box (`unsent`, the claude plugin takes them);
   * answers, an Approve and a Land that waited are dropped (the thread still asks, the buttons are back).
   */
  function setAway(id, on) {
    const task = p.need(id);
    if (task.inBatch) throw new Error(`#${task.number} runs with its batch: set When away on the batch`);
    if (task.settledAt) throw new Error(`#${task.number} is settled`);
    if (on) {
      const landWaits = !task.landing && !p.busy?.has(id);
      const later = (m) =>
        task.threadId
          ? ((m.kind === "message" || m.kind === "answer") && m.by !== "agent") || (m.kind === "land" && landWaits)
          : m.kind === "launch" && !task.planning;
      store.mutate(id, (t) => {
        const move = (t.held ?? []).filter(later);
        const launchNow = !t.threadId && !t.plan && !t.planning && ![...(t.held ?? []), ...(t.parked ?? [])].some((m) => m.kind === "launch");
        if (!t.threadId && t.batch && !p.members(id).length && launchNow) throw new Error(`Batch #${t.number} has no tasks in it yet`);
        const parked = [...(t.parked ?? []), ...move, ...(launchNow ? [{ kind: "launch", at: now() }] : [])];
        const held = (t.held ?? []).filter((m) => !later(m));
        return { whenAway: true, parked: parked.length ? parked : undefined, held: held.length ? held : undefined, later: undefined, skipped: undefined };
      });
    } else {
      store.mutate(id, (t) => {
        if (!t.threadId) {
          const parked = (t.parked ?? []).filter((m) => m.kind !== "launch");
          return { whenAway: undefined, parked: parked.length ? parked : undefined };
        }
        const back = (t.parked ?? []).filter((m) => m.kind === "message" && !m.start).map(unsentText).filter(Boolean);
        const text = [t.unsent?.text, ...back].filter(Boolean).join("\n\n");
        for (const m of t.parked ?? []) if (m.attachments?.length) p.attachments.drop(m.attachments);
        return { whenAway: undefined, parked: undefined, ...(text ? { unsent: { text, at: now() } } : {}) };
      });
    }
    return done(id);
  }

  /** A message that waited for Away, as text for the thread's text box (its files by name: they don't come back). */
  const unsentText = (m) => {
    const files = (m.attachments ?? []).map((a) => a.name).filter(Boolean);
    return [m.said ?? m.text, files.length ? `(attach again: ${files.join(", ")})` : ""].filter(Boolean).join("\n");
  };

  /** The claude plugin put the unsent text back into the thread's text box. */
  function unsentTaken(id) {
    p.need(id);
    store.mutate(id, () => ({ unsent: undefined }));
    return done(id);
  }

  /**
   * The Plan toggle. On (a proposal): Run plans first; its work starts only with Approve. Off: Run does the work at
   * once; a planning thread becomes an ordinary task's thread (no plan reminder, no Approve).
   */
  function setPlan(id, on) {
    const task = p.need(id);
    if (task.inBatch) throw new Error(`#${task.number} runs with its batch: set Plan on the batch`);
    if (on) {
      if (task.threadId) throw new Error(`#${task.number} has started: tell its thread to plan instead`);
      if (task.held?.some((m) => m.kind === "launch")) throw new Error(`#${task.number} is starting: stop it first`);
      // Plan with When away: planning needs you, so it waits for Run, not for Away (it leaves Ready).
      store.mutate(id, (t) => {
        const parked = (t.parked ?? []).filter((m) => m.kind !== "launch");
        return { plan: true, parked: parked.length ? parked : undefined };
      });
    } else {
      // A planning launch still waiting for a slot goes too: Run starts it again, as ordinary work.
      store.mutate(id, (t) => {
        const held = t.threadId || !t.planning ? t.held : (t.held ?? []).filter((m) => m.kind !== "launch");
        return { plan: undefined, start: t.start === "plan" ? "either" : t.start, planning: undefined, held: held?.length ? held : undefined };
      });
      if (!task.threadId && task.whenAway && !task.planning) setAway(id, true);
    }
    return done(id);
  }

  function edit(id, given) {
    const task = p.need(id);
    const patch = planFromStart(given);
    // The store changes tasks in place: what it was before the toggles below.
    const wasPlanning = !!task.planning;
    // Older panels took Plan back on a planning thread with `start: either` (or manual).
    if (task.planning && patch.plan === undefined && patch.start !== undefined && patch.start !== "agents") patch.plan = false;
    // The toggles first: they may change a started task too.
    if (patch.plan !== undefined && !!patch.plan !== !!(task.plan || task.planning)) setPlan(id, !!patch.plan);
    if (patch.whenAway !== undefined && !!patch.whenAway !== !!task.whenAway) setAway(id, !!patch.whenAway);
    const allowed = ["title", "prompt", "projectId", "start", "size", "sizePct", "later", "hidden", "tested", "controversial", ...DRAFT_FIELDS.filter((k) => k !== "plan")];
    const changes = {};
    for (const key of allowed) if (patch[key] !== undefined) changes[key] = patch[key];
    delete changes.startAt;
    checkDraft(changes, task);
    if (batchStarted(task) && ["title", "prompt"].some((k) => changes[k] !== undefined && changes[k] !== task[k])) {
      throw new Error(`#${task.number} is in a batch that has started: it can't change now`);
    }
    if (task.threadId) {
      if (wasPlanning && changes.start !== "agents") delete changes.start;
      // The size stays changeable: it is only pacing's guess of what the task costs.
      for (const key of ["title", "prompt", "start", "model", "effort", "permissionMode", "noWorktree", "after"]) {
        if (key in changes && key !== "title") throw new Error(`#${task.number} has started: tell its thread instead`);
      }
    }
    // The user's (or an agent's) size replaces a guess; a size letter and an exact size replace each other.
    if (changes.sizePct !== undefined) {
      changes.sizePct = changes.sizePct === null ? undefined : Math.round(Number(changes.sizePct));
      changes.sizeBy = undefined;
      if (changes.sizePct) changes.size = undefined;
    } else if (changes.size) changes.sizePct = undefined;
    if (changes.size !== undefined) changes.sizeBy = undefined;
    if (changes.tested !== undefined) {
      if (!task.threadId) throw new Error(`#${task.number} hasn't run yet: nothing to test`);
      changes.tested = changes.tested ? new Date().toISOString() : undefined;
    }
    if (changes.controversial !== undefined) changes.controversial = changes.controversial ? new Date().toISOString() : undefined;
    // A title given by hand stays: no title is written over it any more.
    if (changes.title !== undefined) {
      if (!String(changes.title).trim()) throw new Error("A task needs a title");
      if (changes.title !== task.title) changes.titleAuto = undefined;
    }
    // Another project (only a proposal): out of its batch, and a chain link into the old project goes.
    const moves = changes.projectId !== undefined && changes.projectId !== task.projectId;
    if (moves && task.batch) throw new Error(`#${task.number} is a batch: it stays in its project`);
    if (moves && task.inBatch) Object.assign(changes, store.leaveBatch(task));
    if (moves && changes.after === undefined && task.after) changes.after = null;
    if (changes.after !== undefined) changes.after = changes.after === null ? undefined : store.idOf(changes.after);
    if (changes.attachments !== undefined) {
      if (task.threadId) throw new Error(`#${task.number} has started: send files with a message instead`);
      const next = changes.attachments?.length ? p.attachments.check(changes.attachments) : [];
      const kept = new Set(next.map((a) => a.id));
      p.attachments.drop((task.attachments ?? []).filter((a) => !kept.has(a.id)));
      changes.attachments = next.length ? next : undefined;
    }
    if (patch.addFrom?.length) {
      const had = [task.from, ...(task.alsoFrom ?? [])].filter(Boolean);
      const fresh = patch.addFrom.filter((l) => !had.includes(l));
      if (!task.from && fresh.length) changes.from = fresh.shift();
      if (fresh.length) changes.alsoFrom = [...(task.alsoFrom ?? []), ...fresh];
    }
    if (Object.keys(changes).length) store.mutate(id, () => changes);
    if (patch.startAt !== undefined) setStart(id, patch.startAt);
    // A new title from the small model, over whatever title it has now (the ⋯ menu's New title).
    if (patch.retitle) {
      if (!String(store.get(id).prompt ?? "").trim()) throw new Error(`#${task.number} has no description to name it from`);
      autoTitled(id);
    }
    if (patch.batch === true || patch.batch === "open" || patch.batch === "new" || typeof patch.batch === "number") {
      toBatch(id, patch.batch);
    }
    if ((patch.batch === false || patch.batch === null) && task.inBatch) toBatch(id, null);
    // Sub-tasks: a batch takes them as more tasks; a proposal becomes a batch with them (its own title and description
    // stay: the description goes to the worker as what the whole batch is about).
    const subs = subTasks(patch.tasks);
    if (subs.length) {
      const now = store.get(id);
      if (now.inBatch) throw new Error(`#${now.number} is in a batch: add the sub-tasks to the batch`);
      if (now.threadId || now.held?.some((m) => m.kind === "launch")) throw new Error(`#${now.number} has started: its tasks can't change now`);
      if (!now.batch && (now.noWorktree || now.after)) throw new Error(`#${now.number} can't have sub-tasks: a batch has its own worktree and no \`after\``);
      addSubTasks(id, subs);
    }
    return done(id);
  }

  /** A sub-task of a batch that has started can't change: the batch's thread works on it. */
  function batchStarted(task) {
    const batch = task.inBatch ? store.get(task.inBatch) : null;
    return !!batch && (!!batch.threadId || !!batch.held?.length);
  }

  function remove(id) {
    const task = p.need(id);
    if (task.threadId) throw new Error(`#${task.number} has a thread: Discard it instead (its worktree and branch go, its thread is archived)`);
    if (batchStarted(task)) throw new Error(`#${task.number} is in a batch that has started: it can't change now`);
    for (const [mid] of p.members(id)) store.mutate(mid, (m) => store.leaveBatch(m));
    store.remove(id);
    p.wake();
    return { deleted: task.number };
  }

  /**
   * Run a proposal now: it queues for a running slot. Plan on: it only plans now (it stays in Proposed until you
   * approve the plan), whatever When away says. A proposal waiting in Ready for Away goes now. While the user is
   * Away a run goes through Ready, so pacing decides when it starts. `away: true` (old callers' 🌙 Run when Away)
   * turns When away on instead. `by: "agent"` refuses what only the user may start. `now`: at the time the user chose
   * (Start at): it doesn't wait in Ready, Away or not.
   */
  function runTask(id, { by = "you", away = false, now: atOnce = false } = {}) {
    const task = p.need(id);
    if (task.threadId) throw new Error(`#${task.number} has started already`);
    if (task.held?.some((m) => m.kind === "launch")) throw new Error(`#${task.number} waits for a slot already`);
    if (task.inBatch) throw new Error(`#${task.number} is in batch #${store.get(task.inBatch)?.number}: run the batch`);
    if (task.batch && !p.members(id).length) throw new Error(`Batch #${task.number} has no tasks in it yet`);
    if (by === "agent" && task.start === "manual") throw new Error(`Only the user starts #${task.number}`);
    if (away) {
      if (task.whenAway) throw new Error(`#${task.number} waits for Away already`);
      return setAway(id, true);
    }
    const plans = !!task.plan;
    const launch = { kind: "launch", at: now() };
    const parked = (t) => (t.parked ?? []).filter((m) => m.kind !== "launch");
    const park = !plans && !atOnce && store.global().mode === "away" && !task.parked?.some((m) => m.kind === "launch");
    store.mutate(id, (t) => ({
      ...(park ? { parked: [...parked(t), launch] } : { held: [...(t.held ?? []), launch], parked: parked(t).length ? parked(t) : undefined }),
      planning: plans ? true : undefined,
      // Run now on a When away proposal is "now after all": the toggle goes off. Plan keeps it, for its Approve.
      ...(plans ? {} : { whenAway: undefined }),
      skipped: undefined,
      later: undefined,
      startAt: undefined,
    }));
    return done(id);
  }

  /**
   * A message to a started task's thread; it waits for a slot unless the turn runs (then it steers it). `attachments`:
   * staged file ids.
   */
  function message(id, text, { away, attachments, by = "you" } = {}) {
    const task = p.need(id);
    // When away holds back the work, never planning: answers to a plan go now (only its Approve waits).
    away = away ?? (by !== "agent" && !!task.whenAway && !task.planning);
    if (!task.threadId) throw new Error(`#${task.number} has no thread yet: run it, or edit its description`);
    const files = attachments?.length ? p.attachments.check(attachments) : [];
    if (!String(text ?? "").trim() && !files.length) throw new Error("The message is empty");
    const said = String(text ?? "").trim() || "(see the attached files)";
    // 🌙 on a planning task's answers means "do it while I'm away": they go as its approval (Start the work), not as
    // one more planning message that would end in a plan nobody approves until the user is back.
    const starts = away && task.planning && approvable(task);
    const m = {
      kind: "message",
      text: starts ? startText(said, true) : said,
      ...(starts ? { start: true, said } : {}),
      ...(by === "agent" ? { by } : {}),
      at: now(),
      ...(files.length ? { attachments: files } : {}),
    };
    if (away) store.mutate(id, (t) => ({ parked: [...(t.parked ?? []), m] }));
    // A message that failed goes again, first.
    else store.mutate(id, (t) => ({ held: [...retryFailed(t.held), m], settledAt: undefined, stopNote: undefined }));
    return done(id);
  }

  /** Answers to what its thread waits for (a question, a permission, a plan). */
  function answer(id, { requestId, answers, decision, message: note, away, by = "you" }) {
    const task = p.need(id);
    // When away holds back the work, never planning: answers to a plan go now (only its Approve waits).
    away = away ?? (by !== "agent" && !!task.whenAway && !task.planning);
    const pending = task.thread?.pending ?? [];
    const request = pending.find((a) => a.requestId === requestId);
    if (!request) throw new Error(`#${task.number} doesn't wait for ${requestId} (see task: pending)`);
    const choice = decision ?? (request.kind === "question" && !answers ? null : "allow");
    if (!choice) throw new Error("A question needs `answers`: { question text: label or [labels] }");
    const m = { kind: "answer", requestId, decision: choice, ...(by === "agent" ? { by } : {}), ...(answers ? { answers } : {}), ...(note ? { message: note } : {}), at: now() };
    if (away) store.mutate(id, (t) => ({ parked: [...(t.parked ?? []).filter((x) => x.requestId !== requestId), m] }));
    else store.mutate(id, (t) => ({ held: [...retryFailed(t.held), m] }));
    return done(id);
  }

  /** Interrupt its turn and drop what is held for it, and what waits for Away (a queued launch goes back to Proposed). */
  async function stop(id) {
    const task = p.need(id);
    releaseLane(p, id);
    store.mutate(id, (t) => ({
      held: undefined,
      parked: undefined,
      landing: undefined,
      resumeAt: undefined,
      wake: undefined,
      startAt: undefined,
      deliveryTries: undefined,
      retryNote: undefined,
      ...(t.landing ? { stopNote: "Landing stopped by you" } : {}),
      ...(t.verify && ["queued", "running"].includes(t.verify.state) ? { verify: { ...t.verify, state: "you", report: "Stopped by you" } } : {}),
      ...(t.planning && !t.threadId ? { planning: undefined } : {}),
    }));
    if (task.threadId && (isActive(task.thread) || waitsForAnswer(task.thread))) await p.claude.interrupt(task.threadId);
    if (task.verify?.state === "running" && task.verify.threadId) await p.claude.interrupt(task.verify.threadId).catch(() => {});
    return done(id);
  }

  /** Land it (`by`: an agent asked on the user's word). With When away on it waits for Away (p.holdLand). */
  function land(id, by) {
    const task = p.need(id);
    if (task.noWorktree) throw new Error(`#${task.number} works without a worktree: nothing to land`);
    if (!task.threadId) throw new Error(`#${task.number} hasn't run yet`);
    if (task.landed) throw new Error(`#${task.number} has landed already`);
    if (task.landing || landQueued(task)) throw new Error(`#${task.number} is landing already`);
    p.holdLand(id, by);
    if (!by) store.mutate(id, () => ({ landedFor: undefined }));
    return done(id);
  }

  /**
   * Agent lands: the task's own worker asks to land it when it is done. Nothing lands now: layr lands it once the
   * turn ends committed and clean with Status: done and no risky Risk, as the user's Land button does.
   */
  async function wantLand(id) {
    const task = p.need(id);
    if (!task.agentLands) throw new Error(`#${task.number}: the user hasn't let its agent land it (Agent lands is off)`);
    if (task.noWorktree) throw new Error(`#${task.number} works without a worktree: nothing to land`);
    if (task.landed) throw new Error(`#${task.number} has landed already`);
    if (task.landing || landQueued(task)) throw new Error(`#${task.number} is landing already`);
    // Its thread as it is now, so the turn this request belongs to is the one layr knows of.
    const s = await p.threadById(task.threadId).catch(() => undefined);
    if (s) await p.seeThread(id, s).catch(() => {});
    const at = nowIso();
    store.mutate(id, () => ({ landWanted: { at } }));
    return done(id);
  }

  function settle(id) {
    const task = p.need(id);
    if (task.settledAt) throw new Error(`#${task.number} is settled already`);
    if (task.inBatch) throw new Error(`#${task.number} settles with its batch`);
    const { column } = p.placement(id, task);
    if (column !== "stopped" && column !== "proposed") throw new Error(`#${task.number} is ${column}: stop it first`);
    p.settle(id);
    return done(id);
  }

  function unsettle(id) {
    const task = p.need(id);
    if (!task.settledAt) throw new Error(`#${task.number} isn't settled`);
    if (task.discarded) throw new Error(`#${task.number} was discarded`);
    // `unsettledAt`: a landed task you take back doesn't settle by itself again until it lands again.
    store.mutate(id, () => ({ settledAt: undefined, settledBy: undefined, unsettledAt: nowIso() }));
    return done(id);
  }

  async function discard(id) {
    p.need(id);
    await p.discard(id);
    return done(id);
  }

  /**
   * Approve (the only one): a planning task's Start the work, or "go ahead" for one that stopped with its work not
   * done. With When away on (or `away`), it waits in Ready for Away. While the user is Away it goes through Ready too,
   * so pacing decides when it starts. A planning task's Plan toggle goes off: its work has started.
   */
  function approve(id, { text, away, now: atOnce = false } = {}) {
    const task = p.need(id);
    away = !atOnce && (away || !!task.whenAway);
    if (!approvable(task)) throw new Error(`#${task.number} has nothing to approve now`);
    if (task.parked?.some((m) => m.start)) throw new Error(`#${task.number} is approved already: it waits in Ready`);
    const awayMode = !atOnce && store.global().mode === "away";
    const m = task.planning
      ? { kind: "message", text: startText(text, away || awayMode), start: true, at: now() }
      : { kind: "message", text: goAheadText(text, away || awayMode), start: true, at: now() };
    const park = away || awayMode;
    const unplan = task.planning ? { plan: undefined } : {};
    store.mutate(id, (t) => (park ? { parked: [...(t.parked ?? []), m], startAt: undefined, ...unplan } : { held: [...retryFailed(t.held), m], stopNote: undefined, startAt: undefined, ...unplan }));
    return done(id);
  }

  /**
   * The time the user chose for a task to start (`text`: "08:00", the next such time on the PC's clock, or a date and
   * time; empty or null takes it back) as an ISO time, or undefined for none. Only a task that can still start.
   */
  function checkStart(task, text) {
    if (text === null || text === false || !String(text).trim()) return undefined;
    if (task.settledAt) throw new Error(`#${task.number} is settled`);
    if (task.inBatch) throw new Error(`#${task.number} runs with its batch: set the time on the batch`);
    if (task.landed || task.landing) throw new Error(`#${task.number} has landed already`);
    if (task.held?.some((m) => m.kind === "launch")) throw new Error(`#${task.number} is starting already`);
    const at = parseBackAt(text);
    if (!at) throw new Error(`startAt: give a time like 08:00 (the next one), or a date and time later than now like 2026-12-01 08:00 (not "${text}")`);
    return at;
  }

  /** Set (or with an empty `text`, take back) the time task `id` starts at: see `startDue`. */
  function setStart(id, text) {
    const task = p.need(id);
    const at = checkStart(task, text);
    store.mutate(id, () => ({ startAt: at, ...(at ? { stopNote: undefined } : {}) }));
    if (at) p.wakeAt(at);
    return done(id);
  }

  /**
   * At the time chosen (`startAt`) the task starts, as if the user pressed its button then, but it doesn't wait for
   * Away: a proposal is run (with Plan on it plans), what waits in Ready goes, and a task whose worker stopped is
   * sent "go ahead" (a planning one "start the work"). The gate still decides when it reaches the thread (the running
   * slots, Soft stop, a usage limit). A task with nothing to start loses the time, with a note.
   */
  function startDue(id) {
    const task = p.need(id);
    store.mutate(id, () => ({ startAt: undefined }));
    const at = new Date(task.startAt);
    const clock = `${String(at.getHours()).padStart(2, "0")}:${String(at.getMinutes()).padStart(2, "0")}`;
    try {
      if (task.settledAt) return;
      if (task.parked?.some((m) => m.kind === "launch" || m.start)) {
        p.releaseParked(id);
        store.mutate(id, () => ({ whenAway: undefined }));
      } else if (!task.threadId) runTask(id, { by: "you", now: true });
      else if (approvable(task)) approve(id, { now: true });
      else throw new Error("nothing is waiting to be approved");
    } catch (error) {
      store.mutate(id, () => ({ stopNote: `The start time ${clock} came, but it didn't start: ${String(error.message ?? error).replace(/^#\S+ /, "")}` }));
    }
  }

  /** What waits for Away: send it now, drop it (a proposal goes back to Proposed), or keep waiting (after a turn asked again). */
  function parked(id, op) {
    const task = p.need(id);
    if (!task.parked?.length) throw new Error(`Nothing of #${task.number} waits for Away`);
    // Send now: you're here after all, so When away goes off.
    if (op === "send") {
      p.releaseParked(id);
      store.mutate(id, () => ({ whenAway: undefined }));
    }
    // A proposal's launch dropped is When away turned off: it is back in Proposed.
    else if (op === "drop") store.mutate(id, (t) => ({ parked: undefined, ...(t.threadId ? {} : { whenAway: undefined }) }));
    else if (op === "keep") store.mutate(id, (t) => ({ parked: t.parked.map((m) => ({ ...m, at: now() })) }));
    else throw new Error("op is send, drop or keep");
    return done(id);
  }

  /**
   * Out of its batch (`batch` null): a proposal of its own again, with the project's next number. Tasks don't go into a
   * batch any more: a sub-task is made in its batch (its Edit's Add sub-task, or create and propose with `batch`).
   */
  function toBatch(id, batch) {
    const task = p.need(id);
    if (batch !== null && batch !== undefined) {
      throw new Error(`#${task.number} can't go into a batch: sub-tasks are made in their batch (the batch's Edit, or create with \`batch\`)`);
    }
    if (!task.inBatch) throw new Error(`#${task.number} isn't in a batch`);
    const b = store.get(task.inBatch);
    if (b?.threadId || b?.held?.length) throw new Error("Its batch has started: it can't leave it now");
    store.mutate(id, (t) => store.leaveBatch(t));
    return done(id);
  }

  function reorder(ids) {
    ids.forEach((id, i) => store.mutate(String(id), () => ({ order: i })));
    p.wake();
    return { order: ids.map(Number) };
  }

  /** Add a claude thread to the board as a task. */
  async function adopt(threadId) {
    const existing = store.entries().find(([, t]) => t.threadId === threadId);
    if (existing) throw new Error(`That thread is task #${existing[1].number} already`);
    const s = (await p.claude.status(threadId)).thread;
    if (!s) throw new Error(`No thread ${threadId}`);
    const [id] = store.create(
      { projectId: s.projectId, title: s.title, prompt: s.preview ?? "" },
      { kind: "adopted" },
    );
    store.mutate(id, () => ({
      threadId,
      branch: s.workspace?.branch ?? null,
      worktreePath: s.workspace?.path ?? s.cwd,
      noWorktree: s.workspace?.kind === "project" || undefined,
    }));
    await p.seeThread(id, s);
    return done(id);
  }

  function release(id) {
    const task = p.need(id);
    if (!task.threadId) throw new Error(`#${task.number} has no thread: delete it instead`);
    if (task.landing || landQueued(task)) throw new Error(`#${task.number} is landing: stop it first`);
    for (const [mid] of p.members(id)) store.mutate(mid, (m) => store.leaveBatch(m));
    store.remove(id);
    p.wake();
    return { released: task.number };
  }

  p.startDue = startDue;
  return { create, edit, setStart, startDue, setAway, setPlan, unsentTaken, remove, run: runTask, message, answer, stop, land, wantLand, settle, unsettle, discard, approve, parked, toBatch, reorder, adopt, release, heldWaiting };
}
