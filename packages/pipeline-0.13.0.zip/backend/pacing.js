// Pacing: a guess of what every task costs, and whether the work waiting for Away fits in what the Claude accounts
// have left (layr_code's usage forecast, back in a simpler form).
//
// Units. Costs and room are in *points*: percent of one Pro 5-hour window (a Max 5x window is 500 points, as the
// accounts plugin weighs plans). Panels show them as percent of the active account's 5-hour window.
//
// What a task costs is learned from what tasks really spent. The claude plugin counts each thread's spend
// (`costUsd`, the API price of its tokens); `pointsPerUsd` turns dollars into points, measured from the active
// account's readings against what all Claude threads spent between them (Claude Code used outside layr makes it
// read a little high: on the safe side). A size's cost is the median of the latest landed tasks of that size, once
// there are MIN_SAMPLES; until then layr_code's defaults (SIZE_COST). A task without a size gets a guess from a small
// model (`guessSizes`; a size an earlier refiner stored still counts), and the user's own replaces it.
//
// Room comes from the accounts plugin (every account, plan-weighted, below its own switch points) or, without it,
// the claude plugin's reading of the active account. The weekly window counts too: while Away, at most a fair share
// of what is left of the week (what is left divided by the days until it resets) goes in one night. A reserve of the
// active account's 5-hour window (`pacingReserve`) is kept for the user's own chats.
//
// What it does: in Away, Ready is released in its order only while it fits the room there is now (less what running
// work still needs); the rest waits for a window to reset. Without readings nothing is held back.
import { parksOnlyLand } from "./columns.js";
import { errorText, nowIso, snippet } from "./util.js";
import { byNumber } from "./store.js";

/** A task's cost by size in points, until layr has measured enough tasks of that size (layr_code's defaults). */
export const SIZE_COST = { S: 10, M: 30, L: 60 };
export const MIN_SAMPLES = 3;
/** Only the latest this many landed tasks of a size count: how tasks are written changes. */
export const RECENT = 10;
/** Points per dollar of spend until measured: one Pro 5-hour window ≈ $15 of API-priced tokens (a guess). */
export const DEFAULT_POINTS_PER_USD = 100 / 15;
/** Weekly percent per 5-hour percent until measured: a week ≈ ten 5-hour windows (a guess). */
export const DEFAULT_WEEK_PER_FIVE = 0.1;
/** How often the accounts are read. */
export const READ_MS = 5 * 60_000;
/** A measurement needs at least this much spend and 5-hour growth between two readings, or it waits for more. */
const CAL_MIN_USD = 1;
const CAL_MIN_PCT = 3;
/** How much one new measurement moves the ratio. */
const CAL_WEIGHT = 0.3;
const FIVE_HOURS = 5 * 3_600_000;
const DAY = 86_400_000;
const SIZE_PROMPT_MAX = 3000;

/** The exact sizes: percent of the active account's 5-hour window (`task.sizePct`). */
export const SIZE_PCT_MAX = 500;
/** The size letter an exact size counts as when sizes are learned: below 20% S, below 45% M, else L. */
const letterOf = (pct) => (pct < 20 ? "S" : pct < 45 ? "M" : "L");

export const sizeOf = (t) => (t?.sizePct ? letterOf(t.sizePct) : (t?.size ?? t?.preflight?.size ?? "M"));

/** A task's whole size in points: its exact percent of the active account's window (`weight`), else its size's cost. */
export const sizeCost = (task, costs, weight = 1) => (task?.sizePct ? task.sizePct * weight : costs[sizeOf(task)]);
const round = (n) => Math.round(n * 10) / 10;

export function median(xs) {
  const s = [...xs].sort((a, b) => a - b);
  if (!s.length) return null;
  const mid = s.length / 2;
  return s.length % 2 ? s[Math.floor(mid)] : (s[mid - 1] + s[mid]) / 2;
}

/**
 * Each size's cost in points: the median of the latest landed tasks of that size (oldest first), once there are
 * enough, else the default. `finished`: [{size, spentUsd}].
 */
export function sizeCosts(finished, pointsPerUsd = DEFAULT_POINTS_PER_USD) {
  const costs = { ...SIZE_COST };
  for (const size of Object.keys(SIZE_COST)) {
    const spent = finished.filter((t) => sizeOf(t) === size && (t.spentUsd ?? 0) > 0).slice(-RECENT).map((t) => t.spentUsd * pointsPerUsd);
    if (spent.length >= MIN_SAMPLES) costs[size] = round(median(spent));
  }
  return costs;
}

/** What a task still needs: its size's cost less what it spent so far (never below nothing). */
export const stillNeeds = (task, costs, pointsPerUsd = DEFAULT_POINTS_PER_USD, weight = 1) =>
  Math.max(0, sizeCost(task, costs, weight) - (task.spentUsd ?? 0) * pointsPerUsd);

/** A new turn of a started task: what it still needs, but at least half an S (a turn past the estimate costs too). */
export const turnCost = (task, costs, pointsPerUsd = DEFAULT_POINTS_PER_USD, weight = 1) =>
  Math.max(stillNeeds(task, costs, pointsPerUsd, weight), costs.S / 2);

/**
 * The accounts as pacing reads them: [{email, active, weight, five: {pct, resetsAt}|null, week, fiveAt, weekAt,
 * measuredAt}]. From the accounts plugin's `usage` (all accounts that work and auto-switch may use, and the active
 * one), else the claude plugin's reading of the active account (weight 1, switch points at 100).
 */
export function accountsFrom({ overview, reading }) {
  if (overview?.accounts?.length) {
    const points = overview.switchPoints ?? {};
    return overview.accounts
      .filter((a) => a.state === "ok" && (a.active || (a.enabled && overview.autoSwitch !== false)))
      .filter((a) => a.fiveHour || a.weekly)
      .map((a) => ({
        email: a.email ?? null,
        active: !!a.active,
        weight: a.weight ?? 1,
        five: a.fiveHour,
        week: a.weekly,
        fiveAt: points.fiveHour ?? 100,
        weekAt: points.weekly ?? 100,
        measuredAt: a.measuredAt ?? null,
      }));
  }
  if (reading && (reading.fiveHour || reading.weekly)) {
    return [{ email: reading.account, active: true, weight: 1, five: reading.fiveHour, week: reading.weekly, fiveAt: 100, weekAt: 100, measuredAt: reading.at }];
  }
  return [];
}

const pctOf = (w, now) => (!w || w.pct === null || w.pct === undefined ? 0 : w.resetsAt && Date.parse(w.resetsAt) <= now ? 0 : Number(w.pct));
const resetOf = (w, now) => (w?.resetsAt && Date.parse(w.resetsAt) > now ? Date.parse(w.resetsAt) : null);

/**
 * One account's room in points before `until` (now: only what is left of its windows). Its 5-hour room (and a full
 * window after each reset before `until`), held to its weekly room in 5-hour terms; while Away (`awayStart`: its
 * weekly percent then, and when), the weekly room is at most the night's fair share less what the night used.
 */
export function accountRoom(a, { now = Date.now(), until = now, weekPerFive = DEFAULT_WEEK_PER_FIVE, awayStart = null } = {}) {
  const fivePct = pctOf(a.five, now);
  let five = Math.max(0, a.fiveAt - fivePct);
  const reset = resetOf(a.five, now) ?? (fivePct > 0 ? null : now + FIVE_HOURS);
  if (reset !== null && until > reset) five += Math.ceil((until - reset) / FIVE_HOURS) * a.fiveAt;
  let week = Infinity;
  if (a.week) {
    const weekPct = pctOf(a.week, now);
    week = Math.max(0, a.weekAt - weekPct);
    if (awayStart && awayStart.week !== undefined && awayStart.week !== null) {
      const weekReset = resetOf(a.week, Date.parse(awayStart.at)) ?? resetOf(a.week, now);
      const days = weekReset ? Math.max(1, (weekReset - Date.parse(awayStart.at)) / DAY) : 7;
      const share = Math.max(0, a.weekAt - awayStart.week) / days;
      week = Math.min(week, Math.max(0, share - Math.max(0, weekPct - awayStart.week)));
    }
  }
  const weekInFive = week === Infinity ? Infinity : week / Math.max(weekPerFive, 1e-6);
  return Math.min(five, weekInFive) * (a.weight ?? 1);
}

/** All accounts' room in points before `until`, less the reserve (percent of the active account's 5-hour window). */
export function roomOf(accounts, { reserve = 0, ...opts } = {}) {
  if (!accounts.length) return null;
  let sum = 0;
  for (const a of accounts) sum += accountRoom(a, { ...opts, awayStart: opts.awayStarts?.[a.email] ?? null });
  const active = accounts.find((a) => a.active) ?? accounts[0];
  return Math.max(0, sum - reserve * (active.weight ?? 1));
}

/**
 * Which parked tasks go now: in order, each while its cost fits what is left of `budget`; when nothing runs at all
 * and there is any room, the first one goes anyway (a task bigger than the room would wait forever otherwise).
 * `items`: [{id, cost}]. Gives {go: [ids], held: [{id, cost, left}]}.
 */
export function release(items, budget, { idle = false } = {}) {
  const go = [];
  const held = [];
  let left = budget;
  for (const item of items) {
    if (item.cost <= left || (idle && !go.length && left > 0)) {
      go.push(item.id);
      left -= item.cost;
    } else held.push({ ...item, left: Math.max(0, left) });
  }
  return { go, held };
}

/** "08:00" or an ISO time → when the user is back (ISO), the next such time on the PC's clock; null when unreadable. */
export function parseBackAt(text, now = Date.now()) {
  const s = String(text ?? "").trim();
  if (!s) return null;
  const hm = /^(\d{1,2})(?::(\d{2}))?$/.exec(s);
  if (hm) {
    const hour = Number(hm[1]);
    const minute = Number(hm[2] ?? 0);
    if (hour > 23 || minute > 59) return null;
    const at = new Date(now);
    at.setSeconds(0, 0);
    at.setHours(hour, minute);
    if (at.getTime() <= now) at.setDate(at.getDate() + 1);
    return at.toISOString();
  }
  const t = Date.parse(s);
  return Number.isNaN(t) || t <= now ? null : new Date(t).toISOString();
}

/** A small model's answer to "how much of a 5-hour window" → a whole percent (1 to SIZE_PCT_MAX), or null. */
export function pctFromAnswer(text) {
  const m = /(\d+(?:[.,]\d+)?)\s*%?/.exec(String(text ?? ""));
  const n = m ? Math.round(Number(m[1].replace(",", "."))) : NaN;
  return n >= 1 && n <= SIZE_PCT_MAX ? n : null;
}

/** A small model's answer to "how big is it" → S, M or L, or null. */
export function sizeFromAnswer(text) {
  const m = /\b([SML])\b/.exec(String(text ?? "").trim().toUpperCase());
  return m ? m[1] : null;
}

/** `anchors`: what S, M and L cost now, in percent of a 5-hour window (measured, else the defaults). */
export function sizePrompt(task, anchors = { S: SIZE_COST.S, M: SIZE_COST.M, L: SIZE_COST.L }) {
  return [
    "Guess how much of a Claude account's 5-hour usage window this coding task costs a Claude Code agent working " +
      "alone in a git worktree, in whole percent.",
    `A small fix or tweak, one to a few files: about ${anchors.S}%. A feature or a change across several files: ` +
      `about ${anchors.M}%. Many files, a large change, or research and then work: about ${anchors.L}% or more.`,
    "Be exact for this task, not one of those three. Answer with the number only, e.g. 18.",
    "",
    `Title: ${task.title}`,
    "",
    String(task.prompt ?? "").slice(0, SIZE_PROMPT_MAX),
  ].join("\n");
}

const clock = (iso) => {
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
};

/** Pacing on the PC. `p`: the pipeline. */
export function createPacing(p) {
  const { store } = p;
  let overview = null;
  let readAt = 0;
  let nextRoom = null;
  /** Ready tasks pacing held back on the last look: id → why. */
  let holds = new Map();
  /** What each thread had spent when last seen (for the spend counter). */
  const seenCost = new Map();
  /** What tasks had spent at the last reading: spend since then isn't in the readings yet. */
  let spentAtRead = null;
  const taskSpend = () => store.entries().reduce((sum, [, t]) => sum + (t.spentUsd ?? 0), 0);

  const cal = () => store.crew("pacing", {});
  const saveCal = (patch) => store.setCrew("pacing", { ...cal(), ...patch });
  const on = () => store.global().pacing !== false;
  const calibrated = () => (cal().pointsPerUsd?.n ?? 0) > 0;
  const pointsPerUsd = () => (calibrated() ? cal().pointsPerUsd.value : DEFAULT_POINTS_PER_USD);
  const weekPerFive = () => (cal().weekPerFive?.n ? cal().weekPerFive.value : DEFAULT_WEEK_PER_FIVE);

  function accounts() {
    return accountsFrom({ overview, reading: p.limits.reading() });
  }

  function activeWeight() {
    const list = accounts();
    return (list.find((a) => a.active) ?? list[0])?.weight ?? 1;
  }

  /** Landed tasks with what they spent, oldest first. */
  function finished() {
    return store
      .entries()
      .map(([, t]) => t)
      .filter((t) => t.landed && (t.spentUsd ?? 0) > 0 && !t.batch)
      .sort((a, b) => Date.parse(a.landed.at ?? 0) - Date.parse(b.landed.at ?? 0));
  }

  // Each view asks for the costs: worked out at most once a second.
  let costMemo = { at: 0, value: null };
  function costs() {
    // Until a dollar's worth is measured, what tasks spent says nothing about the window: the defaults hold.
    const learned = calibrated() ? finished() : [];
    if (!costMemo.value || Date.now() - costMemo.at > 1000) costMemo = { at: Date.now(), value: sizeCosts(learned, pointsPerUsd()) };
    return costMemo.value;
  }

  /** A task's cost in points from here: a proposal's whole size, a started task's next turn. */
  function costOf(task, c = costs()) {
    // A land needs no turn: it never waits for room.
    if (parksOnlyLand(task)) return 0;
    return task.threadId ? turnCost(task, c, pointsPerUsd(), activeWeight()) : sizeCost(task, c, activeWeight());
  }

  /** The spend counter: dollars all Claude threads spent, added up from what thread_list shows. */
  async function spendCounter() {
    const list = await p.claude.list();
    let added = 0;
    for (const t of list) {
      const cost = Number(t.costUsd ?? 0);
      const before = seenCost.get(t.id);
      if (before !== undefined && cost > before) added += cost - before;
      seenCost.set(t.id, cost);
    }
    const total = (cal().spent ?? 0) + added;
    if (added) saveCal({ spent: total });
    return total;
  }

  /** One new reading of the active account against the spend counter: measure the two ratios when there is enough. */
  function calibrate(active, spent) {
    if (!active?.five) return;
    const now = Date.now();
    const cur = {
      email: active.email,
      five: pctOf(active.five, now),
      fiveReset: active.five.resetsAt ?? null,
      week: active.week ? pctOf(active.week, now) : null,
      weekReset: active.week?.resetsAt ?? null,
      spent,
      at: active.measuredAt ?? nowIso(),
      weight: active.weight ?? 1,
    };
    const last = cal().last;
    const sameWindow = (a, b) => !!a && !!b && Math.abs(Date.parse(a) - Date.parse(b)) < 120_000;
    if (!last || last.email !== cur.email || !sameWindow(last.fiveReset, cur.fiveReset) || cur.five < last.five || cur.spent < last.spent) {
      saveCal({ last: cur });
      return;
    }
    if (Date.parse(cur.at) <= Date.parse(last.at)) return;
    const dFive = cur.five - last.five;
    const dUsd = cur.spent - last.spent;
    if (dFive < CAL_MIN_PCT || dUsd < CAL_MIN_USD) return;
    const ema = (old, sample) => (old?.n ? { value: old.value * (1 - CAL_WEIGHT) + sample * CAL_WEIGHT, n: old.n + 1 } : { value: sample, n: 1 });
    const patch = { last: cur, pointsPerUsd: ema(cal().pointsPerUsd, (dFive * cur.weight) / dUsd), measuredAt: nowIso() };
    if (cur.week !== null && last.week !== null && sameWindow(last.weekReset, cur.weekReset) && cur.week >= last.week) {
      patch.weekPerFive = ema(cal().weekPerFive, (cur.week - last.week) / dFive);
    }
    saveCal(patch);
  }

  /** Read the accounts (every READ_MS unless `force`), the spend, and measure. */
  async function read(force = false) {
    if (!force && Date.now() - readAt < READ_MS) return;
    readAt = Date.now();
    spentAtRead = taskSpend();
    if (p.hub.available && p.hub.call) {
      overview = await p.hub.call("accounts__usage", {}).catch(() => null);
    }
    if (!overview?.accounts?.length) await p.limits.read(force);
    const spent = await spendCounter().catch((error) => (p.log("pacing: thread spend:", errorText(error)), null));
    if (spent !== null) calibrate(accounts().find((a) => a.active), spent);
    fillAwayStart();
    nextRoom = null;
    if (p.hub.available && p.hub.call && (holds.size || store.state().limitUntil)) {
      nextRoom = (await p.hub.call("accounts__next_room", {}).catch(() => null))?.next ?? null;
    }
  }

  /** The crew's look: read now and then while there is work or Away; guess sizes. */
  async function tick({ busy }) {
    if (!on()) return;
    if (busy || store.global().mode === "away" || store.entries().some(([, t]) => t.parked?.length)) await read();
    p.job("sizing", () => guessSizes());
  }

  /** A small model guesses the size of tasks nobody sized, in exact percent (one try each). */
  async function guessSizes(limit = 3) {
    if (!on()) return;
    const due = store
      .entries()
      .filter(([, t]) => !t.size && !t.sizePct && !t.preflight?.size && !t.sizeTried && !t.settledAt && !t.batch && !t.inBatch)
      .slice(0, limit);
    for (const [id, t] of due) {
      store.mutate(id, () => ({ sizeTried: nowIso() }));
      try {
        const c = costs();
        const w = activeWeight();
        const anchors = Object.fromEntries(Object.entries(c).map(([k, v]) => [k, Math.round(v / w)]));
        const answer = await p.claude.ask({ prompt: sizePrompt(t, anchors), model: store.global().briefModel || "haiku" });
        // A number is the exact size; an answer in the old way (a letter) still counts.
        const sizePct = pctFromAnswer(answer?.text);
        const size = sizePct ? null : sizeFromAnswer(answer?.text);
        const now = store.get(id);
        if (now && !now.size && !now.sizePct) {
          if (sizePct) store.mutate(id, () => ({ sizePct, sizeBy: "guess" }));
          else if (size) store.mutate(id, () => ({ size, sizeBy: "guess" }));
        }
      } catch (error) {
        p.log(`pacing: sizing #${id}:`, snippet(errorText(error), 200));
      }
    }
  }

  /** Room in points now (`until` later: with the windows that reset before it), less tasks' spend since the reading. */
  function room(until = Date.now()) {
    const state = store.state();
    const since = spentAtRead === null ? 0 : Math.max(0, taskSpend() - spentAtRead) * pointsPerUsd();
    const r = roomOf(accounts(), {
      now: Date.now(),
      until,
      weekPerFive: weekPerFive(),
      reserve: store.global().pacingReserve ?? 0,
      awayStarts: store.global().mode === "away" ? state.awayStart?.accounts ?? null : null,
    });
    return r === null ? null : Math.max(0, r - since);
  }

  /** What running work still needs: tasks whose turn runs or that hold messages for a slot. */
  function runningNeeds(c = costs()) {
    let sum = 0;
    let count = 0;
    for (const [id, t] of store.entries()) {
      if (t.settledAt || t.inBatch) continue;
      const runs = p.busy.has(id) || ["running", "starting", "queued", "limit", "landing", "verifying"].includes(p.placement(id, t).why);
      if (!runs) continue;
      sum += t.threadId ? stillNeeds(t, c, pointsPerUsd(), activeWeight()) : sizeCost(t, c, activeWeight());
      count++;
    }
    return { sum, count };
  }

  /** Ready tasks (in their order) that Away would release: [[id, task]]. One with a start time waits for it. */
  function readyQueue() {
    return store
      .entries()
      .filter(([id, t]) => t.parked?.length && !t.settledAt && !(t.startAt && Date.parse(t.startAt) > Date.now()) && p.placement(id, t).why === "ready")
      .sort(([, a], [, b]) => (a.order ?? 0) - (b.order ?? 0) || byNumber(a.number, b.number));
  }

  /** Away: which Ready tasks go now. Without readings (or pacing off) all of them. */
  function releasable() {
    const queue = readyQueue();
    const now = room();
    if (!on() || now === null) {
      holds = new Map();
      return queue.map(([id]) => id);
    }
    const c = costs();
    const running = runningNeeds(c);
    const { go, held } = release(queue.map(([id, t]) => ({ id, cost: costOf(t, c) })), now - running.sum, { idle: running.count === 0 });
    const w = activeWeight();
    const pct = (points) => Math.round(points / w);
    const resets = nextReset();
    const after = nextRoom?.at && Date.parse(nextRoom.at) > Date.now() ? `another account has room at ${clock(nextRoom.at)}` : resets ? `a window resets at ${clock(resets)}` : "";
    holds = new Map(held.map((h) => [h.id, `waits for room: needs ~${pct(h.cost)}%, ~${pct(h.left)}% free${after ? `; ${after}` : ""}`]));
    return go;
  }

  /** The soonest 5-hour reset among the accounts (ISO), or null. */
  function nextReset() {
    const now = Date.now();
    const times = accounts().map((a) => resetOf(a.five, now)).filter(Boolean);
    return times.length ? new Date(Math.min(...times)).toISOString() : null;
  }

  /** When the user is back: the Away's own time, else `awayHours` from now. */
  function backAt() {
    const until = store.state().awayUntil;
    if (until && Date.parse(until) > Date.now()) return until;
    return new Date(Date.now() + (store.global().awayHours ?? 8) * 3_600_000).toISOString();
  }

  /** Away begins: the weekly percent of each account now, for the night's fair share. */
  function awayBegins(until) {
    const list = accounts();
    store.setState({
      awayUntil: until ?? undefined,
      awayStart: { at: nowIso(), accounts: Object.fromEntries(list.map((a) => [a.email, { at: nowIso(), week: a.week ? pctOf(a.week, Date.now()) : null }])) },
    });
  }

  function awayEnds() {
    holds = new Map();
    store.setState({ awayUntil: undefined, awayStart: undefined });
  }

  /** An account read for the first time since Away began (layr restarted, not read yet): its share starts now. */
  function fillAwayStart() {
    const start = store.state().awayStart;
    if (store.global().mode !== "away" || !start) return;
    const missing = accounts().filter((a) => !(a.email in (start.accounts ?? {})));
    if (!missing.length) return;
    const add = Object.fromEntries(missing.map((a) => [a.email, { at: nowIso(), week: a.week ? pctOf(a.week, Date.now()) : null }]));
    store.setState({ awayStart: { ...start, accounts: { ...(start.accounts ?? {}), ...add } } });
  }

  /** A task's guess for the panels: {size, by, pct (still needed, of the active 5-hour window), spentPct}. */
  function estimate(task, c = costs()) {
    if (!on()) return null;
    const w = activeWeight();
    const by = task.size || task.sizePct ? (task.sizeBy ?? "you") : task.preflight?.size ? "refiner" : "default";
    const spent = calibrated() ? (task.spentUsd ?? 0) * pointsPerUsd() : 0;
    const need = task.settledAt || task.landed ? 0 : task.threadId ? stillNeeds(task, c, pointsPerUsd(), w) : sizeCost(task, c, w);
    return { size: sizeOf(task), ...(task.sizePct ? { exact: task.sizePct } : {}), by, pct: Math.round(need / w), ...(spent ? { spentPct: Math.round(spent / w) } : {}) };
  }

  /** The Ready column's line and what agents see: does Ready fit before the user is back? */
  function summary() {
    if (!on()) return { on: false };
    const list = accounts();
    const c = costs();
    const w = activeWeight();
    const pct = (points) => (points === null ? null : Math.round(points / w));
    const queue = readyQueue();
    const needs = queue.map(([, t]) => costOf(t, c));
    const running = runningNeeds(c);
    const until = backAt();
    const later = room(Date.parse(until));
    let fits = 0;
    if (later !== null) {
      let left = later - running.sum;
      for (const n of needs) {
        if (n > left) break;
        left -= n;
        fits++;
      }
    }
    const readyPct = pct(needs.reduce((a, b) => a + b, 0));
    const known = list.length > 0;
    const line = !queue.length
      ? null
      : !known
        ? `Ready ${queue.length} ≈ ${readyPct}% of a 5-hour window · room not measured yet`
        : `Ready ${queue.length} ≈ ${readyPct}% · room until ${clock(until)} ≈ ${pct(Math.max(0, later - running.sum))}% · ${fits === queue.length ? "fits ✓" : `fits ${fits} of ${queue.length}`}`;
    return {
      on: true,
      known,
      unit: "percent of the active account's 5-hour window",
      sizes: Object.fromEntries(Object.entries(c).map(([k, v]) => [k, pct(v)])),
      measured: { tasks: finished().length, ratio: cal().pointsPerUsd?.n ?? 0 },
      ready: queue.length,
      readyPct,
      runningPct: pct(running.sum),
      roomNowPct: pct(room()),
      until,
      roomUntilPct: later === null ? null : pct(later),
      fits,
      ok: !known || fits === queue.length,
      nextRoom: nextRoom?.at ? { at: nextRoom.at } : null,
      nextReset: nextReset(),
      line,
    };
  }

  /** The thread's spend, kept on the task (the claude plugin's `costUsd`). */
  function spent(id, s) {
    const cost = Number(s?.costUsd ?? 0);
    if (!cost) return;
    const task = store.get(id);
    if (task && Math.abs((task.spentUsd ?? 0) - cost) >= 0.005) store.mutate(id, () => ({ spentUsd: Math.round(cost * 1000) / 1000 }));
  }

  return {
    read,
    tick,
    guessSizes,
    releasable,
    hold: (id) => holds.get(id) ?? null,
    estimate,
    costs,
    summary,
    spent,
    awayBegins,
    awayEnds,
    backAt,
    room,
    accounts,
  };
}
