// The pipeline: the board's tasks, the scheduler loop and every action on a task.
//
// A task is a Claude thread (the claude plugin) in its own worktree. layr holds what has no thread yet (Proposed),
// decides when a message may reach a thread (the gate: the running cap, the mode, a usage limit), watches turns end
// (it hears the claude plugin's thread events, with a slow look at thread_list as a fallback; without events,
// thread_wait per running thread and a look every few seconds), and lands finished work.
// Everything about a thread is read from the claude plugin; `task.thread` is layr's copy for the board.
// The crew (background jobs) hangs off the same loop: wake-ups and the test lane (lane.js), usage limits (limits.js),
// pacing (pacing.js: what each task costs, and how much of Ready Away lets go), briefs (briefs.js), scouts (scouts.js), Keep up to date (updater.js) and the orchestrator (orchestrator.js);
// attachments go with launches and messages (attachments.js); ▶ Try and Open in… open windows on the PC (tryit.js).
// The concept map (concepts.js), when the concepts plugin is there: the project node in launch messages, tasks linked
// to their nodes and those nodes' Status following them. The PC stays awake while work runs (keepAwake.js).
import { existsSync } from "node:fs";
import { createAttachments } from "./attachments.js";
import { createBriefs, stakesOf } from "./briefs.js";
import { createTitles } from "./titles.js";
import { noteOf, taskButtons, taskToggles } from "./buttons.js";
import { createConcepts } from "./concepts.js";
import { createKeepAwake } from "./keepAwake.js";
import { dueWakes, freeLanes, laneOf, releaseLane, waitsForLane } from "./lane.js";
import { createLimits } from "./limits.js";
import { createOrchestrator } from "./orchestrator.js";
import { createPacing } from "./pacing.js";
import { createScouts } from "./scouts.js";
import { byNumber } from "./store.js";
import { hasLane, workerSettings } from "./settings.js";
import { createWindows } from "./tryit.js";
import { createUpdater } from "./updater.js";
import { createWorktrees } from "./worktrees.js";
import { approvable, heldWaiting, inBackground, isActive, isStarting, landQueued, placeTask, usesSlot, waitsForAnswer, WHY_LABEL } from "./columns.js";
import {
  branchExists,
  changedFiles,
  commitsAhead,
  currentBranch,
  deleteBranch,
  fetchBase,
  headOf,
  removeWorktree,
  revParse,
  samePath,
  uncommitted,
  worktreeOf,
} from "./git.js";
import { createLander } from "./land.js";
import {
  baseRef,
  continueMessage,
  goAheadText,
  launchMessage,
  PLAN_REMINDER,
  remoteLanding,
  reverifyMessage,
  startText,
  verifierMessage,
  verifyFixesMessage,
  VERIFY_ROUNDS,
} from "./prompts.js";
import { askPathHits, ASK_RISKS, batchReport, LAND_RISKS, classifyError, replyStatus, verdictOf } from "./report.js";
import { errorText, log, nowIso, slugify, snippet } from "./util.js";

const MAX_RESUMES = 5;
/** A launch or message the claude plugin couldn't take (network, not running): tried again this much later… */
export const DELIVERY_RETRY_MS = 5 * 60_000;
/** …at most this many times (an hour), then it is dropped with a note. */
const DELIVERY_TRIES = 12;
/** "While away" shows on the board this long after an Away period ends. */
export const AWAY_REPORT_MS = 18 * 3_600_000;
const MISPLACED_NOTE =
  "Its thread would have worked in the project's own checkout, not a worktree of its own, so layr stopped it. Look " +
  "at the project's folder for anything it changed, then Run it again";
const WAIT_SEC = 300;
/** The claude plugin's topics that say a thread changed (docs/ARCHITECTURE.md › The claude plugin). */
export const THREAD_TOPICS = ["claude:threads", "claude:approval"];
/** While thread events come, the look at the threads when nothing happens is at least this far apart. */
export const EVENT_POLL_SEC = 30;
const CLEANUP_MS = 10 * 60_000;
/** Tasks without a worktree: their checkout is looked at this often until they are settled (and after each turn). */
export const CHECKOUT_MS = 60_000;
const REPLY_MAX = 20_000;
const CHECKOUT_FILES = 20;

export class Pipeline {
  constructor({ store, claude, hub, logger = log, dataDir = store.dir }) {
    this.store = store;
    this.claude = claude;
    this.hub = hub;
    this.log = logger;
    /** Tasks whose held message is being sent right now. */
    this.busy = new Set();
    /** Threads with a thread_wait out (only while thread events don't come). */
    this.watching = new Set();
    /** The hub sends the claude plugin's thread events (layr__events_subscribe worked). */
    this.eventsLive = false;
    this.projectsCache = [];
    this.timer = null;
    this.ticking = null;
    this.again = false;
    this.stopped = false;
    this.lastCleanup = 0;
    this.lastError = null;
    this.lander = createLander(this);
    this.emitTimer = null;
    this.attachments = createAttachments(dataDir);
    this.limits = createLimits(this);
    this.pacing = createPacing(this);
    this.briefs = createBriefs(this);
    this.titles = createTitles(this);
    this.scouts = createScouts(this);
    this.updater = createUpdater(this);
    this.worktrees = createWorktrees(this);
    this.windows = createWindows(this, dataDir);
    this.orchestrator = createOrchestrator(this, this.scouts, { dataDir });
    /** Background jobs running now (each at most once at a time). */
    this.jobs = new Set();
    this.wakeTimer = null;
    this.lastCheckouts = 0;
    this.concepts = createConcepts(this);
    this.keepAwake = createKeepAwake(this);
    store.onChange = () => this.emitChanged();
    store.onTaskChange = (id, before, after) => this.concepts.changed(id, before, after);
  }

  // ---------------------------------------------------------------- loop

  start() {
    this.stopped = false;
    // An After landing command can't still run after a restart: it ended with the old process.
    for (const [id, t] of this.store.entries()) {
      if (t.afterLanding?.state !== "running" || this.lander.afterLandingRuns(id)) continue;
      this.store.mutate(id, () => ({
        afterLanding: { state: "failed", at: nowIso(), output: "layr restarted while it ran" },
        stopNote: "After landing didn't finish: layr restarted while it ran",
      }));
    }
    this.wake();
  }

  stop() {
    this.stopped = true;
    clearTimeout(this.timer);
    clearTimeout(this.wakeTimer);
    this.keepAwake.set(false);
  }

  /** Look at `iso` (a wake-up's time) even if nothing else wakes the loop then (at most a day ahead). */
  wakeAt(iso) {
    const ms = Math.min(Math.max(0, Date.parse(iso) - Date.now()) + 500, 86_400_000);
    clearTimeout(this.wakeTimer);
    this.wakeTimer = setTimeout(() => this.wake(), ms);
    this.wakeTimer.unref?.();
  }

  /** Tasks whose start time (Start at) has come start now: `startDue` is the actions' (createActions sets it). */
  dueStarts(now = Date.now()) {
    for (const [id, task] of this.store.entries()) {
      if (task.startAt && Date.parse(task.startAt) <= now) this.startDue?.(id);
    }
  }

  /** Look again exactly when the next wake-up or start time comes (the loop's own look may be 30 s away). */
  armWake() {
    const times = this.store.entries().flatMap(([, t]) => [t.startAt, t.wake?.at]).filter(Boolean).map(Date.parse).filter((t) => t > Date.now());
    if (times.length) this.wakeAt(new Date(Math.min(...times)).toISOString());
  }

  /** Run a background job unless it runs already; failures are logged. */
  job(name, fn) {
    if (this.jobs.has(name) || this.stopped) return;
    this.jobs.add(name);
    void this.safely(name, fn).finally(() => this.jobs.delete(name));
  }

  /** The crew's part of a look: the account while a limit holds, scouts, briefs, Keep up to date, the orchestrator. */
  async crewTick() {
    const now = Date.now();
    const busy = this.store.entries().some(([id, t]) => this.busy.has(id) || usesSlot(t, now) || (heldWaiting(t).length && !t.settledAt));
    if (this.store.state().limitUntil) await this.limits.read();
    await this.safely("pacing", () => this.pacing.tick({ busy }));
    await this.scouts.tick({ idle: !busy });
    this.job("briefs", () => this.briefs.tick());
    this.job("updates", () => this.updater.tick());
    this.job("orchestrator", () => this.orchestrator.pulse());
  }

  /**
   * Hear the claude plugin's thread events (layr__events_subscribe, docs/ARCHITECTURE.md › Backends hearing events)
   * instead of a thread_wait per running thread; the look at the threads then comes every EVENT_POLL_SEC at most.
   * An older core without the tool: stays as it was.
   */
  async listen(topics = THREAD_TOPICS) {
    if (!this.hub.available) return false;
    try {
      for (const topic of topics) await this.hub.call("layr__events_subscribe", { topic });
      this.eventsLive = true;
    } catch (error) {
      this.log("no thread events (watching with thread_wait instead):", errorText(error));
    }
    return this.eventsLive;
  }

  /** An event from the hub (notifications/layr/event): a thread changed, so look now. */
  heard(topic) {
    if (THREAD_TOPICS.includes(topic)) this.wake();
  }

  /** Run a tick soon (coalesced). */
  wake(ms = 50) {
    if (this.stopped) return;
    clearTimeout(this.timer);
    this.timer = setTimeout(() => void this.tick(), ms);
    this.timer.unref?.();
  }

  async tick() {
    if (this.ticking) {
      this.again = true;
      return this.ticking;
    }
    this.ticking = (async () => {
      try {
        await this.refreshProjects();
        await this.refreshThreads();
        for (const [id, task] of this.store.entries()) if (task.landing) await this.safely(`landing #${id}`, () => this.lander.advance(id));
        dueWakes(this);
        this.dueStarts();
        freeLanes(this);
        if (this.store.global().mode === "away") this.releaseAway();
        await this.gate();
        this.watch();
        await this.safely("crew", () => this.crewTick());
        if (Date.now() - this.lastCheckouts > CHECKOUT_MS) {
          this.lastCheckouts = Date.now();
          await this.safely("checkouts", () => this.checkCheckouts());
        }
        this.keepAwake.set(this.store.global().keepAwake && this.hasWork());
        if (Date.now() - this.lastCleanup > CLEANUP_MS) {
          this.lastCleanup = Date.now();
          await this.safely("cleanup", () => this.cleanup());
        }
        this.armWake();
        this.lastError = null;
      } catch (error) {
        this.lastError = errorText(error);
        this.log("tick failed:", error);
      } finally {
        this.ticking = null;
        const again = this.again;
        this.again = false;
        if (!this.stopped) {
          clearTimeout(this.timer);
          const pollSec = this.store.global().pollSec;
          const idleSec = this.eventsLive ? Math.max(pollSec, EVENT_POLL_SEC) : pollSec;
          this.timer = setTimeout(() => void this.tick(), again ? 50 : idleSec * 1000);
          this.timer.unref?.();
        }
      }
    })();
    return this.ticking;
  }

  async safely(what, fn) {
    try {
      return await fn();
    } catch (error) {
      this.log(`${what} failed:`, errorText(error));
      return undefined;
    }
  }

  emitChanged() {
    if (this.emitTimer) return;
    this.emitTimer = setTimeout(() => {
      this.emitTimer = null;
      this.hub.emit("pipeline:changed", { at: nowIso(), tasks: this.store.takeChanged() });
      this.statusBar();
    }, 120);
    this.emitTimer.unref?.();
  }

  /** The status bar item (layr.json `statusBar` "status"): running against the cap, and what asks you. */
  statusBar() {
    if (!this.hub.available || !this.hub.call) return;
    const s = this.status();
    const asks = this.store.entries().filter(([id, t]) => !t.inBatch && this.placement(id, t).why === "question").length;
    const mode = { stop: "❚❚ ", here: "", away: "🌙 " }[s.mode] ?? "";
    const text = `${mode}Pipeline ${s.running}/${s.maxRunning}${asks ? ` · ${asks} ask` : ""}`;
    if (text === this.statusText) return;
    this.statusText = text;
    this.hub.call("layr__status_set", { id: "status", text, tooltip: s.headline }).catch(() => {});
  }

  // ---------------------------------------------------------------- projects

  async refreshProjects() {
    try {
      this.projectsCache = await this.claude.projects();
    } catch (error) {
      if (!this.projectsCache.length) throw error;
    }
  }

  projectInfo(projectId) {
    return this.projectsCache.find((p) => p.id === projectId) ?? null;
  }

  /** The repository folder of a project (the claude project's folder). */
  repoOf(projectId) {
    const project = this.projectInfo(projectId);
    if (!project) throw new Error(`There is no project ${projectId}: see projects`);
    return project.path;
  }

  // ---------------------------------------------------------------- reading threads

  /** Threads layr follows: tasks' (not settled) and verifiers'. */
  followed() {
    const out = [];
    for (const [id, task] of this.store.entries()) {
      // A card its thread's archive settled stays followed: unarchiving the thread unsettles it.
      const archived = task.settledBy === "archive" && !task.discarded;
      if (task.threadId && (!task.settledAt || task.landing || archived)) out.push({ id, role: "task", thread: task.threadId });
      if (task.verify?.threadId && task.verify.state === "running") out.push({ id, role: "verify", thread: task.verify.threadId });
    }
    for (const f of [...this.scouts.followed(), ...this.orchestrator.followed()]) out.push({ id: f.thread, role: "crew", thread: f.thread, see: f.see });
    return out;
  }

  async refreshThreads() {
    const followed = this.followed();
    if (!followed.length) return;
    const list = await this.claude.list();
    const byId = new Map(list.map((t) => [t.id, t]));
    for (const f of followed) {
      // Not in the list (it holds the newest threads only): asked by its id before it counts as gone.
      const summary = byId.has(f.thread) ? byId.get(f.thread) : await this.threadById(f.thread);
      if (summary === undefined) continue;
      if (f.role === "task") await this.safely(`thread of #${f.id}`, () => this.seeThread(f.id, summary));
      else if (f.role === "verify") await this.safely(`verifier of #${f.id}`, () => this.seeVerifier(f.id, summary));
      else if (f.role === "crew") await this.safely(`crew thread ${f.thread}`, () => f.see(summary));
    }
  }

  /** A thread's summary by its id: null when the claude plugin says it is gone, undefined when it can't tell now. */
  async threadById(thread) {
    try {
      return (await this.claude.status(thread))?.thread ?? null;
    } catch (error) {
      return /no thread|not found|unknown thread|there is no/i.test(errorText(error)) ? null : undefined;
    }
  }

  /** A task meant to have a worktree of its own whose thread works in the project's checkout (adopted ones aside). */
  misplaced(task, where) {
    if (task.noWorktree || task.source?.kind === "adopted" || !where) return false;
    const repo = this.projectInfo(task.projectId)?.path;
    return !!repo && samePath(where, repo);
  }

  /** Take in a thread summary of a task's thread; on a turn's end read its reply and react. */
  async seeThread(id, s) {
    const task = this.store.get(id);
    if (!task) return;
    const prev = task.thread ?? {};
    if (!s) {
      if (!prev.missing) this.store.mutate(id, () => ({ thread: { ...prev, missing: true, status: "missing" } }));
      return;
    }
    this.pacing.spent(id, s);
    const background = (s.background ?? []).map((b) => ({ id: b.id, type: b.type ?? null, ...(b.agent ? { agent: b.agent } : {}),
      description: b.description ?? "", startedAt: b.startedAt ?? null }));
    const sig = `${s.status}|${s.turns}|${(s.pendingApprovals ?? []).join(",")}|${s.archived}|${s.error ?? ""}|` +
      background.map((b) => b.id).join(",");
    if (sig === prev.sig) {
      if (task.archivePending) this.archiveFollows(id, true);
      return;
    }
    const next = {
      ...prev,
      sig,
      missing: false,
      status: s.status,
      archived: !!s.archived,
      turns: s.turns ?? 0,
      branch: s.workspace?.branch ?? prev.branch ?? null,
      worktreePath: s.workspace?.path ?? s.cwd ?? prev.worktreePath ?? null,
      lastError: s.error ?? null,
      background: background.length ? background : undefined,
      updatedAt: nowIso(),
    };
    const newTurn = (s.turns ?? 0) > (prev.turns ?? 0);
    if (newTurn) next.turnStartedAt = nowIso();
    next.pending = s.pendingApprovals?.length ? ((await this.claude.status(task.threadId)).approvals ?? []) : [];
    // A turn whose background work (subagents, background shells, watches) still runs isn't over yet: layr reacts to
    // its end once that work is done (Claude Code usually starts a new turn with its results by then).
    const settled = !isActive({ status: s.status }) && s.status !== "waiting" && !background.length;
    const wasBusy = isActive(prev) || prev.status === "waiting" || (prev.background?.length ?? 0) > 0;
    const ended = settled && (newTurn || wasBusy || !prev.turnEndedAt);
    if (ended) {
      const reply = await this.claude.lastReply(task.threadId).catch(() => null);
      next.turnEndedAt = nowIso();
      next.turnStatus = s.status;
      if (reply) {
        next.lastMessage = reply.length > REPLY_MAX ? `${reply.slice(0, 2000)}\n…\n${reply.slice(-(REPLY_MAX - 2000))}` : reply;
        next.replyStatus = replyStatus(reply);
      }
    }
    // While layr reacts to a turn's end (reads the worktree, holds what comes next) the task still shows as running.
    if (ended) next.reacting = true;
    this.store.mutate(id, () => ({ thread: next }));
    if (ended) {
      try {
        await this.afterTurn(id);
      } finally {
        this.store.mutate(id, (t) => (t.thread?.reacting ? { thread: { ...t.thread, reacting: undefined } } : null));
      }
    }
    this.archiveFollows(id, !!prev.archived);
  }

  /**
   * Archiving a task's thread (in the claude plugin) settles its card, once its turn isn't running (until then the
   * archive waits, `archivePending`); unarchiving it unsettles a card the archive settled. A card you unsettle while
   * its thread stays archived stays unsettled.
   */
  archiveFollows(id, wasArchived = false) {
    const task = this.store.get(id);
    const thread = task?.thread;
    if (!task || !thread || thread.missing || task.discarded || task.inBatch) return;
    const due = thread.archived && (!wasArchived || task.archivePending) && !task.settledAt;
    if (due && (task.landing || isActive(thread) || this.busy.has(id))) {
      if (!task.archivePending) this.store.mutate(id, () => ({ archivePending: true }));
    } else if (due) {
      this.settle(id);
      this.store.mutate(id, () => ({ settledBy: "archive", archivePending: undefined }));
      this.log(`#${id}: its thread was archived, so it is settled`);
    } else if (!thread.archived && task.archivePending) {
      this.store.mutate(id, () => ({ archivePending: undefined }));
    } else if (!thread.archived && wasArchived && task.settledAt && task.settledBy === "archive") {
      this.store.mutate(id, () => ({ settledAt: undefined, settledBy: undefined }));
      for (const [mid] of this.members(id)) if (task.landed) this.store.mutate(mid, () => ({ settledAt: undefined }));
      this.log(`#${id}: its thread was unarchived, so it is back`);
    }
  }

  /** A task's turn ended (not a landing turn: the lander reads those). */
  async afterTurn(id) {
    const task = this.store.get(id);
    if (!task || task.landing || task.settledAt) return;
    const thread = task.thread;
    if (this.misplaced(task, thread.worktreePath)) {
      this.store.mutate(id, () => ({ stopNote: MISPLACED_NOTE, held: undefined }));
      return;
    }
    if (thread.turnStatus === "failed") {
      const kind = classifyError(thread.lastError);
      if (!kind) return;
      const continueMsg = (t) => [...(t.held ?? []).filter((m) => m.kind !== "continue"), { kind: "continue", at: nowIso() }];
      if (kind === "limit") {
        // Waiting for a limit is no failed try: it waits for the reset, however often that happens.
        const resumeAt = await this.limits.resetAt(thread.lastError);
        this.store.setState({ limitUntil: resumeAt, limitAt: nowIso() });
        this.store.mutate(id, (t) => ({ resumeAt, limitWaits: (t.limitWaits ?? 0) + 1, held: continueMsg(t) }));
        return;
      }
      const resumes = (task.resumes ?? 0) + 1;
      if (resumes > MAX_RESUMES) {
        this.store.mutate(id, () => ({ stopNote: `Stopped after ${MAX_RESUMES} tries: ${snippet(thread.lastError, 200)}` }));
        return;
      }
      const resumeAt = new Date(Date.now() + 2 ** (resumes - 1) * 60_000).toISOString();
      this.store.mutate(id, (t) => ({ resumes, resumeAt, held: continueMsg(t) }));
      return;
    }
    if (thread.turnStatus === "done" && (task.resumes || task.limitWaits)) {
      this.store.mutate(id, () => ({ resumes: undefined, resumeAt: undefined, limitWaits: undefined }));
    }
    if (task.noWorktree) await this.readCheckout(id).catch(() => {});
    if (task.planning) {
      if (task.worktreePath && !task.noWorktree) {
        const files = await uncommitted(task.worktreePath).catch(() => []);
        if (files.length) this.store.mutate(id, () => ({ planEdits: files.slice(0, 20) }));
      }
      return;
    }
    this.concepts.readyToTry(this.store.get(id));
    if (task.batch && thread.lastMessage) {
      const numbers = this.members(id).map(([, t]) => t.number);
      const report = batchReport(thread.lastMessage, numbers);
      if (report.length) this.store.mutate(id, () => ({ batchReport: report }));
    }
    if (task.worktreePath && !task.noWorktree && existsSync(task.worktreePath)) await this.readWork(id);
    const fresh = this.store.get(id);
    if (this.verifyDue(fresh)) {
      this.store.mutate(id, (t) => ({
        verify: { ...(t.verify ?? { rounds: 0 }), state: "queued", head: t.work?.head },
        held: [...(t.held ?? []), { kind: "verify", at: nowIso() }],
      }));
    } else if (this.autoMergeDue(fresh) || this.agentLandDue(fresh)) this.agentHoldLand(id);
  }

  /** What the worktree holds after a turn: head, commits beyond the base, uncommitted files, what asks you first. */
  async readWork(id) {
    const task = this.store.get(id);
    const settings = this.store.project(task.projectId);
    const dir = task.worktreePath;
    const ref = baseRef(settings);
    const [head, ahead, dirty, files] = await Promise.all([
      headOf(dir),
      commitsAhead(dir, ref).catch(() => 0),
      uncommitted(dir).catch(() => []),
      changedFiles(dir, ref).catch(() => []),
    ]);
    const work = { head, ahead, dirty: dirty.length, at: nowIso() };
    const landed = task.landed;
    const changed = landed && Date.parse(work.at) > Date.parse(landed.at) && (head !== landed.head || dirty.length > 0);
    const paths = askPathHits(files, settings.askPaths);
    const risks = (task.thread?.replyStatus?.risks ?? []).filter((r) => ASK_RISKS.includes(r));
    this.store.mutate(id, () => ({
      work,
      ...(changed ? { landed: undefined } : {}),
      ask: paths.length || risks.length ? { paths, risks, at: nowIso() } : undefined,
    }));
  }

  /** A task without a worktree: whether the project's checkout is still clean and on the base branch (for Settle). */
  async readCheckout(id) {
    const task = this.store.get(id);
    const repo = this.repoOf(task.projectId);
    const base = this.store.project(task.projectId).baseBranch;
    const [files, branch] = await Promise.all([uncommitted(repo), currentBranch(repo)]);
    const checkout =
      files.length || branch !== base
        ? {
            files: files.slice(0, CHECKOUT_FILES),
            ...(files.length > CHECKOUT_FILES ? { more: files.length - CHECKOUT_FILES } : {}),
            ...(branch !== base ? { branch: branch ?? "(detached)" } : {}),
            at: nowIso(),
          }
        : undefined;
    const key = (c) => JSON.stringify([c?.files ?? null, c?.more ?? 0, c?.branch ?? ""]);
    if (key(checkout) !== key(task.checkout)) this.store.mutate(id, () => ({ checkout }));
  }

  /** Every minute: the checkout of each task without a worktree whose thread exists, until it is settled. */
  async checkCheckouts() {
    for (const [id, t] of this.store.entries()) {
      if (!t.noWorktree || !t.threadId || t.settledAt || t.thread?.missing || isActive(t.thread)) continue;
      await this.safely(`checkout of #${id}`, () => this.readCheckout(id));
    }
  }

  /** Work that needs the PC awake: turns running, landings, messages waiting for a slot (not in Soft stop). */
  hasWork(now = Date.now()) {
    if (this.busy.size || this.lander.busy()) return true;
    const mode = this.store.global().mode;
    return this.store.entries().some(([, t]) => t.landing || (t.startAt && !t.settledAt) || usesSlot(t, now) || (mode !== "stop" && !t.settledAt && !t.inBatch && heldWaiting(t).length > 0));
  }

  /** Whether a verifier checks it before it lands (`autoMerge` verifying: tasks that land without the user). */
  verifies(task) {
    const v = this.store.project(task.projectId).verify;
    return !task.noWorktree && (v === "always" || (v === "autoMerge" && (!!task.autoMerge || !!task.agentLands)));
  }

  verifyDue(task) {
    if (!this.verifies(task) || task.planning || task.landing || task.landed || task.stopNote) return false;
    if (heldWaiting(task).length || ["queued", "running"].includes(task.verify?.state)) return false;
    const status = task.thread?.replyStatus?.status;
    if (status && status !== "done") return false;
    // A task the agent lands is only verified (verify: autoMerge) once its worker asked to land it.
    const always = this.store.project(task.projectId).verify === "always";
    if (!always && !task.autoMerge && !this.landWantedNow(task)) return false;
    return !!task.work && task.work.ahead > 0 && task.verify?.head !== task.work.head;
  }

  autoMergeDue(task) {
    return !!task.autoMerge && this.mayLandAlone(task);
  }

  /** Whether its worker asked to land it (pipeline__land from its own thread) in the turn that ended last. */
  landWantedNow(task) {
    const asked = Date.parse(task.landWanted?.at ?? "");
    return !!task.agentLands && asked >= Date.parse(task.thread?.turnStartedAt ?? 0);
  }

  /**
   * Agent lands: its worker asked to land in its last turn, which ended with Status: done and no risky Risk; then
   * layr lands it as the user's Land button does (and as auto-merge would).
   */
  agentLandDue(task) {
    if (!this.landWantedNow(task) || !this.mayLandAlone(task)) return false;
    const status = task.thread?.replyStatus;
    return status?.status === "done" && !(status.risks ?? []).some((r) => LAND_RISKS.includes(r));
  }

  /** Land it, noting when its worker asked for it (the asked-for request is then used up). */
  agentHoldLand(id) {
    const task = this.store.get(id);
    const byAgent = !task.autoMerge && this.landWantedNow(task);
    this.holdLand(id);
    if (byAgent) this.store.mutate(id, (t) => ({ landWanted: undefined, agentAskedLand: t.landWanted?.at ?? nowIso() }));
  }

  /** What landing without the user (auto-merge, agent lands) needs: finished, committed, clean, nothing asks. */
  mayLandAlone(task) {
    if (task.planning || task.noWorktree || task.landing || task.landed || task.ask) return false;
    if (task.stopNote || task.held?.length || task.parked?.length || task.settledAt || task.wake) return false;
    if (this.verifies(task) && task.verify?.state !== "passed") return false;
    if (waitsForLane(this, this.store.idOf(task.number), task)) return false;
    const t = task.thread;
    if (!t || t.missing || isActive(t) || inBackground(t) || waitsForAnswer(t) || t.turnStatus !== "done") return false;
    return !!task.work && task.work.ahead > 0 && task.work.dirty === 0;
  }

  /**
   * Land it: to the gate, or with When away on to Ready, where it waits for Away (whoever asked: the user, an agent
   * on their word, auto-merge or Agent lands).
   */
  holdLand(id, by) {
    this.store.mutate(id, (t) => {
      if (landQueued(t) || t.landing) return null;
      const m = { kind: "land", at: nowIso() };
      const queue = t.whenAway ? { parked: [...(t.parked ?? []), m] } : { held: [...(t.held ?? []), m] };
      return { ...queue, stopNote: undefined, landedFor: by ?? undefined };
    });
  }

  /** Keep a thread_wait out for every running thread, so a turn's end is seen at once (unless events come). */
  watch() {
    if (this.eventsLive) return;
    const threads = [];
    for (const [, task] of this.store.entries()) {
      if (task.threadId && isActive(task.thread)) threads.push(task.threadId);
      if (task.verify?.state === "running" && task.verify.threadId) threads.push(task.verify.threadId);
    }
    for (const f of [...this.scouts.followed(), ...this.orchestrator.followed()]) threads.push(f.thread);
    for (const thread of threads) {
      if (this.watching.has(thread)) continue;
      this.watching.add(thread);
      this.claude
        .wait(thread, WAIT_SEC)
        .catch((error) => this.log(`thread_wait ${thread}:`, errorText(error)))
        .finally(() => {
          this.watching.delete(thread);
          this.wake();
        });
    }
  }

  // ---------------------------------------------------------------- the gate

  /** What a held message needs: a new turn (held by Soft stop) or not (landing, verifying). */
  static newTurn(m) {
    return !["land", "verify"].includes(m.kind);
  }

  async gate() {
    const global = this.store.global();
    const state = this.store.state();
    const now = Date.now();
    let running = 0;
    const perProject = new Map();
    const count = (task) => {
      running++;
      perProject.set(task.projectId, (perProject.get(task.projectId) ?? 0) + 1);
    };
    for (const [id, task] of this.store.entries()) if (this.busy.has(id) || usesSlot(task, now)) count(task);
    // After a limit, the gate opens again when the account shows room (switched accounts) or the back-off passed.
    if (state.limitUntil && Date.parse(state.limitUntil) > now && this.limits.limitOver(state.limitAt)) {
      this.store.setState({ limitUntil: undefined, limitAt: undefined });
      for (const [id, t] of this.store.entries()) if (t.resumeAt) this.store.mutate(id, () => ({ resumeAt: undefined }));
    }
    const limited = state.limitUntil && Date.parse(state.limitUntil) > now;
    if (state.limitUntil && !limited) this.store.setState({ limitUntil: undefined, limitAt: undefined });
    const queue = this.store
      .entries()
      .filter(([, t]) => heldWaiting(t).length && !t.settledAt && !t.inBatch)
      .sort(([, a], [, b]) => (a.order ?? 0) - (b.order ?? 0) || byNumber(a.number, b.number));
    const landingIn = new Set(this.store.entries().filter(([, t]) => t.landing).map(([, t]) => t.projectId));
    /** Tasks without a worktree launched in this pass (they have no thread yet), so a second one waits. */
    const launching = new Set();
    this.waitReasons = new Map();
    for (const [id, task] of queue) {
      if (this.busy.has(id)) continue;
      const msg = heldWaiting(task)[0];
      const why = (text) => this.waitReasons.set(id, text);
      const midTurn = task.threadId && (isActive(task.thread) || waitsForAnswer(task.thread) || inBackground(task.thread));
      if (midTurn) {
        // Messages and answers to a thread whose turn runs (or waits for an answer, or whose background work runs) go
        // at once: no new slot.
        if (msg.kind === "message" || msg.kind === "answer") void this.deliver(id, msg);
        else why("waits for its turn to end");
        continue;
      }
      if (task.threadId && task.thread?.missing) {
        why("its thread is gone");
        continue;
      }
      if (msg.kind === "launch") {
        const chain = this.chainWait(task);
        if (chain) {
          why(chain);
          continue;
        }
        if (task.noWorktree) {
          const holder = this.checkoutHolder(id, task, launching);
          if (holder) {
            why(`no worktree · after #${holder}`);
            continue;
          }
        }
      }
      const settings = this.store.project(task.projectId);
      if (!settings.enabled) {
        why("its project isn't enabled (Pipeline settings)");
        continue;
      }
      if (global.mode === "stop" && Pipeline.newTurn(msg)) {
        why("Soft stop: nothing new starts");
        continue;
      }
      if (limited && msg.kind !== "answer") {
        why(`usage limit until ${clock(state.limitUntil)}`);
        continue;
      }
      if (task.resumeAt && Date.parse(task.resumeAt) > now) {
        why(task.retryNote ?? `tries again at ${clock(task.resumeAt)}`);
        continue;
      }
      if (msg.kind === "land" && landingIn.has(task.projectId)) {
        why("another task of the project is landing");
        continue;
      }
      const projectMax = Math.min(settings.maxRunning ?? global.maxRunning, global.maxRunning);
      if (running >= global.maxRunning || (perProject.get(task.projectId) ?? 0) >= projectMax) {
        why(`waits for a slot (${running}/${global.maxRunning} running)`);
        continue;
      }
      count(task);
      if (msg.kind === "land") landingIn.add(task.projectId);
      if (msg.kind === "launch" && task.noWorktree) launching.add(id);
      void this.deliver(id, msg);
    }
  }

  /** Send a held message to its thread (or launch the thread). */
  async deliver(id, msg) {
    this.busy.add(id);
    try {
      const task = this.store.get(id);
      if (!task) return;
      switch (msg.kind) {
        case "launch":
          await this.launch(id);
          break;
        case "message": {
          const mid = isActive(task.thread) || waitsForAnswer(task.thread);
          const text = task.planning && !msg.start ? `${PLAN_REMINDER}\n\n${msg.text}` : msg.text;
          const files = msg.attachments?.length ? this.attachments.payload(msg.attachments) : { images: [], note: "" };
          const sent = await this.claude.send(task.threadId, text + files.note, mid ? "steer" : "queue", files.images);
          if (msg.attachments?.length) this.dropSent(id, msg.attachments);
          this.store.mutate(id, () => ({ sentAt: nowIso(), stopNote: undefined, ...(msg.start ? { planning: undefined } : {}) }));
          if (sent?.thread) await this.seeThread(id, sent.thread);
          break;
        }
        case "answer":
          try {
            await this.claude.answer(task.threadId, msg);
          } catch (error) {
            if (!/not waiting any more/i.test(errorText(error))) throw error;
            this.log(`#${id}: the question was answered already`);
          }
          break;
        case "continue": {
          const sent = await this.claude.send(task.threadId, continueMessage());
          this.store.mutate(id, () => ({ sentAt: nowIso(), resumeAt: undefined }));
          if (sent?.thread) await this.seeThread(id, sent.thread);
          break;
        }
        case "land":
          await this.lander.begin(id);
          break;
        case "verify":
          await this.startVerify(id);
          break;
      }
      this.store.mutate(id, (t) => ({
        held: (t.held ?? []).filter((m) => m !== msg && !(m.at === msg.at && m.kind === msg.kind)),
        ...(t.deliveryTries ? { deliveryTries: undefined, retryNote: undefined } : {}),
      }));
    } catch (error) {
      const text = errorText(error);
      this.log(`sending ${msg.kind} to #${id} failed:`, text);
      let task = this.store.get(id);
      const notFound = !!task?.threadId && msg.kind !== "launch" && threadNotFound(text);
      if (notFound) {
        // Its thread wasn't found: read it by id (gone: the card says so), and the message goes again later.
        const s = await this.threadById(task.threadId);
        if (s !== undefined) await this.safely(`thread of #${id}`, () => this.seeThread(id, s));
        task = this.store.get(id);
      }
      const again = notFound ? !task?.thread?.missing : retryable(text);
      if (task && again && (task.deliveryTries ?? 0) < DELIVERY_TRIES && ["launch", "message", "continue"].includes(msg.kind)) {
        // The claude plugin couldn't take it (network, not running): it stays, first in line, and goes again later.
        const resumeAt = new Date(Date.now() + DELIVERY_RETRY_MS).toISOString();
        this.store.mutate(id, (t) => ({
          deliveryTries: (t.deliveryTries ?? 0) + 1,
          resumeAt,
          retryNote: `${notFound ? "its thread wasn't found" : "couldn't reach the claude plugin"} (${snippet(text, 80)}): tries again at ${clock(resumeAt)}`,
        }));
        return;
      }
      if (msg.kind === "message") {
        this.store.mutate(id, (t) => ({ held: (t.held ?? []).map((m) => (m === msg || m.at === msg.at ? { ...m, failed: text } : m)), stopNote: `Sending failed: ${snippet(text, 200)}` }));
      } else {
        const note = msg.kind === "launch" ? `Could not launch: ${snippet(text, 300)}` : `Could not send ${msg.kind}: ${snippet(text, 300)}`;
        this.store.mutate(id, (t) => ({
          held: (t.held ?? []).filter((m) => !(m.at === msg.at && m.kind === msg.kind)),
          stopNote: note,
          ...(msg.kind === "verify" ? { verify: { ...(t.verify ?? {}), state: "you", report: note } } : {}),
        }));
      }
    } finally {
      this.busy.delete(id);
      this.wake();
    }
  }

  /** Start the task's thread: a new worktree on its own branch from the base (or the project's checkout). */
  async launch(id) {
    const task = this.store.get(id);
    const settings = this.store.project(task.projectId);
    const repo = this.repoOf(task.projectId);
    let branch = null;
    let workspace = "project";
    if (!task.noWorktree) {
      branch = `${settings.branchPrefix}${task.number}-${slugify(task.title, 32) || "task"}`;
      workspace = "worktree";
      if (await branchExists(repo, branch)) {
        const dir = await worktreeOf(repo, branch);
        if (!dir) throw new Error(`The branch ${branch} exists without a worktree: delete it or rename the task`);
        workspace = { worktreePath: dir };
      }
      if (remoteLanding(settings)) await fetchBase(repo, settings.remote, settings.baseBranch).catch(() => null);
      if (!(await revParse(repo, baseRef(settings)))) throw new Error(`There is no ${baseRef(settings)} in ${repo}`);
    }
    const parent = task.after ? this.store.get(task.after) : null;
    const concepts = await this.concepts.available().catch(() => false);
    const map = concepts && settings.projectNode ? await this.concepts.projectMap(settings.projectNode) : null;
    const files = task.attachments?.length ? this.attachments.payload(task.attachments) : { images: [], note: "" };
    const prompt = launchMessage({
      id,
      task,
      branch,
      settings,
      parent,
      members: task.batch ? this.members(id) : [],
      away: this.store.global().mode === "away",
      lane: hasLane(settings),
      map,
      concepts,
      note: files.note,
    });
    const { model, effort } = workerSettings(task, settings, this.store.global());
    const thread = await this.claude.start({
      project: task.projectId,
      prompt,
      ...(files.images.length ? { images: files.images } : {}),
      title: `#${task.number} ${task.title}`,
      workspace,
      ...(workspace === "worktree" ? { branch, baseRef: baseRef(settings) } : {}),
      ...(model ? { model } : {}),
      ...(effort ? { effort } : {}),
      permissionMode: task.permissionMode ?? settings.workerPermissionMode,
    });
    if (workspace !== "project" && this.misplaced(task, thread.workspace?.path ?? thread.cwd)) {
      // Never let a task meant for a worktree work in the project's own checkout.
      await this.claude.interrupt(thread.id).catch(() => {});
      await this.claude.archive(thread.id, true).catch(() => {});
      throw new Error(MISPLACED_NOTE);
    }
    const at = nowIso();
    if (task.attachments?.length) this.dropSent(id, task.attachments);
    this.store.mutate(id, () => ({
      threadId: thread.id,
      branch: thread.workspace?.branch ?? branch,
      worktreePath: thread.workspace?.path ?? thread.cwd,
      sentAt: at,
      stopNote: undefined,
      thread: {
        status: thread.status,
        turns: 0,
        pending: [],
        branch: thread.workspace?.branch ?? branch,
        worktreePath: thread.workspace?.path ?? thread.cwd,
      },
    }));
    if (task.batch) for (const [mid] of this.members(id)) this.store.mutate(mid, () => ({ skipped: undefined }));
    await this.seeThread(id, thread);
  }

  /** Sent images are dropped (the claude plugin keeps its copy), unless another task still has to send them. */
  dropSent(id, list) {
    const named = new Set();
    for (const [other, t] of this.store.entries()) {
      if (other === id) continue;
      if (!t.threadId) for (const a of t.attachments ?? []) named.add(a.id);
      for (const m of [...(t.held ?? []), ...(t.parked ?? [])]) for (const a of m.attachments ?? []) named.add(a.id);
    }
    this.attachments.drop(list.filter((a) => !named.has(a.id)), { imagesOnly: true });
  }

  /** Why a chained task can't launch yet, or null. */
  chainWait(task) {
    if (!task.after) return null;
    const parent = this.store.get(task.after);
    if (!parent) return `Waits for #${task.after}, which is no longer on the board: drop the link to run it`;
    if (parent.landed) return null;
    if (parent.settledAt) return `Waits for #${parent.number}, which was settled without landing`;
    return `Starts after #${parent.number} lands`;
  }

  /**
   * The task without a worktree that has the project's checkout (from its launch until it is settled), other than
   * `id`. `launching`: tasks launched in this gate pass; those being launched now (busy, no thread yet) count too.
   */
  checkoutHolder(id, task, launching = new Set()) {
    for (const [other, t] of this.store.entries()) {
      if (other === id || t.projectId !== task.projectId || !t.noWorktree) continue;
      if (t.threadId ? !t.settledAt : launching.has(other) || (this.busy.has(other) && t.held?.some((m) => m.kind === "launch"))) return t.number;
    }
    return null;
  }

  // ---------------------------------------------------------------- verifier

  async startVerify(id) {
    const task = this.store.get(id);
    const settings = this.store.project(task.projectId);
    const verify = task.verify ?? { rounds: 0 };
    let summary;
    if (!verify.threadId) {
      summary = await this.claude.start({
        project: task.projectId,
        prompt: verifierMessage(task, task.branch, settings),
        title: `#${task.number} verify: ${task.title}`,
        workspace: { worktreePath: task.worktreePath },
        model: settings.verifierModel ?? this.store.global().verifierModel,
        permissionMode: "bypassPermissions",
      });
    } else {
      summary = (await this.claude.send(verify.threadId, reverifyMessage(verify.rounds))).thread;
    }
    this.store.mutate(id, (t) => ({
      verify: { ...(t.verify ?? {}), state: "running", threadId: summary.id, turns: summary.turns ?? 1, sentAt: nowIso() },
    }));
  }

  async seeVerifier(id, s) {
    const task = this.store.get(id);
    const v = task?.verify;
    if (!v || v.state !== "running") return;
    if (!s) {
      this.store.mutate(id, () => ({ verify: { ...v, state: "you", report: "The verifier's thread is gone." } }));
      return;
    }
    if (s.status === "waiting") return this.denyAll(s.id, "You only verify: decide yourself, and say what only the user can tell.");
    if (isActive(s) || (s.turns ?? 0) < (v.turns ?? 1)) return;
    const report = ((await this.claude.lastReply(s.id).catch(() => null)) ?? "").slice(-3000);
    const verdict = s.status === "done" ? verdictOf(report) : null;
    if (verdict === "pass") {
      this.store.mutate(id, () => ({ verify: { ...v, state: "passed", report, at: nowIso() } }));
      const passed = this.store.get(id);
      if (this.autoMergeDue(passed) || this.agentLandDue(passed)) this.agentHoldLand(id);
    } else if (verdict === "fix" && (v.rounds ?? 0) < VERIFY_ROUNDS) {
      const round = (v.rounds ?? 0) + 1;
      this.store.mutate(id, (t) => ({
        verify: { ...v, state: "fixing", rounds: round, report, at: nowIso() },
        held: [...(t.held ?? []), { kind: "message", text: verifyFixesMessage(round, report), at: nowIso() }],
      }));
    } else {
      this.store.mutate(id, () => ({ verify: { ...v, state: "you", report, at: nowIso() } }));
    }
    this.wake();
  }

  async denyAll(thread, message) {
    const { approvals = [] } = await this.claude.status(thread);
    for (const a of approvals) await this.claude.answer(thread, { requestId: a.requestId, decision: "deny", message }).catch(() => {});
  }

  // ---------------------------------------------------------------- modes

  /** `backAt`: when the user is back (ISO), for Away (pacing's room; else `awayHours` from now). */
  setMode(mode, { backAt } = {}) {
    const was = this.store.global().mode;
    if (mode !== was) {
      const at = nowIso();
      // The Away that ends now, for the board's "While away" for a while after.
      if (was === "away") this.store.setState({ lastAway: { from: this.store.state().modeSince ?? at, to: at } });
      this.store.setState({ modeSince: at });
      if (was === "away") this.pacing.awayEnds();
      if (mode === "away") this.pacing.awayBegins(backAt);
    } else if (mode === "away" && backAt) this.store.setState({ awayUntil: backAt });
    this.store.setGlobal({ mode });
    if (mode === "away") this.releaseAway();
    this.wake();
  }

  /** Run on a Plan task: its worker starts, only to plan and ask (actions.run does the same). */
  planNow(id) {
    this.store.mutate(id, (t) =>
      t.threadId || t.planning || t.inBatch || t.held?.some((m) => m.kind === "launch") || t.parked?.some((m) => m.kind === "launch")
        ? null
        : { planning: true, held: [...(t.held ?? []), { kind: "launch", at: nowIso() }] },
    );
  }

  /** Away: what waits for it goes, in Ready's order, as far as pacing finds room for it. */
  releaseAway() {
    for (const id of this.pacing.releasable()) this.releaseParked(id);
  }

  releaseParked(id) {
    this.store.mutate(id, (t) => (t.parked?.length ? { held: [...(t.held ?? []), ...t.parked], parked: undefined } : null));
  }

  // ---------------------------------------------------------------- batches

  members(batchId) {
    return this.store
      .entries()
      .filter(([, t]) => t.inBatch === batchId)
      .sort(([, a], [, b]) => byNumber(a.number, b.number));
  }

  openBatch(projectId) {
    // The newest, when a project has several.
    const open = this.store.entries().filter(([, t]) => t.batch && t.projectId === projectId && !t.threadId && !t.settledAt && !t.held?.some((m) => m.kind === "launch"));
    return open.sort(([, a], [, b]) => byNumber(b.number, a.number))[0] ?? null;
  }

  cannotJoin(task, batch) {
    if (task.batch) return "a batch can't join another batch";
    if (task.threadId || task.held?.length) return "it has started";
    if (task.noWorktree) return "it works without a worktree";
    if (task.after) return "it starts after another task";
    if (task.plan || task.planning) return "it plans first";
    if (batch && batch.projectId !== task.projectId) return "the batch is another project's";
    return null;
  }

  batchLanded(batchId) {
    const batch = this.store.get(batchId);
    const report = new Map((batch.batchReport ?? []).map((r) => [String(r.number), r]));
    for (const [id, t] of this.members(batchId)) {
      const r = report.get(String(t.number));
      if (r && !r.done) {
        this.store.mutate(id, (m) => ({ ...this.store.leaveBatch(m), skipped: { batch: batch.number, why: r.why, at: nowIso() } }));
      } else this.store.mutate(id, () => ({ landed: batch.landed }));
    }
  }

  // ---------------------------------------------------------------- settle, discard, cleanup

  /** Done with it: it leaves Running and Stopped (its worktree goes once its work is on the base branch). */
  settle(id) {
    const task = this.store.get(id);
    if (!task) return;
    this.store.mutate(id, () => ({ settledAt: nowIso(), settledBy: undefined, held: undefined, parked: undefined, landing: undefined }));
    for (const [mid] of this.members(id)) {
      if (task.landed) this.store.mutate(mid, () => ({ settledAt: nowIso() }));
      else this.store.mutate(mid, (m) => this.store.leaveBatch(m));
    }
  }

  async discard(id) {
    const task = this.need(id);
    if (task.landing || usesSlot(task) || this.busy.has(id) || isActive(task.thread)) {
      throw new Error(`#${task.number} runs or lands now: stop it first`);
    }
    if (task.threadId && waitsForAnswer(task.thread)) await this.claude.interrupt(task.threadId).catch(() => {});
    if (task.threadId) await this.claude.archive(task.threadId, true).catch(() => {});
    if (task.verify?.threadId) await this.claude.archive(task.verify.threadId, true).catch(() => {});
    await this.removeWork(task);
    releaseLane(this, id);
    if (task.attachments?.length) this.attachments.drop(task.attachments);
    this.store.mutate(id, () => ({ settledAt: task.settledAt ?? nowIso(), discarded: nowIso(), held: undefined, parked: undefined, landing: undefined, wake: undefined, startAt: undefined, attachments: undefined }));
    for (const [mid] of this.members(id)) this.store.mutate(mid, (m) => this.store.leaveBatch(m));
  }

  async removeWork(task) {
    if (task.noWorktree || !task.worktreePath) return;
    const repo = this.projectInfo(task.projectId)?.path;
    if (!repo || samePath(repo, task.worktreePath)) return;
    await removeWorktree(repo, task.worktreePath).catch((error) => this.log(`removing ${task.worktreePath}:`, errorText(error)));
    if (task.branch) await deleteBranch(repo, task.branch).catch(() => {});
  }

  /**
   * Every few minutes: landed tasks settle some days after (a project setting), settled tasks whose work is on the
   * base branch lose their worktree and local branch (their card and thread stay: worktrees.js), and staged files
   * nothing names go.
   */
  async cleanup() {
    await this.worktrees.tick();
    // Staged files nothing names any more.
    const named = new Set();
    for (const [, t] of this.store.entries()) {
      for (const a of t.attachments ?? []) named.add(a.id);
      for (const m of [...(t.held ?? []), ...(t.parked ?? [])]) for (const a of m.attachments ?? []) named.add(a.id);
    }
    this.attachments.sweep(named);
  }

  // ---------------------------------------------------------------- reading for panels and agents

  need(id) {
    const task = this.store.get(id);
    if (!task) throw new Error(`There is no task #${id}: see tasks`);
    return task;
  }

  placement(id, task = this.store.get(id)) {
    const batch = task.inBatch ? this.store.get(task.inBatch) : null;
    return placeTask(task, Date.now(), batch);
  }

  /** One line of state: what holds it back, when something does. */
  waits(id, task) {
    const timed = task.parked?.length && task.startAt && Date.parse(task.startAt) > Date.now() ? `waits for its start time ${clock(task.startAt)}` : null;
    const reason = this.waitReasons?.get(id) ?? timed ?? (task.parked?.length ? this.pacing.hold(id) : null);
    if (reason) return reason;
    if (task.retryNote && task.resumeAt && Date.parse(task.resumeAt) > Date.now()) return task.retryNote;
    if (task.held?.some((m) => m.kind === "launch")) return this.chainWait(task);
    return null;
  }

  /** The board's headline. */
  status() {
    const global = this.store.global();
    const state = this.store.state();
    const now = Date.now();
    const running = this.store.entries().filter(([id, t]) => this.busy.has(id) || usesSlot(t, now)).length;
    const queued = this.store
      .entries()
      .filter(([, t]) => heldWaiting(t).length && !t.settledAt)
      .sort(([, a], [, b]) => (a.order ?? 0) - (b.order ?? 0) || byNumber(a.number, b.number));
    const limited = state.limitUntil && Date.parse(state.limitUntil) > now;
    const scouts = this.scouts.state();
    let headline;
    if (global.mode === "stop") headline = running ? `Soft stop: ${running} still finishing` : "Soft stop: safe to shut down";
    else if (limited) {
      const next = this.pacing.summary().nextRoom;
      headline = `Usage limit: tries again at ${clock(state.limitUntil)}${next ? ` · another account has room at ${clock(next.at)}` : ""}`;
    }
    else headline = `Running ${running}/${global.maxRunning}${queued.length ? ` · next: #${queued[0][1].number}` : ""}`;
    return {
      mode: global.mode,
      headline,
      running,
      maxRunning: global.maxRunning,
      queued: queued.length,
      limitUntil: limited ? state.limitUntil : null,
      lastError: this.lastError,
      landingChecks: this.lander.busy(),
      away: this.awayReport(now),
      scouts: { running: (scouts.active ?? []).filter((a) => !a.waiting).length, waiting: (scouts.active ?? []).filter((a) => a.waiting).length },
      orchestrator: global.orchestrator ? this.orchestrator.status().headline : null,
      lanes: Object.fromEntries(Object.keys(this.store.crew("lanes", {})).map((pid) => [pid, laneOf(this, pid)])),
      pacing: this.pacing.summary(),
      ...(global.mode === "away" ? { backAt: this.pacing.backAt() } : {}),
    };
  }

  /** What happened while the user was last Away, for AWAY_REPORT_MS after they're back: {from, to, landed, toTry, ask}. */
  awayReport(now = Date.now()) {
    const last = this.store.state().lastAway;
    if (!last || this.store.global().mode === "away" || now - Date.parse(last.to) > AWAY_REPORT_MS) return null;
    const from = Date.parse(last.from);
    const since = (iso) => !!iso && Date.parse(iso) >= from;
    const tasks = this.store.entries().filter(([, t]) => t.threadId && !t.inBatch && since(t.updatedAt));
    const placed = tasks.map(([tid, t]) => [t, this.placement(tid, t)]);
    return {
      from: last.from,
      to: last.to,
      landed: tasks.filter(([, t]) => since(t.landed?.at)).length,
      toTry: placed.filter(([t, pl]) => !t.landed && pl.column === "stopped" && t.thread?.replyStatus?.try === "ready").length,
      ask: placed.filter(([, pl]) => pl.why === "question").length,
    };
  }

  /** A task as panels and agents see it: its fields, column, state and what can be done with it. */
  view(id, task = this.store.get(id)) {
    const { column, why } = this.placement(id, task);
    const v = {
      id,
      ...task,
      column,
      why,
      state: task.landing ? `landing: ${task.landing.phase}${task.landing.rounds ? ` · round ${task.landing.rounds + 1}` : ""}` : WHY_LABEL[why],
      approvable: approvable(task),
      canLand: column === "stopped" && !!task.threadId && !task.noWorktree && !task.landed && (!task.work || task.work.ahead > 0 || task.work.dirty > 0),
      waits: this.waits(id, task),
      ...(task.batch ? { members: this.members(id).map(([mid, t]) => ({ id: mid, number: t.number, title: t.title })) } : {}),
      starting: isStarting(task, task.thread),
      stakes: stakesOf(task, why),
      estimate: this.pacing.estimate(task),
      worktreeGone: !!task.threadId && !task.noWorktree && !!task.worktreePath && !existsSync(task.worktreePath),
    };
    v.note = noteOf(v);
    v.buttons = taskButtons(v, this.store.project(task.projectId));
    v.toggles = taskToggles(v);
    return v;
  }
}

/** A delivery error worth trying again later: the network, or the claude plugin not running or not answering. */
export function retryable(text) {
  return classifyError(text) === "network" || /not running|isn't running|unavailable|offline|timed? ?out|ECONNREFUSED|-32003|no hub|unknown tool|tool .*not found/i.test(String(text ?? ""));
}

/** A delivery error that says the thread isn't there (gone, or not known yet). */
export const threadNotFound = (text) => /no thread|thread .*not found|unknown thread|not found/i.test(String(text ?? ""));

function clock(iso) {
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}
