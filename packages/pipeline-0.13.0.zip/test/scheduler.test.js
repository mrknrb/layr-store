// The scheduler against a fake claude plugin (test/fakeClaude.js) and real git repositories in a temp folder: the
// whole flow without Claude usage. Run: node test/scheduler.test.js
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { createActions } from "../backend/actions.js";
import { Pipeline } from "../backend/pipeline.js";
import { Store } from "../backend/store.js";
import { registerTools } from "../backend/tools.js";
import { FakeClaude } from "./fakeClaude.js";

let failures = 0;
let passed = 0;
async function test(name, fn) {
  const t0 = Date.now();
  try {
    await fn();
    passed++;
    console.log(`ok   ${name} (${Date.now() - t0} ms)`);
  } catch (error) {
    failures++;
    console.log(`FAIL ${name}: ${error.stack || error.message}`);
  }
}
const assert = (cond, msg) => {
  if (!cond) throw new Error(msg || "assertion failed");
};
const eq = (a, b, msg) => assert(JSON.stringify(a) === JSON.stringify(b), `${msg}: ${JSON.stringify(a)} != ${JSON.stringify(b)}`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const tmp = mkdtempSync(path.join(os.tmpdir(), "layr-pipeline-test-"));
const git = (dir, ...args) => execFileSync("git", ["-C", dir, ...args], { stdio: ["ignore", "pipe", "pipe"] }).toString().trim();

function makeRepo(name) {
  const repo = path.join(tmp, name);
  execFileSync("git", ["init", "-q", "-b", "main", repo]);
  git(repo, "config", "user.name", "Test");
  git(repo, "config", "user.email", "test@example.com");
  writeFileSync(path.join(repo, "README.md"), "# Demo\n");
  git(repo, "add", ".");
  git(repo, "commit", "-q", "-m", "init");
  return repo;
}

function commitFile(dir, file, content, message) {
  mkdirSync(path.dirname(path.join(dir, file)), { recursive: true });
  writeFileSync(path.join(dir, file), content);
  git(dir, "add", file);
  git(dir, "commit", "-q", "-m", message);
}

/** What a worker does with a landing message: rebase onto main and squash into one commit. */
function rebaseSquash(dir, message = "Squashed") {
  git(dir, "rebase", "-q", "main");
  const ahead = Number(git(dir, "rev-list", "--count", "main..HEAD"));
  if (ahead > 1) {
    git(dir, "reset", "-q", "--soft", "main");
    git(dir, "commit", "-q", "-m", message);
  }
}

const DONE = "Did it.\n\nStatus: done · Risk: none · Try: none";

/** A fresh pipeline with a fake claude and one enabled project. */
async function setup({ maxRunning = 2, settings = {} } = {}) {
  const repo = makeRepo(`repo-${Math.random().toString(36).slice(2, 7)}`);
  const store = new Store(path.join(repo, "..", `data-${path.basename(repo)}`));
  const claude = new FakeClaude();
  const project = await claude.addProject(repo);
  const hub = { emit() {}, notify() {} };
  const logs = [];
  const p = new Pipeline({ store, claude, hub, logger: (...a) => logs.push(a.join(" ")) });
  const actions = createActions(p);
  store.setGlobal({ pollSec: 1, maxRunning });
  store.setProject(project.id, { enabled: true, baseBranch: "main", ...settings });
  await p.refreshProjects();
  p.start();
  /** Per-title worker behaviour: (thread, text, tools) → {reply, status?, error?}. */
  const behaviours = new Map();
  claude.worker = async (thread, text, tools) => {
    const dir = thread.cwd;
    if (/^(Land this task|Not ready to land|`main` moved on)/.test(text)) {
      rebaseSquash(dir);
      return { reply: "Rebased and squashed.\n\nStatus: done · Risk: none · Try: none" };
    }
    if (/^The checks failed/.test(text)) {
      writeFileSync(path.join(dir, "ok.flag"), "1");
      git(dir, "add", ".");
      git(dir, "commit", "-q", "--amend", "--no-edit");
      return { reply: "Fixed.\n\nStatus: done · Risk: none · Try: none" };
    }
    const title = /^Task #\d+: (.+)$/m.exec(text)?.[1] ?? thread.title?.replace(/^#\d+ /, "");
    const fn = behaviours.get(title) ?? behaviours.get("*");
    if (!fn) return { reply: DONE };
    return fn(thread, text, tools, dir);
  };
  const until = async (cond, what, ms = 15000) => {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      if (await cond()) return;
      p.wake();
      await sleep(60);
    }
    const tasks = store.entries().map(([id, t]) => `#${id} ${p.placement(id).why} ${JSON.stringify(t.thread ?? null).slice(0, 300)} held=${JSON.stringify(t.held ?? [])}`);
    throw new Error(`timed out: ${what} (logs: ${logs.slice(-5).join(" | ")})\n  ${tasks.join("\n  ")}`);
  };
  const col = (id) => p.placement(id).column;
  const why = (id) => p.placement(id).why;
  return { repo, store, claude, project, p, actions, behaviours, until, col, why, logs };
}

// ------------------------------------------------------------------------------------------------------------------

await test("propose, run, finish, land locally, settle", async () => {
  const s = await setup({ settings: { checks: 'node -e "process.exit(0)"' } });
  s.behaviours.set("Add hello", (t, text, tools, dir) => {
    commitFile(dir, "hello.txt", "hi\n", "Add hello.txt");
    return { reply: `Added hello.txt.\n\n## How to test\n1. cat hello.txt\n\n${DONE.split("\n\n")[1]}` };
  });
  const v = s.actions.create({ projectId: s.project.id, title: "Add hello", prompt: "add hello.txt with hi" });
  eq(v.column, "proposed", "a new task is proposed");
  s.actions.run(v.id);
  await s.until(() => s.col(v.id) === "stopped", "it finishes");
  const task = s.store.get(v.id);
  eq(s.why(v.id), "finished", "why");
  eq(task.thread.replyStatus, { status: "done", risks: [], try: "none" }, "status line parsed");
  assert(task.branch === "layr/1-add-hello", `branch ${task.branch}`);
  const start = s.claude.calls.find((c) => c[0] === "start")[1];
  assert(start.prompt.startsWith("Task #1: Add hello"), "launch message");
  eq(start.baseRef, "main", "worktree from the base branch");
  eq(task.work.ahead, 1, "one commit to land");
  assert(s.p.view(v.id).canLand, "Land shows");
  s.actions.land(v.id);
  await s.until(() => s.store.get(v.id).landed, "it lands");
  eq(s.why(v.id), "landed", "landed");
  assert(existsSync(path.join(s.repo, "hello.txt")), "the main checkout has hello.txt (ff merge)");
  eq(git(s.repo, "rev-parse", "main"), s.store.get(v.id).landed.commit, "main is the landed commit");
  // Ready to land as it was: no landing turn was needed.
  assert(!s.claude.calls.some((c) => c[0] === "send" && /^Land this task/.test(c[2])), "no rebase turn for a ready branch");
  s.actions.settle(v.id);
  eq(s.col(v.id), "settled", "settled");
  s.p.stop();
});

await test("the running cap queues the second task; Running order decides", async () => {
  const s = await setup({ maxRunning: 1 });
  let release;
  const gate = new Promise((r) => (release = r));
  s.behaviours.set("*", async (t, text, tools, dir) => {
    await gate;
    commitFile(dir, `${t.title.split(" ")[0].slice(1)}.txt`, "x", "work");
    return { reply: DONE };
  });
  const a = s.actions.create({ projectId: s.project.id, title: "First", run: false });
  const b = s.actions.create({ projectId: s.project.id, title: "Second" });
  const c = s.actions.create({ projectId: s.project.id, title: "Third" });
  s.actions.run(a.id);
  s.actions.run(b.id);
  s.actions.run(c.id);
  s.actions.reorder([a.id, c.id, b.id]);
  await s.until(() => s.store.get(a.id).threadId, "first launches");
  await sleep(400);
  eq(s.why(b.id), "queued", "second waits for a slot");
  assert(s.p.waits(b.id, s.store.get(b.id)).includes("waits for a slot"), "says why");
  release();
  await s.until(() => s.store.get(c.id).threadId, "third (higher in Running) launches next");
  assert(!s.store.get(b.id).threadId || s.store.get(c.id).threadId, "order respected");
  await s.until(() => s.col(b.id) === "stopped", "all finish");
  s.p.stop();
});

await test("a question waits for the user; the answer goes at once and the turn finishes", async () => {
  const s = await setup();
  s.behaviours.set("Ask me", async (t, text, tools, dir) => {
    const answer = await tools.ask([{ question: "Which colour?", options: [{ label: "Red" }, { label: "Blue" }] }]);
    commitFile(dir, "colour.txt", String(answer.answers?.["Which colour?"]), "colour");
    return { reply: DONE };
  });
  const v = s.actions.create({ projectId: s.project.id, title: "Ask me", run: true });
  await s.until(() => s.why(v.id) === "question", "it asks");
  eq(s.col(v.id), "stopped", "a question is in Stopped (Decide)");
  const pending = s.store.get(v.id).thread.pending;
  eq(pending.length, 1, "pending approval read from the thread");
  s.actions.answer(v.id, { requestId: pending[0].requestId, answers: { "Which colour?": "Blue" } });
  await s.until(() => s.why(v.id) === "finished", "it finishes after the answer");
  eq(readFileSync(path.join(s.store.get(v.id).worktreePath, "colour.txt"), "utf8"), "Blue", "the answer reached it");
  s.p.stop();
});

await test("Stop interrupts the turn; a message sends it back to Running", async () => {
  const s = await setup();
  s.behaviours.set("Slow", () => sleep(3000).then(() => ({ reply: DONE })));
  const v = s.actions.create({ projectId: s.project.id, title: "Slow", run: true });
  await s.until(() => s.why(v.id) === "running", "runs");
  await s.actions.stop(v.id);
  await s.until(() => s.why(v.id) === "interrupted", "stopped by you");
  s.behaviours.set("*", () => ({ reply: "Answered.\n\nStatus: done · Risk: none · Try: none" }));
  s.actions.message(v.id, "Carry on, quickly");
  await s.until(() => s.claude.calls.some((c) => c[0] === "send" && c[2] === "Carry on, quickly"), "message sent");
  await s.until(() => s.why(v.id) === "finished", "finishes");
  s.p.stop();
});

await test("Soft stop holds launches; Here lets them go", async () => {
  const s = await setup();
  s.p.setMode("stop");
  const v = s.actions.create({ projectId: s.project.id, title: "Held", run: true });
  await sleep(500);
  assert(!s.store.get(v.id).threadId, "nothing starts in Soft stop");
  assert(s.p.waits(v.id, s.store.get(v.id)).startsWith("Soft stop"), "says why");
  s.p.setMode("here");
  await s.until(() => s.col(v.id) === "stopped", "launched and finished in Here");
  s.p.stop();
});

await test("checks fail: the thread fixes it in a round, then it lands", async () => {
  const s = await setup({ settings: { checks: 'node -e "process.exit(require(\'fs\').existsSync(\'ok.flag\')?0:1)"' } });
  s.behaviours.set("Needs fix", (t, text, tools, dir) => {
    commitFile(dir, "f.txt", "f", "f");
    return { reply: DONE };
  });
  const v = s.actions.create({ projectId: s.project.id, title: "Needs fix", run: true });
  await s.until(() => s.why(v.id) === "finished", "finishes");
  s.actions.land(v.id);
  await s.until(() => s.store.get(v.id).landed, "lands after a fix round", 20000);
  assert(s.claude.calls.some((c) => c[0] === "send" && /^The checks failed/.test(c[2])), "checks failed message sent");
  assert(existsSync(path.join(s.repo, "ok.flag")), "the fix landed too");
  s.p.stop();
});

await test("the base moved: landing rebases in the thread; chains start after their parent lands", async () => {
  const s = await setup();
  s.behaviours.set("*", (t, text, tools, dir) => {
    const name = t.title.replace(/^#\d+ /, "").replace(/\W+/g, "-");
    commitFile(dir, `${name}.txt`, name, `${name} 1`);
    commitFile(dir, `${name}.txt`, `${name}!`, `${name} 2`);
    return { reply: DONE };
  });
  const a = s.actions.create({ projectId: s.project.id, title: "Alpha", run: true });
  const b = s.actions.create({ projectId: s.project.id, title: "Beta", run: true });
  const c = s.actions.create({ projectId: s.project.id, title: "Gamma", after: Number(a.id) });
  s.actions.run(c.id);
  await s.until(() => s.why(a.id) === "finished" && s.why(b.id) === "finished", "both finish");
  assert(!s.store.get(c.id).threadId, "Gamma waits for Alpha");
  eq(s.p.waits(c.id, s.store.get(c.id)), "Starts after #1 lands", "chain wait text");
  s.actions.land(a.id);
  await s.until(() => s.store.get(a.id).landed, "Alpha lands (squash turn first)");
  s.actions.land(b.id);
  await s.until(() => s.store.get(b.id).landed, "Beta lands after rebasing onto Alpha");
  await s.until(() => s.store.get(c.id).threadId, "Gamma launches once Alpha landed");
  const log = git(s.repo, "log", "--format=%s", "main");
  assert(/Squashed/.test(log), `squashed commits on main: ${log}`);
  assert(existsSync(path.join(s.repo, "Alpha.txt")) && existsSync(path.join(s.repo, "Beta.txt")), "both on main");
  const gammaStart = s.claude.calls.filter((c) => c[0] === "start").at(-1)[1];
  assert(/It builds on task #1 \(Alpha\)/.test(gammaStart.prompt), "Gamma's launch names its parent");
  s.p.stop();
});

await test("Plan: it plans first, Approve starts the work", async () => {
  const s = await setup();
  s.behaviours.set("Planned", (t, text, tools, dir) => {
    if (/^\*\*Start the work/.test(text)) {
      commitFile(dir, "p.txt", "p", "p");
      return { reply: DONE };
    }
    return { reply: "My plan: write p.txt.\n\nStatus: asks · Risk: none · Try: none" };
  });
  const v = s.actions.create({ projectId: s.project.id, title: "Planned", plan: true });
  await sleep(300);
  assert(!s.store.get(v.id).threadId && !s.store.get(v.id).held, "Plan is a toggle: nothing starts before Run");
  s.actions.run(v.id);
  await s.until(() => s.store.get(v.id).thread?.turnEndedAt && !s.store.get(v.id).thread.reacting, "plan turn ends");
  eq(s.col(v.id), "proposed", "a planning task stays in Proposed");
  eq(s.why(v.id), "question", "waits for the user");
  const launch = s.claude.calls.find((c) => c[0] === "start")[1].prompt;
  assert(/This task is in Plan mode/.test(launch), "plan lines in the launch");
  assert(s.p.view(v.id).approvable, "approvable");
  s.actions.approve(v.id, { text: "1A" });
  await s.until(() => s.store.get(v.id).work?.ahead === 1, "works after Approve");
  assert(!s.store.get(v.id).planning && !s.store.get(v.id).plan, "planning ends, the Plan toggle goes off");
  eq(s.why(v.id), "finished", "finished");
  s.p.stop();
});

await test("Plan + When away: Run plans now, it stays in Proposed, Approve waits in Ready until Away", async () => {
  const s = await setup();
  s.behaviours.set("Nightly", (t, text, tools, dir) => {
    if (/^\*\*Start the work/.test(text)) {
      commitFile(dir, "n.txt", "n", "n");
      return { reply: DONE };
    }
    return { reply: "Plan.\n\nStatus: asks · Risk: none · Try: none" };
  });
  const v = s.actions.create({ projectId: s.project.id, title: "Nightly", start: "plan", whenAway: true });
  eq(s.col(v.id), "proposed", "Plan with When away waits for Run, not in Ready");
  await sleep(300);
  assert(!s.store.get(v.id).threadId, "nothing runs by itself");
  s.actions.run(v.id);
  await s.until(() => s.why(v.id) === "question", "planned");
  eq(s.col(v.id), "proposed", "after its plan it is still in Proposed");
  assert(s.store.get(v.id).whenAway, "Run on a Plan task keeps When away (for its Approve)");
  const ids = s.p.view(v.id).buttons.map((b) => b.id);
  assert(ids.includes("approve") && !ids.includes("approve_away"), `one Approve: ${ids}`);
  s.actions.approve(v.id);
  eq(s.col(v.id), "ready", "Ready waits for Away");
  await sleep(300);
  eq(s.col(v.id), "ready", "still ready while Here");
  s.p.setMode("away");
  await s.until(() => s.store.get(v.id).work?.ahead === 1, "goes when Away");
  const sent = s.claude.calls.filter((c) => c[0] === "send").at(-1)[2];
  assert(/The user is away/.test(sent), "the away line goes with it");
  s.p.stop();
});

await test("batch: one thread, per-task report, skipped ones go back to Proposed", async () => {
  const s = await setup();
  s.behaviours.set("Small changes", (t, text, tools, dir) => {
    commitFile(dir, "one.txt", "1", "one");
    const n = [...text.matchAll(/^## #(\d+-\d+): /gm)].map((m) => m[1]);
    return { reply: `Done.\n\n#${n[0]} done\n#${n[1]} skipped: needs a decision\n\nStatus: done · Risk: none · Try: none` };
  });
  const a = s.actions.create({ projectId: s.project.id, title: "Tiny one", batch: true });
  const b = s.actions.create({ projectId: s.project.id, title: "Tiny two", batch: true });
  const batchId = s.store.get(a.id).inBatch;
  const batchNumber = s.store.get(batchId).number;
  assert(batchId && s.store.get(batchId).batch, "a batch was made");
  eq(s.store.get(b.id).inBatch, batchId, "both in the same open batch");
  eq([a.number, b.number], [`${batchNumber}-1`, `${batchNumber}-2`], "numbered in the batch");
  eq(s.store.counter, batchNumber, "no project numbers go to sub-tasks");
  // Task #88: a task made on its own doesn't go into a batch later.
  const loose = s.actions.create({ projectId: s.project.id, title: "On its own" });
  let joined = true;
  try {
    s.actions.edit(loose.id, { batch: true });
  } catch {
    joined = false;
  }
  assert(!joined && !s.store.get(loose.id).inBatch, "a proposal can't join a batch");
  s.actions.remove(loose.id);
  let refused = false;
  try {
    s.actions.run(a.id);
  } catch {
    refused = true;
  }
  assert(refused, "a member can't run alone");
  // Task #113: an open batch's sub-task is edited and deleted from the batch's Edit; once it has started, neither.
  const c = s.actions.create({ projectId: s.project.id, title: "Tiny three", batch: true });
  s.actions.edit(c.id, { title: "Tiny three, said again", prompt: "Its details" });
  eq([s.store.get(c.id).title, s.store.get(c.id).prompt], ["Tiny three, said again", "Its details"],
    "a sub-task edited");
  s.actions.remove(c.id);
  assert(!s.store.get(c.id), "a sub-task deleted");
  s.actions.run(batchId);
  await s.until(() => s.why(batchId) === "finished", "batch finishes");
  let changed = 0;
  for (const change of [() => s.actions.remove(b.id), () => s.actions.edit(b.id, { title: "Other" })]) {
    try {
      change();
      changed++;
    } catch {
      // refused, as it should be
    }
  }
  eq(changed, 0, "a started batch's sub-tasks can't change");
  eq(s.col(a.id), "stopped", "members share the batch's column");
  eq(s.store.get(batchId).batchReport.length, 2, "report read");
  s.actions.land(batchId);
  await s.until(() => s.store.get(batchId).landed, "batch lands");
  assert(s.store.get(a.id).landed, "done member landed");
  eq(s.col(b.id), "proposed", "skipped member back in Proposed");
  eq(s.store.get(b.id).skipped.why, "needs a decision", "with the reason");
  const back = s.store.get(b.id);
  eq(typeof back.number, "number", "with a project number of its own");
  eq(s.store.idOf(back.number), b.id, "found by it, its id kept");
  eq(s.store.idOf(`#${a.number}`), a.id, "a sub-task is found by #84-1");
  s.p.stop();
});

await test("verifier: a fix round, then pass, then auto-merge lands it", async () => {
  const s = await setup({ settings: { verify: "always" } });
  let verifies = 0;
  s.behaviours.set("Checked", (t, text, tools, dir) => {
    if (/verify/.test(t.title)) {
      verifies++;
      return { reply: verifies === 1 ? "Missing newline.\n\nVerdict: fix" : "Good.\n\nVerdict: pass" };
    }
    if (/asks for these fixes/.test(text)) {
      writeFileSync(path.join(dir, "c.txt"), "c\n");
      git(dir, "commit", "-q", "-am", "newline");
      return { reply: DONE };
    }
    commitFile(dir, "c.txt", "c", "c");
    return { reply: DONE };
  });
  s.behaviours.set("*", (...args) => s.behaviours.get("Checked")(...args));
  const v = s.actions.create({ projectId: s.project.id, title: "Checked", autoMerge: true, run: true });
  await s.until(() => s.store.get(v.id).landed, "lands after the verifier passes", 25000);
  eq(verifies, 2, "two verifier rounds");
  eq(s.store.get(v.id).verify.state, "passed", "passed");
  eq(readFileSync(path.join(s.repo, "c.txt"), "utf8").replace(/\r/g, ""), "c\n", "the fix landed (squashed)");
  s.p.stop();
});

await test("background work after the turn: running, holds the slot, lands only once it is done", async () => {
  const s = await setup({ maxRunning: 1, settings: { checks: 'node -e "process.exit(0)"' } });
  s.behaviours.set("Tests behind", (t, text, tools, dir) => {
    commitFile(dir, "bg.txt", "bg\n", "bg");
    return { reply: DONE, background: [{ id: "b1", type: "local_bash", description: "cargo test" }] };
  });
  const v = s.actions.create({ projectId: s.project.id, title: "Tests behind", autoMerge: true, run: true });
  await s.until(() => s.why(v.id) === "background", "its background work shows");
  const w = s.actions.create({ projectId: s.project.id, title: "Next", run: true });
  await sleep(600);
  eq(s.col(v.id), "running", "still running");
  assert(!s.store.get(v.id).landed && !s.store.get(v.id).landing, "no landing while it works");
  assert(!s.store.get(v.id).thread.turnEndedAt, "its turn's end isn't taken in yet");
  assert(!s.store.get(w.id).threadId, "the next task waits for the slot");
  s.claude.endBackground(s.store.get(v.id).threadId);
  await s.until(() => s.store.get(v.id).landed, "lands once the background work ends", 20000);
  await s.until(() => s.store.get(w.id).threadId, "the next task starts");
  s.p.stop();
});

await test("a usage limit queues a continue and holds the gate", async () => {
  const s = await setup({ settings: {} });
  let first = true;
  s.behaviours.set("*", () => {
    if (first) {
      first = false;
      return { status: "failed", error: "Claude AI usage limit reached" };
    }
    return { reply: DONE };
  });
  s.store.setGlobal({ limitBackoffMin: 1 });
  const v = s.actions.create({ projectId: s.project.id, title: "Limited", run: true });
  await s.until(() => s.store.get(v.id).held?.some((m) => m.kind === "continue"), "continue held");
  eq(s.why(v.id), "limit", "shows the limit");
  assert(s.store.state().limitUntil, "the gate is closed until the limit ends");
  // Let it go now (as if the minute passed).
  s.store.setState({ limitUntil: undefined });
  s.store.mutate(v.id, () => ({ resumeAt: undefined }));
  await s.until(() => s.why(v.id) === "finished", "continues and finishes");
  assert(s.claude.calls.some((c) => c[0] === "send" && /cut off/.test(c[2])), "continue message sent");
  s.p.stop();
});

await test("discard removes the worktree and branch; nothing to land settles", async () => {
  const s = await setup();
  s.behaviours.set("Nothing", () => ({ reply: "Looked, nothing to change.\n\nStatus: done · Risk: none · Try: none" }));
  s.behaviours.set("Throwaway", (t, text, tools, dir) => {
    commitFile(dir, "t.txt", "t", "t");
    return { reply: DONE };
  });
  const a = s.actions.create({ projectId: s.project.id, title: "Throwaway", run: true });
  const b = s.actions.create({ projectId: s.project.id, title: "Nothing", run: true });
  await s.until(() => s.why(a.id) === "finished" && s.why(b.id) === "finished", "both finish");
  const dir = s.store.get(a.id).worktreePath;
  assert(existsSync(dir), "worktree exists");
  await s.actions.discard(a.id);
  assert(!existsSync(dir), "worktree removed");
  assert(!git(s.repo, "branch", "--list", s.store.get(a.id).branch), "branch deleted");
  eq(s.col(a.id), "settled", "discarded is settled");
  s.actions.land(b.id);
  await s.until(() => s.col(b.id) === "settled", "nothing to land: settled");
  s.p.stop();
});

await test("tools: propose with duplicates, land guard refusals and agent landing on the user's word", async () => {
  const s = await setup();
  const handlers = new Map();
  registerTools({ registerTool: (name, def, fn) => handlers.set(name, fn) }, s.p, s.actions);
  const agent = { _meta: { "layr/caller": { kind: "agent", plugin: "claude", label: "t_agent" } } };
  const call = async (name, args, extra = agent) => {
    const r = await handlers.get(name)(args, extra);
    if (r.isError) throw new Error(r.content[0].text);
    return r.structuredContent;
  };
  for (const name of ["guide", "projects", "tasks", "task", "propose", "edit", "delete", "run", "send", "stop", "land", "settle", "unsettle", "state", "mode", "settings", "configure", "act", "board"]) {
    assert(handlers.has(name), `tool ${name}`);
  }
  const projects = await call("projects", {});
  eq(projects.projects[0].projectId, s.project.id, "projects lists it");
  const first = await call("propose", { title: "Add a greeting file", description: "Create greeting.txt", projectId: s.project.id });
  eq(first.proposed, false, "first call checks duplicates");
  const made = await call("propose", { title: "Add a greeting file", description: "Create greeting.txt", projectId: s.project.id, confirm: true, size: "S" });
  eq(made.column, "proposed", "proposed");
  const again = await call("propose", { title: "Add a greeting file", description: "Create greeting.txt please", projectId: s.project.id });
  eq(again.duplicates[0].number, made.number, "the duplicate is found");
  s.behaviours.set("Add a greeting file", (t, text, tools, dir) => {
    commitFile(dir, "migrations/001.sql", "create table x();", "migration");
    return { reply: "Added.\n\nStatus: done · Risk: database · Try: none" };
  });
  await call("edit", { number: made.number, start: "manual" });
  await call("run", { number: made.number }).then(
    () => assert(false, "agents can't run a manual task"),
    (e) => assert(/Only the user/.test(e.message), e.message),
  );
  await call("edit", { number: made.number, start: "either" });
  await call("run", { number: made.number });
  await s.until(() => s.why(String(made.number)) === "finished", "finishes");
  const noWords = await call("land", { number: made.number });
  eq(noWords.canLand, false, "needs words");
  const paths = await call("land", { number: made.number, words: "land #1" });
  assert(/always looks at first/.test(paths.why), `ask paths refuse: ${paths.why}`);
  await call("configure", { projectId: s.project.id, set: { askPaths: "" } });
  const risky = await call("land", { number: made.number, words: "land them all" });
  assert(/Risk: database/.test(risky.why), `risk refuses without naming: ${risky.why}`);
  const ok = await call("land", { number: made.number, words: `please land #${made.number}` });
  eq(ok.canLand, true, "named: may land");
  const landing = await call("land", { number: made.number, words: `please land #${made.number}`, confirm: true });
  eq(landing.landing, true, "landing");
  await s.until(() => s.store.get(String(made.number)).landed, "lands");
  eq(s.store.get(String(made.number)).landedFor.words, `please land #${made.number}`, "who asked is kept");
  const settings = await call("settings", { projectId: s.project.id });
  assert(settings.settings.find((x) => x.key === "askPaths").changed, "changed setting shown");
  await call("configure", { global: true, set: { maxRunning: 3 } });
  eq(s.store.global().maxRunning, 3, "global configure");
  await call("configure", { global: true, set: { maxRunning: 99 } }).then(
    () => assert(false, "out of range refused"),
    (e) => assert(/0 to 10/.test(e.message), e.message),
  );
  const state = await call("state", {});
  assert(/Running/.test(state.headline), state.headline);
  s.p.stop();
});

await test("thread events wake the pipeline instead of thread_wait", async () => {
  const s = await setup();
  const subscribed = [];
  s.p.hub = {
    available: true,
    emit() {},
    notify() {},
    call: async (name, args) => (subscribed.push([name, args.topic]), { topics: [args.topic] }),
  };
  // Polls far apart: only an event can make it see the turn end soon.
  s.store.setGlobal({ pollSec: 120 });
  eq(await s.p.listen(), true, "listening");
  eq(subscribed, [["layr__events_subscribe", "claude:threads"], ["layr__events_subscribe", "claude:approval"]], "topics");
  let heard = 0;
  s.claude.onEvent = (topic) => {
    heard++;
    s.p.heard(topic);
  };
  const v = s.actions.create({ projectId: s.project.id, title: "Evented", prompt: "do it" });
  s.actions.run(v.id);
  const end = Date.now() + 10000;
  while (s.col(v.id) !== "stopped" && Date.now() < end) await sleep(50);
  eq(s.why(v.id), "finished", "the turn's end was seen");
  assert(heard > 0, "thread events came");
  assert(!s.claude.calls.some((c) => c[0] === "wait"), "no thread_wait while events come");
  s.p.stop();
});

await test("without thread events it watches with thread_wait", async () => {
  const s = await setup();
  eq(await s.p.listen(), false, "no hub: not listening");
  s.behaviours.set("Waited", async () => (await sleep(600), { reply: DONE }));
  const v = s.actions.create({ projectId: s.project.id, title: "Waited", prompt: "do it" });
  s.actions.run(v.id);
  await s.until(() => s.col(v.id) === "stopped", "it finishes");
  assert(s.claude.calls.some((c) => c[0] === "wait"), "thread_wait used");
  s.p.stop();
});

await test("task threads' model and effort: the task's, else the project's, else the global ones", async () => {
  const s = await setup({ maxRunning: 4 });
  const startOf = async (title) => {
    await s.until(() => s.claude.calls.some((c) => c[0] === "start" && c[1].title?.endsWith(` ${title}`)), `${title} starts`);
    const a = s.claude.calls.find((c) => c[0] === "start" && c[1].title?.endsWith(` ${title}`))[1];
    return [a.model ?? "-", a.effort ?? "-"];
  };
  const launch = (title, extra = {}) => s.actions.run(s.actions.create({ projectId: s.project.id, title, prompt: "do it", ...extra }).id);
  // Nothing set anywhere: the claude plugin decides (the claude project's default model).
  launch("Nothing set");
  eq(await startOf("Nothing set"), ["-", "-"], "no model or effort given");
  s.store.setGlobal({ workerModel: "opus", workerEffort: "high" });
  launch("Global");
  eq(await startOf("Global"), ["opus", "high"], "the global values");
  s.store.setProject(s.project.id, { workerModel: "sonnet" });
  launch("Project model");
  eq(await startOf("Project model"), ["sonnet", "high"], "the project's model, the global effort");
  s.store.setProject(s.project.id, { workerModel: null, workerEffort: "low" });
  launch("Project empty");
  eq(await startOf("Project empty"), ["opus", "low"], "a project's null is the global value");
  launch("Own model", { model: "claude-haiku-4-5", effort: "max" });
  eq(await startOf("Own model"), ["claude-haiku-4-5", "max"], "the task's own model and effort win");
  s.p.stop();
});

await test("Start at: a proposal runs at its time (even Away with When away), a plan's go-ahead is sent then", async () => {
  const s = await setup();
  const soon = (ms) => new Date(Date.now() + ms).toISOString();
  s.behaviours.set("Timed", (t, text, tools, dir) => {
    commitFile(dir, "t.txt", "t", "t");
    return { reply: DONE };
  });
  const v = s.actions.create({ projectId: s.project.id, title: "Timed", whenAway: true, startAt: soon(1500) });
  assert(s.store.get(v.id).startAt, "the time is kept");
  eq(s.p.view(v.id).startAt, s.store.get(v.id).startAt, "the board gets it");
  s.p.setMode("away");
  await sleep(500);
  assert(!s.store.get(v.id).threadId && !s.claude.calls.some((c) => c[0] === "start"), "nothing starts before its time");
  await s.until(() => s.store.get(v.id).work?.ahead === 1, "it starts at its time");
  assert(!s.store.get(v.id).startAt, "the time is used up");
  eq(s.store.get(v.id).whenAway, undefined, "When away is off: it ran");
  // A planning task: at its time the thread gets "start the work".
  s.p.setMode("here");
  s.behaviours.set("Planned later", (t, text, tools, dir) => {
    if (/^\*\*Start the work/.test(text)) {
      commitFile(dir, "pl.txt", "p", "p");
      return { reply: DONE };
    }
    return { reply: "Plan.\n\nStatus: asks · Risk: none · Try: none" };
  });
  const w = s.actions.create({ projectId: s.project.id, title: "Planned later", plan: true });
  s.actions.run(w.id);
  await s.until(() => s.why(w.id) === "question", "planned");
  s.actions.edit(w.id, { startAt: soon(1500) });
  await sleep(500);
  assert(!s.store.get(w.id).work?.ahead, "the work waits for its time");
  await s.until(() => s.store.get(w.id).work?.ahead === 1, "the go-ahead is sent at its time");
  assert(!s.store.get(w.id).planning && !s.store.get(w.id).startAt, "planning ends, the time is used up");
  // Taking it back, the checks, and a time that finds nothing to start.
  const x = s.actions.create({ projectId: s.project.id, title: "Not yet", startAt: soon(60_000) });
  s.actions.edit(x.id, { startAt: null });
  assert(!s.store.get(x.id).startAt, "taken back");
  let error = "";
  try {
    s.actions.edit(x.id, { startAt: "2020-01-01 08:00" });
  } catch (e) {
    error = e.message;
  }
  assert(/later than now/.test(error), `a time in the past is refused: ${error}`);
  eq(s.actions.edit(x.id, { startAt: "08:00" }).startAt > new Date().toISOString(), true, "hh:mm is the next such time");
  s.actions.run(x.id);
  assert(!s.store.get(x.id).startAt, "Run takes the time back: it started");
  await s.until(() => s.col(x.id) === "stopped", "it finishes");
  s.store.mutate(x.id, () => ({ startAt: soon(-1000) }));
  s.p.dueStarts();
  assert(!s.store.get(x.id).startAt && /nothing is waiting/.test(s.store.get(x.id).stopNote ?? ""), `a time with nothing to start says so: ${s.store.get(x.id).stopNote}`);
  s.p.stop();
});

console.log(`${passed} passed, ${failures} failed`);
try {
  rmSync(tmp, { recursive: true, force: true, maxRetries: 3 });
} catch {
  // Windows may hold a file a moment longer
}
process.exit(failures ? 1 : 0);
