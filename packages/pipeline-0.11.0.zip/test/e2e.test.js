// The pipeline for real: a running `layr serve` with the claude and pipeline plugins linked, a temp git repository as
// the project, real Claude (haiku, a tiny task). It acts as the shell (creates a pipeline panel) and then as that
// panel (tools.call over the panel's WebSocket), the way the board does.
//   cd core; layr serve --port 4391 --token dev --home <tmp> --link ../plugins/claude --link ../plugins/pipeline
//   node test/e2e.test.js [ws://127.0.0.1:4391/_layr/ws?token=dev]
import { execFileSync } from "node:child_process";
import { existsSync, mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";

const shellUrl = process.argv[2] || "ws://127.0.0.1:4391/_layr/ws?token=dev";
let failures = 0;
const check = (ok, what, detail) => {
  console.log(`${ok ? "PASS" : "FAIL"} ${what}${detail ? ` — ${detail}` : ""}`);
  if (!ok) failures++;
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function connect(url) {
  const ws = new WebSocket(url);
  let next = 1;
  const waiting = new Map();
  const events = [];
  ws.onmessage = (m) => {
    const msg = JSON.parse(m.data);
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id);
      waiting.delete(msg.id);
      msg.error ? reject(new Error(msg.error.message)) : resolve(msg.result);
    } else if (msg.method === "event") events.push(msg.params);
  };
  const ready = new Promise((resolve, reject) => {
    ws.onopen = resolve;
    ws.onerror = () => reject(new Error(`Can't connect to ${url}`));
  });
  const rpc = (method, params = {}) =>
    new Promise((resolve, reject) => {
      const id = next++;
      waiting.set(id, { resolve, reject });
      ws.send(JSON.stringify({ jsonrpc: "2.0", id, method, params }));
    });
  return { ws, ready, rpc, events };
}

const shell = connect(shellUrl);
await shell.ready;
const created = await shell.rpc("panels.create", { plugin: "pipeline", panel: "board" });
const token = new URL(created.url).searchParams.get("layr");
const panel = connect(shellUrl.replace(/token=[^&]+/, `token=${token}`));
await panel.ready;
await panel.rpc("events.subscribe", { topic: "pipeline:changed" });
const run = async (tool, args = {}) => {
  const r = await panel.rpc("tools.call", { tool, args });
  if (r.isError) throw new Error(r.content?.[0]?.text ?? `${tool} failed`);
  return r.structuredContent ?? JSON.parse(r.content[0].text);
};

const tmp = mkdtempSync(path.join(os.tmpdir(), "layr-pipeline-e2e-"));
const repo = path.join(tmp, "hello-demo");
execFileSync("git", ["init", "-q", "-b", "main", repo]);
execFileSync("git", ["-C", repo, "config", "user.name", "Test"]);
execFileSync("git", ["-C", repo, "config", "user.email", "test@example.com"]);
writeFileSync(path.join(repo, "README.md"), "# Hello demo\n");
execFileSync("git", ["-C", repo, "add", "."]);
execFileSync("git", ["-C", repo, "commit", "-q", "-m", "init"]);

try {
  const added = await run("project_add", { path: repo, checks: "node -e \"require('fs').accessSync('hello.txt')\"" });
  const projectId = added.project.projectId;
  check(added.project.enabled && added.project.baseBranch === "main", "project added and enabled", projectId);
  await run("configure", { projectId, set: { workerModel: "haiku" } });
  const listed = await panel.rpc("tools.call", { plugin: "claude", tool: "projects_list", args: {} });
  check(JSON.stringify(listed).includes("hello-demo"), "the claude plugin has it as a project");

  const { task } = await run("create", {
    projectId,
    title: "Add hello.txt",
    prompt:
      "Create a file hello.txt containing exactly the word hi. Commit it on your branch with the message " +
      "'Add hello.txt'. Then reply with one short sentence and the status line.",
    run: true,
  });
  check(task.column === "running", "Run queues it", task.state);
  const number = task.number;
  let t;
  const until = async (cond, what, ms) => {
    for (const end = Date.now() + ms; Date.now() < end; ) {
      t = await run("task", { number });
      if (cond(t)) return true;
      await sleep(2000);
    }
    check(false, what, JSON.stringify(t).slice(0, 600));
    return false;
  };
  await until((x) => x.threadId, "the thread starts", 60_000);
  check(Boolean(t.threadId && t.branch === `layr/${number}-add-hello-txt`), "a worktree on its own branch", `${t.branch} ${t.worktree}`);
  const finished = await until((x) => x.column === "stopped", "the turn ends (haiku)", 300_000);
  if (finished) {
    check(t.state === "finished", "it finished", t.state);
    check(t.reply?.status === "done", "its status line is read", JSON.stringify(t.reply));
    check(t.work?.ahead === 1 && t.work?.dirty === 0, "one commit, clean", JSON.stringify(t.work));
    console.log(`  reply: ${String(t.lastReply).slice(0, 300).replace(/\n/g, " ⏎ ")}`);
    // The thread panel of the claude plugin opens from the task.
    const thread = await panel.rpc("tools.call", { plugin: "claude", tool: "thread_status", args: { thread: t.threadId } });
    check(!thread.isError, "the claude thread is there", thread.structuredContent?.thread?.title);

    await run("land", { number, user: true });
    await until((x) => x.landed, "it lands", 180_000);
    const main = execFileSync("git", ["-C", repo, "log", "--format=%s", "main"]).toString();
    check(existsSync(path.join(repo, "hello.txt")), "hello.txt is on main in the repository", main.split("\n")[0]);
    check(readFileSync(path.join(repo, "hello.txt"), "utf8").trim() === "hi", "with hi");
    await run("settle", { number });
    t = await run("task", { number });
    check(t.column === "settled", "settled");
  }
  const board = await run("board");
  check(board.status && /Running/.test(board.status.headline), "board status", board.status?.headline);
  check(panel.events.some((e) => e.topic === "pipeline:changed"), "the panel heard pipeline:changed");
} catch (error) {
  failures++;
  console.error("ERROR", error);
} finally {
  panel.ws.close();
  shell.ws.close();
}
console.log(`repo: ${repo}`);
console.log(failures ? `${failures} FAILED` : "ALL PASSED");
process.exit(failures ? 1 : 0);
