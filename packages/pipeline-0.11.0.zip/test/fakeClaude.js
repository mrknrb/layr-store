// A stand-in for the claude plugin with the same methods as backend/claude.js: threads whose turns are played by a
// test's `worker(thread, text)` function (which may change files and commit in the thread's real git worktree).
// Statuses, turns, approvals and worktrees behave like the real engine's, so the scheduler can't tell.
import { execFileSync } from "node:child_process";
import { mkdirSync } from "node:fs";
import path from "node:path";

let seq = 0;
const nid = (p) => `${p}_${(++seq).toString(36)}${Math.random().toString(36).slice(2, 6)}`;

export class FakeClaude {
  constructor() {
    this.projectsList = [];
    this.threads = new Map();
    this.worker = async () => ({ reply: "ok\n\nStatus: done · Risk: none · Try: none" });
    this.calls = [];
    this.delayMs = 30;
    /** (topic, data): what the real engine emits on the hub when a thread changes (`claude:threads`). */
    this.onEvent = null;
    /** claude__ask: ({prompt, system, model}) → {text}. */
    this.asker = async () => ({ text: "" });
    /** claude__usage's answer. */
    this.usageValue = {};
  }

  async projects() {
    return this.projectsList.map((p) => ({ ...p, exists: true }));
  }

  async addProject(dir, name) {
    const found = this.projectsList.find((p) => path.resolve(p.path) === path.resolve(dir));
    if (found) return found;
    const project = { id: nid("p"), name: name ?? path.basename(dir), path: path.resolve(dir) };
    this.projectsList.push(project);
    return project;
  }

  summary(t) {
    return {
      id: t.id,
      projectId: t.projectId,
      title: t.title,
      status: t.status,
      turns: t.turns,
      cwd: t.cwd,
      workspace: t.workspace,
      pendingApprovals: [...t.approvals.keys()],
      archived: t.archived,
      error: t.error,
      preview: t.preview,
      background: t.background ?? [],
      lastActivity: new Date().toISOString(),
    };
  }

  async start(args) {
    this.calls.push(["start", args]);
    const project = this.projectsList.find((p) => p.id === args.project);
    if (!project) throw new Error(`No project ${args.project}`);
    let workspace;
    if (args.workspace === "worktree") {
      const root = path.join(path.dirname(project.path), ".layr-worktrees");
      mkdirSync(root, { recursive: true });
      const folder = path.join(root, `${path.basename(project.path)}-${args.branch.replace(/[^\w-]+/g, "-")}`);
      const base = execFileSync("git", ["-C", project.path, "rev-parse", `${args.baseRef ?? "HEAD"}^{commit}`]).toString().trim();
      execFileSync("git", ["-C", project.path, "worktree", "add", "-q", "-b", args.branch, folder, base]);
      workspace = { kind: "worktree", path: folder, branch: args.branch, base };
    } else if (args.workspace && typeof args.workspace === "object") {
      workspace = { kind: "worktree", path: args.workspace.worktreePath, branch: null };
    } else {
      workspace = { kind: "project", path: project.path, branch: "main" };
    }
    const t = {
      id: nid("t"),
      projectId: project.id,
      title: args.title,
      model: args.model,
      permissionMode: args.permissionMode,
      allowedTools: args.allowedTools ?? [],
      images: args.images ?? [],
      status: "starting",
      turns: 0,
      cwd: workspace.path,
      workspace,
      approvals: new Map(),
      transcript: [],
      archived: false,
      error: null,
      waiters: new Set(),
      queue: [],
      preview: args.prompt.slice(0, 80),
    };
    this.threads.set(t.id, t);
    this.beginTurn(t, args.prompt);
    return this.summary(t);
  }

  beginTurn(t, text) {
    t.turns += 1;
    t.status = "running";
    t.error = null;
    t.transcript.push({ role: "user", text });
    const turn = t.turns;
    t.interrupted = false;
    setTimeout(() => void this.play(t, text, turn), this.delayMs);
  }

  async play(t, text, turn) {
    let out;
    try {
      out = await this.worker(this.summary(t), text, { ask: (q) => this.askQuestion(t, q) });
    } catch (error) {
      out = { status: "failed", error: String(error.message ?? error) };
    }
    if (t.turns !== turn || t.interrupted) return;
    if (out?.reply) t.transcript.push({ role: "assistant", text: out.reply });
    t.status = out?.status ?? "done";
    t.error = out?.error ?? null;
    t.background = out?.background ?? [];
    this.changed(t);
    const next = t.queue.shift();
    if (next) this.beginTurn(t, next);
  }

  /** The thread's background tasks end (the real engine's `background_tasks_changed` with none left). */
  endBackground(id) {
    const t = this.threads.get(id);
    t.background = [];
    this.changed(t);
  }

  /** The worker asks a question (AskUserQuestion): the turn waits for the answer. */
  askQuestion(t, questions) {
    return new Promise((resolve) => {
      const requestId = nid("r");
      t.approvals.set(requestId, { requestId, kind: "question", tool: "AskUserQuestion", questions, resolve });
      t.status = "waiting";
      this.changed(t);
    });
  }

  changed(t) {
    for (const w of [...t.waiters]) w();
    this.onEvent?.("claude:threads", { kind: "thread", thread: this.summary(t) });
  }

  async send(id, text, mode = "queue", images = []) {
    this.calls.push(["send", id, text, mode, images]);
    const t = this.threads.get(id);
    if (t.status === "running" || t.status === "waiting") {
      if (mode === "steer") t.transcript.push({ role: "user", text, steer: true });
      else t.queue.push(text);
      return { sent: mode === "steer" ? "steer" : "queued", thread: this.summary(t) };
    }
    this.beginTurn(t, text);
    return { sent: "turn", thread: this.summary(t) };
  }

  async interrupt(id) {
    this.calls.push(["interrupt", id]);
    const t = this.threads.get(id);
    if (t.status !== "running" && t.status !== "waiting") return { interrupted: false };
    t.interrupted = true;
    for (const a of t.approvals.values()) a.resolve({ decision: "deny" });
    t.approvals.clear();
    t.status = "interrupted";
    this.changed(t);
    return { interrupted: true };
  }

  async wait(id, timeoutSec) {
    this.calls.push(["wait", id]);
    const t = this.threads.get(id);
    const settled = () => t.status !== "running" && t.status !== "starting";
    if (settled()) return { thread: this.summary(t), timedOut: false };
    return new Promise((resolve) => {
      const done = (timedOut) => {
        clearTimeout(timer);
        t.waiters.delete(check);
        resolve({ thread: this.summary(t), timedOut });
      };
      const check = () => settled() && done(false);
      const timer = setTimeout(() => done(true), Math.min(timeoutSec, 5) * 1000);
      t.waiters.add(check);
    });
  }

  async status(id) {
    const t = this.threads.get(id);
    if (!t) return { thread: null, approvals: [] };
    return {
      thread: this.summary(t),
      approvals: [...t.approvals.values()].map(({ resolve: _, ...a }) => a),
    };
  }

  async list() {
    return [...this.threads.values()].map((t) => this.summary(t));
  }

  async lastReply(id) {
    const t = this.threads.get(id);
    let reply = null;
    for (const m of t.transcript) {
      if (m.role === "user" && !m.steer) reply = null;
      else if (m.role === "assistant") reply = m.text;
    }
    return reply;
  }

  async archive(id, archived = true) {
    const t = this.threads.get(id);
    if (t) t.archived = archived;
    return {};
  }

  async update() {
    return {};
  }

  async answer(id, { requestId, decision, answers, message }) {
    this.calls.push(["answer", id, requestId, decision, answers]);
    const t = this.threads.get(id);
    const a = t.approvals.get(requestId);
    if (!a) throw new Error(`Request ${requestId} is not waiting any more`);
    t.approvals.delete(requestId);
    t.status = "running";
    a.resolve({ decision, answers, message });
    return { answered: true };
  }

  async usage() {
    this.calls.push(["usage"]);
    return this.usageValue;
  }

  async ask(args) {
    this.calls.push(["ask", args]);
    return this.asker(args);
  }
}
