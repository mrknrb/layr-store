// The pipeline's panels in headless Chromium against a running `layr serve` (claude and pipeline linked), as the
// shell hosts them. Real Claude for one tiny task that asks a question (haiku), answered from Decide.
//   cd core; layr serve --port 4391 --token dev --home <tmp> --link ../plugins/claude --link ../plugins/pipeline
//   PLAYWRIGHT_DIR=C:\Users\mrknr\pwtools node test/panels.e2e.js [ws://127.0.0.1:4391/_layr/ws?token=dev]
// Screenshots go to plugins/pipeline/screenshots.
import { execFileSync } from "node:child_process";
import { mkdirSync, mkdtempSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(path.join(process.env.PLAYWRIGHT_DIR || "C:\\Users\\mrknr\\pwtools", "package.json"));
const { chromium } = require("playwright");
const shellUrl = process.argv[2] || "ws://127.0.0.1:4391/_layr/ws?token=dev";
const out = path.resolve(here, "..", "screenshots");
mkdirSync(out, { recursive: true });
let failures = 0;
const check = (ok, what, detail) => {
  console.log(`${ok ? "PASS" : "FAIL"} ${what}${detail ? ` — ${detail}` : ""}`);
  if (!ok) failures++;
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- the shell ----------
const ws = new WebSocket(shellUrl);
let next = 1;
const waiting = new Map();
const opened = [];
const notes = [];
ws.onmessage = (m) => {
  const msg = JSON.parse(m.data);
  if (msg.id && waiting.has(msg.id)) {
    const { resolve, reject } = waiting.get(msg.id);
    waiting.delete(msg.id);
    msg.error ? reject(new Error(msg.error.message)) : resolve(msg.result);
  } else if (msg.method === "event") {
    if (msg.params.topic === "shell:open") opened.push(msg.params.data);
    if (msg.params.topic === "shell:notify") notes.push(msg.params.data);
  }
};
await new Promise((resolve, reject) => {
  ws.onopen = resolve;
  ws.onerror = reject;
});
const rpc = (method, params = {}) =>
  new Promise((resolve, reject) => {
    const id = next++;
    waiting.set(id, { resolve, reject });
    ws.send(JSON.stringify({ jsonrpc: "2.0", id, method, params }));
  });
for (const topic of ["shell:open", "shell:notify"]) await rpc("events.subscribe", { topic }).catch(() => {});
await rpc("settings.set", { key: "theme", value: { mode: "dark" } });
await rpc("plugins.restart", { id: "pipeline" }).catch((e) => console.log("restart:", e.message));
await sleep(2500);

const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 });
const errors = [];
async function open(panel, params, size) {
  const created = await rpc("panels.create", { plugin: "pipeline", panel, params });
  const page = await context.newPage();
  if (size) await page.setViewportSize(size);
  page.on("pageerror", (e) => errors.push(`${panel}: ${e.message}`));
  page.on("console", (m) => m.type() === "error" && errors.push(`${panel}: ${m.text()}`));
  await page.goto(created.url);
  return page;
}
const shot = (page, name) => page.screenshot({ path: path.join(out, `${name}.png`) });

// A panel page to call tools with (the board's own connection).
const board = await open("board");
await board.waitForFunction(() => window.layr?.connected);
const run = (tool, args = {}) => board.evaluate(([t, a]) => window.layr.tools.run(t, a), [tool, args]);

// ---------- a project with tasks in several states ----------
const tmp = mkdtempSync(path.join(os.tmpdir(), "layr-pipeline-panels-"));
const repo = path.join(tmp, "panels-demo");
execFileSync("git", ["init", "-q", "-b", "main", repo]);
execFileSync("git", ["-C", repo, "config", "user.name", "Test"]);
execFileSync("git", ["-C", repo, "config", "user.email", "test@example.com"]);
writeFileSync(path.join(repo, "README.md"), "# Panels demo\n");
execFileSync("git", ["-C", repo, "add", "."]);
execFileSync("git", ["-C", repo, "commit", "-q", "-m", "init"]);

try {
  const { project } = await run("project_add", { path: repo });
  const projectId = project.projectId;
  // Permission mode default: its Write and git commands ask, so Decide shows the claude plugin's approvals.
  await run("configure", { projectId, set: { workerModel: "haiku", checks: "git status", workerPermissionMode: "default" } });
  await run("configure", { global: true, set: { maxRunning: 1 } });
  await run("mode", { mode: "stop" });
  const mk = (title, extra = {}) => run("create", { projectId, title, prompt: extra.prompt ?? `${title}.`, ...extra });
  const theme = (await mk("Add a dark theme switch", { prompt: "A switch in the header that flips dark and light.", start: "plan" })).task;
  const typo = (await mk("Fix a typo in the README", { batch: true })).task;
  await mk("Rename the helper module", { batch: true });
  await mk("Write a CHANGELOG", { after: theme.number, size: "S" });
  await mk("Only I start this one", { start: "manual", autoMerge: true });
  const ask = (await mk("Ask which greeting", {
    prompt:
      "First ask me which greeting to use, Hi or Hello, as a question in your reply, and stop without changing " +
      "anything. When I answer, write the chosen word into greeting.txt, commit it on your branch with git, and " +
      "reply with one sentence and the status line.",
    run: true,
  })).task;
  await board.reload();
  await board.locator(".card").first().waitFor();
  await sleep(500);
  await shot(board, "board-soft-stop");
  check((await board.locator(".card").count()) >= 5, "the board shows the cards", String(await board.locator(".card").count()));
  check(await board.locator('.column[data-column="running"] .card').count() === 1, "the run task waits in Running (Soft stop)");
  check(/Soft stop/.test(await board.locator(".infobar").textContent()), "the info bar says Soft stop");

  // Search by number.
  await board.fill(".search", `#${typo.number}`);
  await sleep(200);
  const found = await board.locator(".card").count();
  check(found === 1, "search #number finds the batch member's batch card or the task", String(found));
  await board.fill(".search", "");

  // Here: the question task launches (haiku), the Plan task plans.
  await board.click(".header .modes");
  await board.locator(".own-menu .item", { hasText: "Here" }).click();
  await board.waitForFunction(() => document.querySelector(".infobar")?.textContent?.includes("Running"), null, { timeout: 10_000 });
  const until = async (cond, what, ms) => {
    for (const end = Date.now() + ms; Date.now() < end; ) {
      const t = await run("task", { number: ask.number });
      if (cond(t)) return t;
      await sleep(2000);
    }
    check(false, what);
    return null;
  };
  const asking = await until((t) => t.column === "stopped", "the question task asks (haiku)", 240_000);
  check(asking?.reply?.status === "asks", "its reply asks (Status: asks)", JSON.stringify(asking?.reply));
  await board.reload();
  await board.locator(".card").first().waitFor();
  await sleep(400);
  await shot(board, "board-running");

  // Decide shows the question; answer it there.
  const decide = await open("decide", {}, { width: 520, height: 860 });
  await decide.locator(`[data-section="questions"] .card[data-id="${ask.id}"] .option`).first().waitFor({ timeout: 15_000 });
  await shot(decide, "decide-question");
  await decide.locator(`[data-section="questions"] .card[data-id="${ask.id}"] .option`, { hasText: "Hello" }).first().click();
  await decide.locator(`.card[data-id="${ask.id}"]`).getByRole("button", { name: "Send answers" }).click();
  // Its Write and git commands ask for permission: allow them from Decide as they come.
  let finished = null;
  let shotPermission = false;
  for (const end = Date.now() + 300_000; Date.now() < end; ) {
    const t = await run("task", { number: ask.number });
    if (t.column === "stopped" && !t.pending?.length && t.reply?.status === "done") {
      finished = t;
      break;
    }
    const allow = decide.getByRole("button", { name: "Always allow" });
    if (await allow.count()) {
      if (!shotPermission) {
        shotPermission = true;
        await shot(decide, "decide-permission");
      }
      await allow.first().click().catch(() => {});
      await sleep(800);
    } else await sleep(1500);
  }
  check(shotPermission, "the claude plugin's permission requests show in Decide");
  check(Boolean(finished), "answered from Decide, the turn finished", finished?.state);
  check(finished?.work?.ahead === 1, "with one commit", JSON.stringify(finished?.work));
  await sleep(800);
  await shot(decide, "decide-after");

  // The task panel: the report and its buttons; Open thread asks the shell for the claude thread panel.
  const task = await open("task", { task: String(ask.number) }, { width: 900, height: 900 });
  await task.locator(".task-head h1").waitFor();
  await task.locator(".reply").first().waitFor({ timeout: 15_000 });
  await shot(task, "task-finished");
  check(await task.getByRole("button", { name: "Land" }).count() === 1, "Land shows for a finished task with a commit");
  const before = opened.length;
  await task.getByRole("button", { name: "Open thread ↗" }).click();
  for (let i = 0; i < 30 && opened.length === before; i++) await sleep(100);
  const o = opened.at(-1);
  check(o?.plugin === "claude" && o?.panel === "thread", "Open thread opens the claude plugin's thread panel", o && `${o.plugin}.${o.panel}`);

  // Land from the task panel.
  task.on("dialog", (d) => d.accept());
  await task.getByRole("button", { name: "Land" }).click();
  const landed = await until((t) => t.landed, "it lands", 180_000);
  check(Boolean(landed), "landed from the task panel", landed?.landed);
  await sleep(800);
  await shot(task, "task-landed");

  // The new-task dialog, settings, light theme and a narrow board.
  await board.reload();
  await board.locator(".card").first().waitFor();
  await board.getByRole("button", { name: "New task" }).click();
  await board.locator(".dialog").waitFor();
  await board.fill(".dialog input.layr-input", "Show the version in the footer");
  await shot(board, "new-task-dialog");
  await board.getByRole("button", { name: "Save as proposal" }).click();
  await board.locator(".card", { hasText: "Show the version in the footer" }).waitFor();
  check(true, "a task made in the dialog shows on the board");
  const settings = await open("settings", {}, { width: 820, height: 900 });
  await settings.locator(".setting").first().waitFor();
  await shot(settings, "settings-global");
  await settings.locator(".tabs button", { hasText: "panels-demo" }).click();
  await settings.locator('.setting[data-key="checks"]').waitFor();
  await shot(settings, "settings-project");
  await rpc("settings.set", { key: "theme", value: { mode: "light" } });
  await sleep(600);
  await shot(board, "board-light");
  await board.setViewportSize({ width: 380, height: 760 });
  await sleep(300);
  await shot(board, "board-narrow");
  await rpc("settings.set", { key: "theme", value: { mode: "dark" } });
  await run("mode", { mode: "stop" });
  void theme;
} catch (error) {
  failures++;
  console.error("ERROR", error);
} finally {
  await browser.close();
  ws.close();
}
check(!errors.length, "no page errors", errors.slice(0, 5).join(" | "));
console.log(`screenshots in ${out}`);
console.log(failures ? `${failures} FAILED` : "ALL PASSED");
process.exit(failures ? 1 : 0);
