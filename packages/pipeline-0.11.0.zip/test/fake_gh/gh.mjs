#!/usr/bin/env node
// A fake GitHub CLI for the pipeline's tests (the pattern of core/layr_core/tests/fake_gh/gh.mjs): the `gh pr`
// subcommands `pr` landing uses, against the repository's `origin` remote (a local bare repository), never GitHub.
// State lives in FAKE_GH_DIR: state.json (pull requests) and log.jsonl (every call).
// FAKE_GH_REQUIRE_FILE: CI fails on a head commit without this file. FAKE_GH_REVIEW: a reviewDecision to report.
import { execFileSync } from "node:child_process";
import { appendFileSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const root = process.env.FAKE_GH_DIR;
if (!root) {
  console.error("FAKE_GH_DIR is not set");
  process.exit(2);
}
const args = process.argv.slice(2);
appendFileSync(path.join(root, "log.jsonl"), JSON.stringify({ args, cwd: process.cwd() }) + "\n");
const statePath = path.join(root, "state.json");
const state = existsSync(statePath) ? JSON.parse(readFileSync(statePath, "utf8")) : { prs: [] };
const save = () => writeFileSync(statePath, JSON.stringify(state, null, 2));
const git = (...a) => execFileSync("git", a, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }).trim();
const opt = (name) => {
  const i = args.indexOf(name);
  return i >= 0 ? args[i + 1] : undefined;
};
function fail(message, code = 1) {
  console.error(message);
  process.exit(code);
}
const remote = git("-C", process.cwd(), "remote", "get-url", "origin");
const bare = path.resolve(process.cwd(), remote);
const headOf = (branch) => {
  try {
    return git("-C", bare, "rev-parse", `refs/heads/${branch}`);
  } catch {
    return null;
  }
};
const find = (n) => state.prs.find((x) => x.number === Number(n)) ?? fail(`no pull request found for ${n}`);

const [cmd, sub] = args;
if (cmd !== "pr") fail(`fake gh: ${args.join(" ")} is not faked`);
if (sub === "list") {
  const head = opt("--head");
  const open = state.prs.filter((x) => x.head === head && x.state === "OPEN").map((x) => ({ number: x.number, url: x.url }));
  console.log(JSON.stringify(open.slice(0, Number(opt("--limit") ?? 30))));
} else if (sub === "create") {
  const head = opt("--head");
  if (!headOf(head)) fail(`pull request create failed: ${head} is not on the remote`);
  const number = state.prs.length + 1;
  const body = readFileSync(opt("--body-file"), "utf8");
  const pr = { number, url: `https://github.com/tester/demo/pull/${number}`, head, base: opt("--base"), title: opt("--title"), body, state: "OPEN" };
  state.prs.push(pr);
  save();
  console.log(`Creating pull request for ${head} into ${pr.base}\n\n${pr.url}`);
} else if (sub === "view") {
  const pr = find(args[2]);
  const head = headOf(pr.head);
  const need = process.env.FAKE_GH_REQUIRE_FILE;
  let ok = true;
  if (need && head) {
    try {
      git("-C", bare, "cat-file", "-e", `${head}:${need}`);
    } catch {
      ok = false;
    }
  }
  const base = headOf(pr.base);
  const behind = pr.state === "OPEN" && base && head && !isAncestor(base, head);
  console.log(
    JSON.stringify({
      number: pr.number,
      url: pr.url,
      state: pr.state,
      mergeStateStatus: behind ? "BEHIND" : "CLEAN",
      reviewDecision: process.env.FAKE_GH_REVIEW ?? "",
      statusCheckRollup: [{ __typename: "CheckRun", name: "ci", status: "COMPLETED", conclusion: ok ? "SUCCESS" : "FAILURE", detailsUrl: `${pr.url}/checks` }],
      headRefOid: pr.state === "MERGED" ? pr.mergedHead : head,
      mergeCommit: pr.mergeCommit ? { oid: pr.mergeCommit } : null,
    }),
  );
} else if (sub === "merge") {
  const pr = find(args[2]);
  if (pr.state !== "OPEN") fail("Pull request is not open");
  const head = headOf(pr.head);
  const match = opt("--match-head-commit");
  if (match && match !== head) fail("Head branch was modified. Review and try the merge again.");
  const base = headOf(pr.base);
  let commit = head;
  if (args.includes("--squash")) {
    const tree = git("-C", bare, "rev-parse", `${head}^{tree}`);
    commit = execFileSync("git", ["-C", bare, "commit-tree", tree, "-p", base, "-m", `${pr.title} (#${pr.number})`], {
      encoding: "utf8",
      env: { ...process.env, GIT_AUTHOR_NAME: "GitHub", GIT_AUTHOR_EMAIL: "noreply@github.com", GIT_COMMITTER_NAME: "GitHub", GIT_COMMITTER_EMAIL: "noreply@github.com" },
    }).trim();
  } else if (!isAncestor(base, head)) fail("Pull request is not mergeable");
  git("-C", bare, "update-ref", `refs/heads/${pr.base}`, commit, base);
  Object.assign(pr, { state: "MERGED", mergeCommit: commit, mergedHead: head });
  save();
  console.log(`✓ Merged pull request #${pr.number}`);
} else if (sub === "close") {
  const pr = find(args[2]);
  pr.state = "CLOSED";
  save();
  console.log(`✓ Closed pull request #${pr.number}`);
} else fail(`fake gh: pr ${sub} is not faked`);

function isAncestor(a, b) {
  try {
    git("-C", bare, "merge-base", "--is-ancestor", a, b);
    return true;
  } catch {
    return false;
  }
}
