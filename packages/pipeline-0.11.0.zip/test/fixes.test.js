// Pipeline 0.3.0's fixes and new tools against the fake claude plugin (test/fakeClaude.js) and real git repositories
// in a temp folder: who may do what (agents vs the user), usage limits' reset times, Stop, delivery retries, threads
// followed by id, guards, split, a thread in the wrong folder, After landing after a restart, cleanup, a task's
// thread tools for the claude plugin's panel, While away, Not landed, worktree removal and the Decide round. Run: node test/fixes.test.js
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { createActions } from "../backend/actions.js";
import { heldWaiting } from "../backend/columns.js";
import { Pipeline } from "../backend/pipeline.js";
import { Store } from "../backend/store.js";
import { registerTools } from "../backend/tools.js";
import { FakeClaude } from "./fakeClaude.js";

let failures = 0;
let passed = 0;
async function test(name, fn) {
  const t0 = Date.now();
  try {
    await fn();
    passed++;
    console.log(`ok   ${name} (${Date.now() - t0} ms)`);
  } catch (error) {
    failures++;
    console.log(`FAIL ${name}: ${error.stack || error.message}`);
  }
}
const assert = (cond, msg) => {
  if (!cond) throw new Error(msg || "assertion failed");
};
const eq = (a, b, msg) => assert(JSON.stringify(a) === JSON.stringify(b), `${msg}: ${JSON.stringify(a)} != ${JSON.stringify(b)}`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const refuses = async (promise, re, what) => {
  try {
    await promise;
  } catch (error) {
    assert(re.test(error.message), `${what}: ${error.message}`);
    return;
  }
  throw new Error(`${what}: not refused`);
};

const tmp = mkdtempSync(path.join(os.tmpdir(), "layr-pipeline-fixes-"));
const git = (dir, ...args) => execFileSync("git", ["-C", dir, ...args], { stdio: ["ignore", "pipe", "pipe"] }).toString().trim();
const DONE = "Did it.\n\nStatus: done · Risk: none · Try: ready";

function commitFile(dir, file, content, message) {
  mkdirSync(path.dirname(path.join(dir, file)), { recursive: true });
  writeFileSync(path.join(dir, file), content);
  git(dir, "add", file);
  git(dir, "commit", "-q", "-m", message);
}

async function setup({ settings = {}, global = {} } = {}) {
  const repo = path.join(tmp, `repo-${Math.random().toString(36).slice(2, 7)}`);
  execFileSync("git", ["init", "-q", "-b", "main", repo]);
  git(repo, "config", "user.name", "Test");
  git(repo, "config", "user.email", "test@example.com");
  commitFile(repo, "README.md", "# Demo\n", "init");
  const store = new Store(path.join(tmp, `data-${path.basename(repo)}`));
  const claude = new FakeClaude();
  const project = await claude.addProject(repo, "Demo");
  const logs = [];
  const p = new Pipeline({ store, claude, hub: { emit() {}, notify() {} }, logger: (...a) => logs.push(a.join(" ")) });
  const actions = createActions(p);
  store.setGlobal({ pollSec: 1, maxRunning: 3, briefs: false, ...global });
  store.setProject(project.id, { enabled: true, baseBranch: "main", ...settings });
  await p.refreshProjects();
  const handlers = new Map();
  registerTools({ registerTool: (name, def, fn) => handlers.set(name, fn) }, p, actions);
  const callers = {
    you: { _meta: { "layr/caller": { kind: "panel", plugin: "pipeline" } } },
    claudePanel: { _meta: { "layr/caller": { kind: "panel", plugin: "claude", instance: "p_x" } } },
    agent: { _meta: { "layr/caller": { kind: "agent", plugin: "claude", label: "t_agent" } } },
  };
  const call = async (name, args, who = "agent") => {
    const r = await handlers.get(name)(args, typeof who === "string" ? callers[who] : who);
    if (r.isError) throw new Error(r.content[0].text);
    return r.structuredContent;
  };
  p.start();
  const behaviours = new Map();
  claude.worker = async (thread, text, tools) => {
    const title = /^Task #\d+: (.+)$/m.exec(text)?.[1] ?? thread.title?.replace(/^#\d+ /, "");
    const fn = behaviours.get(title) ?? behaviours.get("*");
    return fn ? fn(thread, text, tools, thread.cwd) : { reply: DONE };
  };
  const until = async (cond, what, ms = 15000) => {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      if (await cond()) return;
      p.wake();
      await sleep(60);
    }
    const tasks = store.entries().map(([id, t]) => `#${id} ${p.placement(id).why} held=${JSON.stringify(t.held ?? [])} note=${t.stopNote ?? ""}`);
    throw new Error(`timed out: ${what} (logs: ${logs.slice(-5).join(" | ")})\n  ${tasks.join("\n  ")}`);
  };
  const why = (id) => p.placement(id).why;
  const create = (title, extra = {}) => actions.create({ projectId: project.id, title, prompt: `do ${title}`, ...extra });
  return { repo, store, claude, project, p, actions, call, behaviours, until, why, create, logs };
}

// ------------------------------------------------------------------------------------------------------------------

await test("1A-1D: the user's own calls, not flags; agents can't approve in advance or turn auto-merge on", async () => {
  const s = await setup();
  const v = s.create("Guarded");
  await refuses(s.call("edit", { number: 1, start: "agents" }), /user's approval/, "agent: start agents");
  await refuses(s.call("edit", { number: 1, autoMerge: true }), /only the user/, "agent: auto-merge on");
  await refuses(s.call("edit", { number: 1, user: true, start: "agents" }), /user's approval/, "a `user` flag is no way around it");
  await s.call("edit", { number: 1, start: "agents", autoMerge: true }, "you");
  eq([s.store.get(v.id).start, s.store.get(v.id).autoMerge], ["agents", true], "the user may");
  await s.call("edit", { number: 1, autoMerge: false });
  eq(s.store.get(v.id).autoMerge, false, "an agent may turn it off");
  // create: propose's checks.
  await refuses(s.call("create", { projectId: s.project.id, title: "X", autoMerge: true }), /only the user/, "create: auto-merge");
  await refuses(s.call("create", { projectId: s.project.id, title: "X", start: "agents" }), /user's approval/, "create: agents");
  const dup = await s.call("create", { projectId: s.project.id, title: "Guarded", prompt: "do Guarded" });
  eq([dup.created, dup.duplicates[0].number], [false, 1], "create: duplicates first");
  const made = await s.call("create", { projectId: s.project.id, title: "Guarded", prompt: "do Guarded", confirm: true });
  eq(made.task.source.kind, "agent", "an agent's task says so");
  await refuses(s.call("create", { projectId: s.project.id, title: "Locked", start: "manual", run: true, confirm: true }), /Only the user/, "create: run a manual one");
  // land: an agent needs the user's words; the user's own call lands.
  s.behaviours.set("*", (t, text, tools, dir) => (commitFile(dir, `${t.id}.txt`, "x", "work"), { reply: DONE }));
  const w = s.create("Wakes", { run: true });
  await s.until(() => s.why(w.id) === "finished", "finished");
  eq((await s.call("land", { number: Number(w.id), user: true })).canLand, false, "an agent's `user: true` is ignored");
  // 1D: a wake-up holds auto-merge.
  s.store.mutate(w.id, () => ({ autoMerge: true, wake: { at: new Date(Date.now() + 60e3).toISOString(), note: "ci" } }));
  eq(s.p.autoMergeDue(s.store.get(w.id)), false, "waits for its wake-up");
  s.store.mutate(w.id, () => ({ wake: undefined }));
  eq(s.p.autoMergeDue(s.store.get(w.id)), true, "then it may");
  s.store.mutate(w.id, () => ({ autoMerge: false }));
  await s.call("land", { number: Number(w.id) }, "you");
  await s.until(() => s.store.get(w.id).landed, "the user's Land lands it");
  s.p.stop();
});

await test("5A: a usage limit waits for its reset time and is no failed try", async () => {
  const s = await setup();
  let limits = 0;
  const resets = Math.floor(Date.now() / 1000) + 600;
  s.behaviours.set("*", () => {
    if (limits < 7) {
      limits++;
      return { status: "failed", error: `Claude AI usage limit reached|${resets}` };
    }
    return { reply: DONE };
  });
  const v = s.create("Limited", { run: true });
  await s.until(() => s.store.get(v.id).held?.some((m) => m.kind === "continue"), "a continue waits");
  const t = s.store.get(v.id);
  eq(t.resumeAt, new Date(resets * 1000 + 60e3).toISOString(), "the reset time from the error (and a minute)");
  eq(s.store.state().limitUntil, t.resumeAt, "the gate waits as long");
  eq(t.resumes, undefined, "no try counted");
  // Six more limits in a row: never "Stopped after 5 tries".
  for (let i = 0; i < 6; i++) {
    s.store.setState({ limitUntil: undefined });
    s.store.mutate(v.id, () => ({ resumeAt: undefined }));
    await s.until(() => s.store.get(v.id).limitWaits === i + 2 || s.why(v.id) === "finished", `limit ${i + 2}`);
  }
  s.store.setState({ limitUntil: undefined });
  s.store.mutate(v.id, () => ({ resumeAt: undefined }));
  await s.until(() => s.why(v.id) === "finished", "finishes after the limits");
  assert(!s.store.get(v.id).stopNote, "not stopped");
  // Without a time in the error, the account's full window says when.
  const until = new Date(Date.now() + 2 * 3600e3).toISOString();
  s.claude.usageValue = { limits: { fiveHour: { utilization: 100, resetsAt: until }, sevenDay: { utilization: 30, resetsAt: until } }, updatedAt: new Date().toISOString() };
  eq(await s.p.limits.resetAt("usage limit reached"), new Date(Date.parse(until) + 60e3).toISOString(), "from usage");
  s.claude.usageValue = { limits: { fiveHour: { utilization: 60, resetsAt: until } }, updatedAt: new Date().toISOString() };
  const fallback = Date.parse(await s.p.limits.resetAt("usage limit reached")) - Date.now();
  assert(fallback > 14 * 60e3 && fallback <= 15 * 60e3, `the back-off: ${fallback}`);
  s.p.stop();
});

await test("5B, 5D: Stop drops what waits for Away; a failed message blocks the later ones", async () => {
  const s = await setup();
  const v = s.create("Parked", { run: true });
  await s.until(() => s.why(v.id) === "finished", "finished");
  s.actions.message(v.id, "later", { away: true });
  eq(s.p.placement(v.id).column, "ready", "parked for Away");
  await s.actions.stop(v.id);
  eq(s.store.get(v.id).parked, undefined, "Stop dropped it: the next Away doesn't restart it");
  const held = [{ kind: "message", text: "a", failed: "x", at: "1" }, { kind: "message", text: "b", at: "2" }];
  eq(heldWaiting({ held }), [], "nothing after a failed message goes");
  eq(heldWaiting({ held: [held[1], held[0]] }).map((m) => m.text), ["b"], "what is before it goes");
  s.store.mutate(v.id, () => ({ held }));
  s.actions.message(v.id, "c");
  await s.until(() => s.claude.calls.filter((c) => c[0] === "send").length >= 1, "sent again");
  await s.until(() => !s.store.get(v.id).held?.length, "all three go");
  const sent = s.claude.calls.filter((c) => c[0] === "send").map((c) => c[2]);
  eq(sent.slice(0, 3), ["a", "b", "c"], "in order, the failed one first");
  s.p.stop();
});

await test("5C: a launch the claude plugin couldn't take tries again in 5 minutes", async () => {
  const s = await setup();
  const start = s.claude.start.bind(s.claude);
  let fails = 1;
  s.claude.start = async (args) => {
    if (fails-- > 0) throw new Error("fetch failed");
    return start(args);
  };
  const v = s.create("Retried", { run: true });
  await s.until(() => s.store.get(v.id).deliveryTries === 1, "the first try failed");
  const t = s.store.get(v.id);
  assert(t.held?.some((m) => m.kind === "launch") && !t.stopNote, "the launch stays, no note");
  const wait = Date.parse(t.resumeAt) - Date.now();
  assert(wait > 4 * 60e3 && wait <= 5 * 60e3, `in 5 minutes: ${wait}`);
  assert(/couldn't reach the claude plugin/.test(s.p.view(v.id).waits), s.p.view(v.id).waits);
  s.store.mutate(v.id, () => ({ resumeAt: undefined }));
  await s.until(() => s.why(v.id) === "finished", "launched on the next try");
  eq([s.store.get(v.id).deliveryTries, s.store.get(v.id).retryNote], [undefined, undefined], "cleared");
  s.p.stop();
});

await test("5C: a message whose thread wasn't found reads the thread, and goes again later while it is there", async () => {
  const s = await setup();
  const v = s.create("Not found", { run: true });
  await s.until(() => s.why(v.id) === "finished", "finished");
  const send = s.claude.send.bind(s.claude);
  let fails = 1;
  s.claude.send = async (...args) => {
    if (fails-- > 0) throw new Error("thread t_x not found");
    return send(...args);
  };
  await s.call("send", { number: 1, text: "Once more" }, "you");
  await s.until(() => s.store.get(v.id).deliveryTries === 1, "the first try failed");
  const t = s.store.get(v.id);
  assert(t.held?.some((m) => m.kind === "message") && !t.stopNote && !t.thread.missing, "it stays held, the thread is there");
  assert(/its thread wasn't found/.test(t.retryNote), t.retryNote);
  s.store.mutate(v.id, () => ({ resumeAt: undefined }));
  await s.until(() => s.claude.calls.some((c) => c[0] === "send" && c[2] === "Once more"), "sent on the next try");
  s.p.stop();
});

await test("Take Plan back on a planning thread; thread_task gives the stakes' level", async () => {
  const s = await setup();
  s.behaviours.set("Plans", () => ({ reply: "My plan.\n\n## Questions\n1. 6 🟠 Which?\n   - A. ⭐ This (80%) **ok**\n\nStatus: asks · Risk: database · Try: none" }));
  const v = s.create("Plans", { start: "plan", run: true });
  await s.until(() => s.store.get(v.id).threadId && s.why(v.id) === "question", "it planned and asks");
  assert(s.store.get(v.id).planning, "planning");
  const q = await s.call("thread_task", { thread: s.store.get(v.id).threadId }, "claudePanel");
  assert(["high", "medium", "low"].includes(q.stakes), `stakes is a level: ${JSON.stringify(q.stakes)}`);
  await s.call("edit", { number: 1, start: "either" }, "you");
  assert(!s.store.get(v.id).planning && s.store.get(v.id).threadId, "an ordinary task's thread now");
  await refuses(s.call("edit", { number: 1, start: "agents" }, "you"), /has started/, "start agents on a started task");
  await refuses(s.call("edit", { number: 1, plan: true }, "you"), /has started/, "Plan on a started task");
  s.p.stop();
});

await test("5E: a thread not in thread_list is asked by its id before it counts as gone", async () => {
  const s = await setup();
  const v = s.create("Old thread", { run: true });
  await s.until(() => s.why(v.id) === "finished", "finished");
  s.claude.list = async () => [];
  s.store.mutate(v.id, (t) => ({ thread: { ...t.thread, sig: "x" } }));
  await s.p.tick();
  eq(s.why(v.id), "finished", "still there");
  s.claude.threads.delete(s.store.get(v.id).threadId);
  await s.p.tick();
  eq(s.why(v.id), "missing", "gone once the plugin says so");
  s.p.stop();
});

await test("5F, 5I: release and discard guards", async () => {
  const s = await setup();
  s.behaviours.set("Slow", () => sleep(1500).then(() => ({ reply: DONE })));
  const v = s.create("Slow", { run: true });
  await s.until(() => s.why(v.id) === "running", "runs");
  await refuses(s.actions.discard(v.id), /stop it first/, "discard while running");
  const proposal = s.create("Never ran");
  await refuses(Promise.resolve().then(() => s.actions.release(proposal.id)), /no thread/, "release without thread");
  s.store.mutate(v.id, () => ({ landing: { phase: "checks", sentAt: new Date().toISOString() } }));
  await refuses(Promise.resolve().then(() => s.actions.release(v.id)), /landing/, "release while landing");
  s.store.mutate(v.id, () => ({ landing: undefined }));
  s.p.stop();
});

await test("5J: a task's thread never works in the project's own checkout", async () => {
  const s = await setup();
  const start = s.claude.start.bind(s.claude);
  s.claude.start = async (args) => start({ ...args, workspace: "project" });
  const v = s.create("Misplaced", { run: true });
  await s.until(() => s.store.get(v.id).stopNote, "stopped");
  assert(!s.store.get(v.id).threadId, "no thread kept");
  assert(/own checkout/.test(s.store.get(v.id).stopNote), s.store.get(v.id).stopNote);
  assert(s.claude.calls.some((c) => c[0] === "interrupt"), "its thread was stopped");
  eq(s.p.view(v.id).note, s.store.get(v.id).stopNote, "the card says why");
  s.p.stop();
});

await test("5K, 5L, 0.8.0: After landing at a restart fails; settled merged tasks lose their worktree, not their card", async () => {
  const s = await setup();
  const a = s.create("Restarted");
  s.store.mutate(a.id, () => ({ threadId: "t_x", afterLanding: { state: "running" } }));
  s.p.start();
  eq(s.store.get(a.id).afterLanding.state, "failed", "failed");
  assert(/restarted/.test(s.store.get(a.id).stopNote), "says why");
  s.store.remove(a.id);
  const b = s.create("No worktree", { noWorktree: true, run: true });
  s.behaviours.set("In base", (t, text, tools, dir) => (commitFile(dir, "in.txt", "x", "in base"), { reply: DONE }));
  s.behaviours.set("Kept", (t, text, tools, dir) => (commitFile(dir, "kept.txt", "x", "not landed"), { reply: DONE }));
  s.behaviours.set("Loose", (t, text, tools, dir) => (commitFile(dir, "loose.txt", "x", "loose"), { reply: DONE }));
  s.behaviours.set("Picked", (t, text, tools, dir) => (commitFile(dir, "picked.txt", "x", "picked"), { reply: DONE }));
  const c = s.create("In base", { run: true });
  const g = s.create("Picked", { run: true });
  const d = s.create("Kept", { run: true });
  const e = s.create("Loose", { run: true });
  await s.until(() => [b, c, d, e, g].every((x) => s.why(x.id) === "finished"), "all finish");
  git(s.repo, "merge", "-q", "--ff-only", s.store.get(c.id).branch);
  git(s.repo, "merge", "-q", "--no-edit", s.store.get(e.id).branch);
  commitFile(s.repo, "other.txt", "x", "main moves on");
  git(s.repo, "cherry-pick", s.store.get(g.id).branch);
  writeFileSync(path.join(s.store.get(e.id).worktreePath, "untracked.txt"), "mine");
  for (const x of [b, c, d, e, g]) s.actions.settle(x.id);
  const kept = s.create("Settled proposal");
  s.actions.settle(kept.id);
  await s.p.cleanup();
  eq([b, c, d, e, kept].map((x) => !!s.store.get(x.id)), [true, true, true, true, true], "every card stays");
  const cw = s.store.get(c.id);
  eq([existsSync(cw.worktreePath), !!cw.worktreeRemoved, s.p.view(c.id).worktreeGone], [false, true, true], "merged: its worktree goes");
  assert(!git(s.repo, "branch", "--list", cw.branch), "with its local branch");
  assert(!existsSync(s.store.get(g.id).worktreePath), "its commit on main as the same change (cherry-picked): it goes");
  assert(existsSync(s.store.get(d.id).worktreePath), "commits not on main: it stays");
  assert(existsSync(s.store.get(e.id).worktreePath), "an untracked file: it stays");
  // Branches & worktrees: what's left and why; Remove all that are safe removes nothing more.
  const list = await s.call("worktrees", { projectId: s.project.id }, "you");
  const why = Object.fromEntries(list.rows.map((r) => [r.task?.number, [r.kind, r.removable, r.why]]));
  eq(why[s.store.get(d.id).number], ["worktree", false, "its commits aren't on the base branch"], "unmerged");
  eq(why[s.store.get(e.id).number], ["worktree", false, "1 uncommitted or untracked file(s)"], "untracked");
  eq((await s.call("remove_worktree", { projectId: s.project.id, all: true }, "you")).removed, [], "nothing safe left");
  rmSync(path.join(s.store.get(e.id).worktreePath, "untracked.txt"));
  const one = await s.call("remove_worktree", { projectId: s.project.id, path: s.store.get(e.id).worktreePath }, "you");
  eq(one.removed.length, 1, "now it can go");
  await refuses(s.call("remove_worktree", { projectId: s.project.id, path: s.store.get(d.id).worktreePath }, "you").then((r) => {
    if (r.kept.length) throw new Error(r.kept[0].why);
  }), /aren't on the base branch/, "an unmerged one is never removed");
  // Off: nothing goes.
  s.store.setProject(s.project.id, { removeWorktrees: false });
  s.behaviours.set("Off", (t, text, tools, dir) => (commitFile(dir, "off.txt", "x", "off"), { reply: DONE }));
  const f = s.create("Off", { run: true });
  await s.until(() => s.why(f.id) === "finished", "finishes");
  git(s.repo, "merge", "-q", "--no-edit", s.store.get(f.id).branch);
  s.actions.settle(f.id);
  await s.p.cleanup();
  assert(existsSync(s.store.get(f.id).worktreePath), "Remove merged worktrees off: it stays");
  s.p.stop();
});

await test("0.8.0: landed tasks settle by themselves after the set days, not after you take them back", async () => {
  const s = await setup({ settings: { settleLandedAfterDays: 1 } });
  s.behaviours.set("*", (t, text, tools, dir) => (commitFile(dir, `${t.id}.txt`, "x", "work"), { reply: DONE }));
  const v = s.create("Landed", { run: true });
  await s.until(() => s.why(v.id) === "finished", "finished");
  const head = git(s.store.get(v.id).worktreePath, "rev-parse", "HEAD");
  const old = new Date(Date.now() - 2 * 86_400_000).toISOString();
  s.store.mutate(v.id, (t) => ({ landed: { commit: head, head, at: old }, thread: { ...t.thread, turnEndedAt: old } }));
  s.p.worktrees.settleLanded(Date.now() - 1.5 * 86_400_000);
  assert(!s.store.get(v.id).settledAt, "half a day after landing: not yet");
  s.p.worktrees.settleLanded();
  eq([s.store.get(v.id).settledBy, s.p.view(v.id).column], ["landed", "settled"], "two days after: settled");
  s.actions.unsettle(v.id);
  s.p.worktrees.settleLanded();
  assert(!s.store.get(v.id).settledAt, "unsettled by you: it stays");
  s.store.setProject(s.project.id, { settleLandedAfterDays: null });
  s.p.stop();
});

await test("thread_task and thread_action: the claude plugin's thread panel; send with images and answers by text", async () => {
  const s = await setup({ settings: { tryCommand: "npm run dev" } });
  s.behaviours.set("Asks", async (t, text, tools, dir) => {
    if (/^Look/.test(text)) return { reply: DONE };
    const answer = await tools.ask([{ question: "Which colour?", options: [{ label: "Red" }, { label: "Blue" }] }]);
    commitFile(dir, "c.txt", String(answer.answers?.["Which colour?"]), "colour");
    return { reply: DONE };
  });
  const v = s.create("Asks", { run: true });
  await s.until(() => s.why(v.id) === "question", "asks");
  const thread = s.store.get(v.id).threadId;
  eq(await s.call("thread_task", { thread: "t_nobody" }, "claudePanel"), { result: null }, "no task's thread");
  const q = await s.call("thread_task", { thread }, "claudePanel");
  eq([q.number, q.column, q.link], [1, "stopped", "layr://pipeline/task/1"], "the task");
  assert(/Which colour/.test(q.note), q.note);
  await s.call("send", { thread, answers: { "Which colour?": "Blue" } }, "claudePanel");
  await s.until(() => s.why(v.id) === "finished", "the answer went by the question's text");
  const done = await s.call("thread_task", { thread }, "claudePanel");
  eq(done.buttons.map((b) => b.id), ["land", "try", "settle", "brief"], "its buttons");
  assert(done.buttons.find((b) => b.id === "land").confirm.startsWith("Land #1 on main?"), "with what Land does");
  const png = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==";
  await s.call("send", { number: 1, text: "Look at this", images: [{ mediaType: "image/png", data: png }] }, "claudePanel");
  await s.until(() => s.claude.calls.some((c) => c[0] === "send" && c[2] === "Look at this" && c[4]?.length === 1), "the image went with it");
  await s.until(() => s.why(v.id) === "finished", "finished again");
  await refuses(s.call("thread_action", { thread, action: "land" }, "agent"), /user's buttons/, "agents can't press them");
  await s.call("thread_action", { thread, action: "land" }, "claudePanel");
  await s.until(() => s.store.get(v.id).landed, "Land from the thread panel");
  await s.call("thread_action", { thread, action: "settle" }, "claudePanel");
  eq(s.p.placement(v.id).column, "settled", "settled");
  await s.call("edit", { number: 1, tested: true }, "you");
  assert(s.store.get(v.id).tested, "Tested ✓");
  s.p.stop();
});

await test("While away, Not landed, ▶ Try needs a command, the Decide round", async () => {
  const s = await setup();
  s.behaviours.set("*", (t, text, tools, dir) => (commitFile(dir, `${t.id}.txt`, "x", "work"), { reply: DONE }));
  s.p.setMode("away");
  const v = s.create("Overnight", { run: true });
  await s.until(() => s.why(v.id) === "finished", "finished");
  s.p.setMode("here");
  const away = s.p.status().away;
  eq([away.landed, away.toTry, away.ask], [0, 1, 0], "one to try");
  const { branches } = await s.call("branches", { projectId: s.project.id }, "you");
  eq(branches.map((b) => [b.branch, b.ahead, b.task?.number]), [[s.store.get(v.id).branch, 1, 1]], "its branch isn't landed");
  assert(branches[0].worktree, "with its worktree");
  await refuses(s.call("try", { number: 1 }, "you"), /Try command/, "Try needs the project's command");
  const round = await s.call("decide_round", {}, "you");
  eq(round.tasks, [1], "what waits");
  const start = s.claude.calls.filter((c) => c[0] === "start").at(-1)[1];
  assert(/one numbered list/.test(start.prompt) && /#1 Overnight/.test(start.prompt), "the round's prompt");
  eq([start.permissionMode, start.allowedTools.includes("mcp__layr__pipeline__send")], ["dontAsk", true], "dontAsk, may answer");
  s.p.stop();
});

await test("Agent lands: the worker asks with pipeline__land, layr lands it after the turn only when all went well", async () => {
  const s = await setup();
  const asThread = (t) => ({ _meta: { "layr/caller": { kind: "agent", plugin: "claude", label: t.id } } });
  // Only the user turns it on; the launch message tells the worker how.
  await refuses(s.call("create", { projectId: s.project.id, title: "X", agentLands: true, confirm: true }), /only the user/, "agent: on");
  const asked = [];
  const behave = (reply, { land = true, dirty = false } = {}) => async (t, text, tools, dir) => {
    commitFile(dir, `${t.id}-${asked.length}.txt`, "x", "work");
    if (dirty) writeFileSync(path.join(dir, "loose.txt"), "x");
    if (land) asked.push(await s.call("land", { number: Number(/^Task #(\d+)/m.exec(text)?.[1] ?? t.title.slice(1)) }, asThread(t)));
    return { reply };
  };
  s.behaviours.set("Lands", behave(DONE));
  const a = s.create("Lands", { agentLands: true, run: true });
  await s.until(() => s.store.get(a.id).landed, "it lands after the turn");
  const start = s.claude.calls.find((c) => c[0] === "start")[1];
  assert(/Agent lands is on/.test(start.prompt) && /pipeline__land \{number: 1\}/.test(start.prompt), "the launch message says so");
  eq(asked[0].landWanted, true, "the tool only notes it");
  assert(s.store.get(a.id).agentAskedLand && !s.store.get(a.id).landWanted, "used up, and the card knows the agent asked");
  // Status: partial: it doesn't land even though the agent asked.
  s.behaviours.set("Partial", behave("Half.\n\nStatus: partial · Risk: none · Try: none"));
  const b = s.create("Partial", { agentLands: true, run: true });
  await s.until(() => s.why(b.id) === "finished" || s.store.get(b.id).landed, "partial ends");
  await sleep(300);
  assert(!s.store.get(b.id).landed && !s.store.get(b.id).held?.length, "partial: not landed");
  // A risky Risk: not landed.
  s.behaviours.set("Risky", behave("Did it.\n\nStatus: done · Risk: Database · Try: ready"));
  const c = s.create("Risky", { agentLands: true, run: true });
  await s.until(() => s.why(c.id) === "finished" || s.store.get(c.id).landed, "risky ends");
  await sleep(300);
  assert(!s.store.get(c.id).landed && !s.store.get(c.id).held?.length, "risky: not landed");
  // The agent didn't ask: nothing lands.
  s.behaviours.set("Quiet", behave(DONE, { land: false }));
  const d = s.create("Quiet", { agentLands: true, run: true });
  await s.until(() => s.why(d.id) === "finished", "quiet ends");
  await sleep(300);
  assert(!s.store.get(d.id).landed && !s.store.get(d.id).held?.length, "not asked: not landed");
  // Agent lands off: the worker's own call is refused as before.
  s.behaviours.set("Off", behave(DONE));
  const e = s.create("Off", { run: true });
  await s.until(() => s.why(e.id) === "finished", "off ends");
  eq(asked.at(-1).canLand, false, "off: refused");
  assert(/Agent lands is off/.test(asked.at(-1).why), "off: says why");
  assert(!s.store.get(e.id).landed, "off: not landed");
  // An asked-for land from an earlier turn doesn't count for a later one.
  s.store.mutate(d.id, () => ({ landWanted: { at: new Date(Date.parse(s.store.get(d.id).thread.turnStartedAt) - 1000).toISOString() } }));
  eq(s.p.agentLandDue(s.store.get(d.id)), false, "an old request is stale");
  // Verify: autoMerge checks a task its agent lands, once the agent asked (and lands it only once it passed).
  s.store.setProject(s.project.id, { verify: "autoMerge" });
  eq(s.p.verifyDue(s.store.get(d.id)), false, "verify: not asked, not checked");
  s.store.mutate(d.id, () => ({ landWanted: { at: new Date().toISOString() } }));
  eq([s.p.verifyDue(s.store.get(d.id)), s.p.agentLandDue(s.store.get(d.id))], [true, false], "verify: asked, checked first");
  s.store.mutate(d.id, (t) => ({ verify: { state: "passed", head: t.work.head } }));
  eq(s.p.agentLandDue(s.store.get(d.id)), true, "verify: passed, it may land");
  s.p.stop();
});

await test("new task defaults: the project's, else the global ones; auto-merge and agent lands for every new task", async () => {
  const s = await setup();
  const newTask = async () => (await s.call("projects", {}, "you")).projects.find((x) => x.projectId === s.project.id).newTask;
  eq(await newTask(), { plan: false, whenAway: false, start: "either", worktree: true, autoMerge: false, agentLands: false }, "the defaults");
  await s.call("configure", { global: true, set: { newPlan: true, newWhenAway: true, newStart: "manual", agentLands: true } }, "you");
  eq(await newTask(), { plan: true, whenAway: true, start: "manual", worktree: true, autoMerge: false, agentLands: true }, "global values");
  await s.call("configure", { projectId: s.project.id, set: { newWhenAway: false, newWorktree: false, autoMerge: true, newStart: "" } }, "you");
  eq(await newTask(), { plan: true, whenAway: false, start: "manual", worktree: false, autoMerge: true, agentLands: true }, "the project's win; empty is global");
  await refuses(s.call("configure", { projectId: s.project.id, set: { newPlan: "yes" } }, "you"), /true or false/, "on/off only");
  // Auto-merge and agent lands reach tasks made without the dialog; the dialog's toggles don't.
  const a = s.create("Defaults");
  eq([!!s.store.get(a.id).autoMerge, !!s.store.get(a.id).agentLands, !!s.store.get(a.id).plan], [true, true, false], "create takes the landing defaults");
  await s.call("configure", { projectId: s.project.id, reset: ["autoMerge"], set: { agentLands: false } }, "you");
  const b = s.create("Defaults 2");
  eq([!!s.store.get(b.id).autoMerge, !!s.store.get(b.id).agentLands], [false, false], "reset: the global value; a saved off stays off");
  s.p.stop();
});

await test("titles (#99-2): no title takes the first line, a small model writes a short one; a title by hand stays", async () => {
  const s = await setup();
  const asked = [];
  let release;
  const gate = new Promise((r) => (release = r));
  s.claude.asker = async (a) => {
    asked.push(a);
    if (/Keep this one/.test(a.prompt)) await gate;
    return { text: /Batch one/.test(a.prompt) ? '"Fix batch sub-task numbers."' : "Short title" };
  };
  const a = await s.call("create", { projectId: s.project.id, prompt: "when i click on the batches in the table nothing opens\nmore" }, "you");
  eq(s.store.get(a.task.id).titleAuto, true, "marked as written for it");
  await s.until(() => s.store.get(a.task.id).title === "Short title", "the model's title replaces the first line");
  eq([asked[0].model, asked[0].effort], ["haiku", "low"], "haiku, effort low");
  // You change the title while the model writes: yours stays.
  const b = await s.call("create", { projectId: s.project.id, prompt: "Keep this one: the user renames it meanwhile" }, "you");
  await s.until(() => asked.length === 2, "asked for b");
  await s.call("edit", { number: b.task.number, title: "Mine" }, "you");
  release();
  await sleep(50);
  eq([s.store.get(b.task.id).title, s.store.get(b.task.id).titleAuto], ["Mine", undefined], "a title by hand stays");
  // A batch's sub-tasks without titles get theirs; one with a title keeps it.
  const batch = await s.call("create", { projectId: s.project.id, title: "Batch", tasks: [{ description: "Batch one: the numbers" }, { title: "Given", description: "x" }] }, "you");
  const n = batch.task.number;
  await s.until(() => s.store.get(`${n}-1`)?.title === "Fix batch sub-task numbers", "a sub-task's title, unquoted, no full stop");
  eq(s.store.get(`${n}-2`).title, "Given", "a given title stays");
  // New title (⋯ menu) writes over a title by hand.
  await s.call("edit", { number: b.task.number, retitle: true }, "you");
  await s.until(() => s.store.get(b.task.id).title === "Short title", "New title");
  await refuses(s.call("create", { projectId: s.project.id }, "you"), /title or a description/, "neither title nor description");
  s.p.stop();
});

await test("controversial (#99-3): the user's mark, on any task, on and off", async () => {
  const s = await setup();
  const v = s.create("Arguable");
  await s.call("edit", { number: v.number, controversial: true }, "you");
  assert(typeof s.store.get(v.id).controversial === "string", "marked with when");
  await s.call("edit", { number: v.number, controversial: false }, "you");
  eq(s.store.get(v.id).controversial, undefined, "unmarked");
  s.p.stop();
});

console.log(`${passed} passed, ${failures} failed`);
try {
  rmSync(tmp, { recursive: true, force: true, maxRetries: 3 });
} catch {
  // Windows may hold a file a moment longer
}
process.exit(failures ? 1 : 0);
