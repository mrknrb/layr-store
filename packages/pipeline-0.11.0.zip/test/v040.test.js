// Pipeline 0.4.0 against the fake claude plugin (test/fakeClaude.js), a fake hub (the concepts plugin's tools,
// layr__keep_awake, layr__supabase_session) and real git in a temp folder: the project node in launch messages, tasks
// linked to concept nodes and their Status following, "needs" chains, layr_code's import (mapping with fixtures and
// the tool), archive settles, checkout drift, two tasks without a worktree in one gate pass, the ready-made rounds,
// keep awake, and the concepts plugin's access to tasks / task. Run: node test/v040.test.js
import { execFileSync } from "node:child_process";
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createActions } from "../backend/actions.js";
import { chainFromNeeds, landedNote, projectMapLines, sourceNodes, sourcesLine } from "../backend/concepts.js";
import { folderKey, mapGlobal, mapProject, modelId, planImport, readLayrCode } from "../backend/importer.js";
import { Pipeline } from "../backend/pipeline.js";
import { launchMessage } from "../backend/prompts.js";
import { projectDefaults } from "../backend/settings.js";
import { Store } from "../backend/store.js";
import { registerTools } from "../backend/tools.js";
import { FakeClaude } from "./fakeClaude.js";

const here = path.dirname(fileURLToPath(import.meta.url));
let failures = 0;
let passed = 0;
async function test(name, fn) {
  const t0 = Date.now();
  try {
    await fn();
    passed++;
    console.log(`ok   ${name} (${Date.now() - t0} ms)`);
  } catch (error) {
    failures++;
    console.log(`FAIL ${name}: ${error.stack || error.message}`);
  }
}
const assert = (cond, msg) => {
  if (!cond) throw new Error(msg || "assertion failed");
};
const eq = (a, b, msg) => assert(JSON.stringify(a) === JSON.stringify(b), `${msg}: ${JSON.stringify(a)} != ${JSON.stringify(b)}`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const refuses = async (promise, re, what) => {
  try {
    await promise;
  } catch (error) {
    assert(re.test(error.message), `${what}: ${error.message}`);
    return;
  }
  throw new Error(`${what}: not refused`);
};

const tmp = mkdtempSync(path.join(os.tmpdir(), "layr-pipeline-040-"));
const git = (dir, ...args) => execFileSync("git", ["-C", dir, ...args], { stdio: ["ignore", "pipe", "pipe"] }).toString().trim();
const DONE = "Did it.\n\nStatus: done · Risk: none · Try: ready";
const NODE_A = "aaaaaaaa-1111-4111-8111-111111111111";
const NODE_B = "bbbbbbbb-2222-4222-8222-222222222222";
const MAP = {
  node: "cccccccc-3333-4333-8333-333333333333",
  title: "Demo app",
  sections: { rules: "r1", brainstorm: "b1", features: "ffffffff-4444-4444-8444-444444444444", plan: "p1", inbox: "iiiiiiii-5555-4555-8555-555555555555" },
  rules: { rules: ["Never change the database without a yes."] },
  workerRules: { rules: ["Never change the database without a yes."], features: ["One node per feature."] },
  missing: [],
};

function commitFile(dir, file, content, message) {
  mkdirSync(path.dirname(path.join(dir, file)), { recursive: true });
  writeFileSync(path.join(dir, file), content);
  git(dir, "add", file);
  git(dir, "commit", "-q", "-m", message);
}

/** A hub with the concepts plugin's tools (`concepts: false`: without it), layr__keep_awake (`keepAwake: false`: an older core). */
function fakeHub({ concepts = true, keepAwake = true, answers = {} } = {}) {
  const calls = [];
  const names = ["nodes", "search", "link", "relink", "advance_status", "needs", "linked_nodes", "project_map", "setup_project_map"];
  return {
    available: true,
    calls,
    emit() {},
    notify() {},
    called: (name) => calls.filter((c) => c[0] === name).map((c) => c[1]),
    async call(name, args) {
      calls.push([name, args]);
      if (answers[name]) return answers[name](args);
      if (name === "layr__plugins_list") return { plugins: concepts ? [{ id: "concepts", status: "running", tools: names.map((n) => ({ name: n })) }] : [] };
      if (name === "layr__keep_awake" && keepAwake) return { on: args.on };
      if (name === "layr__status_set") return null;
      if (name === "concepts__project_map") return MAP;
      if (name === "concepts__link") return { linked: args.nodes.length, nodes: args.nodes };
      if (name.startsWith("concepts__")) return {};
      throw new Error(`unknown tool ${name}`);
    },
  };
}

async function setup({ settings = {}, global = {}, hub = fakeHub() } = {}) {
  const repo = path.join(tmp, `repo-${Math.random().toString(36).slice(2, 7)}`);
  execFileSync("git", ["init", "-q", "-b", "main", repo]);
  git(repo, "config", "user.name", "Test");
  git(repo, "config", "user.email", "test@example.com");
  commitFile(repo, "README.md", "# Demo\n", "init");
  const store = new Store(path.join(tmp, `data-${path.basename(repo)}`));
  const claude = new FakeClaude();
  const project = await claude.addProject(repo, "Demo");
  const logs = [];
  const p = new Pipeline({ store, claude, hub, logger: (...a) => logs.push(a.join(" ")) });
  const actions = createActions(p);
  store.setGlobal({ pollSec: 1, maxRunning: 3, briefs: false, ...global });
  store.setProject(project.id, { enabled: true, baseBranch: "main", ...settings });
  await p.refreshProjects();
  const handlers = new Map();
  registerTools({ registerTool: (name, def, fn) => handlers.set(name, fn) }, p, actions);
  const callers = {
    you: { _meta: { "layr/caller": { kind: "panel", plugin: "pipeline" } } },
    agent: { _meta: { "layr/caller": { kind: "agent", plugin: "claude", label: "t_agent" } } },
  };
  const call = async (name, args, who = "agent") => {
    const r = await handlers.get(name)(args, callers[who]);
    if (r.isError) throw new Error(r.content[0].text);
    return r.structuredContent;
  };
  p.start();
  const behaviours = new Map();
  claude.worker = async (thread, text, tools) => {
    const title = /^Task #\d+: (.+)$/m.exec(text)?.[1] ?? thread.title?.replace(/^#\d+ /, "");
    const fn = behaviours.get(title) ?? behaviours.get("*");
    return fn ? fn(thread, text, tools, thread.cwd) : { reply: DONE };
  };
  const until = async (cond, what, ms = 15000) => {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      if (await cond()) return;
      p.wake();
      await sleep(60);
    }
    throw new Error(`timed out: ${what} (logs: ${logs.slice(-5).join(" | ")})`);
  };
  const why = (id) => p.placement(id).why;
  const create = (title, extra = {}) => actions.create({ projectId: project.id, title, prompt: `do ${title}`, ...extra });
  return { repo, store, claude, project, p, actions, call, behaviours, until, why, create, logs, hub };
}

const link = (id) => `layr://concepts/node/${id}`;

// ------------------------------------------------------------------------------------------------------------------

await test("6: layr_code's settings map to this layr's (fixtures)", async () => {
  const fixture = JSON.parse(readFileSync(path.join(here, "fixtures", "layr_code-records.json"), "utf8"));
  const project = fixture.find((r) => r.id === "project:t3-demo").data;
  const mapped = mapProject(project);
  eq(mapped.landing, "push", "direct → push");
  eq(mapped.workerModel, "claude-opus-4-5", "a T3 model ref → its model id");
  eq(mapped.workerEffort, "high", "workerOptions.effort");
  eq(mapped.workerPermissionMode, "bypassPermissions", "full-access → bypassPermissions");
  eq([mapped.laneRun, mapped.laneTimeoutMin], ["npm run dev", 25], "the lane's fields");
  eq([mapped.projectNode, mapped.featureMap], [NODE_A, NODE_B], "project node and feature map ids");
  eq([mapped.icon, mapped.color], ["🚀", "#0090ff"], "icon emoji and colour name → swatch");
  eq(mapped.orchestratorWake, "asked", "policy.wake");
  eq(mapped.verifierModel, undefined, "a Codex model isn't a Claude model: left out");
  eq(modelId({ instanceId: "claudeAgent", model: "opus" }), "opus", "an alias stays");
  eq(mapProject({ landing: "pr" }).landing, "pr", "pr stays pr");
  eq(mapProject({ icon: { image: "data:…", source: "x.png" } }).icon, undefined, "an image icon is left out");
  eq(mapGlobal({ maxCoders: 4, keepAwake: false, night: { mode: "away" } }), { maxRunning: 4, keepAwake: false }, "global: maxCoders, no mode");
  eq(folderKey("C:\\Work\\Demo\\"), folderKey("c:/work/demo"), "folders compare loosely");

  const plan = planImport({
    records: fixture,
    projects: [
      { projectId: "p_demo", title: "Demo", path: "c:/work/DEMO/", saved: { enabled: true, baseBranch: "develop", instructions: "", checks: "npm run ci" } },
      { projectId: "p_other", title: "Other", path: "D:\\elsewhere", saved: { enabled: true } },
    ],
    global: { maxRunning: 3 },
  });
  eq(plan.found, 2, "two layr_code projects");
  const demo = plan.projects.find((x) => x.projectId === "p_demo");
  assert(demo, "matched by folder");
  eq(demo.fill.baseBranch, undefined, "a saved base branch stays");
  eq(demo.fill.checks, undefined, "saved checks stay");
  eq(demo.fill.instructions, "Use pnpm.", "an empty saved value is filled");
  eq(demo.fill.landing, "push", "landing filled");
  eq(demo.fill.tryCommand, "pnpm dev", "▶ Try filled");
  eq(demo.skipped.length, 1, "a bad value is reported");
  eq(plan.unmatched.map((u) => u.title), ["Old one"], "no project here in its folder");
  eq(plan.global.fill, { limitBackoffMin: 30, scouts: "auto" }, "only empty global settings");
});

await test("6: the import tool reads with GETs only, fills empty settings, says what RLS hides", async () => {
  const fixture = JSON.parse(readFileSync(path.join(here, "fixtures", "layr_code-records.json"), "utf8"));
  const requests = [];
  let rows = fixture;
  let status = 200;
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, init) => {
    requests.push([String(url), init?.method]);
    const query = new URL(url).searchParams;
    const list = rows.filter((r) => `eq.${r.collection}` === query.get("collection") && (!query.get("id") || `eq.${r.id}` === query.get("id")));
    return { ok: status === 200, status, text: async () => (status === 200 ? JSON.stringify(list) : '{"message":"permission denied"}') };
  };
  try {
    const session = { url: "https://x.supabase.co", key: "anon", accessToken: "tok", email: "me@example.com" };
    const s = await setup({ hub: fakeHub({ answers: { layr__supabase_session: () => session } }) });
    // The demo project's folder is the temp repo: point the fixture's catalog at it.
    rows = fixture.map((r) => (r.id === "catalog" ? { ...r, data: { projects: r.data.projects.map((x) => (x.id === "t3-demo" ? { ...x, workspaceRoot: s.repo } : x)) } } : r));
    const dry = await s.call("import_layr_code", { dryRun: true }, "you");
    assert(dry.filled > 5 && !s.store.project(s.project.id).tryCommand, `a dry run fills nothing (${dry.filled})`);
    const done = await s.call("import_layr_code", {}, "you");
    eq(s.store.project(s.project.id).tryCommand, "pnpm dev", "filled");
    eq(s.store.project(s.project.id).baseBranch, "main", "the saved base branch stays");
    eq(s.store.project(s.project.id).landing, "push", "landing direct → push");
    assert(done.projects[0].fill.instructions, "says what it filled");
    assert(requests.length >= 2 && requests.every(([, m]) => m === "GET"), `GET only: ${JSON.stringify(requests)}`);
    assert(requests.every(([u]) => /plugin_id=eq\.pipeline/.test(u)), "only the pipeline's records");
    const again = await s.call("import_layr_code", { dryRun: true }, "you");
    eq(again.projects[0].fill.tryCommand, undefined, "a second run doesn't overwrite");
    rows = [];
    await refuses(s.call("import_layr_code", {}, "you"), /row level security/, "none found: maybe RLS");
    status = 403;
    await refuses(s.call("import_layr_code", {}, "you"), /can't read layr_code's records/, "a refusal says so");
    s.p.stop();
    await refuses(readLayrCode(null), /Not signed in/, "no session");
  } finally {
    globalThis.fetch = realFetch;
  }
});

await test("5: launch messages carry the project map, the thread line and the sources line", async () => {
  const settings = { ...projectDefaults(), projectNode: MAP.node };
  const task = { number: 7, title: "Greeting", prompt: "add it", from: link(NODE_A), alsoFrom: [link(NODE_B)] };
  const text = launchMessage({ id: "7", task, branch: "layr/7-greeting", settings, map: MAP, concepts: true });
  assert(/Concept map: project "Demo app" \(#cccccccc\), Features #ffffffff/.test(text), "the map's line");
  assert(/its Inbox #iiiiiiii/.test(text), "the inbox");
  assert(/Rules for Features: One node per feature\./.test(text), "worker rules");
  assert(text.includes('pass `thread: "layr://pipeline/task/7"`'), "the thread line");
  assert(/It was made from these concept nodes \(#aaaaaaaa, #bbbbbbbb\)/.test(text), "the sources line");
  const order = ["Task #7: Greeting\n\nadd it\n\n---\n", "**How to work on it**", "Your own worktree", "Branch `layr/7-greeting`"];
  const after = (p, i) => !i || text.indexOf(p) > text.indexOf(order[i - 1]);
  assert(text.startsWith(order[0]) && order.every(after), "the task first, then the rule, then layr's instructions");
  const planned = launchMessage({ id: "7", task: { ...task, planning: true }, branch: "b", settings, note: "\n\nFiles: x" });
  assert(planned.startsWith("Task #7: Greeting\n\nadd it\n\nFiles: x\n\n---"), "attached files stay with the task");
  assert(planned.indexOf("Plan mode") < planned.indexOf("Your own worktree"), "Plan mode leads the instructions");
  const stopping = /never by name or by tree/.test(text) && /Stop-Process -Id/.test(text);
  assert(stopping, "workers are told how to stop processes");
  const without = launchMessage({ id: "7", task, branch: "b", settings, map: MAP, concepts: false });
  assert(!/concept/i.test(without), "nothing about the map without the concepts plugin");
  eq(projectMapLines(settings, null).length, 1, "the node alone when the map didn't answer");
  assert(/features are on the concept map under #bbbbbbbb/.test(projectMapLines({ projectNode: null, featureMap: NODE_B }, null)[0]), "the feature map line");
  eq(sourcesLine({ from: "layr://other/x" }), [], "only concept nodes");
  eq(sourceNodes({ from: link(NODE_A), alsoFrom: ["layr://other/x", link(NODE_B)] }), [NODE_A, NODE_B], "sources");
  const s = await setup({ settings: { projectNode: MAP.node } });
  const v = s.create("Mapped", { run: true, from: link(NODE_A) });
  await s.until(() => s.why(v.id) === "finished", "finished");
  const start = s.claude.calls.find((c) => c[0] === "start")[1];
  assert(/Concept map: project "Demo app"/.test(start.prompt) && /made from #aaaaaaaa/.test(start.prompt), "the launch had them");
  eq(s.hub.called("concepts__project_map")[0], { node: MAP.node }, "read through concepts__project_map");
  const { projects } = await s.call("projects", {});
  eq([projects[0].map.node, projects[0].map.inbox], [MAP.node, MAP.sections.inbox], "projects lists the node");
  const setupMap = await s.call("setup_project_map", { projectId: s.project.id }, "you");
  assert(Array.isArray(setupMap.made) && s.hub.called("concepts__setup_project_map")[0].node === MAP.node, "Set up project map");
  s.p.stop();
});

await test("5: without the concepts plugin nothing breaks", async () => {
  const s = await setup({ settings: { projectNode: MAP.node }, hub: fakeHub({ concepts: false }) });
  const v = s.create("Plain", { run: true, from: link(NODE_A) });
  await s.until(() => s.why(v.id) === "finished", "finished");
  const start = s.claude.calls.find((c) => c[0] === "start")[1];
  assert(!/concept/i.test(start.prompt), "no map lines");
  eq(s.hub.calls.filter((c) => c[0].startsWith("concepts__")).length, 0, "no concepts calls");
  eq((await s.call("concepts", { query: "x" }, "you")).available, false, "the panels hear it isn't there");
  await refuses(s.call("setup_project_map", { projectId: s.project.id }, "you"), /isn't there/, "Set up project map says so");
  s.p.stop();
});

await test("4: links, renames, forgetting; Status follows the task; a landing on the user's word leaves a note", async () => {
  const s = await setup();
  s.behaviours.set("*", (t, text, tools, dir) => (commitFile(dir, `${t.id}.txt`, "x", "work"), { reply: DONE }));
  const v = s.create("Linked", { from: link(NODE_A), alsoFrom: [link(NODE_B)] });
  await s.p.concepts.idle();
  const links = s.hub.called("concepts__link");
  eq(links.map((l) => l.nodes), [[NODE_A], [NODE_B]], "linked to both");
  eq(links[0].thread, `layr://pipeline/task/${v.id}`, "by the task's link");
  s.actions.edit(v.id, { title: "Renamed" });
  await s.p.concepts.idle();
  eq(s.hub.called("concepts__relink").at(-1), { thread: `layr://pipeline/task/${v.id}`, to: { thread: `layr://pipeline/task/${v.id}`, title: `#${v.number} Renamed` } }, "a rename relinks");
  s.actions.run(v.id);
  await s.until(() => s.why(v.id) === "finished", "finished");
  await s.p.concepts.idle();
  const statuses = s.hub.called("concepts__advance_status").map((a) => a.status);
  assert(statuses.includes("In progress") && statuses.includes("To try"), `In progress and To try: ${statuses}`);
  // The user's word, through an agent: the nodes get Done and a note.
  const r = await s.call("land", { number: Number(v.id), words: `land #${v.number}`, confirm: true });
  assert(r.landing, `landing: ${JSON.stringify(r)}`);
  await s.until(() => s.store.get(v.id).landed, "landed");
  await s.p.concepts.idle();
  assert(s.hub.called("concepts__advance_status").some((a) => a.status === "Done" && a.nodes.includes(NODE_A)), "Done once it lands");
  const note = s.hub.called("concepts__link").find((l) => l.note);
  assert(note && /asked by t_agent on the user's word: "land #1"/.test(note.note), `the note: ${JSON.stringify(note)}`);
  assert(/^Landed as [0-9a-f]{8} on /.test(landedNote(s.store.get(v.id))), "landedNote");
  // Forgotten: its links go to its claude thread; a proposal without one drops them.
  const thread = s.store.get(v.id).threadId;
  s.actions.release(v.id);
  const drop = s.create("Dropped", { from: link(NODE_A) });
  s.actions.remove(drop.id);
  await s.p.concepts.idle();
  const relinks = s.hub.called("concepts__relink");
  assert(relinks.some((x) => x.thread === `layr://pipeline/task/${v.id}` && x.to?.thread === `layr://claude/thread/${thread}`), "released: to its thread");
  assert(relinks.some((x) => x.thread === `layr://pipeline/task/${drop.id}` && x.to === null), "deleted: dropped");
  // Adopted: what its thread did on the map becomes the task's.
  const loose = await s.claude.start({ project: s.project.id, prompt: "hi", title: "Loose", workspace: "worktree", branch: "loose-1" });
  await s.until(() => s.claude.threads.get(loose.id).status === "done", "the loose thread's turn");
  const adopted = await s.actions.adopt(loose.id);
  await s.p.concepts.idle();
  assert(s.hub.called("concepts__relink").some((x) => x.thread === `layr://claude/thread/${loose.id}` && x.to?.thread === `layr://pipeline/task/${adopted.id}`), "adopted: its thread's links move to the task");
  s.p.stop();
});

await test("4: a refused concepts call is logged once and the pipeline carries on", async () => {
  const hub = fakeHub({ answers: { concepts__link: () => Promise.reject(new Error("not allowed to call concepts's tools: write")) } });
  const s = await setup({ hub });
  s.create("One", { from: link(NODE_A) });
  s.create("Two", { from: link(NODE_B) });
  await s.p.concepts.idle();
  eq(s.logs.filter((l) => /concepts \(link\)/.test(l)).length, 1, "logged once");
  eq(s.store.entries().length, 2, "both tasks made");
  s.p.stop();
});

await test("4: a batch's members go In progress with it", async () => {
  const s = await setup();
  const a = s.create("Small A", { from: link(NODE_A), batch: true, size: "S" });
  s.create("Small B", { from: link(NODE_B), batch: true, size: "S" });
  const batch = s.store.get(a.id).inBatch;
  s.actions.run(batch);
  await s.until(() => s.store.get(batch).threadId, "the batch's thread");
  await s.p.concepts.idle();
  const progress = s.hub.called("concepts__advance_status").find((x) => x.status === "In progress");
  eq(progress?.nodes, [NODE_A, NODE_B], "both members' nodes");
  const start = s.claude.calls.find((c) => c[0] === "start")[1];
  assert(/these concept nodes \(#aaaaaaaa, #bbbbbbbb\)/.test(start.prompt), "the batch's launch names them");
  s.p.stop();
});

await test("4: \"needs\" edges chain a new task to the task of what it needs", async () => {
  const needs = (args) => args.nodes.includes(NODE_B) ? [{ node: NODE_B, needs: [{ id: NODE_A, title: "Base", status: "In progress" }, { id: "dddddddd", title: "Loose", status: "Idea" }] }] : [];
  const s = await setup({ hub: fakeHub({ answers: { concepts__needs: needs } }) });
  const base = s.create("Base", { from: link(NODE_A) });
  const r = await s.call("propose", { projectId: s.project.id, title: "On top", description: "needs the base", from: link(NODE_B), confirm: true });
  eq(r.startsAfter, base.number, "chained after the task of what it needs");
  eq(r.needs, ['needs "Loose" (#dddddddd), which has no task'], "the rest is noted");
  const own = await s.call("propose", { projectId: s.project.id, title: "Own parent", description: "x", from: link(NODE_B), after: base.number, confirm: true });
  eq(own.startsAfter, base.number, "an `after` given wins");
  const made = await s.call("create", { projectId: s.project.id, title: "From the board", from: [link(NODE_B)] }, "you");
  eq(made.task.after, base.id, "create chains too");
  eq(chainFromNeeds([{ node: "x", needs: [{ id: NODE_A, title: "Base", status: "Done" }] }], [], "p").notes, [], "a Done node without a task needs nothing");
  s.p.stop();
});

await test("11: archiving a task's thread settles its card; unarchiving unsettles it", async () => {
  const s = await setup();
  const v = s.create("Archived", { run: true });
  await s.until(() => s.why(v.id) === "finished", "finished");
  const thread = s.store.get(v.id).threadId;
  await s.claude.archive(thread, true);
  await s.until(() => s.p.placement(v.id).column === "settled", "settled by the archive");
  eq(s.store.get(v.id).settledBy, "archive", "says why");
  await s.claude.archive(thread, false);
  await s.until(() => s.p.placement(v.id).column === "stopped", "unarchived: back in Stopped");
  // Settled by the user, the thread's archive changes nothing; unsettled while archived, it stays.
  await s.claude.archive(thread, true);
  await s.until(() => s.store.get(v.id).settledAt, "settled again");
  s.actions.unsettle(v.id);
  await s.p.refreshThreads();
  eq(s.p.placement(v.id).column, "stopped", "unsettled by you while archived: stays");
  // Archived while its turn runs: settled once the turn ends.
  let release;
  s.behaviours.set("Slow", () => new Promise((r) => (release = () => r({ reply: DONE }))));
  const w = s.create("Slow", { run: true });
  await s.until(() => s.why(w.id) === "running" && release, "running");
  await s.claude.archive(s.store.get(w.id).threadId, true);
  s.claude.changed(s.claude.threads.get(s.store.get(w.id).threadId));
  await s.until(() => s.store.get(w.id).archivePending, "waits for the turn");
  eq(s.p.placement(w.id).column, "running", "still running");
  release();
  await s.until(() => s.p.placement(w.id).column === "settled", "settled once it ended");
  s.p.stop();
});

await test("12: a task without a worktree records checkout drift, every minute too; Settle asks first", async () => {
  const s = await setup();
  const v = s.create("Live", { noWorktree: true, run: true });
  await s.until(() => s.why(v.id) === "finished", "finished");
  eq(s.store.get(v.id).checkout, undefined, "clean");
  writeFileSync(path.join(s.repo, "dirty.txt"), "x");
  git(s.repo, "checkout", "-q", "-b", "side");
  await s.p.checkCheckouts();
  const c = s.store.get(v.id).checkout;
  eq([c.branch, c.files.length], ["side", 1], "another branch and a file");
  const settle = s.p.view(v.id).buttons.find((b) => b.id === "settle");
  assert(/1 uncommitted file\(s\) and is on side/.test(settle.confirm), `Settle asks: ${settle.confirm}`);
  git(s.repo, "checkout", "-q", "main");
  rmSync(path.join(s.repo, "dirty.txt"));
  s.p.lastCheckouts = 0;
  await s.until(() => !s.store.get(v.id).checkout, "the minute's look clears it");
  s.p.stop();
});

await test("13: two tasks without a worktree don't launch in the same gate pass", async () => {
  const s = await setup();
  s.p.stop();
  const a = s.create("First live", { noWorktree: true, run: true });
  const b = s.create("Second live", { noWorktree: true, run: true });
  await s.p.gate();
  await sleep(300);
  const launched = s.claude.calls.filter((c) => c[0] === "start").length;
  eq(launched, 1, "only one launched");
  assert(/no worktree · after #/.test(s.p.waits(b.id, s.store.get(b.id)) ?? ""), `the other waits: ${s.p.waits(b.id, s.store.get(b.id))}`);
  eq(s.store.get(a.id).threadId !== undefined, true, "the first has its thread");
});

await test("43: the ready-made rounds start threads with the tools they need", async () => {
  const s = await setup();
  for (const kind of ["stuck", "land_safe", "running"]) {
    const r = await s.call("round", { kind }, "you");
    const start = s.claude.calls.filter((c) => c[0] === "start").at(-1)[1];
    assert(r.thread && start.permissionMode === "dontAsk", `${kind}: a dontAsk thread`);
    assert(/question format/.test(start.prompt) && /## The board now/.test(start.prompt), `${kind}: its prompt`);
    eq(start.allowedTools.includes("mcp__layr__pipeline__land"), kind === "land_safe", `${kind}: land only for land_safe`);
  }
  const land = s.claude.calls.filter((c) => c[0] === "start").find((c) => /Land the safe ones/.test(c[1].title))[1];
  assert(/Land nothing yet/.test(land.prompt) && /ask the user once/.test(land.prompt), "it asks before landing");
  const scout = await s.call("round", { kind: "scout", focus: "slow queries" }, "you");
  const start = s.claude.calls.filter((c) => c[0] === "start").at(-1)[1];
  assert(scout.thread && /slow queries/.test(start.prompt) && start.allowedTools.includes("mcp__layr__pipeline__scout"), "Send a scout");
  s.store.setGlobal({ scouts: "off" });
  await refuses(s.call("round", { kind: "scout", focus: "x" }, "you"), /Scouts are off/, "scouts off");
  const manifest = JSON.parse(readFileSync(path.join(here, "..", "layr.json"), "utf8"));
  const ids = manifest.commands.map((c) => c.id);
  for (const id of ["round-stuck", "round-land-safe", "round-running", "round-scout"]) assert(ids.includes(id), `command ${id}`);
  s.p.stop();
});

await test("9: keep awake while work runs, off when it stops; an older core without the tool is left alone", async () => {
  const s = await setup();
  let release;
  s.behaviours.set("*", () => new Promise((r) => (release = () => r({ reply: DONE }))));
  const v = s.create("Awake", { run: true });
  await s.until(() => s.hub.called("layr__keep_awake").some((a) => a.on), "on while it runs");
  eq(s.hub.called("layr__keep_awake")[0].reason, "Pipeline work runs", "with a reason");
  await s.until(() => release, "running");
  release();
  await s.until(() => s.why(v.id) === "finished", "finished");
  await s.until(() => s.hub.called("layr__keep_awake").at(-1).on === false, "off when nothing runs");
  s.store.setGlobal({ keepAwake: false });
  s.behaviours.set("*", () => ({ reply: DONE }));
  const before = s.hub.called("layr__keep_awake").length;
  const w = s.create("Asleep", { run: true });
  await s.until(() => s.why(w.id) === "finished", "finished");
  eq(s.hub.called("layr__keep_awake").length, before, "the setting off: never on");
  s.p.stop();
  const old = await setup({ hub: fakeHub({ keepAwake: false }) });
  const x = old.create("Old core", { run: true });
  await old.until(() => old.why(x.id) === "finished", "finished");
  eq(old.hub.called("layr__keep_awake").length, 1, "asked once");
  assert(old.p.keepAwake.missing && old.logs.some((l) => /no layr__keep_awake/.test(l)), "then left alone");
  old.p.stop();
});

await test("3: the concepts plugin may read tasks and task without asking", async () => {
  const manifest = JSON.parse(readFileSync(path.join(here, "..", "layr.json"), "utf8"));
  const read = manifest.access.groups.find((g) => g.tools.includes("tasks"));
  assert(read.tools.includes("task"), "task in the same group");
  eq(read.defaults["plugin:concepts"], "allow", "plugin:concepts: allow");
  assert(manifest.permissions.includes("supabase"), "the supabase permission (layr_code's import)");
  eq(manifest.version, JSON.parse(readFileSync(path.join(here, "..", "package.json"), "utf8")).version, "layr.json and package.json versions");
});

console.log(`${passed} passed, ${failures} failed`);
try {
  rmSync(tmp, { recursive: true, force: true, maxRetries: 3 });
} catch {
  // Windows may hold a file a moment longer
}
process.exit(failures ? 1 : 0);
