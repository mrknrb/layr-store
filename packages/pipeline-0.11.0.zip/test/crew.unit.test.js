// Pure parts of the crew (the features ported last): PR verdicts, Keep up to date's decision and script, usage limits'
// reset times, briefs and stakes, scouts, the orchestrator's look and the Decide round, the task buttons and their
// confirm texts. Run: node test/crew.unit.test.js
import { briefKey, briefOf, jsonOf, maxControversy, stakesOf, wantsBrief } from "../backend/briefs.js";
import { discardText, landText, noteOf, settleText, taskButtons } from "../backend/buttons.js";
import { readingOf, resetFromText, resetFromUsage } from "../backend/limits.js";
import { changes, decideRoundPrompt, endings, everyDue, fingerprint, lookalikes, NOTHING, parseReply, ROUND_TOOLS, toolsFor, workWaits } from "../backend/orchestrator.js";
import { CI_GRACE_MS, prVerdict } from "../backend/pr.js";
import { floodReason, frictionNotes, nextKind, scoutPrompt, SCOUT_TOOLS } from "../backend/scouts.js";
import { checkValue, globalDefaults, PROJECT, projectDefaults } from "../backend/settings.js";
import { decideUpdate, updateScriptText } from "../backend/updater.js";

let failures = 0;
let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`ok   ${name}`);
  } catch (error) {
    failures++;
    console.log(`FAIL ${name}: ${error.message}`);
  }
}
const eq = (a, b, msg = "values differ") => {
  if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${msg}: ${JSON.stringify(a)} != ${JSON.stringify(b)}`);
};
const now = Date.parse("2026-11-15T12:00:00Z");
const iso = (ms) => new Date(now + ms).toISOString();

test("defaults: no usage guard or retro, the orchestrator is off, scouts when asked", () => {
  const g = globalDefaults();
  eq(["usageGuard", "usageStopFiveHour", "chatReserve", "retroWeekly"].filter((k) => k in g), [], "removed settings");
  eq([g.orchestrator, g.orchestratorModel, g.scouts, g.scoutModel, g.briefModel], [false, "haiku", "ask", "sonnet", "haiku"]);
  const p = projectDefaults();
  eq([p.updateMain, p.laneRun, p.scoutFeatures, p.orchestratorWake, p.tryCommand, p.icon, p.color], [false, "", null, "events", "", "", null]);
  eq(checkValue(PROJECT, "icon", " 🚀 "), "🚀", "an emoji");
  eq(checkValue(PROJECT, "icon", "API"), "API", "or three letters");
  eq(checkValue(PROJECT, "color", "#3E63DD"), "#3e63dd", "a colour");
  eq(checkValue(PROJECT, "color", ""), null, "no colour");
  let threw = 0;
  for (const [k, v] of [["icon", "four"], ["color", "blue"]]) {
    try {
      checkValue(PROJECT, k, v);
    } catch {
      threw++;
    }
  }
  eq(threw, 2, "a long icon and a colour name are refused");
});

test("PR verdicts", () => {
  const view = (extra = {}) => ({ state: "OPEN", headRefOid: "h", mergeStateStatus: "CLEAN", reviewDecision: "", statusCheckRollup: [{ __typename: "CheckRun", name: "ci", status: "COMPLETED", conclusion: "SUCCESS" }], ...extra });
  const old = iso(-CI_GRACE_MS - 1000);
  eq(prVerdict(view(), "h", old, now).kind, "ready");
  eq(prVerdict(view({ state: "MERGED", mergeCommit: { oid: "m" } }), "h", old, now), { kind: "merged", commit: "m" });
  eq(prVerdict(view({ state: "CLOSED" }), "h", old, now).kind, "closed");
  eq(prVerdict(view({ headRefOid: "x" }), "h", iso(-1000), now).kind, "wait");
  eq(prVerdict(view({ headRefOid: "x" }), "h", old, now), { kind: "foreign", head: "x" });
  eq(prVerdict(view({ statusCheckRollup: [{ __typename: "CheckRun", name: "ci", status: "COMPLETED", conclusion: "FAILURE", detailsUrl: "u" }] }), "h", old, now), { kind: "failed", checks: [{ name: "ci", url: "u" }] });
  eq(prVerdict(view({ statusCheckRollup: [{ __typename: "StatusContext", context: "x", state: "PENDING" }] }), "h", old, now), { kind: "wait", why: "CI runs" });
  eq(prVerdict(view({ statusCheckRollup: [] }), "h", iso(-1000), now).why, "waits for CI to start");
  eq(prVerdict(view({ statusCheckRollup: [] }), "h", old, now).kind, "ready");
  eq(prVerdict(view({ mergeStateStatus: "BEHIND" }), "h", old, now).kind, "rebase");
  eq(prVerdict(view({ reviewDecision: "CHANGES_REQUESTED" }), "h", old, now).kind, "changes");
  eq(prVerdict(view({ reviewDecision: "REVIEW_REQUIRED" }), "h", old, now).why, "waits for a review");
});

test("Keep up to date: the order of the checks", () => {
  const f = { base: "main", branch: "main", head: "a", target: "b", targetName: "origin/main", behind: 1, ahead: 0, clean: true, busy: null, forced: false };
  eq(decideUpdate(f), { kind: "update", goal: "b" });
  eq(decideUpdate({ ...f, behind: 0, target: "a" }).kind, "current", "never updated, not behind: counts as done");
  eq(decideUpdate({ ...f, behind: 0, target: "a", doneOn: "z" }), { kind: "update", goal: "a" }, "an update that didn't finish runs again");
  eq(decideUpdate({ ...f, failedOn: "b" }).kind, "failed");
  eq(decideUpdate({ ...f, failedOn: "b", forced: true }).kind, "update");
  eq(decideUpdate({ ...f, branch: "dev" }).you, true);
  eq(decideUpdate({ ...f, ahead: 2 }).kind, "wait");
  eq(decideUpdate({ ...f, clean: false }).you, true);
  eq(decideUpdate({ ...f, approve: true }).kind, "ready");
  eq(decideUpdate({ ...f, approve: true, approved: true }).kind, "update");
  eq(decideUpdate({ ...f, busy: "#3 is landing" }), { kind: "wait", you: false, why: "Waits until nothing runs here: #3 is landing." });
  const ps = updateScriptText("npm ci", true);
  eq(ps.charCodeAt(0), 0xfeff, "a BOM: PowerShell reads it as UTF-8");
  eq(ps.includes("$ErrorActionPreference = 'Stop'\r\nnpm ci\r\nif ($LASTEXITCODE) { exit $LASTEXITCODE }"), true, "a failing native command fails it");
  eq(updateScriptText("make", false), "set -e\nmake\n");
});

test("usage limits: the real reset time", () => {
  const at = new Date(now);
  eq(resetFromText("Claude AI usage limit reached|1763215200", now), new Date(1763215200 * 1000).toISOString(), "epoch seconds");
  eq(resetFromText("Rate limited: try again in 20 minutes", now), iso(20 * 60e3), "in minutes");
  const four = new Date(at);
  four.setHours(16, 0, 0, 0);
  if (four.getTime() <= now) four.setDate(four.getDate() + 1);
  eq(resetFromText("You've hit your limit · resets 4pm (Europe/Budapest)", now), four.toISOString(), "the next 4 pm");
  const early = new Date(at);
  early.setHours(3, 30, 0, 0);
  if (early.getTime() <= now) early.setDate(early.getDate() + 1);
  eq(resetFromText("5-hour limit reached ∙ resets 3:30am", now), early.toISOString(), "3:30 am, tomorrow if past");
  eq(new Date(resetFromText("Weekly limit reached ∙ resets Nov 20, 5pm", now)).getDate(), 20, "a date");
  eq(resetFromText("usage limit reached", now), null, "nothing said");
  eq(resetFromText("resets 5", now), null, "no time of day");
  const usage = (extra) => ({ limits: { fiveHour: { utilization: 100, resetsAt: iso(3600e3) }, sevenDay: { utilization: 40, resetsAt: iso(86400e3) }, rejectedUntil: null, ...extra } });
  eq(resetFromUsage(usage(), now), iso(3600e3), "the full 5-hour window");
  eq(resetFromUsage(usage({ rejectedUntil: iso(600e3) }), now), iso(600e3), "a rejection's end first");
  eq(resetFromUsage(usage({ fiveHour: { utilization: 50, resetsAt: iso(3600e3) } }), now), null, "no full window");
  eq(readingOf(usage()).fiveHour, { pct: 100, resetsAt: iso(3600e3) });
});

test("task buttons and their confirm texts", () => {
  const s = { ...projectDefaults(), baseBranch: "main", checks: "npm test", tryCommand: "npm run dev" };
  const t = { id: "4", number: 4, column: "stopped", why: "finished", threadId: "t", worktreePath: "/w", canLand: true, approvable: false, work: { ahead: 1, dirty: 0 }, thread: { replyStatus: { status: "done", risks: [], try: "ready" } } };
  eq(taskButtons(t, s).map((b) => b.id), ["land", "try", "settle"]);
  eq(taskButtons(t, s).find((b) => b.id === "try"), { id: "try", label: "▶ Try", kind: "primary", pc: true }, "Try: primary when ready to try");
  eq(taskButtons(t, { ...s, tryCommand: "" }).some((b) => b.id === "try"), false, "no Try command: no Try");
  eq(landText(t, s).includes("runs `npm test` and moves main in the project's folder"), true, landText(t, s));
  eq(landText(t, { ...s, landing: "pr" }).includes("opens a pull request into main"), true);
  eq(landText(t, { ...s, landing: "push" }).includes("pushes it to origin/main (never forced)"), true);
  eq(landText({ ...t, ask: { paths: ["db/1.sql"], risks: [] } }, s).includes("db/1.sql"), true, "says what you look at first");
  eq(settleText(t).includes("1 commit(s)"), true, "unlanded work");
  eq(settleText({ ...t, landed: { commit: "c" } }), undefined, "landed: no question");
  eq(settleText({ ...t, noWorktree: true, checkout: { files: [" M a.js"] } }).includes("1 uncommitted"), true, "a dirty checkout");
  eq(discardText(t).includes("it's lost"), true);
  eq(discardText({ ...t, noWorktree: true }).includes("checkout stays"), true);
  eq(taskButtons({ ...t, column: "running", why: "running", canLand: false }, s).find((b) => b.id === "stop").confirm.includes("interrupted"), true);
  eq(taskButtons({ ...t, approvable: true, planning: true, column: "proposed", canLand: false }, s)[0], { id: "approve", label: "Approve", kind: "primary" });
  eq(noteOf({ column: "proposed", why: "proposal", stopNote: "Could not launch: x", prompt: "p" }), "Could not launch: x", "a launch that failed shows");
});

test("briefs and stakes", () => {
  const task = { number: 3, title: "x", prompt: "y", source: { kind: "agent" } };
  eq(briefKey(task, "proposal").startsWith("p:"), true);
  eq(briefKey(task, "running"), null);
  eq(wantsBrief(task, "proposal"), true);
  eq(wantsBrief({ ...task, source: { kind: "you" } }, "proposal"), false);
  eq(wantsBrief(task, "finished"), true);
  eq(jsonOf('Sure:\n```json\n{"what":"a","ask":"b","cost":"c","stakes":12}\n```').stakes, 12);
  eq(jsonOf('{"a":1} trailing'), { a: 1 });
  eq(briefOf({ what: "a", ask: "b", cost: "c", stakes: 12 }, "k").stakes, 10);
  eq(briefOf({ what: "a" }, "k"), null);
  eq(maxControversy("## Questions\n1. 7 🟠 Where?\n2. 🚩 9 🔴 What?"), 9);
  const risky = stakesOf({ ...task, thread: { replyStatus: { status: "done", risks: ["database"] }, pending: [] } }, "finished");
  eq(risky.level, "medium");
  eq(stakesOf(task, "running"), null);
  const withBrief = stakesOf({ ...task, brief: { stakes: 10 } }, "proposal");
  eq(withBrief.reasons.at(-1), "The brief rates it 10/10");
});

test("scouts", () => {
  eq(floodReason([], now), null);
  eq(floodReason(Array.from({ length: 16 }, () => ({ at: iso(0) })), now).includes("16"), true);
  eq(floodReason([{ at: iso(-3 * 86400e3) }], now).includes("2 days"), true);
  eq(nextKind([{ projectId: "p", kind: "code", at: iso(0) }], "p"), "friction");
  const board = scoutPrompt("code", { projectId: "p1", projectName: "Demo", features: null, focus: "slow queries" });
  eq(/pipeline__propose \(projectId: "p1"/.test(board) && /slow queries/.test(board), true, "proposes on the board");
  const map = scoutPrompt("friction", { projectId: "p1", projectName: "Demo", features: "abc123", friction: "- #1 x: stopped" });
  eq(/concepts__file/.test(map) && /stuck lately/.test(map), true, "files on the map");
  eq(SCOUT_TOOLS.includes("Bash") || SCOUT_TOOLS.includes("Edit"), false, "no tools that change anything");
  eq(frictionNotes([["1", { number: 1, title: "A", updatedAt: iso(0), stopNote: "Landing stopped" }]], now - 1000).includes("Landing stopped"), true);
});

test("the orchestrator's look", () => {
  const before = { mode: "here", tasks: [{ number: 1, title: "A", column: "running" }], scoutIds: ["s1"], lookalikes: [] };
  const after = { mode: "here", tasks: [{ number: 1, title: "A", column: "stopped", asks: true }, { number: 2, title: "B", column: "proposed", start: "either" }], scoutIds: [], lookalikes: [] };
  eq(fingerprint(before) === fingerprint(after), false);
  eq(changes(before, after), ["#2 proposed", "#1 asks a question", "a running slot freed up (0 running, was 1)"]);
  eq(changes(after, after), [NOTHING]);
  eq(changes(undefined, after), ["first check-in"]);
  eq(endings(before, after), ["#1 ended (stopped)", "a scout ended"]);
  eq(workWaits(after), true);
  eq(workWaits({ tasks: [{ number: 3, column: "proposed", start: "manual" }] }), false, "the user starts it");
  const s = { orchestratorAwayEveryMin: 30 };
  eq(everyDue(s, "away", iso(-31 * 60e3), now), true);
  eq(everyDue(s, "here", iso(-31 * 60e3), now), false);
  const pairs = lookalikes([
    { number: 4, title: "Add a dark theme switch", prompt: "theme switch dark light", column: "proposed", projectId: "p" },
    { number: 5, title: "Dark theme switch", prompt: "add theme switch dark", column: "proposed", projectId: "p" },
  ]);
  eq(pairs.map((x) => [x.a, x.b]), [[4, 5]]);
  const tools = toolsFor({ ...globalDefaults(), orchestratorRun: "never" });
  eq(tools.includes("mcp__layr__pipeline__run"), false, "never takes its tools away");
  eq(tools.includes("mcp__layr__pipeline__tasks") && tools.includes("Read"), true);
  eq(parseReply("Ran #2.\n**Log:** Ran #2"), { text: "Ran #2.", log: "Ran #2" });
});

test("the Decide round", () => {
  const prompt = decideRoundPrompt(["### #3 A (Demo, question)"]);
  eq(/one numbered list/.test(prompt) && /Safe to land/.test(prompt) && /#3 A/.test(prompt), true);
  eq(ROUND_TOOLS.includes("mcp__layr__pipeline__send") && !ROUND_TOOLS.some((t) => /land|act$|discard/.test(t)), true, "answers, never lands");
});

console.log(`${passed} passed, ${failures} failed`);
process.exit(failures ? 1 : 0);
