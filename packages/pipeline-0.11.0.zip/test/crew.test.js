// The crew against the fake claude plugin (test/fakeClaude.js), a fake gh (test/fake_gh/gh.mjs) and real git
// repositories in a temp folder: PR landing, wake-ups, the test lane, briefs, scouts, the orchestrator, Keep up to date
// and attachments, without Claude usage and without GitHub.
// Run: node test/crew.test.js
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createActions } from "../backend/actions.js";
import { Pipeline } from "../backend/pipeline.js";
import { Store } from "../backend/store.js";
import { registerTools } from "../backend/tools.js";
import { FakeClaude } from "./fakeClaude.js";

const here = path.dirname(fileURLToPath(import.meta.url));
let failures = 0;
let passed = 0;
async function test(name, fn) {
  const t0 = Date.now();
  try {
    await fn();
    passed++;
    console.log(`ok   ${name} (${Date.now() - t0} ms)`);
  } catch (error) {
    failures++;
    console.log(`FAIL ${name}: ${error.stack || error.message}`);
  }
}
const assert = (cond, msg) => {
  if (!cond) throw new Error(msg || "assertion failed");
};
const eq = (a, b, msg) => assert(JSON.stringify(a) === JSON.stringify(b), `${msg}: ${JSON.stringify(a)} != ${JSON.stringify(b)}`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const nowIso = () => new Date().toISOString();

const tmp = mkdtempSync(path.join(os.tmpdir(), "layr-pipeline-crew-"));
const git = (dir, ...args) => execFileSync("git", ["-C", dir, ...args], { stdio: ["ignore", "pipe", "pipe"] }).toString().trim();

function makeRepo(name, { remote = false } = {}) {
  const repo = path.join(tmp, name);
  execFileSync("git", ["init", "-q", "-b", "main", repo]);
  git(repo, "config", "user.name", "Test");
  git(repo, "config", "user.email", "test@example.com");
  writeFileSync(path.join(repo, "README.md"), "# Demo\n");
  git(repo, "add", ".");
  git(repo, "commit", "-q", "-m", "init");
  if (remote) {
    const bare = path.join(tmp, `${name}.git`);
    execFileSync("git", ["init", "-q", "--bare", "-b", "main", bare]);
    git(repo, "remote", "add", "origin", bare);
    git(repo, "push", "-q", "origin", "main");
    return { repo, bare };
  }
  return { repo };
}

function commitFile(dir, file, content, message) {
  mkdirSync(path.dirname(path.join(dir, file)), { recursive: true });
  writeFileSync(path.join(dir, file), content);
  git(dir, "add", file);
  git(dir, "commit", "-q", "-m", message);
}

const DONE = "Did it.\n\nStatus: done · Risk: none · Try: none";

async function setup({ maxRunning = 2, settings = {}, global = {}, remote = false } = {}) {
  const { repo, bare } = makeRepo(`repo-${Math.random().toString(36).slice(2, 7)}`, { remote });
  const dataDir = path.join(tmp, `data-${path.basename(repo)}`);
  const store = new Store(dataDir);
  const claude = new FakeClaude();
  const project = await claude.addProject(repo);
  const notes = [];
  const hub = { emit() {}, notify: (text) => notes.push(text) };
  const logs = [];
  const p = new Pipeline({ store, claude, hub, logger: (...a) => logs.push(a.join(" ")) });
  const actions = createActions(p);
  store.setGlobal({ pollSec: 1, maxRunning, briefs: false, ...global });
  store.setProject(project.id, { enabled: true, baseBranch: "main", ...settings });
  await p.refreshProjects();
  const handlers = new Map();
  registerTools({ registerTool: (name, def, fn) => handlers.set(name, fn) }, p, actions);
  /** Call a tool as `thread` (a Claude thread's id: _meta["layr/caller"]) or as the user (no thread). */
  const call = async (name, args, thread) => {
    const extra = thread ? { _meta: { "layr/caller": { kind: "agent", plugin: "claude", label: thread } } } : { _meta: { "layr/caller": { kind: "panel", plugin: "pipeline" } } };
    const r = await handlers.get(name)(args, extra);
    if (r.isError) throw new Error(r.content[0].text);
    return r.structuredContent;
  };
  p.start();
  const behaviours = new Map();
  claude.worker = async (thread, text, tools) => {
    const dir = thread.cwd;
    if (/^(Land this task|Not ready to land|`main` moved on|The pull request can't be merged)/.test(text)) {
      git(dir, "fetch", "-q", "origin", "main");
      git(dir, "rebase", "-q", remote ? "origin/main" : "main");
      return { reply: "Rebased.\n\nStatus: done · Risk: none · Try: none" };
    }
    const title = /^Task #\d+: (.+)$/m.exec(text)?.[1] ?? thread.title?.replace(/^#\d+ /, "");
    const fn = behaviours.get(title) ?? [...behaviours.entries()].find(([k]) => k.endsWith("*") && title?.startsWith(k.slice(0, -1)))?.[1] ?? behaviours.get("*");
    if (!fn) return { reply: DONE };
    return fn(thread, text, tools, dir);
  };
  const until = async (cond, what, ms = 15000) => {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      if (await cond()) return;
      p.wake();
      await sleep(60);
    }
    const tasks = store.entries().map(([id, t]) => `#${id} ${p.placement(id).why} held=${JSON.stringify(t.held ?? [])} note=${t.stopNote ?? ""} landing=${JSON.stringify(t.landing ?? null)}`);
    throw new Error(`timed out: ${what} (logs: ${logs.slice(-5).join(" | ")})\n  ${tasks.join("\n  ")}`);
  };
  const why = (id) => p.placement(id).why;
  return { repo, bare, store, claude, project, p, actions, behaviours, until, why, logs, call, notes, dataDir };
}

// ------------------------------------------------------------------------------------------------------------------

await test("pr landing: push the branch, open the PR, a CI failure goes back to the thread, then merge", async () => {
  const ghDir = path.join(tmp, "gh");
  mkdirSync(ghDir, { recursive: true });
  process.env.LAYR_PIPELINE_GH = path.join(here, "fake_gh", "gh.mjs");
  process.env.FAKE_GH_DIR = ghDir;
  process.env.FAKE_GH_REQUIRE_FILE = "ci.ok";
  try {
    const s = await setup({ remote: true, settings: { landing: "pr" } });
    s.p.prPollMs = 50;
    s.behaviours.set("Via PR", (t, text, tools, dir) => {
      if (/^CI fails on pull request/.test(text)) {
        writeFileSync(path.join(dir, "ci.ok"), "1");
        git(dir, "add", ".");
        git(dir, "commit", "-q", "--amend", "--no-edit");
        return { reply: "Fixed CI.\n\nStatus: done · Risk: none · Try: none" };
      }
      commitFile(dir, "pr.txt", "pr\n", "Add pr.txt");
      return { reply: DONE };
    });
    const v = s.actions.create({ projectId: s.project.id, title: "Via PR", run: true });
    await s.until(() => s.why(v.id) === "finished", "it finishes");
    const startArgs = s.claude.calls.find((c) => c[0] === "start")[1];
    eq(startArgs.baseRef, "origin/main", "pr landing starts from the remote's base");
    s.actions.land(v.id);
    await s.until(() => s.store.get(v.id).landed, "it lands through the pull request", 25000);
    const task = s.store.get(v.id);
    eq(task.landed.pr.number, 1, "pull request #1");
    assert(s.claude.calls.some((c) => c[0] === "send" && /^CI fails on pull request #1/.test(c[2])), "the CI failure went to the thread");
    const log = readFileSync(path.join(ghDir, "log.jsonl"), "utf8").trim().split("\n").map((l) => JSON.parse(l).args.slice(0, 2).join(" "));
    assert(log.includes("pr create") && log.includes("pr merge"), `gh calls: ${log.join(", ")}`);
    eq(log.filter((x) => x === "pr create").length, 1, "the fix reused the pull request");
    const state = JSON.parse(readFileSync(path.join(ghDir, "state.json"), "utf8"));
    eq(state.prs[0].state, "MERGED", "merged");
    eq(git(s.bare, "rev-parse", "main"), task.landed.commit, "the remote's main is the merge commit");
    eq(git(s.repo, "rev-parse", "main"), task.landed.commit, "the local main followed");
    await s.until(() => !git(s.bare, "branch", "--list", task.branch), "its branch is deleted on the remote");
    assert(existsSync(path.join(s.repo, "pr.txt")) && existsSync(path.join(s.repo, "ci.ok")), "the main checkout has the work");
    // Agents can't land pr projects on the user's word: the Land button does.
    const refusal = await s.call("land", { number: task.number, words: `land #${task.number}` }, "t_agent9");
    eq(refusal.canLand, false, "agents refused");
    s.p.stop();
  } finally {
    delete process.env.LAYR_PIPELINE_GH;
    delete process.env.FAKE_GH_REQUIRE_FILE;
  }
});

await test("wake-ups: a worker asks to be woken, its note goes to its thread when the time comes", async () => {
  const s = await setup();
  let woken = null;
  s.behaviours.set("Waits for CI", async (t, text) => {
    if (/^The wake-up you asked for/.test(text)) {
      woken = text;
      return { reply: DONE };
    }
    const r = await s.call("wake", { inMinutes: 5, note: "check the CI run" }, t.id);
    assert(/End your turn/.test(r.note), "told to end its turn");
    return { reply: "Waiting for CI.\n\nStatus: partial · Risk: none · Try: none" };
  });
  const v = s.actions.create({ projectId: s.project.id, title: "Waits for CI", run: true });
  await s.until(() => s.store.get(v.id).wake && s.why(v.id) !== "running" && s.why(v.id) !== "starting", "it asked to be woken");
  const launch = s.claude.calls.find((c) => c[0] === "start")[1].prompt;
  assert(/pipeline__wake \{number: 1/.test(launch), "the launch message names the wake tool");
  assert(!woken, "not before its time");
  s.store.mutate(v.id, (t) => ({ wake: { ...t.wake, at: new Date(Date.now() - 1000).toISOString() } }));
  await s.until(() => woken, "woken");
  assert(/check the CI run/.test(woken), woken);
  assert(!s.store.get(v.id).wake, "one wake-up, used");
  s.p.stop();
});

await test("test lane: one task at a time, the next waits in the queue and is messaged when it is free", async () => {
  const s = await setup({ settings: { laneRun: "npm run dev", laneUrl: "http://localhost:3000" } });
  const got = {};
  s.behaviours.set("Lane A", async (t, text) => {
    if (/test lane is free and kept for you/.test(text)) return { reply: DONE };
    got.a = await s.call("lane", {}, t.id);
    return { reply: DONE };
  });
  s.behaviours.set("Lane B", async (t, text) => {
    if (/test lane is free and kept for you/.test(text)) {
      got.offer = text;
      got.b2 = await s.call("lane", {}, t.id);
      return { reply: DONE };
    }
    got.b = await s.call("lane", { wait: true }, t.id);
    return { reply: "Waiting for the lane.\n\nStatus: partial · Risk: none · Try: none" };
  });
  const a = s.actions.create({ projectId: s.project.id, title: "Lane A", run: true });
  await s.until(() => got.a, "A takes the lane");
  eq(got.a.granted, true, "granted");
  eq(got.a.run, "npm run dev", "with the lane's commands");
  assert(/test lane/.test(s.claude.calls.find((c) => c[0] === "start")[1].prompt), "the launch message names the lane");
  // A's turn ended: the lane frees a minute later at the earliest; give it back by hand meanwhile.
  const b = s.actions.create({ projectId: s.project.id, title: "Lane B", run: true });
  await s.until(() => got.b, "B asks for it");
  eq([got.b.granted, got.b.queued], [false, 1], "busy: B waits first in the queue");
  assert(!s.p.autoMergeDue({ ...s.store.get(b.id), autoMerge: true, work: { ahead: 1, dirty: 0 } }), "waiting for the lane: no auto-merge");
  await s.call("lane", { number: Number(a.id), release: true });
  await s.until(() => got.b2, "B is messaged and takes it");
  eq(got.b2.granted, true, "B has it now");
  const hold = await s.call("hold_lane", { projectId: s.project.id });
  assert(hold.lane.you, "you hold it");
  s.p.stop();
});

await test("briefs: a finished task and an agent's proposal get one; stakes come with the task", async () => {
  const s = await setup({ global: { briefs: true } });
  s.claude.asker = async ({ prompt, model }) => {
    assert(model === "haiku", "haiku by default");
    return { text: JSON.stringify({ what: `About: ${/Task #(\d+)/.exec(prompt)[1]}`, ask: "Try it", cost: "Little", stakes: /Risk: data/.test(prompt) ? 8 : 2 }) };
  };
  s.behaviours.set("Risky", () => ({ reply: "Changed the data.\n\nStatus: done · Risk: data · Try: ready" }));
  const v = s.actions.create({ projectId: s.project.id, title: "Risky", run: true });
  const proposal = await s.call("propose", { title: "An agent idea", description: "Something", projectId: s.project.id, confirm: true }, "t_agent1");
  await s.until(() => s.store.get(v.id).brief && s.store.get(String(proposal.number)).brief, "both briefed");
  eq(s.store.get(v.id).brief.stakes, 8, "the brief");
  const view = s.p.view(v.id);
  eq(view.stakes.level, "high", `stakes ${JSON.stringify(view.stakes)}`);
  eq(s.store.get(String(proposal.number)).source.kind, "agent", "from an agent");
  const task = await s.call("task", { number: Number(v.id) });
  assert(task.brief && task.stakesWhy.includes("Risk: data"), "task gives the brief and why the stakes");
  s.p.stop();
});

await test("scouts: off refuses; a code scout runs read-only, proposes, and its run is kept", async () => {
  const s = await setup({ global: { scouts: "off" } });
  await s.call("scout", { projectId: s.project.id }).then(
    () => assert(false, "off refuses"),
    (e) => assert(/Scouts are off/.test(e.message), e.message),
  );
  s.store.setGlobal({ scouts: "ask" });
  s.behaviours.set("Code scout*", async (t) => {
    await s.call("propose", { title: "Guard the empty list", description: "src/list.js:12 crashes on []", projectId: s.project.id, confirm: true, size: "S" }, t.id);
    return { reply: 'Looked at src.\n\n```json\n{"area": "src", "summary": "one crash", "filed": 1}\n```' };
  });
  const sent = await s.call("scout", { projectId: s.project.id, kind: "code", focus: "crashes" });
  assert(sent.scout.threadId, "a thread");
  const start = s.claude.calls.find((c) => c[0] === "start")[1];
  eq([start.permissionMode, start.model, start.workspace], ["dontAsk", "sonnet", "project"], "read-only, sonnet, the project's folder");
  assert(start.allowedTools.includes("mcp__layr__pipeline__propose") && !start.allowedTools.includes("Bash"), "reading and filing tools only");
  await s.until(() => (s.p.scouts.state().runs ?? []).length === 1, "its run is kept");
  const run = s.p.scouts.state().runs[0];
  eq([run.kind, run.area, run.filed, run.summary], ["code", "src", 1, "one crash"], "the run");
  const task = s.store.entries().find(([, t]) => t.title === "Guard the empty list")[1];
  eq(task.source.kind, "scout", "the proposal is the scout's");
  const listed = await s.call("scouts", {});
  assert(listed.lines.some((l) => /Code scout/.test(l)), "listed for the orchestrator");
  // Auto: while Away and idle, one per project.
  s.store.setGlobal({ scouts: "auto" });
  s.p.setMode("away");
  s.store.mutate(task.number.toString(), () => ({ later: nowIso() }));
  await s.until(() => (s.p.scouts.state().runs ?? []).length === 2, "an automatic scout ran while Away");
  s.p.stop();
});

await test("orchestrator: a check-in thread when something changed, nothing when nothing did", async () => {
  const s = await setup({ global: { orchestrator: true, orchestratorRun: "never" } });
  let prompt = null;
  s.behaviours.set("Check-in*", (t, text) => {
    prompt = text;
    return { reply: "Nothing to run yet.\n\nLog: Nothing to do" };
  });
  s.actions.create({ projectId: s.project.id, title: "Waiting proposal", prompt: "do it" });
  const first = await s.p.orchestrator.lookNow(false);
  assert(first.started, `checks in: ${JSON.stringify(first)}`);
  const start = s.claude.calls.filter((c) => c[0] === "start").at(-1)[1];
  eq(start.permissionMode, "dontAsk", "dontAsk");
  assert(!start.allowedTools.includes("mcp__layr__pipeline__run") && start.allowedTools.includes("mcp__layr__pipeline__tasks"), "running proposals: never");
  eq(s.claude.projectsList.find((x) => x.id === start.project)?.name, "Pipeline orchestrator", "its own claude project");
  await s.until(() => s.p.orchestrator.status().threads[0]?.status === "done", "the check-in ends");
  assert(/#1 Waiting proposal/.test(prompt) && /first check-in/.test(prompt), "the state and why");
  eq(s.p.orchestrator.status().threads[0].log, "Nothing to do", "its log line");
  const again = await s.p.orchestrator.lookNow(false);
  eq(again.started, false, "nothing changed: no check-in");
  s.actions.create({ projectId: s.project.id, title: "Second proposal", prompt: "more" });
  const third = await s.p.orchestrator.lookNow(false);
  assert(third.started, "a new proposal wakes it");
  await s.until(() => s.p.orchestrator.status().threads[0]?.status === "done", "ends");
  const wake = await s.call("orchestrator", { action: "wake", inMinutes: 30, note: "the window resets" });
  assert(wake.wake.note === "the window resets", "scheduled");
  s.p.setMode("stop");
  s.actions.create({ projectId: s.project.id, title: "Third proposal", prompt: "x" });
  eq((await s.p.orchestrator.lookNow(false)).why, "Soft stop", "Soft stop: no check-in by itself");
  s.p.stop();
});

await test("keep up to date: after a landing the update command runs in the project's folder; approve waits", async () => {
  const command = process.platform === "win32" ? "Set-Content -Path updated.txt -Value $env:LAYR_COMMIT" : 'printf "%s" "$LAYR_COMMIT" > updated.txt';
  const s = await setup({ settings: { updateMain: true, updateCommand: command } });
  await s.p.updater.tick();
  eq(s.p.updater.all()[s.project.id].status, "current", "turning it on with nothing new counts as done");
  s.behaviours.set("Update me", (t, text, tools, dir) => {
    commitFile(dir, "u.txt", "u", "Add u.txt");
    return { reply: DONE };
  });
  const v = s.actions.create({ projectId: s.project.id, title: "Update me", run: true });
  await s.until(() => s.why(v.id) === "finished", "finished");
  s.actions.land(v.id);
  await s.until(() => s.store.get(v.id).landed, "landed");
  await s.until(() => s.p.updater.all()[s.project.id]?.doneOn === s.store.get(v.id).landed.commit, "the update ran", 20000);
  eq(readFileSync(path.join(s.repo, "updated.txt"), "utf8").trim(), s.store.get(v.id).landed.commit, "with LAYR_COMMIT");
  s.store.setProject(s.project.id, { updateApprove: true });
  commitFile(s.repo, "x.txt", "x", "by hand");
  await s.p.updater.check(s.project.id);
  eq(s.p.updater.all()[s.project.id].ready, true, "waits for Update now");
  await s.call("updates", { projectId: s.project.id, now: true });
  await s.until(() => s.p.updater.all()[s.project.id]?.doneOn === git(s.repo, "rev-parse", "HEAD"), "Update now ran it", 20000);
  s.p.stop();
});

await test("attachments: images go to the thread as images, other files by path", async () => {
  const s = await setup();
  const png = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==";
  const image = (await s.call("attach", { name: "shot.png", mediaType: "image/png", data: png })).file;
  const log = (await s.call("attach", { name: "error.log", mediaType: "text/plain", data: Buffer.from("boom").toString("base64") })).file;
  const v = s.actions.create({ projectId: s.project.id, title: "With files", attachments: [image.id, log.id], run: true });
  await s.until(() => s.why(v.id) === "finished", "finished");
  const start = s.claude.calls.find((c) => c[0] === "start")[1];
  eq(start.images.length, 1, "one image");
  eq(start.images[0].mediaType, "image/png", "as an image");
  assert(start.prompt.includes("error.log") && start.prompt.includes(s.p.attachments.dir), "the log by its path");
  assert(!existsSync(path.join(s.p.attachments.dir, `${image.id}.png`)), "the image was dropped once sent");
  assert(existsSync(path.join(s.p.attachments.dir, `${log.id}.log`)), "the log stays");
  const shot = (await s.call("attach", { name: "again.png", mediaType: "image/png", data: png })).file;
  await s.call("send", { number: Number(v.id), text: "look at this", attachments: [shot.id] });
  await s.until(() => s.claude.calls.some((c) => c[0] === "send" && c[2] === "look at this" && c[4]?.length === 1), "a message with an image");
  await s.call("attach", { name: "big.bin", data: Buffer.alloc(6 * 1024 * 1024).toString("base64") }).then(
    () => assert(false, "too big"),
    (e) => assert(/5 MB/.test(e.message), e.message),
  );
  s.p.stop();
});

console.log(`${passed} passed, ${failures} failed`);
try {
  rmSync(tmp, { recursive: true, force: true, maxRetries: 3 });
} catch {
  // Windows may hold a file a moment longer
}
process.exit(failures ? 1 : 0);
