// The board table's views (panels/tableview.js, task #50): sorting by several columns, moving and showing columns,
// grouping, telling a changed view from its saved one, and what ticked rows can do together.
//   node test/table.test.js
import assert from "node:assert/strict";
import {
  bulkActions,
  clickSort,
  groupTasks,
  moveBy,
  moveColumn,
  newViewId,
  normalize,
  sameView,
  savedViews,
  sortTasks,
  startingViews,
  subTasksText,
  toggleColumn,
} from "../panels/tableview.js";

let passed = 0;
const test = (name, fn) => {
  fn();
  passed++;
  console.log(`PASS ${name}`);
};

const task = (number, extra = {}) => ({ id: String(number), number, title: `Task ${number}`, projectId: "a", column: "proposed", ...extra });
const projects = { a: { title: "Alpha" }, b: { title: "beta" } };

test("the starting views until views are saved", () => {
  const views = savedViews(null);
  assert.deepEqual(views.map((v) => v.name), ["Open", "Waits for me", "Running", "Settled"]);
  assert.ok(!views[0].stages.includes("settled"));
  assert.deepEqual(savedViews([]).map((v) => v.id), views.map((v) => v.id));
  assert.deepEqual(savedViews([{ id: "x", name: "Mine", columns: ["title"] }]).map((v) => v.name), ["Mine"]);
});

test("normalize drops unknown columns, sorts on unsortable columns and bad widths", () => {
  const v = normalize({ id: "x", name: "X", columns: ["title", "nope", "title", "actions"], widths: { title: 10, nope: 50, branch: 5000 },
    sorts: [{ by: "actions", desc: true }, { by: "nope" }], stages: ["settled", "bogus", "proposed"], group: "weird" });
  assert.deepEqual(v.columns, ["title", "actions"]);
  assert.deepEqual(v.widths, { title: 40, branch: 900 });
  assert.deepEqual(v.sorts, [{ by: "number", desc: true }]);
  assert.deepEqual(v.stages, ["proposed", "settled"]);
  assert.equal(v.group, "none");
});

test("a changed view is told from its saved one; the name and id don't count", () => {
  const [open] = startingViews();
  assert.ok(sameView(open, { ...open, name: "Other", id: "z" }));
  assert.ok(sameView(open, { ...open, query: "  " }));
  assert.ok(!sameView(open, { ...open, query: "fix" }));
  assert.ok(!sameView(open, { ...open, widths: { title: 300 } }));
  assert.ok(sameView({ ...open, widths: { a: 1, title: 300, number: 60 } }, { ...open, widths: { number: 60, title: 300 } }));
  assert.ok(!sameView(open, { ...open, stages: ["proposed"] }));
  assert.ok(!sameView(open, { ...open, group: "project" }));
});

test("click to sort, Shift+click to sort by several", () => {
  let s = clickSort([{ by: "changed", desc: true }], "title", false);
  assert.deepEqual(s, [{ by: "title", desc: false }]);
  s = clickSort(s, "title", false);
  assert.deepEqual(s, [{ by: "title", desc: true }]);
  s = clickSort([{ by: "title", desc: false }], "changed", true);
  assert.deepEqual(s, [{ by: "title", desc: false }, { by: "changed", desc: true }]);
  s = clickSort(s, "changed", true);
  assert.deepEqual(s, [{ by: "title", desc: false }, { by: "changed", desc: false }]);
  s = clickSort(s, "changed", true);
  assert.deepEqual(s, [{ by: "title", desc: false }]);
  assert.deepEqual(clickSort(s, "title", true), [{ by: "title", desc: true }]);
});

test("sorting by several columns; empty values last either way; ties newest first", () => {
  const tasks = [
    task(1, { column: "stopped", stakes: { score: 3 } }),
    task(2, { column: "proposed" }),
    task(3, { column: "stopped", stakes: { score: 8 } }),
    task(4, { column: "proposed", stakes: { score: 1 } }),
  ];
  const n = (list) => list.map((t) => t.number);
  assert.deepEqual(n(sortTasks(tasks, [{ by: "stage", desc: false }, { by: "stakes", desc: true }])), [4, 2, 3, 1]);
  assert.deepEqual(n(sortTasks(tasks, [{ by: "stakes", desc: false }])), [4, 1, 3, 2]);
  assert.deepEqual(n(sortTasks(tasks, [{ by: "stakes", desc: true }])), [3, 1, 4, 2]);
  assert.deepEqual(n(sortTasks(tasks, [{ by: "title", desc: false }])), [1, 2, 3, 4]);
  const named = [task(1, { projectId: "b" }), task(2, { projectId: "a" })];
  assert.deepEqual(n(sortTasks(named, [{ by: "project", desc: false }], projects)), [2, 1]);
  const sized = [task(1, { size: "L" }), task(2, { size: "S" }), task(3)];
  assert.deepEqual(n(sortTasks(sized, [{ by: "size", desc: false }])), [2, 3, 1]);
});

test("moving columns: before another, to the end; one place left or right", () => {
  assert.deepEqual(moveColumn(["a", "b", "c", "d"], "d", "b"), ["a", "d", "b", "c"]);
  assert.deepEqual(moveColumn(["a", "b", "c"], "a", null), ["b", "c", "a"]);
  assert.deepEqual(moveColumn(["a", "b", "c"], "b", "b"), ["a", "b", "c"]);
  assert.deepEqual(moveBy(["a", "b", "c"], 0, 1), ["b", "a", "c"]);
  assert.deepEqual(moveBy(["a", "b", "c"], 0, -1), ["a", "b", "c"]);
});

test("a column shown again goes back where it belongs; the last one stays", () => {
  assert.deepEqual(toggleColumn(["number", "title", "changed"], "status"), ["number", "title", "status", "changed"]);
  assert.deepEqual(toggleColumn(["title", "number"], "project"), ["title", "number", "project"]);
  assert.deepEqual(toggleColumn(["number", "title"], "number"), ["title"]);
  assert.deepEqual(toggleColumn(["title"], "title"), ["title"]);
  assert.deepEqual(toggleColumn(["actions"], "number"), ["number", "actions"]);
});

test("groups: projects by title, stages left to right, none as one group", () => {
  const rows = [task(1, { projectId: "b", column: "settled" }), task(2, { projectId: "a", column: "running" }), task(3, { projectId: "b", column: "running" })];
  const byProject = groupTasks(rows, "project", projects);
  assert.deepEqual(byProject.map((g) => [g.label, g.rows.map((t) => t.number)]), [["Alpha", [2]], ["beta", [1, 3]]]);
  const byStage = groupTasks(rows, "stage", projects);
  assert.deepEqual(byStage.map((g) => [g.key, g.rows.length]), [["stage:running", 2], ["stage:settled", 1]]);
  assert.deepEqual(groupTasks(rows, "none").map((g) => g.rows.length), [3]);
});

test("ticked rows: each action with the tasks it fits; no Try, Discard or Brief", () => {
  const tasks = [
    task(1),
    task(2, { held: [{ kind: "launch" }] }),
    task(3, { column: "stopped", threadId: "t", buttons: [{ id: "land" }, { id: "try" }, { id: "settle" }] }),
    task(4, { column: "stopped", threadId: "t", buttons: [{ id: "settle" }] }),
    task(5, { column: "settled", threadId: "t", buttons: [{ id: "discard" }, { id: "brief" }] }),
  ];
  const acts = bulkActions(tasks);
  assert.deepEqual(acts.map((a) => [a.id, a.tasks.map((t) => t.number)]), [["run", [1]], ["land", [3]], ["settle", [3, 4]]]);
  assert.ok(acts.every((a) => a.label && a.about));
});

test("new view ids don't clash", () => {
  assert.equal(newViewId([{ id: "open" }, { id: "v2" }]), "v3");
  assert.equal(newViewId([{ id: "v2" }]), "v3");
});

test("a batch's sub-tasks one after the other; Tested and 🚩 sort marked ones first", () => {
  const b = task(84, { batch: true, members: [{ id: "84-1", number: "84-1", title: "Old" }, { id: "100", number: 100, title: "Legacy" }] });
  assert.equal(subTasksText(b, { "84-1": { number: "84-1", title: "New" } }), "#84-1 New · #100 Legacy");
  assert.equal(subTasksText(task(1)), "");
  const rows = sortTasks([task(1), task(2, { tested: "2026-11-19T10:00:00Z" }), task(3, { controversial: "2026-11-19T11:00:00Z" })], [{ by: "tested", desc: true }]);
  assert.equal(rows[0].number, 2);
  assert.equal(sortTasks(rows, [{ by: "controversial", desc: true }])[0].number, 3);
  assert.ok(normalize({ columns: ["number", "tested", "controversial"] }).columns.includes("controversial"));
});

console.log(`${passed} passed`);
