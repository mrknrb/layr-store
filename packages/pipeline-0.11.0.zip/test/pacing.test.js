// Pacing (backend/pacing.js) and 🌙 When Away for proposals: the pure parts, then the pipeline with a fake claude
// plugin and a fake accounts plugin on the hub. Run: node test/pacing.test.js
import { execFileSync } from "node:child_process";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { createActions } from "../backend/actions.js";
import { placeTask } from "../backend/columns.js";
import { batchPrompt } from "../backend/prompts.js";
import {
  accountRoom,
  accountsFrom,
  parseBackAt,
  release,
  roomOf,
  SIZE_COST,
  sizeCosts,
  sizeFromAnswer,
  stillNeeds,
  turnCost,
} from "../backend/pacing.js";
import { Pipeline } from "../backend/pipeline.js";
import { Store } from "../backend/store.js";
import { FakeClaude } from "./fakeClaude.js";

let failures = 0;
let passed = 0;
async function test(name, fn) {
  try {
    await fn();
    passed++;
    console.log(`ok   ${name}`);
  } catch (error) {
    failures++;
    console.log(`FAIL ${name}: ${error.stack || error.message}`);
  }
}
const assert = (cond, msg) => {
  if (!cond) throw new Error(msg || "assertion failed");
};
const eq = (a, b, msg) => assert(JSON.stringify(a) === JSON.stringify(b), `${msg}: ${JSON.stringify(a)} != ${JSON.stringify(b)}`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const HOUR = 3_600_000;

// ---------------------------------------------------------------- the pure parts

await test("size costs: defaults until three landed tasks of a size, then their median", () => {
  eq(sizeCosts([]), SIZE_COST, "defaults");
  const ppu = 10;
  const two = [{ size: "S", spentUsd: 0.5 }, { size: "S", spentUsd: 0.7 }];
  eq(sizeCosts(two, ppu).S, 10, "two samples: still the default");
  const three = [...two, { size: "S", spentUsd: 3 }];
  eq(sizeCosts(three, ppu).S, 7, "median of 5, 7, 30");
  eq(sizeCosts(three, ppu).M, 30, "M untouched");
});

await test("still needs and a turn's cost", () => {
  const c = { S: 10, M: 30, L: 60 };
  eq(stillNeeds({ size: "M", spentUsd: 1 }, c, 10), 20, "30 less 10 spent");
  eq(stillNeeds({ size: "S", spentUsd: 5 }, c, 10), 0, "past its estimate: nothing");
  eq(turnCost({ size: "S", spentUsd: 5 }, c, 10), 5, "a turn costs at least half an S");
  eq(stillNeeds({}, c), 30, "no size: M");
});

await test("an account's room: its 5-hour gap, more windows before `until`, held to the week", () => {
  const now = Date.parse("2026-11-18T22:00:00Z");
  const a = { weight: 1, fiveAt: 100, weekAt: 100, five: { pct: 70, resetsAt: new Date(now + 2 * HOUR).toISOString() }, week: { pct: 10, resetsAt: new Date(now + 5 * 24 * HOUR).toISOString() } };
  eq(accountRoom(a, { now, weekPerFive: 0.1 }), 30, "now: 30 left");
  eq(accountRoom(a, { now, until: now + 8 * HOUR, weekPerFive: 0.1 }), 230, "two resets before 06:00 add two windows");
  eq(accountRoom({ ...a, weight: 5 }, { now, weekPerFive: 0.1 }), 150, "a Max 5x point counts five");
  const tight = { ...a, week: { pct: 98, resetsAt: a.week.resetsAt } };
  eq(Math.round(accountRoom(tight, { now, weekPerFive: 0.1 })), 20, "2% of the week left = 20 five-hour points");
  // Away since 20:00 at 10% of the week, 5 days left: the night's share is 18% of the week; 8% used since.
  const away = { ...a, week: { pct: 18, resetsAt: a.week.resetsAt } };
  const start = { at: new Date(now - 2 * HOUR).toISOString(), week: 10 };
  const room = accountRoom(away, { now, until: now + 8 * HOUR, weekPerFive: 0.1, awayStart: start });
  assert(room > 90 && room < 110, `about (90/5.08 - 8) / 0.1 ≈ 97 points, got ${room}`);
});

await test("all accounts' room, less the reserve; accounts from the accounts plugin or the claude reading", () => {
  const now = Date.now();
  const overview = {
    autoSwitch: true,
    switchPoints: { fiveHour: 90, weekly: 95 },
    accounts: [
      { email: "a@x", active: true, enabled: true, state: "ok", weight: 1, fiveHour: { pct: 50, resetsAt: null }, weekly: { pct: 0, resetsAt: null } },
      { email: "b@x", active: false, enabled: true, state: "ok", weight: 5, fiveHour: { pct: 80, resetsAt: null }, weekly: null },
      { email: "c@x", active: false, enabled: false, state: "ok", weight: 1, fiveHour: { pct: 0 }, weekly: null },
      { email: "d@x", active: false, enabled: true, state: "needs-login", weight: 1, fiveHour: { pct: 0 }, weekly: null },
    ],
  };
  const list = accountsFrom({ overview });
  eq(list.map((a) => a.email), ["a@x", "b@x"], "only accounts that work and auto-switch may use");
  eq(roomOf(list, { now, reserve: 15 }), 40 + 50 - 15, "a: 40, b: 10×5, less 15");
  const one = accountsFrom({ reading: { account: "a@x", fiveHour: { pct: 20, resetsAt: null }, weekly: null, at: new Date().toISOString() } });
  eq(roomOf(one, { now }), 80, "the claude reading: one account up to 100");
  eq(roomOf([], { now }), null, "nothing known");
});

await test("release: in order while it fits; when nothing runs the first goes anyway", () => {
  const items = [{ id: "1", cost: 10 }, { id: "2", cost: 10 }, { id: "3", cost: 3 }];
  eq(release(items, 15).go, ["1", "3"], "1 fits, 2 doesn't, 3 does");
  eq(release([{ id: "1", cost: 50 }], 15, { idle: true }).go, ["1"], "idle: the first goes");
  eq(release([{ id: "1", cost: 50 }], 15).go, [], "not idle: it waits");
  eq(release([{ id: "1", cost: 5 }], 0, { idle: true }).go, [], "no room at all: nothing");
});

await test("back at: HH:MM is the next such time; an ISO time in the past is no time", () => {
  const now = new Date(2026, 10, 18, 22, 0).getTime();
  const at = new Date(parseBackAt("08:00", now));
  eq([at.getDate(), at.getHours(), at.getMinutes()], [19, 8, 0], "tomorrow 08:00");
  eq(new Date(parseBackAt("23:30", now)).getDate(), 18, "later today");
  eq(parseBackAt("25:00", now), null, "not a time");
  eq(parseBackAt(new Date(now - 1000).toISOString(), now), null, "past");
  eq(sizeFromAnswer("m"), "M", "a lowercase letter");
  eq(sizeFromAnswer("I'd say L."), "L", "in a sentence");
  eq(sizeFromAnswer("medium"), null, "no letter");
});

// ---------------------------------------------------------------- the pipeline

const tmp = mkdtempSync(path.join(os.tmpdir(), "layr-pacing-test-"));
const git = (dir, ...args) => execFileSync("git", ["-C", dir, ...args], { stdio: ["ignore", "pipe", "pipe"] }).toString().trim();

async function setup({ overview = null, global = {} } = {}) {
  const repo = path.join(tmp, `repo-${Math.random().toString(36).slice(2, 7)}`);
  execFileSync("git", ["init", "-q", "-b", "main", repo]);
  git(repo, "config", "user.name", "Test");
  git(repo, "config", "user.email", "test@example.com");
  writeFileSync(path.join(repo, "README.md"), "# Demo\n");
  git(repo, "add", ".");
  git(repo, "commit", "-q", "-m", "init");
  const store = new Store(path.join(tmp, `data-${path.basename(repo)}`));
  const claude = new FakeClaude();
  const project = await claude.addProject(repo);
  const calls = [];
  const hub = {
    available: !!overview,
    emit() {},
    notify() {},
    async call(name, args) {
      calls.push(name);
      if (name === "accounts__usage") return overview;
      if (name === "accounts__next_room") return { next: null };
      return {};
    },
  };
  const p = new Pipeline({ store, claude, hub, logger: () => {} });
  const actions = createActions(p);
  store.setGlobal({ pollSec: 1, maxRunning: 3, ...global });
  store.setProject(project.id, { enabled: true, baseBranch: "main" });
  await p.refreshProjects();
  const until = async (cond, what, ms = 10000) => {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      if (await cond()) return;
      p.wake();
      await sleep(50);
    }
    throw new Error(`timed out: ${what}`);
  };
  return { store, claude, project, p, actions, until, calls };
}

await test("🌙 When away is a toggle: a proposal waits in Ready and launches when you go Away; off is Proposed; Run now", async () => {
  const s = await setup();
  s.p.start();
  const a = s.actions.create({ projectId: s.project.id, title: "Night work", prompt: "do it", whenAway: true });
  eq([a.column, a.why], ["ready", "ready"], "in Ready");
  assert(a.buttons.some((b) => b.id === "start" && b.label === "Run now"), "Run now");
  eq(a.toggles.whenAway, { on: true, can: true }, "the toggle is on");
  const b = s.actions.create({ projectId: s.project.id, title: "Changed my mind", prompt: "x" });
  s.actions.run(b.id, { away: true });
  eq(s.p.view(b.id).column, "ready", "run whenAway");
  s.actions.edit(b.id, { whenAway: false });
  eq([s.p.view(b.id).column, s.store.get(b.id).whenAway], ["proposed", undefined], "toggled off: back to Proposed");
  s.actions.edit(b.id, { whenAway: true });
  eq(s.p.view(b.id).column, "ready", "toggled on again: Ready");
  s.actions.edit(b.id, { plan: true });
  eq([s.p.view(b.id).column, s.store.get(b.id).whenAway], ["proposed", true], "Plan on: it waits for Run (planning needs you)");
  s.actions.edit(b.id, { plan: false });
  eq(s.p.view(b.id).column, "ready", "Plan off again: back in Ready");
  s.actions.parked(b.id, "drop");
  eq([s.p.view(b.id).column, s.store.get(b.id).whenAway], ["proposed", undefined], "dropped: back to Proposed, toggle off");
  let threw = false;
  try {
    s.actions.run(a.id, { away: true });
  } catch {
    threw = true;
  }
  assert(threw, "twice for Away is refused");
  await sleep(200);
  assert(!s.store.get(a.id).threadId, "Here: it waits");
  s.p.setMode("away", { backAt: new Date(Date.now() + 8 * HOUR).toISOString() });
  await s.until(() => !!s.store.get(a.id).threadId, "Away launches it");
  assert(s.store.state().awayUntil, "the back-at time is kept");
  eq(s.p.status().backAt, s.store.state().awayUntil, "status says when you're back");
  s.p.setMode("here");
  assert(!s.store.state().awayUntil && !s.store.state().awayStart, "back: forgotten");
  // Run on a proposal waiting in Ready (not for Away) sends it now.
  const c = s.actions.create({ projectId: s.project.id, title: "Now after all", prompt: "x", whenAway: true });
  s.actions.run(c.id);
  eq(s.store.get(c.id).parked, undefined, "no longer parked");
  eq(s.store.get(c.id).whenAway, undefined, "Run now turns When away off");
  await s.until(() => !!s.store.get(c.id).threadId, "it launches in Here");
  s.p.stop();
});

await test("a plan task with When away doesn't wait in Ready as a launch", async () => {
  const s = await setup();
  const t = s.actions.create({ projectId: s.project.id, title: "Plan it", prompt: "x", start: "manual", plan: true });
  s.actions.run(t.id, { away: true });
  const v = s.p.view(t.id);
  eq([v.column, v.whenAway, v.parked], ["proposed", true, undefined], "flagged, not parked");
});

await test("🌙 on a running thread: your messages wait; agents' don't; off gives them back unsent", async () => {
  const s = await setup();
  const t = s.actions.create({ projectId: s.project.id, title: "Talk", prompt: "x" });
  s.store.mutate(t.id, () => ({ threadId: "th1", thread: { status: "done", turnEndedAt: new Date().toISOString() } }));
  s.actions.edit(t.id, { whenAway: true });
  s.actions.message(t.id, "later please");
  eq(s.p.view(t.id).column, "ready", "Ready");
  s.actions.message(t.id, "agent note", { by: "agent" });
  eq(s.store.get(t.id).parked.map((m) => m.text), ["later please"], "yours waits");
  assert(s.store.get(t.id).held.some((m) => m.text === "agent note"), "the agent's goes");
  s.actions.edit(t.id, { whenAway: false });
  eq([s.store.get(t.id).parked, s.store.get(t.id).unsent?.text], [undefined, "later please"], "back, unsent");
  assert(!s.store.get(t.id).held.some((m) => m.text === "later please"), "not sent");
  s.actions.unsentTaken(t.id);
  eq(s.store.get(t.id).unsent, undefined, "taken");
});

await test("🌙 with Land: it waits in Ready and lands when you go Away; Land now, Don't land, the toggle", async () => {
  const s = await setup();
  const t = s.actions.create({ projectId: s.project.id, title: "Land later", prompt: "x" });
  const finished = () => ({ threadId: "th1", thread: { status: "done", turnStatus: "done", turnEndedAt: new Date().toISOString() },
    work: { ahead: 1, dirty: 0, head: "abc" } });
  s.store.mutate(t.id, finished);
  s.actions.edit(t.id, { whenAway: true });
  const labels = () => s.p.view(t.id).buttons.map((b) => b.label);
  assert(labels().includes("Land · 🌙"), `Land says it waits: ${labels()}`);
  s.actions.land(t.id);
  const lands = (list) => !!list?.some((m) => m.kind === "land");
  eq([lands(s.store.get(t.id).parked), lands(s.store.get(t.id).held)], [true, false], "the land waits for Away");
  const v = s.p.view(t.id);
  eq(v.column, "ready", "Ready");
  eq(v.note, "🌙 Lands when you're Away", "the card says so");
  assert(labels().includes("Land now") && labels().includes("Don't land"), `its buttons: ${labels()}`);
  let refused = "";
  try { s.actions.land(t.id); } catch (error) { refused = error.message; }
  assert(/landing already/.test(refused), `a second Land: ${refused}`);
  // Don't land: Land is back.
  s.actions.parked(t.id, "drop");
  eq(s.store.get(t.id).parked, undefined, "dropped");
  assert(labels().includes("Land · 🌙"), `Land is back: ${labels()}`);
  // Turning When away off drops a waiting land too.
  s.actions.land(t.id);
  s.actions.edit(t.id, { whenAway: false });
  eq([s.store.get(t.id).parked, lands(s.store.get(t.id).held)], [undefined, false], "toggle off: not landed");
  // A Land waiting for a slot moves to Ready when the toggle goes on.
  s.actions.land(t.id);
  assert(lands(s.store.get(t.id).held), "without When away it goes at once");
  s.actions.edit(t.id, { whenAway: true });
  eq([lands(s.store.get(t.id).parked), lands(s.store.get(t.id).held)], [true, false], "moved to Ready");
  // Away: it goes to the gate.
  s.p.setMode("away");
  eq([s.store.get(t.id).parked, lands(s.store.get(t.id).held)], [undefined, true], "released when Away");
  s.p.stop();
});

await test("🌙 with auto-merge: layr's own land waits for Away too", async () => {
  const s = await setup();
  const t = s.actions.create({ projectId: s.project.id, title: "Auto", prompt: "x" });
  s.store.mutate(t.id, () => ({ threadId: "th2", whenAway: true }));
  s.p.agentHoldLand(t.id);
  eq([s.store.get(t.id).parked?.map((m) => m.kind), s.store.get(t.id).held], [["land"], undefined], "parked, not held");
  s.p.stop();
});

await test("batches: several open per project, a new one, one made with its tasks", async () => {
  const s = await setup();
  const mk = (title) => s.actions.create({ projectId: s.project.id, title, prompt: "x" });
  const sub = (title, batch) => s.actions.create({ projectId: s.project.id, title, prompt: "x", batch });
  const a = sub("A", "new");
  const b = sub("B", "new");
  assert(s.store.get(a.id).inBatch !== s.store.get(b.id).inBatch, "two batches");
  const c = sub("C", Number(s.store.get(a.id).inBatch));
  eq(s.store.get(c.id).inBatch, s.store.get(a.id).inBatch, "into the one named");
  eq(c.number, `${s.store.get(a.id).inBatch}-2`, "the second in it");
  const made = s.actions.create({ projectId: s.project.id, title: "Pipeline bits", tasks: [{ title: "One", prompt: "1" }, { title: "Two" }] });
  assert(made.batch && made.members.length === 2, "a batch with two tasks");
  eq(made.members.map((m) => m.number), [`${made.number}-1`, `${made.number}-2`], "numbered in the batch");
  eq(mk("Next").number, made.number + 1, "sub-tasks take no project numbers");
  // Taken out, a sub-task is a proposal of its own with the next number; its id (and links to it) stay.
  const out = s.actions.toBatch(c.id, null);
  eq([out.id, out.number, out.inBatch], [c.id, made.number + 2, undefined], "taken out: the next number");
  s.actions.edit(made.id, { plan: true });
  assert(s.store.get(made.id).plan, "a batch can plan");
  // Task #66: a sub-task with only details keeps them (its first line is the title); an Edit adds sub-tasks, and a
  // proposal becomes a batch with them, its own description going to the worker as what the batch is about.
  const untitled = s.actions.create({ projectId: s.project.id, title: "Bits", tasks: [{ title: "", prompt: "Fix the scroll\nit jumps" }] });
  eq(untitled.members.map((m) => m.title), ["Fix the scroll"], "an untitled sub-task takes its first line");
  s.actions.edit(made.id, { tasks: [{ title: "Three", prompt: "3" }] });
  eq(s.p.members(made.id).length, 3, "a batch's Edit adds a task");
  const single = mk("Threads");
  s.actions.edit(single.id, { prompt: "All about threads", tasks: [{ title: "Scroll", prompt: "" }] });
  assert(s.store.get(single.id).batch && s.p.members(single.id).length === 1, "a proposal becomes a batch with its sub-tasks");
  const message = batchPrompt(s.p.members(single.id), s.store.get(single.id).prompt);
  assert(/What the whole batch is about\n\nAll about threads/.test(message) && /## #\d+-1: Scroll/.test(message) && /`#\d+-1 done`/.test(message), message);
  const away = s.actions.create({ projectId: s.project.id, title: "Elsewhere", prompt: "x", noWorktree: true });
  let refused = "";
  try {
    s.actions.edit(away.id, { tasks: [{ title: "No" }] });
  } catch (e) {
    refused = e.message;
  }
  assert(/can't have sub-tasks/.test(refused), `a task without a worktree can't: ${refused}`);
});

await test("pacing holds back what doesn't fit: Ready goes in order as far as the room goes", async () => {
  const now = Date.now();
  const overview = {
    autoSwitch: true,
    switchPoints: { fiveHour: 100, weekly: 100 },
    accounts: [{ email: "a@x", active: true, enabled: true, state: "ok", weight: 1, fiveHour: { pct: 70, resetsAt: new Date(now + 2 * HOUR).toISOString() }, weekly: { pct: 5, resetsAt: new Date(now + 6 * 24 * HOUR).toISOString() }, measuredAt: new Date().toISOString() }],
  };
  const s = await setup({ overview, global: { pacingReserve: 15 } });
  const ids = ["One", "Two", "Three"].map((title) => s.actions.create({ projectId: s.project.id, title, prompt: "x", size: "S", whenAway: true }).id);
  s.actions.reorder(["3", "1", "2"]);
  await s.p.pacing.read(true);
  assert(s.calls.includes("accounts__usage"), "reads the accounts plugin");
  const sum = s.p.pacing.summary();
  eq([sum.ready, sum.readyPct, sum.roomNowPct], [3, 30, 15], "3 × S = 30%, 30 left less 15 kept");
  assert(/Ready 3 ≈ 30%/.test(sum.line) && sum.fits === 3, `until back there are more windows: ${sum.line}`);
  s.p.setMode("away");
  // Only the top of Ready (#3) fits now (10 of 15); #1 and #2 wait for room.
  const parked = (id) => !!s.store.get(id).parked?.length;
  eq([parked("3"), parked("1"), parked("2")], [false, true, true], "only #3 went");
  const v = s.p.view("1");
  eq(v.column, "ready", "#1 still in Ready");
  assert(/waits for room/.test(v.waits) && /a window resets at/.test(v.waits), `why: ${v.waits}`);
  assert(/^🌙 waits for room/.test(v.note), `the card says so: ${v.note}`);
  eq(v.estimate, { size: "S", by: "you", pct: 10 }, "its guess");
  // Send now goes past pacing.
  s.actions.parked("1", "send");
  assert(!parked("1"), "Send now");
  s.p.stop();
  void ids;
});

await test("pacing off, or no readings: Ready all goes at once (as before)", async () => {
  const s = await setup({ global: { pacing: false } });
  for (const title of ["A", "B"]) s.actions.create({ projectId: s.project.id, title, prompt: "x", size: "L", whenAway: true });
  s.p.setMode("away");
  assert(s.store.entries().every(([, t]) => !t.parked?.length), "both released");
  eq(s.p.pacing.summary(), { on: false }, "no summary");
  const t = await setup();
  for (const title of ["A", "B"]) t.actions.create({ projectId: t.project.id, title, prompt: "x", size: "L", whenAway: true });
  t.p.setMode("away");
  assert(t.store.entries().every(([, x]) => !x.parked?.length), "no readings: both released");
});

await test("size guesses: a small model sizes tasks nobody sized; yours replaces a guess", async () => {
  const s = await setup();
  let asked = 0;
  s.claude.asker = async ({ prompt }) => {
    asked++;
    return { text: /Huge/.test(prompt) ? "L" : "S" };
  };
  const a = s.actions.create({ projectId: s.project.id, title: "Huge rewrite", prompt: "everything" });
  const b = s.actions.create({ projectId: s.project.id, title: "Typo", prompt: "fix" });
  const c = s.actions.create({ projectId: s.project.id, title: "Mine", prompt: "x", size: "M" });
  await s.p.pacing.guessSizes();
  eq([s.store.get(a.id).size, s.store.get(a.id).sizeBy], ["L", "guess"], "guessed L");
  eq(s.store.get(b.id).size, "S", "guessed S");
  eq(asked, 2, "the sized one isn't asked");
  await s.p.pacing.guessSizes();
  eq(asked, 2, "one try each");
  eq(s.p.view(a.id).estimate.by, "guess", "the card says it's a guess");
  s.actions.edit(b.id, { size: "M" });
  eq(s.store.get(b.id).sizeBy, undefined, "your size replaces the guess");
  void c;
});

await test("spend: a thread's costUsd is kept on its task; a started task's size can still change", async () => {
  const s = await setup();
  s.p.start();
  const t = s.actions.create({ projectId: s.project.id, title: "Spend", prompt: "x", size: "M", run: true });
  await s.until(() => !!s.store.get(t.id).threadId, "launched");
  const thread = s.store.get(t.id).threadId;
  await s.p.seeThread(t.id, { ...s.claude.summary(s.claude.threads.get(thread)), costUsd: 1.2345 });
  eq(s.store.get(t.id).spentUsd, 1.235, "kept, rounded");
  s.actions.edit(t.id, { size: "L" });
  eq(s.store.get(t.id).size, "L", "size changed on a started task");
  s.p.stop();
});

await test("calibration: the active account's 5-hour growth against what threads spent", async () => {
  const at = (min) => new Date(Date.now() + min * 60_000).toISOString();
  const reset = at(240);
  const overview = { autoSwitch: true, switchPoints: { fiveHour: 100, weekly: 100 }, accounts: [{ email: "a@x", active: true, enabled: true, state: "ok", weight: 5, fiveHour: { pct: 10, resetsAt: reset }, weekly: { pct: 2, resetsAt: at(9000) }, measuredAt: at(-30) }] };
  const s = await setup({ overview });
  let cost = 0;
  s.claude.list = async () => [{ id: "t1", costUsd: cost }];
  await s.p.pacing.read(true);
  cost = 4;
  overview.accounts[0] = { ...overview.accounts[0], fiveHour: { pct: 22, resetsAt: reset }, weekly: { pct: 3.2, resetsAt: overview.accounts[0].weekly.resetsAt }, measuredAt: at(0) };
  await s.p.pacing.read(true);
  const cal = s.store.crew("pacing");
  eq(cal.pointsPerUsd, { value: 15, n: 1 }, "12% × 5 per $4");
  eq(Math.round(cal.weekPerFive.value * 100) / 100, 0.1, "1.2% of the week per 12% of the window");
});

await test("a planning task: 🌙 on its answers approves it for Away; Approve while Away goes through Ready", async () => {
  const s = await setup();
  s.p.start();
  const plan = "The plan.\n\n## Questions\n1. 3 ⚪ Blue?\n   - A. ⭐ Yes (80%) **calm**\n\nStatus: asks · Risk: none · Try: none";
  s.claude.worker = async (thread, text) => ({ reply: /Start the work|go ahead/i.test(text) ? "Done.\n\nStatus: done · Risk: none · Try: none" : plan });
  const a = s.actions.create({ projectId: s.project.id, title: "Plan one", prompt: "x", start: "plan", run: true });
  const b = s.actions.create({ projectId: s.project.id, title: "Plan two", prompt: "y", plan: true, run: true });
  await s.until(() => s.p.view(a.id).approvable && s.p.view(b.id).approvable, "both planned");
  const ids = s.p.view(a.id).buttons.map((x) => x.id);
  assert(ids.includes("approve") && !ids.includes("approve_away"), `buttons: ${ids}`);
  // With When away on, answers to the plan still go now; only Approve waits.
  s.actions.edit(b.id, { whenAway: true });
  eq(s.p.view(b.id).buttons.find((x) => x.id === "approve")?.label, "Approve · 🌙", "the one Approve says it waits");
  s.actions.message(a.id, "My answers: 1A.", { away: true });
  const parked = s.store.get(a.id).parked[0];
  assert(parked.start && /\*\*Start the work\*\*/.test(parked.text) && /My answers: 1A\./.test(parked.text), parked.text);
  eq(s.p.view(a.id).column, "ready", "it waits in Ready");
  assert(!s.p.view(a.id).buttons.some((x) => x.id === "approve"), "approved already: no Approve");
  s.p.setMode("away");
  s.actions.approve(b.id, { text: "go" });
  assert(s.store.get(b.id).parked?.length || s.store.get(b.id).held?.length, "approve while Away is held or parked");
  await s.until(() => !s.store.get(a.id).planning && !s.store.get(b.id).planning, "both start the work");
  const sent = s.claude.calls.filter((c) => c[0] === "send").map((c) => c[2] ?? c[1]);
  assert(!JSON.stringify(sent).includes("Still Plan mode"), "no planning reminder went with them");
  s.p.stop();
});

await test("pacing: until a dollar's worth is measured, landed tasks' spend doesn't set the sizes", async () => {
  const s = await setup();
  for (let i = 0; i < 3; i++) {
    const t = s.actions.create({ projectId: s.project.id, title: `Big ${i}`, prompt: "x", size: "L" });
    s.store.mutate(t.id, () => ({ landed: { at: new Date().toISOString(), commit: "abc" }, spentUsd: 300 }));
  }
  eq(s.p.pacing.costs().L, 60, "the default, not 300 × the guess");
  eq(s.p.pacing.estimate(s.store.get("1")).spentPct, undefined, "no spent % yet");
  s.store.setCrew("pacing", { pointsPerUsd: { value: 0.5, n: 1 } });
  await sleep(1100);
  eq(s.p.pacing.costs().L, 150, "measured: 300 × 0.5");
});

await test("the columns: a parked launch is Ready, not Proposed", () => {
  eq(placeTask({ number: 1, parked: [{ kind: "launch", at: new Date().toISOString() }] }).column, "ready", "ready");
  eq(placeTask({ number: 1 }).column, "proposed", "proposed");
});

console.log(`${passed} passed, ${failures} failed`);
try {
  rmSync(tmp, { recursive: true, force: true, maxRetries: 3 });
} catch {
  // Windows may hold a file a moment longer
}
process.exit(failures ? 1 : 0);
