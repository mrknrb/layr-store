// The board as a table (task #50): views as tabs (each a saved setup of the whole table; a changed one offers Save,
// Save as new and Reset), stage chips, grouping by project or stage, a Columns picker, headings that sort (Shift:
// several), move (drag) and resize (drag the edge, double-click: fit), rows with the card's next step and ⋯ menu, ▸ to
// open a row's description, last reply and every button, ticked rows acted on together, and the keys (↑ ↓ Enter ← →
// Space Esc). The views' logic is in tableview.js; board.js keeps which view is shown and its unsaved changes.
import { asks, buttonCall, cardActions, cardBadges, cardMenu, nextStep, openTask, sizeChip, togglePills } from "./card.js";
import { act, ago, api, button, chip, confirmMenu, contextMenu, h, markdown, menuAt, projectLabel, promptMenu, selectedThread, STAKES_TONE, TONE } from "./common.js";
import {
  ALL_COLUMNS,
  bulkActions,
  clampWidth,
  clickSort,
  COLUMNS,
  firstLines,
  subTasksText,
  groupTasks,
  GROUPS,
  modelText,
  moveBy,
  moveColumn,
  newViewId,
  sortTasks,
  STAGE_TITLE,
  STAGES,
  START_LABEL,
  startingViews,
  TITLE_MIN,
  toggleColumn,
} from "./tableview.js";

const STAGE_TONE = { proposed: "neutral", ready: "accent", running: "progress", stopped: "warning", settled: "muted" };
const LEAD_WIDTH = 50;

/** What the table keeps between redraws, not saved: the row the keys move, the ticked rows, the opened rows. */
const ui = { selected: null, picked: new Set(), expanded: new Set(), busy: false, env: null, rows: [] };

/** A heading is being dragged or resized: the board waits with redrawing. */
export const tableBusy = () => ui.busy;

/**
 * Draw the table into `env.host`. `env`: { host, tasks (the board's, after project, search and hidden), projects (by
 * id), ctx (the cards' context), oneProject, views (saved, normalized), current (the view shown, with its unsaved
 * changes), dirty, change(patch), select(id), saveViews(list, selectId), reset(), folded (Set of group keys),
 * toggleFold(key), redraw(), notify(text, kind) }.
 */
export function drawTable(env) {
  ui.env = env;
  const { host, current: v } = env;
  const old = host.querySelector(".table-scroll");
  const scroll = old ? [old.scrollTop, old.scrollLeft] : null;
  const group = env.oneProject && v.group === "project" ? "none" : v.group;
  // The column the rows are grouped by says the same as the group's heading: left out meanwhile.
  const cols = v.columns.filter((c) => (c !== "project" || (!env.oneProject && group !== "project")) && (c !== "stage" || group !== "stage"));
  const shownStages = new Set(v.stages);
  const rows = sortTasks(env.tasks.filter((t) => shownStages.has(t.column)), v.sorts, env.projects);
  ui.rows = rows;
  const ids = new Set(env.tasks.map((t) => t.id));
  for (const id of [...ui.picked]) if (!ids.has(id)) ui.picked.delete(id);
  const groups = groupTasks(rows, group, env.projects);

  const table = h("table.tasks.grid");
  const widthOf = (c) => (c === "title" && !v.widths.title ? null : (v.widths[c] ?? COLUMNS[c].width ?? 240));
  const fixedSum = LEAD_WIDTH + cols.reduce((sum, c) => sum + (widthOf(c) ?? 0), 0);
  const auto = cols.some((c) => widthOf(c) === null);
  table.style.cssText = auto ? `width:100%;min-width:${fixedSum + TITLE_MIN}px` : `width:${fixedSum}px`;
  table.append(h("colgroup", {}, h("col", { style: `width:${LEAD_WIDTH}px` }), cols.map((c) => h("col", { "data-col": c, style: widthOf(c) === null ? undefined : `width:${widthOf(c)}px` }))));
  table.append(h("thead", {}, headRow(env, v, cols, rows)));
  const body = h("tbody");
  const span = cols.length + 1;
  for (const g of groups) {
    const folded = g.key && env.folded.has(g.key);
    if (g.key) body.append(groupRow(env, g, group, span, folded));
    if (folded) continue;
    for (const t of g.rows) {
      body.append(taskRow(env, t, cols));
      if (ui.expanded.has(t.id)) body.append(previewRow(env, t, span));
    }
  }
  if (!rows.length) {
    const why = !v.stages.length ? "Pick a stage above to see its tasks." : v.query.trim() ? "Nothing matches the search." : `Nothing in ${v.stages.map((s) => STAGE_TITLE[s]).join(", ")}.`;
    body.append(h("tr.empty-row", {}, h("td", { colspan: span }, why)));
  }
  table.append(body);
  const wrap = h("div.table-scroll", {}, table);
  host.replaceChildren(viewTabs(env), ui.picked.size ? bulkBar(env) : toolbar(env, rows.length), wrap);
  if (scroll) [wrap.scrollTop, wrap.scrollLeft] = scroll;
}

// ---------------------------------------------------------------- the views' tabs

function viewTabs(env) {
  const { views, current, dirty } = env;
  const tabs = views.map((x, i) => {
    const on = x.id === current.id;
    return h(`button.view-tab${on ? ".on" : ""}`, {
      "data-view": x.id,
      title: on ? "Click for this view's menu" : `Show the view ${x.name}`,
      onclick: (e) => (on ? viewMenu(env, x, i, e.currentTarget) : env.select(x.id)),
      oncontextmenu: (e) => (e.preventDefault(), viewMenu(env, x, i, e)),
    }, x.name, on && dirty ? h("span.changed-dot", { title: "Changed, not saved" }) : null, on ? h("span.caret", {}, "▾") : null);
  });
  const add = h("button.view-tab.add", { title: "A new view", onclick: (e) => addMenu(env, e.currentTarget) }, "+");
  const save = dirty
    ? h("span.save-bar", {},
        h("span.dim", {}, "Changed"),
        button("Reset", () => env.reset(), { title: `Back to the saved ${current.name}` }),
        button("Save as new…", () => saveAsNew(env), { title: "Keep these changes as a view of their own" }),
        button("Save", () => env.saveViews(env.views.map((x) => (x.id === current.id ? { ...current, name: x.name } : x)), current.id), { kind: "primary", title: `Save the changes into ${current.name}` }))
    : null;
  return h("div.view-tabs", {}, tabs, add, h("span.grow"), save);
}

async function askName(title, value) {
  const name = await promptMenu(title, { ok: "OK", value, placeholder: "e.g. Waits for me" });
  return name?.trim() ? name.trim().slice(0, 60) : null;
}

async function saveAsNew(env, from = env.current) {
  const name = await askName("Name the new view (what the table shows now)", `${from.name} (copy)`);
  if (!name) return;
  const id = newViewId(env.views);
  await env.saveViews([...env.views, { ...from, id, name }], id);
}

function viewMenu(env, x, i, at) {
  const list = env.views;
  const items = [
    { label: "Rename…", run: async () => {
      const name = await askName("Rename the view", x.name);
      if (name) await env.saveViews(list.map((y) => (y.id === x.id ? { ...y, name } : y)));
    } },
    { label: "Duplicate", run: () => saveAsNew(env, x.id === env.current.id ? env.current : x) },
    i > 0 ? { label: "Move left", run: () => env.saveViews(moveBy(list, i, -1)) } : null,
    i < list.length - 1 ? { label: "Move right", run: () => env.saveViews(moveBy(list, i, 1)) } : null,
    "-",
    { label: "Delete…", danger: true, disabled: list.length < 2, run: async () => {
      if (!(await confirmMenu(`Delete the view “${x.name}”? The tasks stay; only this setup of the table goes.`, { ok: "Delete", danger: true }))) return;
      const rest = list.filter((y) => y.id !== x.id);
      await env.saveViews(rest, x.id === env.current.id ? rest[Math.max(0, i - 1)].id : env.current.id);
    } },
  ].filter(Boolean);
  return at instanceof Event ? contextMenu(items, at) : menuAt(items, at);
}

function addMenu(env, el) {
  return menuAt([
    { label: "Copy of this view…", run: () => saveAsNew(env) },
    { label: "New view…", run: async () => {
      const name = await askName("Name the new view (it starts like Open)", "");
      if (!name) return;
      const id = newViewId(env.views);
      await env.saveViews([...env.views, { ...startingViews()[0], id, name }], id);
    } },
    "-",
    { label: "Restore the starting views…", run: async () => {
      if (!(await confirmMenu("Go back to the starting views (Open, Waits for me, Running, Settled)? Your own views are deleted.", { ok: "Restore", danger: true }))) return;
      await env.saveViews(null, "open");
    } },
  ], el);
}

// ---------------------------------------------------------------- stages, grouping, columns; acting on ticked rows

function toolbar(env, count) {
  const v = env.current;
  const counts = Object.fromEntries(STAGES.map((s) => [s, env.tasks.filter((t) => t.column === s).length]));
  const stages = STAGES.map((s) => {
    const on = v.stages.includes(s);
    return h(`button.stage-chip.tone-${STAGE_TONE[s]}${on ? ".on" : ""}`, {
      "data-stage": s,
      title: `${on ? "Hide" : "Show"} the tasks in ${STAGE_TITLE[s]}`,
      onclick: () => env.change({ stages: on ? v.stages.filter((x) => x !== s) : [...v.stages, s] }),
    }, h("span.sq"), STAGE_TITLE[s], h("span.n", {}, counts[s]));
  });
  const groupBtn = button(`Group: ${GROUPS[env.oneProject && v.group === "project" ? "none" : v.group]} ▾`, (e) => menuAt(Object.entries(GROUPS).map(([k, label]) => ({
    label,
    checked: v.group === k,
    disabled: k === "project" && env.oneProject,
    run: () => env.change({ group: k }),
  })), e.currentTarget), { small: false, title: "Rows under a heading per project or stage" });
  groupBtn.classList.add("group-btn");
  const colsBtn = button("Columns ▾", (e) => columnPicker(env, e.currentTarget), { small: false, title: "Which columns show (drag a heading to move it, its edge to resize it)" });
  colsBtn.classList.add("columns-btn");
  return h("div.table-tools", {}, h("div.stages", {}, stages), h("span.grow"), h("span.dim.count-text", {}, `${count} task${count === 1 ? "" : "s"}`), groupBtn, colsBtn);
}

/** The Columns picker: a box under the button with a tick per column; it stays open while you tick. */
function columnPicker(env, el) {
  document.querySelector(".col-picker-back")?.remove();
  const close = () => {
    back.remove();
    document.removeEventListener("keydown", onKey, true);
  };
  const onKey = (e) => e.key === "Escape" && (e.stopPropagation(), close());
  const list = h("div.col-list");
  const draw = () => {
    const v = ui.env.current;
    list.replaceChildren(...ALL_COLUMNS.map((c) => {
      const box = h("input", { type: "checkbox", checked: v.columns.includes(c), disabled: v.columns.length === 1 && v.columns.includes(c) });
      const muted = (c === "project" && (ui.env.oneProject || v.group === "project")) || (c === "stage" && v.group === "stage");
      return h(`label.col-item${muted ? ".muted" : ""}`, { title: muted ? `${COLUMNS[c].about} (not shown while rows are grouped by it${c === "project" ? ", or there is one project" : ""})` : COLUMNS[c].about },
        box, h("span", {}, COLUMNS[c].label === "#" ? "# Number" : COLUMNS[c].label), h("span.dim.about", {}, COLUMNS[c].about));
    }));
    list.querySelectorAll("input").forEach((box, i) => (box.onchange = () => {
      ui.env.change({ columns: toggleColumn(ui.env.current.columns, ALL_COLUMNS[i]) });
      draw();
    }));
  };
  draw();
  const box = h("div.col-picker", { onclick: (e) => e.stopPropagation() },
    h("div.col-head", {}, h("b", {}, "Columns"), h("span.grow"),
      button("Reset widths", () => (ui.env.change({ widths: {} }), draw()), { title: "Every column back to its own width" })),
    list,
    h("div.dim.hint", {}, "Drag a heading to move its column, its right edge to resize it; double-click the edge to fit."));
  const back = h("div.col-picker-back", { onclick: close }, box);
  document.addEventListener("keydown", onKey, true);
  document.body.append(back);
  const r = el.getBoundingClientRect();
  const w = 340;
  box.style.left = `${Math.max(6, Math.min(r.right - w, innerWidth - w - 6))}px`;
  box.style.top = `${r.bottom + 4}px`;
  box.style.maxHeight = `${innerHeight - r.bottom - 14}px`;
}

function bulkBar(env) {
  const picked = env.tasks.filter((t) => ui.picked.has(t.id));
  const actions = bulkActions(picked);
  const anyHidden = picked.some((t) => t.hidden);
  const run = async (label, list, about, danger, call) => {
    const names = list.slice(0, 8).map((t) => `#${t.number} ${t.title}`).join("\n");
    const more = list.length > 8 ? `\n…and ${list.length - 8} more` : "";
    const text = `${label}: ${list.length} task${list.length === 1 ? "" : "s"}?${about ? ` ${about}` : ""}\n\n${names}${more}`;
    if (!(await confirmMenu(text, { ok: label, danger, title: `${label} ${list.length}` }))) return;
    const failed = [];
    for (const t of list) {
      try {
        await call(t);
      } catch (error) {
        failed.push(`#${t.number}: ${error.message ?? error}`);
      }
    }
    if (!failed.length) ui.picked.clear();
    env.notify(failed.length ? `${label}: ${list.length - failed.length} done, ${failed.length} failed (${failed[0]})` : `${label}: ${list.length} done`, failed.length ? "error" : "success");
    env.redraw();
  };
  return h("div.table-tools.bulk", {},
    h("b", {}, `${picked.length} ticked`),
    actions.map((a) => button(`${a.label}${a.tasks.length < picked.length ? ` · ${a.tasks.length}` : ""}`,
      () => run(a.label, a.tasks, a.about, a.danger, (t) => buttonCall(a.id, t.number)),
      { kind: a.id === "stop" ? "danger" : "", small: false, title: `${a.about}\nFits ${a.tasks.map((t) => `#${t.number}`).join(", ")}` })),
    button(anyHidden ? "Unhide" : "Hide", () => run(anyHidden ? "Unhide" : "Hide", picked, anyHidden ? "They come back on the board." : "They leave the board until you unhide them (⊘ in the header).", false,
      (t) => api("edit", { number: t.number, hidden: !anyHidden })), { small: false }),
    h("span.grow"),
    button("Clear", () => (ui.picked.clear(), env.redraw()), { small: false, title: "Untick them all (Esc)" }));
}

// ---------------------------------------------------------------- headings: sort, move, resize

function headRow(env, v, cols, rows) {
  const shownIds = rows.map((t) => t.id);
  const all = shownIds.length > 0 && shownIds.every((id) => ui.picked.has(id));
  const some = shownIds.some((id) => ui.picked.has(id));
  const tickAll = h("input.pick", { type: "checkbox", title: all ? "Untick them all" : "Tick every row shown", checked: all, onclick: (e) => e.stopPropagation(),
    onchange: () => {
      if (all) ui.picked.clear();
      else for (const id of shownIds) ui.picked.add(id);
      env.redraw();
    } });
  tickAll.indeterminate = some && !all;
  const tr = h("tr", {}, h("th.lead", {}, tickAll));
  cols.forEach((c, i) => {
    const sortAt = v.sorts.findIndex((s) => s.by === c);
    const sort = v.sorts[sortAt];
    const def = COLUMNS[c];
    const th = h(`th${sort ? ".sorted" : ""}${def.noSort ? ".nosort" : ""}`, {
      "data-col": c,
      draggable: "true",
      title: `${def.about}${def.noSort ? "" : "\nClick: sort by it · Shift+click: sort by it too"}\nDrag: move it · Right-click: more`,
      onclick: (e) => !def.noSort && env.change({ sorts: clickSort(v.sorts, c, e.shiftKey) }),
      oncontextmenu: (e) => (e.preventDefault(), headMenu(env, v, c, e, th)),
    },
      h("span.label", {}, def.label),
      sort ? h("span.arrow", {}, sort.desc ? "▼" : "▲", v.sorts.length > 1 ? h("sub", {}, sortAt + 1) : null) : null,
      h("span.resize", { title: "Drag to resize · double-click: fit" }));
    dragHeading(env, v, th, c, cols[i + 1] ?? null);
    resizeHeading(env, v, th, c);
    tr.append(th);
  });
  return tr;
}

function headMenu(env, v, c, e, th) {
  const def = COLUMNS[c];
  const others = v.sorts.filter((s) => s.by !== c);
  const items = [];
  if (!def.noSort) {
    items.push(
      { label: "Sort ascending", checked: v.sorts.length === 1 && v.sorts[0].by === c && !v.sorts[0].desc, run: () => env.change({ sorts: [{ by: c, desc: false }] }) },
      { label: "Sort descending", checked: v.sorts.length === 1 && v.sorts[0].by === c && v.sorts[0].desc, run: () => env.change({ sorts: [{ by: c, desc: true }] }) },
      v.sorts.some((s) => s.by === c)
        ? (v.sorts.length > 1 ? { label: "Take out of the sort", run: () => env.change({ sorts: others }) } : null)
        : { label: "Sort by it too (Shift+click)", run: () => env.change({ sorts: [...v.sorts, { by: c, desc: !!def.desc }] }) },
    );
  }
  if (c === "project" || c === "stage") items.push({ label: `Group by ${def.label.toLowerCase()}`, checked: v.group === c, run: () => env.change({ group: v.group === c ? "none" : c }) });
  items.push("-",
    { label: "Fit the width", run: () => fit(env, v, th, c) },
    v.widths[c] ? { label: "Its own width again", run: () => env.change({ widths: Object.fromEntries(Object.entries(v.widths).filter(([k]) => k !== c)) }) } : null,
    { label: "Hide the column", disabled: v.columns.length < 2, run: () => env.change({ columns: toggleColumn(v.columns, c) }) });
  return contextMenu(items.filter(Boolean), e);
}

function dragHeading(env, v, th, c) {
  th.addEventListener("dragstart", (e) => {
    if (ui.resizing) return e.preventDefault();
    ui.busy = true;
    ui.dragCol = c;
    th.classList.add("dragging");
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", c);
  });
  th.addEventListener("dragend", () => {
    th.classList.remove("dragging");
    ui.busy = false;
    const was = ui.dragCol;
    ui.dragCol = null;
    th.closest("tr")?.querySelectorAll("th").forEach((x) => x.classList.remove("drop-left", "drop-right"));
    if (was) env.redraw();
  });
  th.addEventListener("dragover", (e) => {
    if (!ui.dragCol || ui.dragCol === c) return;
    e.preventDefault();
    const r = th.getBoundingClientRect();
    const left = e.clientX < r.left + r.width / 2;
    th.closest("tr").querySelectorAll("th").forEach((x) => x.classList.remove("drop-left", "drop-right"));
    th.classList.add(left ? "drop-left" : "drop-right");
  });
  th.addEventListener("drop", (e) => {
    const moved = ui.dragCol;
    if (!moved || moved === c) return;
    e.preventDefault();
    const r = th.getBoundingClientRect();
    const left = e.clientX < r.left + r.width / 2;
    // Before this column, or before the column after it in the view's own order (hidden ones included).
    const at = v.columns.indexOf(c);
    const before = left ? c : (v.columns.slice(at + 1).find((x) => x !== moved) ?? null);
    ui.dragCol = null;
    ui.busy = false;
    env.change({ columns: moveColumn(v.columns, moved, before) });
  });
}

function resizeHeading(env, v, th, c) {
  const grip = th.querySelector(".resize");
  grip.addEventListener("click", (e) => e.stopPropagation());
  grip.addEventListener("dblclick", (e) => (e.stopPropagation(), fit(env, v, th, c)));
  grip.addEventListener("pointerdown", (e) => {
    e.preventDefault();
    e.stopPropagation();
    const table = th.closest("table");
    const col = table.querySelector(`col[data-col="${CSS.escape(c)}"]`);
    const from = e.clientX;
    const base = th.getBoundingClientRect().width;
    const tableBase = table.getBoundingClientRect().width;
    const autoTable = table.style.width === "100%";
    let width = base;
    ui.busy = true;
    ui.resizing = true;
    grip.setPointerCapture?.(e.pointerId);
    document.body.classList.add("col-resizing");
    const move = (ev) => {
      width = clampWidth(base + ev.clientX - from);
      col.style.width = `${width}px`;
      if (!autoTable || c === "title") table.style.width = `${Math.round(tableBase + width - base)}px`;
    };
    const up = () => {
      grip.removeEventListener("pointermove", move);
      grip.removeEventListener("pointerup", up);
      grip.removeEventListener("pointercancel", up);
      document.body.classList.remove("col-resizing");
      ui.busy = false;
      setTimeout(() => (ui.resizing = false), 0);
      if (Math.abs(width - base) >= 2) env.change({ widths: { ...v.widths, [c]: width } });
      else env.redraw();
    };
    grip.addEventListener("pointermove", move);
    grip.addEventListener("pointerup", up);
    grip.addEventListener("pointercancel", up);
  });
}

/** The column's width to fit its widest cell (at most 600 px). */
function fit(env, v, th, c) {
  const table = th.closest("table");
  const index = [...th.parentElement.children].indexOf(th);
  let widest = 0;
  for (const row of table.querySelectorAll("tr")) {
    const cell = row.children[index];
    if (!cell || cell.colSpan > 1 || row.children.length <= index) continue;
    widest = Math.max(widest, cell.scrollWidth);
  }
  env.change({ widths: { ...v.widths, [c]: clampWidth(Math.min(600, widest + 6)) } });
}

// ---------------------------------------------------------------- rows

function groupRow(env, g, group, span, folded) {
  const label = group === "project"
    ? (projectLabel(env.projects[g.rows[0].projectId]) ?? g.label)
    : h(`span.stage.tone-${STAGE_TONE[g.rows[0].column]}`, {}, h("span.sq"), g.label);
  return h("tr.group-row", { "data-group": g.key, onclick: () => env.toggleFold(g.key), title: folded ? "Unfold" : "Fold" },
    h("td", { colspan: span }, h("span.fold", {}, folded ? "▸" : "▾"), label, h("span.count", {}, g.rows.length)));
}

function taskRow(env, t, cols) {
  const tone = asks(t) ? "danger" : (TONE[t.why] ?? "neutral");
  const open = ui.expanded.has(t.id);
  const picked = ui.picked.has(t.id);
  const lead = h("td.lead", {},
    h("input.pick", { type: "checkbox", checked: picked, title: "Tick it (Space): act on several at once", onclick: (e) => e.stopPropagation(), onchange: () => {
      picked ? ui.picked.delete(t.id) : ui.picked.add(t.id);
      env.redraw();
    } }),
    h("button.expand", { title: open ? "Close (←)" : "Its description, last reply and every button (→)", onclick: (e) => (e.stopPropagation(), toggleOpen(t.id)) }, open ? "▾" : "▸"));
  const tr = h(`tr.task-row.tone-${tone}${t.hidden ? ".hidden-row" : ""}${picked ? ".picked" : ""}${ui.selected === t.id ? ".selected" : ""}${open ? ".open" : ""}${t.threadId && t.threadId === selectedThread() ? ".selected-task" : ""}`, {
    "data-id": t.id,
    "data-number": t.number,
    "data-thread": t.threadId ?? undefined,
    onclick: (e) => {
      if (e.target.closest("button, input, a, .chip")) return;
      select(t.id);
      openTask(t, env.ctx);
    },
    oncontextmenu: (e) => (select(t.id), cardMenu(t, env.ctx, e)),
  }, lead, cols.map((c) => cell(env, t, c)));
  return tr;
}

function cell(env, t, c) {
  const text = (value, cls = "", tip) => h(`td${cls}`, { "data-col": c, title: tip ?? (typeof value === "string" && value.length > 24 ? value : undefined) }, value ?? "");
  switch (c) {
    case "number":
      return text(`#${t.number}`, ".mono.num");
    case "title":
      return h("td.title-cell", { "data-col": c, title: t.title },
        // The whole row opens its thread (task #99-1): the title too; ⋯ › See it shows it in a window.
        h("span", {}, t.title), t.tested ? h("span.tested", { title: "You tested it" }, " ✓") : null,
        t.controversial ? h("span", { title: "You marked it controversial" }, " 🚩") : null, t.hidden ? h("span.dim", {}, " (hidden)") : null,
        t.batch ? h("span.dim", {}, ` · 📦 ${t.members?.length ?? 0}`) : null);
    case "project": {
      const p = env.projects[t.projectId];
      return h("td", { "data-col": c }, projectLabel(p) ?? t.projectId);
    }
    case "stage":
      return h("td", { "data-col": c }, h(`span.stage.tone-${STAGE_TONE[t.column]}`, {}, h("span.sq"), STAGE_TITLE[t.column] ?? t.column));
    case "status":
      return h("td", { "data-col": c, title: t.state }, h("span.status-dot"), asks(t) ? "asks you" : t.state);
    case "note":
      return text(t.note ?? "", ".dim");
    case "stakes":
      return h("td", { "data-col": c }, t.stakes ? chip(String(t.stakes.score), STAKES_TONE[t.stakes.level], [t.brief?.ask, ...(t.stakes.reasons ?? [])].filter(Boolean).join("\n")) : null);
    case "size":
      return h("td.size", { "data-col": c }, sizeChip(t));
    case "needs":
      return text(t.estimate && !t.settledAt && t.estimate.pct ? `~${t.estimate.pct}%` : "", ".dim.numeric");
    case "spent":
      return text(t.estimate?.spentPct ? `${t.estimate.spentPct}%` : "", ".dim.numeric");
    case "model":
      return text(modelText(t), ".dim");
    case "start":
      return text(t.threadId ? "" : (START_LABEL[t.start ?? "either"] ?? t.start), ".dim");
    case "branch":
      return text(t.branch && t.worktreeGone && env.ctx.worktreeMark !== false ? `⌀ ${t.branch}` : (t.branch ?? ""), ".mono.dim", t.worktreeGone ? `${t.branch ?? ""}: its worktree was removed (its work is on the base branch)` : t.branch);
    case "prompt": {
      // A batch's sub-tasks follow its own description, one after the other.
      const subs = subTasksText(t, env.ctx.byId);
      const all = [firstLines(t.prompt, 900), subs && `Sub-tasks: ${subs}`].filter(Boolean);
      return text(all.join(" · ").slice(0, 240), ".dim", all.join("\n"));
    }
    case "tested":
      return h("td.mark-cell", { "data-col": c }, markButton(t, "tested", "✓", t.threadId ? null : "It hasn't run yet: nothing to test"));
    case "controversial":
      return h("td.mark-cell", { "data-col": c }, markButton(t, "controversial", "🚩"));
    case "reply":
      return text(firstLines(t.thread?.lastMessage), ".dim", firstLines(t.thread?.lastMessage, 900));
    case "chips":
      return h("td.chips", { "data-col": c }, cardBadges(t, env.ctx));
    case "changed":
      return text(t.updatedAt ? ago(t.updatedAt) : "", ".dim", t.updatedAt ? new Date(t.updatedAt).toLocaleString() : "");
    case "created":
      return text(t.createdAt ? ago(t.createdAt) : "", ".dim", t.createdAt ? new Date(t.createdAt).toLocaleString() : "");
    case "actions": {
      const next = nextStep(t, env.ctx);
      return h("td.actions-cell", { "data-col": c },
        next ? button(next.label, next.run, { kind: next.kind ?? "", title: next.title }) : null,
        h("button.more", { title: "Every command", onclick: (e) => (e.stopPropagation(), select(t.id), cardMenu(t, env.ctx, e)) }, "⋯"));
    }
  }
  return h("td", { "data-col": c });
}

/** The Tested or 🚩 column's mark: a click sets or takes it back (`off`: why it can't be set now). */
function markButton(t, key, sign, off = null) {
  const on = !!t[key];
  const what = key === "tested" ? "tested" : "controversial";
  return h(`button.mark${on ? ".on" : ""}${key === "tested" ? ".tested" : ""}`, {
    title: off && !on ? off : on ? `Marked ${what} (${new Date(t[key]).toLocaleString()}): click to take it back` : `Mark it ${what}`,
    disabled: !!off && !on,
    onclick: (e) => (e.stopPropagation(), act(() => api("edit", { number: t.number, [key]: !on }))),
  }, sign);
}

/** A batch's sub-tasks under its row's description: each one's number, title, description and the batch's report. */
function subTasksSection(env, t) {
  const report = new Map((t.batchReport ?? []).map((r) => [String(r.number), r]));
  return h("div.pv-section", {}, h("div.pv-title", {}, `Sub-tasks (${t.members.length})`),
    h("ol.pv-subtasks", {}, t.members.map((m) => {
      const full = env.ctx.byId?.[m.id] ?? m;
      const r = report.get(String(full.number));
      return h("li", {},
        h("div", {}, h("span.mono.dim", {}, `#${full.number} `), h("strong", {}, full.title),
          r ? chip(r.done ? "done" : "skipped", r.done ? "success" : "warning", r.why) : null),
        full.prompt?.trim() && full.prompt.trim() !== full.title ? h("div.dim", {}, markdown(full.prompt.slice(0, 2000))) : null);
    })));
}

/** ▸: the row's description, last reply, chips and every button, under it. */
function previewRow(env, t, span) {
  const parts = [];
  if (t.note && !String(t.prompt ?? "").trim().startsWith(t.note.trim())) parts.push(h("div.pv-note", {}, t.note));
  const badges = cardBadges(t, env.ctx);
  if (badges.childElementCount) parts.push(badges);
  if (t.prompt?.trim()) parts.push(h("div.pv-section", {}, h("div.pv-title", {}, "Description"), markdown(t.prompt.slice(0, 6000))));
  if (t.members?.length) parts.push(subTasksSection(env, t));
  if (t.thread?.lastMessage?.trim()) parts.push(h("div.pv-section", {}, h("div.pv-title", {}, "Last reply"), markdown(t.thread.lastMessage.slice(0, 8000))));
  if (t.brief) parts.push(h("div.pv-section", {}, h("div.pv-title", {}, "Brief"), h("div", {}, t.brief.what), h("div.dim", {}, t.brief.ask)));
  const pills = togglePills(t);
  if (pills) parts.push(pills);
  parts.push(cardActions(t, { ...env.ctx, inline: false }));
  return h("tr.preview-row", { "data-for": t.id }, h("td", { colspan: span }, h("div.preview", {}, parts)));
}

// ---------------------------------------------------------------- the keys

function select(id) {
  ui.selected = id;
  const body = ui.env?.host.querySelector("table.grid tbody");
  body?.querySelectorAll("tr.task-row.selected").forEach((r) => r.classList.remove("selected"));
  const row = body?.querySelector(`tr.task-row[data-id="${CSS.escape(id)}"]`);
  row?.classList.add("selected");
  row?.scrollIntoView({ block: "nearest" });
}

function toggleOpen(id, open = !ui.expanded.has(id)) {
  if (open) ui.expanded.add(id);
  else ui.expanded.delete(id);
  ui.selected = id;
  ui.env?.redraw();
}

/**
 * The table's keys, while it shows and nothing else has the keyboard: ↑ ↓ pick a row, Enter opens it, → ← open and
 * close its preview, Space ticks it, Esc unticks all.
 */
export function tableKeys(e, shown) {
  if (!shown() || !ui.env) return;
  const el = document.activeElement;
  if (el && (/INPUT|TEXTAREA|SELECT/.test(el.tagName) || el.isContentEditable)) return;
  if (el?.tagName === "BUTTON" && (e.key === " " || e.key === "Enter")) return;
  if (document.querySelector(".backdrop, .menu-back, .col-picker-back")) return;
  if (e.ctrlKey || e.altKey || e.metaKey) return;
  const rows = [...ui.env.host.querySelectorAll("table.grid tr.task-row")];
  const at = rows.findIndex((r) => r.dataset.id === ui.selected);
  const task = () => ui.env.tasks.find((t) => t.id === ui.selected);
  if (e.key === "ArrowDown" || e.key === "ArrowUp") {
    if (!rows.length) return;
    e.preventDefault();
    const next = at < 0 ? 0 : Math.max(0, Math.min(rows.length - 1, at + (e.key === "ArrowDown" ? 1 : -1)));
    select(rows[next].dataset.id);
  } else if (e.key === "Enter" && task()) {
    e.preventDefault();
    openTask(task(), ui.env.ctx);
  } else if ((e.key === "ArrowRight" || e.key === "ArrowLeft") && task()) {
    e.preventDefault();
    toggleOpen(ui.selected, e.key === "ArrowRight");
  } else if (e.key === " " && task()) {
    e.preventDefault();
    ui.picked.has(ui.selected) ? ui.picked.delete(ui.selected) : ui.picked.add(ui.selected);
    ui.env.redraw();
  } else if (e.key === "Escape" && ui.picked.size) {
    ui.picked.clear();
    ui.env.redraw();
  }
}

/** The row a task link reveals is the one the keys move from. */
export function selectRow(id) {
  ui.selected = id;
}
