// Shared by the pipeline's panels: talking to the backend, small DOM helpers, menus (the shell's context menu, and
// the panels' own confirm and prompt menus), project labels, the prompt cache, the report boxes and the question
// forms. The card is in card.js, the new-task dialog in dialog.js.
import DOMPurify from "./vendor/purify.es.mjs";
import { marked } from "./vendor/marked.esm.js";

marked.setOptions({ gfm: true, breaks: false });

export const layr = window.layr;

// append / replaceChildren with a `cond ? el : null` child would print "null": leave such children out.
for (const name of ["append", "replaceChildren", "prepend"]) {
  const original = Element.prototype[name];
  Element.prototype[name] = function (...nodes) {
    return original.apply(this, nodes.flat(Infinity).filter((n) => n !== null && n !== undefined && n !== false));
  };
}

/** Call one of the pipeline backend's tools; gives its value or throws its message. */
export const api = (tool, args = {}) => layr.tools.run(tool, args);

/** Run an action and tell the user when it fails. */
export async function act(fn, ok) {
  try {
    const result = await fn();
    if (ok) layr.ui.notify(ok, "success");
    return result;
  } catch (error) {
    layr.ui.notify(error.message ?? String(error), "error");
    return undefined;
  }
}

/** Call `fn` when the board changes (coalesced). */
export function onChanged(fn) {
  let timer = null;
  return layr.events.on("pipeline:changed", () => {
    clearTimeout(timer);
    timer = setTimeout(fn, 80);
  });
}

/** Shown on a phone (the panel's calls still run on the PC): buttons that open windows on the PC are left out. */
export const onPhone = () => layr.info?.device?.kind === "phone";

const SELECTED_KEY = "pipeline.selectedThread";

/**
 * The selected task: the one whose thread a pipeline panel opened last in the reused tab, by that thread's id. It means
 * nothing else; it only marks the task (`.selected-task` on whatever carries its `data-thread`), in every panel.
 */
export function selectedThread() {
  try {
    return localStorage.getItem(SELECTED_KEY);
  } catch {
    return null;
  }
}

/** Moves the selected task's mark (`.selected-task`) in `root` to whatever carries the selected thread. */
export function markSelected(root = document) {
  const id = selectedThread();
  for (const el of root.querySelectorAll(".selected-task")) if (el.dataset.thread !== id) el.classList.remove("selected-task");
  if (id) for (const el of root.querySelectorAll(`[data-thread="${CSS.escape(id)}"]`)) el.classList.add("selected-task");
}

// Another pipeline panel opened a thread: the mark moves here too.
window.addEventListener("storage", (e) => e.key === SELECTED_KEY && markSelected());

/**
 * The task's Claude thread in the claude plugin's thread panel: the first time a tab next to this one, then that tab.
 * Its task becomes the selected one.
 */
export function openThread(thread) {
  try {
    localStorage.setItem(SELECTED_KEY, thread);
  } catch {
    // No storage in this web view: the mark stays where it was.
  }
  markSelected();
  return layr.panels.open("thread", { thread }, { plugin: "claude", where: "tab", reuse: true }).catch((error) =>
    layr.ui.notify(`Can't open the thread: ${error.message ?? error}`, "error"),
  );
}

/** A task's link (layr://pipeline/task/N), as launch messages print them. */
export const taskLink = (t) => `layr://pipeline/task/${t.id ?? t.number ?? t}`;

/** Orders task numbers: 83, 84, "84-1", "84-2", 85 (a batch's sub-tasks right after it). */
export function byNumber(a, b) {
  const [a1, a2 = 0] = String(a).split("-").map(Number);
  const [b1, b2 = 0] = String(b).split("-").map(Number);
  return a1 - b1 || a2 - b2;
}

/** Copy text; the WebView may refuse the clipboard API, so a hidden text field is the fallback. */
export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const area = h("textarea", { style: "position:fixed;opacity:0" });
    area.value = text;
    document.body.append(area);
    area.select();
    document.execCommand("copy");
    area.remove();
  }
  layr.ui.notify(`Copied ${text}`, "success");
}

/** h("div.card.tone-x", {onclick, title}, children...) */
export function h(spec, attrs = {}, ...children) {
  const [tag, ...classes] = spec.split(".");
  const el = document.createElement(tag || "div");
  if (classes.length) el.className = classes.join(" ");
  for (const [k, v] of Object.entries(attrs ?? {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "class") el.className += ` ${v}`;
    else if (k === "style") el.style.cssText = v;
    else if (k in el && typeof v !== "string") el[k] = v;
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const c of children.flat(Infinity)) if (c !== null && c !== undefined && c !== false) el.append(c instanceof Node ? c : String(c));
  return el;
}

export function markdown(text, cls = "md") {
  const el = h(`div.${cls}`);
  el.innerHTML = DOMPurify.sanitize(marked.parse(String(text ?? "")));
  for (const a of el.querySelectorAll("a")) a.target = "_blank";
  return el;
}

export function button(label, onclick, { kind = "", title, small = true } = {}) {
  return h(`button.layr-button${kind ? `.${kind}` : ""}${small ? ".small" : ""}`, {
    title,
    onclick: (e) => {
      e.stopPropagation();
      onclick(e);
    },
  }, label);
}

/**
 * An icon-only toolbar button: `label` is its name (tooltip and aria-label), `badge` an optional count on it
 * (`hot`: drawn in the danger colour).
 */
export function iconButton(name, label, onclick, { title, badge, hot = false } = {}) {
  const b = button([icon(name), badge ? h(`span.badge${hot ? ".hot" : ""}`, {}, badge) : null], onclick, { small: false, title: title ?? label });
  b.classList.add("icon-tool");
  b.setAttribute("aria-label", label);
  return b;
}

export const chip = (text, tone, title) => h(`span.chip${tone ? `.tone.tone-${tone}` : ""}`, { title }, text);

export function ago(iso) {
  if (!iso) return "";
  const s = Math.max(0, (Date.now() - Date.parse(iso)) / 1000);
  if (s < 60) return "now";
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  if (s < 86400) return `${Math.floor(s / 3600)}h`;
  return `${Math.floor(s / 86400)}d`;
}

export function clock(iso) {
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

/** The tone of a why (the backend's columns.js WHY_TONE). */
export const TONE = {
  proposal: "neutral", idle: "neutral", batched: "neutral", queued: "info", limit: "warning", interrupted: "warning",
  starting: "progress", running: "progress", background: "progress", landing: "accent", verifying: "accent", ready: "accent", question: "danger",
  failed: "danger", note: "danger", missing: "danger", finished: "success", landed: "landed", settled: "muted",
};
export const LETTER = {
  queued: "W", limit: "L", starting: "S", running: "R", background: "R", landing: "→", verifying: "V", question: "?", finished: "F",
  landed: "✓", failed: "X", interrupted: "I", note: "!", missing: "–", idle: "·", batched: "B", ready: "🌙",
};
export const COLUMN_TITLE = { proposed: "Proposed", ready: "Ready", running: "Running", stopped: "Stopped", settled: "Settled" };
export const MODE_INFO = {
  stop: { label: "Soft stop", tone: "warning", about: "Nothing new starts; what has started finishes." },
  here: { label: "Here", tone: "success", about: "You're at the PC: what you Run runs (📝 Plan tasks plan and ask you); 🌙 Ready waits for Away." },
  away: { label: "Away", tone: "accent", about: "You're away: what waits in Ready goes on, in its order, as far as the accounts have room (pacing). Nobody is asked meanwhile." },
};

/**
 * Switch the mode; Away first asks when you're back (pacing fits Ready into the time until then). `hours`: the
 * default time away (the awayHours setting). Gives the mode tool's answer, or undefined.
 */
export async function pickMode(mode, hours = 8) {
  if (mode !== "away") return act(() => api("mode", { mode }));
  const at = new Date(Date.now() + hours * 3_600_000);
  const hhmm = `${String(at.getHours()).padStart(2, "0")}:${String(at.getMinutes()).padStart(2, "0")}`;
  const backAt = await promptMenu("Going Away. When are you back? Pacing lets Ready go as far as the accounts have room until then.", { ok: "Away", value: hhmm, placeholder: "e.g. 08:00" });
  if (backAt === null) return undefined;
  return act(() => api("mode", { mode, ...(backAt.trim() ? { backAt: backAt.trim() } : {}) }));
}

/** The mode switch (Soft stop / Here / Away): a dropdown showing the mode's dot and name. */
export function modeSwitch(mode, onPick) {
  const info = MODE_INFO[mode] ?? MODE_INFO.here;
  const items = () => Object.entries(MODE_INFO).map(([m, i]) => ({ label: i.label, checked: m === mode, run: () => m !== mode && onPick(m) }));
  return h(`button.modes.tone-${info.tone}`, {
    type: "button",
    title: info.about,
    "aria-label": `Mode: ${info.label}`,
    "aria-haspopup": "menu",
    "data-mode": mode,
    onclick: (e) => (e.stopPropagation(), menuAt(items(), e.currentTarget)),
  }, h("span.dot"), h("span.mode-label", {}, info.label), icon("chevron"));
}

// ---------------------------------------------------------------- files, briefs, stakes

/** A File as base64 (no data: prefix). */
export function fileBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).replace(/^data:[^;]*;base64,/, ""));
    reader.onerror = () => reject(reader.error ?? new Error("Couldn't read the file"));
    reader.readAsDataURL(file);
  });
}

/**
 * A file picker (and paste target for images) that stages files with the backend's attach tool. `files`: the
 * staged ones ([{id, name}]), changed in place; `onChange()` after each change. Gives the element (`redraw()` after
 * changing `files` from outside).
 */
export function attachPicker(files, onChange = () => {}) {
  const list = h("span.attach-list");
  const draw = () => list.replaceChildren(...files.map((f, i) => h("span.chip.file-chip", { title: f.mediaType },
    icon(f.mediaType?.startsWith("image/") ? "image" : "file"), h("span.file-name", {}, f.name),
    h("button", { type: "button", title: "Remove", "aria-label": `Remove ${f.name}`, onclick: (e) => (e.stopPropagation(), files.splice(i, 1), draw(), onChange()) }, "×"))));
  const add = async (picked) => {
    for (const file of picked) {
      const staged = await act(async () => (await api("attach", { name: file.name || "pasted.png", mediaType: file.type || "application/octet-stream", data: await fileBase64(file) })).file);
      if (staged) files.push(staged);
    }
    draw();
    onChange();
  };
  const input = h("input", { type: "file", multiple: true, hidden: true, onchange: () => add([...input.files]).then(() => (input.value = "")) });
  const pick = h("button.icon-button.attach-btn", {
    type: "button",
    "aria-label": "Attach files",
    onclick: (e) => (e.preventDefault(), e.stopPropagation(), input.click()),
  }, icon("clip"));
  pick.append(helpTip("Attach files. You can also paste images into the description, or drop files anywhere here. " +
    "Images go to Claude as images, other files by their path on the PC.", { on: pick }));
  const wrap = h("span.attach", {}, pick, input, list);
  wrap.redraw = draw;
  wrap.add = add;
  /** Files dropped onto `el` are staged too. */
  wrap.dropInto = (el) => {
    el.addEventListener("dragover", (e) => {
      if (![...(e.dataTransfer?.types ?? [])].includes("Files")) return;
      e.preventDefault();
      el.classList.add("drop-files");
    });
    el.addEventListener("dragleave", (e) => e.target === el && el.classList.remove("drop-files"));
    el.addEventListener("drop", (e) => {
      el.classList.remove("drop-files");
      const dropped = [...(e.dataTransfer?.files ?? [])];
      if (!dropped.length) return;
      e.preventDefault();
      void add(dropped);
    });
  };
  wrap.pasteInto = (el) =>
    el.addEventListener("paste", (e) => {
      const images = [...(e.clipboardData?.files ?? [])].filter((f) => f.type.startsWith("image/"));
      if (images.length) {
        e.preventDefault();
        void add(images);
      }
    });
  draw();
  return wrap;
}

// ---------------------------------------------------------------- icons and tips

const SVG_NS = "http://www.w3.org/2000/svg";
/** Line icons (24×24, stroked), drawn in the text colour. */
const ICONS = {
  clip: '<path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>',
  plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
  chevron: '<polyline points="6 9 12 15 18 9"/>',
  "eye-off": '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>',
  "check-circle": '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>',
  sort: '<path d="m21 16-4 4-4-4"/><path d="M17 20V4"/><path d="m3 8 4-4 4 4"/><path d="M7 4v16"/>',
  table: '<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/><line x1="9" y1="3" x2="9" y2="21"/>',
  columns: '<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/>',
  branch: '<line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/>',
  inbox: '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
  zap: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
};

/** One of ICONS as an inline SVG. */
export function icon(name) {
  const svg = document.createElementNS(SVG_NS, "svg");
  for (const [k, v] of Object.entries({ viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true" })) {
    svg.setAttribute(k, v);
  }
  svg.classList.add("icon");
  svg.innerHTML = ICONS[name] ?? "";
  return svg;
}

/**
 * A tooltip: a small ⓘ-style "?" that shows `text` on hover or focus. `on`: show it for that element instead (the
 * mark itself stays hidden), e.g. an icon button's explanation.
 */
export function helpTip(text, { on = null } = {}) {
  const mark = h("span.help-tip", on ? { hidden: true } : { tabindex: 0, role: "note", "aria-label": text }, "?");
  const host = on ?? mark;
  let pop = null;
  const show = () => {
    hide();
    pop = h("div.tip-pop", { role: "tooltip" }, text);
    document.body.append(pop);
    const r = host.getBoundingClientRect();
    const left = Math.max(8, Math.min(r.left + r.width / 2 - pop.offsetWidth / 2, innerWidth - pop.offsetWidth - 8));
    const below = r.bottom + 6 + pop.offsetHeight < innerHeight - 8;
    pop.style.left = `${left}px`;
    pop.style.top = `${below ? r.bottom + 6 : r.top - pop.offsetHeight - 6}px`;
  };
  const hide = () => (pop?.remove(), (pop = null));
  host.addEventListener("mouseenter", show);
  host.addEventListener("mouseleave", hide);
  host.addEventListener("focus", show);
  host.addEventListener("blur", hide);
  host.addEventListener("mousedown", hide);
  return mark;
}

/** Tooltips left open by an element that went away (a closed dialog). */
export const hideTips = () => document.querySelectorAll(".tip-pop").forEach((el) => el.remove());

export const STAKES_TONE = { high: "danger", medium: "warning", low: "neutral" };

/** A task's brief (what, what it asks, what a wrong answer costs) with its stakes; `onWrite`: write one now. */
export function briefView(t, onWrite) {
  const box = h("div.brief");
  if (t.brief) {
    box.append(
      h("div", {}, h("b", {}, "What: "), t.brief.what),
      h("div", {}, h("b", {}, "It asks you: "), t.brief.ask),
      h("div", {}, h("b", {}, "If you decide wrong: "), t.brief.cost),
    );
  } else box.append(h("div.dim", {}, "No brief yet."));
  if (t.stakes) box.append(h("div.row", {}, chip(`stakes: ${t.stakes.level} (${t.stakes.score})`, STAKES_TONE[t.stakes.level], t.stakes.reasons.join("\n")), h("span.dim", { style: "font-size:12px" }, t.stakes.reasons.join(" · "))));
  if (onWrite) box.append(h("div.row", {}, button(t.brief ? "Write it again" : "Write a brief", onWrite, { title: "A small model (haiku) reads the task" })));
  return box;
}

// ---------------------------------------------------------------- the report

const BOX_KINDS = [
  ["summary", /^(summary|tl;?dr)$/],
  ["changes", /^(changes|what changed)$/],
  ["decisions", /^(decisions|decided)$/],
  ["questions", /^questions?$/],
  ["needs", /^(needs you|action needed|your turn)$/],
  ["problems", /^(problems|issues|not done)$/],
  ["risks", /^risks?$/],
  ["checks", /^(checks|checked|verified)$/],
  ["test", /^(how to test|testing|to test)$/],
  ["next", /^(next|next steps|ideas|follow-ups)$/],
  ["notes", /^notes?$/],
];

function boxKind(heading) {
  const h2 = heading.toLowerCase().replace(/[^\p{L}\p{N} ;/-]/gu, "").trim();
  return BOX_KINDS.find(([, re]) => re.test(h2))?.[0] ?? null;
}

/**
 * The questions of a reply's Questions section, in the user's format: numbered questions (☑️ first: several answers),
 * lettered answers (`- A. ⭐ text (90%) **why**`).
 */
export function parseQuestions(body) {
  const questions = [];
  for (const line of String(body ?? "").split("\n")) {
    const q = /^\s{0,3}(\d+)\.\s+(.*)$/.exec(line);
    const o = /^\s*[-*]\s+([A-Z])\.\s+(⭐\s*)?(.*)$/u.exec(line);
    if (q && !o) questions.push({ number: Number(q[1]), text: q[2], multi: /☑️/u.test(q[2]), options: [] });
    else if (o && questions.length) questions.at(-1).options.push({ letter: o[1], starred: !!o[2], text: o[3] });
  }
  return questions.filter((q) => q.options.length);
}

/** The answer message: what differs from the ⭐ ones, or agreeing with all of them. */
export function answerText(questions, picks, extra) {
  const changed = [];
  for (const q of questions) {
    const set = picks.get(q.number);
    if (!set?.size) continue;
    const stars = q.options.filter((o) => o.starred).map((o) => o.letter).sort();
    const mine = [...set].sort();
    if (mine.join("") !== stars.join("")) changed.push(`${q.number}${mine.join("")}`);
  }
  const head = changed.length ? `My answers: ${changed.join(", ")}. Everything else as recommended.` : "I agree with everything recommended";
  return extra?.trim() ? `${head}\n\n${extra.trim()}` : head;
}

/** What you picked and typed in a reply's questions, by reply, so a redraw of the panel keeps it. */
const replyPicks = new Map();

/**
 * The Questions box made answerable: click letters, then Send (or agree with every ⭐). `onApprove(text)`: the task
 * can be approved, and Approve sends the picks with it.
 */
function questionsView(questions, onSend, key, onApprove) {
  const kept = (key && replyPicks.get(key)) || { picks: new Map(), extra: "" };
  if (key) replyPicks.set(key, kept);
  const picks = kept.picks;
  const wrap = h("div.reply-questions");
  const hint = h("div.dim", { style: "font-size:12px" }, "Pick answers, or agree with all the ⭐ ones");
  for (const q of questions) {
    if (!picks.has(q.number)) picks.set(q.number, new Set());
    const opts = h("div.options");
    for (const o of q.options) {
      const b = h(`button.option${picks.get(q.number).has(o.letter) ? ".chosen" : ""}`, { type: "button", "data-q": q.number, "data-letter": o.letter }, `${o.letter}. ${o.starred ? "⭐ " : ""}`, h("span", {}, o.text.replace(/\*\*/g, "")));
      b.onclick = (e) => {
        e.stopPropagation();
        const set = picks.get(q.number);
        if (q.multi) set.has(o.letter) ? set.delete(o.letter) : set.add(o.letter);
        else {
          const had = set.has(o.letter);
          set.clear();
          if (!had) set.add(o.letter);
        }
        for (const other of opts.children) other.classList.toggle("chosen", set.has(other.dataset.letter));
        hint.textContent = `Sends: ${answerText(questions, picks, "")}`;
      };
      opts.append(b);
    }
    wrap.append(h("div.question", {}, h("div.qt", {}, `${q.number}. ${q.text}`), opts));
  }
  const extra = h("textarea.layr-textarea", { rows: 2, placeholder: "Anything else to tell it (optional)", style: "min-height:40px", onclick: (e) => e.stopPropagation(), oninput: () => (kept.extra = extra.value) });
  extra.value = kept.extra;
  if ([...picks.values()].some((set) => set.size)) hint.textContent = `Sends: ${answerText(questions, picks, "")}`;
  wrap.append(
    extra,
    hint,
    h("div.row", {},
      button("I agree with everything recommended", () => onSend(answerText(questions, new Map(), extra.value), false)),
      h("span.grow"),
      onApprove ? button("Approve with these", () => onApprove(answerText(questions, picks, extra.value)), { title: "Approve it, with your picks as its answers" }) : null,
      button("Send answers", () => onSend(answerText(questions, picks, extra.value), false), { kind: "primary" })),
  );
  return wrap;
}

/**
 * A worker's reply as boxes per `## Section`, with its status line as chips. `onSend(text, away)`: its Questions can
 * be answered (the task waits for the user); `onApprove(text)`: Approve goes with the picks.
 */
export function renderReply(text, status, onSend, key, onApprove) {
  const out = h("div.reply");
  const lines = String(text ?? "").split("\n");
  // The status line itself becomes chips.
  while (lines.length && !lines.at(-1).trim()) lines.pop();
  if (status && /status\s*:/i.test(lines.at(-1) ?? "")) lines.pop();
  const sections = [];
  let current = { heading: null, body: [] };
  for (const line of lines) {
    const m = /^#{1,3}\s+(.+?)\s*$/.exec(line);
    if (m && boxKind(m[1])) {
      sections.push(current);
      current = { heading: m[1], body: [] };
    } else current.body.push(line);
  }
  sections.push(current);
  for (const s of sections) {
    const body = s.body.join("\n").trim();
    if (!s.heading && !body) continue;
    const kind = s.heading ? boxKind(s.heading) : "plain";
    const questions = kind === "questions" && onSend ? parseQuestions(body) : [];
    out.append(h(`div.box.box-${kind}`, {}, s.heading && kind !== "notes" ? h("div.box-title", {}, s.heading) : null,
      questions.length ? questionsView(questions, onSend, key, onApprove) : markdown(body)));
  }
  if (status) {
    out.append(
      h(
        "div.reply-chips",
        {},
        h("span.reply-chip", {}, status.status || "no status"),
        status.risks?.length ? h("span.reply-chip.risk", {}, `risk: ${status.risks.join(", ")}`) : h("span.reply-chip", {}, "no risk"),
        status.try ? h(`span.reply-chip${status.try === "ready" ? ".ok" : ""}`, {}, status.try === "ready" ? "ready to try" : `try: ${status.try}`) : null,
      ),
    );
  }
  return out;
}

// ---------------------------------------------------------------- what a thread waits for

/**
 * The form for one pending approval of a task's thread: a question (options, multi-select, own words), a plan
 * (approve or send feedback), or a permission (allow, always, deny). `send({requestId, answers?, decision?, message?})`.
 */
export function approvalForm(approval, send) {
  const wrap = h("div.approval");
  if (approval.kind === "question") {
    const picks = new Map();
    const typed = new Map();
    const questions = approval.questions ?? [];
    const answersNow = () => {
      const answers = {};
      for (const q of questions) {
        const own = typed.get(q.question)?.trim();
        const chosen = [...(picks.get(q.question) ?? [])];
        if (q.multiSelect) answers[q.question] = own ? [...chosen, own] : chosen;
        else answers[q.question] = own || chosen[0];
      }
      return answers;
    };
    const sendBtn = button("Send answers", () => send({ requestId: approval.requestId, answers: answersNow() }), { kind: "primary" });
    const hint = h("span.dim", { style: "font-size:12px" });
    const refresh = () => {
      const missing = questions.filter((q) => !(picks.get(q.question)?.size || typed.get(q.question)?.trim())).length;
      sendBtn.disabled = missing > 0;
      hint.textContent = missing ? `Answer all ${questions.length} to send` : "";
    };
    for (const q of questions) {
      picks.set(q.question, new Set());
      const opts = h("div.options");
      for (const o of q.options ?? []) {
        const b = h("button.option", { type: "button", title: o.description || undefined }, `${q.multiSelect ? "☐ " : ""}${o.label}`);
        b.onclick = (e) => {
          e.stopPropagation();
          const set = picks.get(q.question);
          if (q.multiSelect) set.has(o.label) ? set.delete(o.label) : set.add(o.label);
          else {
            const had = set.has(o.label);
            set.clear();
            if (!had) set.add(o.label);
            typed.set(q.question, "");
            own.value = "";
          }
          for (const other of opts.children) {
            const label = other.dataset.label;
            other.classList.toggle("chosen", set.has(label));
            if (q.multiSelect) other.firstChild.textContent = `${set.has(label) ? "☑ " : "☐ "}${label}`;
          }
          refresh();
        };
        b.dataset.label = o.label;
        opts.append(b);
      }
      const own = h("textarea.layr-textarea", { rows: 1, placeholder: q.options?.length ? "Or answer in your own words…" : "Your answer…", style: "min-height:32px" });
      own.oninput = () => {
        typed.set(q.question, own.value);
        refresh();
      };
      own.onclick = (e) => e.stopPropagation();
      wrap.append(h("div.question", {}, q.header ? h("div.qh", {}, q.header) : null, h("div.qt", {}, q.question), opts, own));
    }
    wrap.append(h("div.row", {}, sendBtn, hint));
    refresh();
  } else if (approval.kind === "plan") {
    const note = h("textarea.layr-textarea", { rows: 2, placeholder: "What should change in the plan? (for Send feedback)" });
    note.onclick = (e) => e.stopPropagation();
    wrap.append(
      markdown(approval.plan ?? ""),
      note,
      h(
        "div.row",
        {},
        button("Approve the plan", () => send({ requestId: approval.requestId, decision: "allow" }), { kind: "primary" }),
        button("Send feedback", () => send({ requestId: approval.requestId, decision: "deny", message: note.value })),
      ),
    );
  } else {
    const input = approval.input ?? {};
    const what = input.command ?? input.file_path ?? input.path ?? input.url ?? JSON.stringify(input).slice(0, 200);
    wrap.append(
      h("div", {}, h("b", {}, approval.tool ?? "A tool"), " wants to run: ", h("code.mono", {}, String(what))),
      approval.reason ? h("div.dim", {}, approval.reason) : null,
      h(
        "div.row",
        { style: "margin-top:6px" },
        button("Allow", () => send({ requestId: approval.requestId, decision: "allow" }), { kind: "primary" }),
        button("Always allow", () => send({ requestId: approval.requestId, decision: "allow_always" })),
        button("Deny", () => send({ requestId: approval.requestId, decision: "deny" }), { kind: "danger" }),
      ),
    );
  }
  return wrap;
}


// ---------------------------------------------------------------- menus

/**
 * A context menu: the shell's (`layr.ui.contextMenu`, drawn above the panel, the same in every plugin), or where
 * there is none (a browser, tests) the panel's own. Items: {label, run?, items?, danger?, checked?, disabled?} or "-".
 */
export async function contextMenu(items, at) {
  try {
    return await layr.ui.contextMenu(items, at);
  } catch (error) {
    if (error?.code && !/NOT_AVAILABLE|-32003/.test(String(error.code)) && !/isn't in it|not available/i.test(error.message ?? "")) throw error;
    return ownMenu(items, at);
  }
}

/** The panel's own menu: submenus shown inline under their heading. */
function ownMenu(items, at) {
  at?.preventDefault?.();
  return new Promise((resolve) => {
    const back = h("div.menu-back", { onclick: () => done(null), oncontextmenu: (e) => (e.preventDefault(), done(null)) });
    const menu = h("div.own-menu", { role: "menu", onclick: (e) => e.stopPropagation() });
    const done = (item) => {
      back.remove();
      document.removeEventListener("keydown", onKey, true);
      if (item?.run) item.run(item);
      resolve(item);
    };
    const add = (list, depth) => {
      for (const it of list) {
        if (it === "-") menu.append(h("div.sep"));
        else if (it?.items) {
          menu.append(h("div.sub", { style: `padding-left:${8 + depth * 12}px` }, it.label));
          add(it.items, depth + 1);
        } else if (it) {
          menu.append(h(`button.item${it.danger ? ".danger" : ""}`, { disabled: !!it.disabled, style: `padding-left:${10 + depth * 12}px`, onclick: () => done(it) }, it.checked ? `✓ ${it.label}` : it.label));
        }
      }
    };
    add(items, 0);
    const onKey = (e) => e.key === "Escape" && (e.stopPropagation(), done(null));
    document.addEventListener("keydown", onKey, true);
    back.append(menu);
    document.body.append(back);
    const x = at?.clientX ?? at?.x ?? 20;
    const y = at?.clientY ?? at?.y ?? 20;
    const r = menu.getBoundingClientRect();
    menu.style.left = `${Math.max(4, Math.min(x, innerWidth - r.width - 4))}px`;
    menu.style.top = `${Math.max(4, Math.min(y, innerHeight - r.height - 4))}px`;
    menu.querySelector("button.item:not([disabled])")?.focus();
  });
}

/** Where a menu opened from a button goes: under it. */
const below = (el) => {
  const r = el?.getBoundingClientRect?.();
  return r ? { x: r.left, y: r.bottom + 2 } : { x: 40, y: 40 };
};

/**
 * The panel's own confirm (never `window.confirm`, which the Flutter WebView may not show): a small dialog that says
 * what pressing it does. Resolves true or false.
 */
export function confirmMenu(text, { ok = "OK", danger = false, title } = {}) {
  return new Promise((resolve) => {
    const done = (v) => {
      back.remove();
      resolve(v);
    };
    const yes = button(ok, () => done(true), { kind: danger ? "danger" : "primary", small: false });
    const back = h("div.backdrop.ask", { onclick: (e) => e.target === back && done(false) },
      h("div.dialog.ask-dialog", { role: "alertdialog", onkeydown: (e) => {
        if (e.key === "Escape") done(false);
        if (e.key === "Enter") done(true);
      } },
        title ? h("h2", {}, title) : null,
        h("div.ask-text", {}, text),
        h("div.row", {}, h("span.grow"), button("Cancel", () => done(false), { small: false }), yes)));
    document.body.append(back);
    yes.focus();
  });
}

/** The panel's own prompt (never `window.prompt`): resolves the text, or null when cancelled. */
/**
 * Ask for a text: gives it, or null. `extra`: a second button's label (e.g. "🌙 When Away"); with it the answer is
 * `{value, extra}` (`extra`: that button was pressed), or null.
 */
export function promptMenu(text, { ok = "OK", placeholder = "", value = "", danger = false, multiline = false, title, extra } = {}) {
  return new Promise((resolve) => {
    const done = (v, second = false) => {
      back.remove();
      resolve(extra && v !== null ? { value: v, extra: second } : v);
    };
    const input = multiline ? h("textarea.layr-textarea", { rows: 4, placeholder }) : h("input.layr-input", { placeholder });
    input.value = value;
    const back = h("div.backdrop.ask", { onclick: (e) => e.target === back && done(null) },
      h("div.dialog.ask-dialog", { role: "dialog", onkeydown: (e) => {
        if (e.key === "Escape") done(null);
        if (e.key === "Enter" && (!multiline || e.ctrlKey)) done(input.value);
      } },
        title ? h("h2", {}, title) : null,
        h("div.ask-text", {}, text),
        input,
        h("div.row", {}, h("span.grow"), button("Cancel", () => done(null), { small: false }),
          extra ? button(extra, () => done(input.value, true), { small: false }) : null,
          button(ok, () => done(input.value), { kind: danger ? "danger" : "primary", small: false }))));
    document.body.append(back);
    input.focus();
  });
}

/** A menu under a header button. */
export const menuAt = (items, el) => contextMenu(items, below(el));

// ---------------------------------------------------------------- projects, the prompt cache

/** A project's icon and title, in its colour. */
export function projectLabel(project, { title = true } = {}) {
  if (!project) return null;
  return h("span.project-label", { style: project.color ? `--project:${project.color}` : undefined, title: project.title },
    project.color ? h("span.project-dot") : null, project.icon ? h("span.project-icon", {}, project.icon) : null, title ? project.title : null);
}

/** A project's name for a <select> option: its icon first. */
export const projectOption = (project) => `${project.icon ? `${project.icon} ` : ""}${project.title}`;

/** How long Claude keeps a thread's prompt cache after its last turn (Claude Code on a subscription: an hour). */
export const CACHE_TTL_MS = 60 * 60_000;

/**
 * The prompt cache of a task's thread between turns: { warm, leftMin } or { warm: false } once it is cold; null while
 * a turn runs, and for tasks without a turn to go by. A message while warm re-reads the context from the cache;
 * after it the whole context is processed again (much more of the plan's usage).
 */
export function cacheOf(t, now = Date.now()) {
  const th = t.thread;
  if (!t.threadId || !th || th.missing || th.archived || t.settledAt || ["starting", "running"].includes(th.status)) return null;
  const ended = Date.parse(th.turnEndedAt ?? "");
  if (Number.isNaN(ended)) return null;
  const left = CACHE_TTL_MS - Math.max(0, now - ended);
  return left > 0 ? { warm: true, leftMin: Math.ceil(left / 60_000) } : { warm: false };
}

/** The card's cache ring: a ring that empties as the hour goes, ❄ once it is cold. */
export function cacheBadge(t) {
  const c = cacheOf(t);
  if (!c) return null;
  if (!c.warm) return h("span.cache.cold", { title: "Its prompt cache is cold: the next message re-reads the whole thread (more usage)" }, "❄");
  const part = c.leftMin / 60;
  return h("span.cache.warm", {
    title: `Its prompt cache is warm for ${c.leftMin} more min: a message now is cheaper`,
    style: `--part:${Math.round(part * 360)}deg`,
    class: c.leftMin <= 10 ? "soon" : undefined,
  }, h("span", {}, c.leftMin));
}
