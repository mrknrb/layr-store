// The board: five columns (Proposed, Ready, Running, Stopped, Settled) or a table with saved views (table.js; not on
// a phone), the mode switch, a project picker, search by #number or title (in the table: the view's search), a sort
// order, cards folded to one line, Settled hidden (its own ✓ Settled button shows it), hidden tasks (⊘), drag to order Running, Branches &
// worktrees, the Decide round, "While away", and task links (layr://pipeline/task/N: the core opens the board with
// params {task}, and the board reveals and flashes the card).
import { asks, card } from "./card.js";
import { act, api, button, byNumber, chip, clock, COLUMN_TITLE, confirmMenu, contextMenu, h, icon, iconButton, layr, menuAt, modeSwitch, onChanged, onPhone, openThread, pickMode, projectLabel, projectOption, promptMenu } from "./common.js";
import { taskDialog } from "./dialog.js";
import { drawTable, selectRow, tableBusy, tableKeys } from "./table.js";
import { normalize, sameView, savedViews } from "./tableview.js";

await layr.ready;

const COLUMNS = ["proposed", "ready", "running", "stopped", "settled"];
const COLUMN_TONE = { proposed: "neutral", ready: "accent", running: "progress", stopped: "warning", settled: "muted" };
const EMPTY = {
  proposed: "New tasks wait here until you press Run. With 📝 Plan they plan first and stay here until you Approve.",
  ready: "🌙 When away: what waits for you to be Away (proposals, your messages, answers, approvals). Turn 🌙 off to take it back.",
  running: "Nothing runs or waits for a slot.",
  stopped: "Nothing waits for you.",
  settled: "Nothing settled yet.",
};
const SORTS = { column: "Each column's own order", newest: "Newest first", oldest: "Oldest first", changed: "Last changed first", title: "By title" };
const saved = layr.info.state ?? {};
const view = {
  project: saved.project ?? "",
  query: "",
  column: saved.column ?? "stopped",
  settledAll: false,
  mode: saved.mode === "table" ? "table" : "columns",
  sort: SORTS[saved.sort] ? saved.sort : "column",
  folded: new Set(saved.folded ?? []),
  settledOpen: !!saved.settledOpen,
  showHidden: false,
  /** The table: the view shown, each view's unsaved changes (by id), the folded groups. */
  table: { viewId: saved.table?.viewId ?? "open", drafts: saved.table?.drafts ?? {}, folded: new Set(saved.table?.folded ?? []) },
};
let board = null;
/** The concept nodes linked to each task ({"<number>": [{id, text}]}), read now and then (the concepts plugin). */
let linked = {};
let linkedAt = 0;
const LINKED_MS = 30_000;
let localOrder = null;
/** A redraw asked for while a table heading is dragged: it comes once the drag ends. */
let renderLater = false;
/** The table view's search was put in the search box. */
let tableQuerySet = false;
/** A task link to reveal once the board has loaded. */
let pendingReveal = null;
/** The card a task link flashes, until when: redraws meanwhile keep flashing it. */
let flashing = null;

const header = h("div.header");
const info = h("div.infobar");
const tabs = h("div.column-tabs");
const columns = h("div.board");
document.body.append(header, info, tabs, columns);

async function load() {
  try {
    board = await api("board");
  } catch (error) {
    info.className = "infobar bad";
    info.textContent = `The pipeline's backend doesn't answer: ${error.message}`;
    return;
  }
  if (!tableQuerySet && tableMode()) view.query = tableShown().current.query;
  tableQuerySet = true;
  render();
  if (pendingReveal) {
    const n = pendingReveal;
    pendingReveal = null;
    void reveal(n);
  }
  if (Date.now() - linkedAt > LINKED_MS) void loadLinked();
}

/** The ◆ chips' nodes; nothing without the concepts plugin. */
async function loadLinked() {
  linkedAt = Date.now();
  const r = await api("concepts", { linked: true }).catch(() => null);
  const next = r?.available ? (r.linked ?? {}) : {};
  if (JSON.stringify(next) === JSON.stringify(linked)) return;
  linked = next;
  if (board) render();
}

function keep() {
  void layr.panel.setState({
    project: view.project,
    column: view.column,
    mode: view.mode,
    sort: view.sort,
    folded: [...view.folded],
    settledOpen: view.settledOpen,
    table: { viewId: view.table.viewId, drafts: view.table.drafts, folded: [...view.table.folded] },
  });
}

const projectOf = (t) => board.projects.find((p) => p.projectId === t.projectId);

function match(t) {
  if (view.project && t.projectId !== view.project) return false;
  const q = view.query.trim().toLowerCase();
  if (!q) return !t.hidden || view.showHidden;
  const n = /^#?(\d+(?:-\d+)?)$/.exec(q)?.[1];
  if (n) return String(t.number) === n;
  return `${t.title} ${t.branch ?? ""} ${projectOf(t)?.title ?? ""}`.toLowerCase().includes(q);
}

function sortColumn(col, list) {
  const by = {
    newest: (a, b) => byNumber(b.number, a.number),
    oldest: (a, b) => byNumber(a.number, b.number),
    changed: (a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)),
    title: (a, b) => a.title.localeCompare(b.title),
  }[view.sort];
  if (by) return list.sort(by);
  if (col === "running") {
    const order = localOrder ?? null;
    return list.sort((a, b) => (order ? order.indexOf(a.id) - order.indexOf(b.id) : 0) || (a.order ?? 0) - (b.order ?? 0) || byNumber(a.number, b.number));
  }
  if (col === "stopped") {
    const rank = (t) => (t.why === "question" ? 0 : ["failed", "note", "missing"].includes(t.why) ? 1 : t.why === "interrupted" ? 2 : 3);
    return list.sort((a, b) => rank(a) - rank(b) || String(a.updatedAt).localeCompare(String(b.updatedAt)));
  }
  if (col === "settled") return list.sort((a, b) => String(b.settledAt).localeCompare(String(a.settledAt)));
  return list.sort((a, b) => byNumber(b.number, a.number));
}

/** The table shows (never on a phone: there the board is columns). */
const tableMode = () => view.mode === "table" && !onPhone();

/** The saved views, the one shown (with its unsaved changes) and whether it has any. */
function tableShown() {
  const views = savedViews(board?.views);
  const saved = views.find((v) => v.id === view.table.viewId) ?? views[0];
  const draft = view.table.drafts[saved.id];
  const current = draft ? normalize({ ...draft, id: saved.id, name: saved.name }) : saved;
  return { views, saved, current, dirty: !!draft };
}

/** Change the view shown: kept as its unsaved changes (none once it is the saved view again). */
function tableChange(patch, { redraw = true } = {}) {
  const { saved, current } = tableShown();
  const next = normalize({ ...current, ...patch });
  if (sameView(next, saved)) delete view.table.drafts[saved.id];
  else view.table.drafts[saved.id] = next;
  if ("query" in patch) view.query = next.query;
  keep();
  if (redraw) renderBody(...maps());
}

/** Show a saved view (its unsaved changes come along); the search box gets its search. */
function tableSelect(id) {
  view.table.viewId = id;
  view.query = tableShown().current.query;
  keep();
  render();
}

/** Save the views (null: back to the starting ones), then show `selectId`; the changes saved are dropped. */
async function tableSave(list, selectId = view.table.viewId) {
  const r = await act(() => api("views", list ? { views: list.map(normalize) } : { reset: true }), "Views saved");
  if (!r) return;
  board.views = r.views;
  const ids = new Set(savedViews(board.views).map((v) => v.id));
  for (const id of Object.keys(view.table.drafts)) if (!ids.has(id) || id === view.table.viewId) delete view.table.drafts[id];
  view.table.viewId = ids.has(selectId) ? selectId : [...ids][0];
  view.query = tableShown().current.query;
  keep();
  render();
}

const maps = () => [Object.fromEntries(board.projects.map((p) => [p.projectId, p])), Object.fromEntries(board.tasks.map((t) => [t.id, t]))];

function render() {
  if (tableMode() && tableBusy()) {
    renderLater = true;
    return;
  }
  renderLater = false;
  const { status, global } = board;
  const projectsById = Object.fromEntries(board.projects.map((p) => [p.projectId, p]));
  const byId = Object.fromEntries(board.tasks.map((t) => [t.id, t]));
  const decide = board.tasks.filter((t) => !t.inBatch && !t.later && !t.hidden && (t.why === "question" || asks(t) || ["failed", "note", "missing"].includes(t.why))).length;
  const hidden = board.tasks.filter((t) => t.hidden && !t.inBatch && (!view.project || t.projectId === view.project));

  // Header
  const projectSelect = h("select.layr-select", { onchange: () => ((view.project = projectSelect.value), keep(), render()), style: "width:auto" },
    h("option", { value: "" }, "All projects"),
    board.projects.map((p) => h("option", { value: p.projectId, selected: view.project === p.projectId }, projectOption(p))));
  const setQuery = (q) => {
    if (tableMode()) return tableChange({ query: q });
    view.query = q;
    renderBody(projectsById, byId);
  };
  const search = h("input.layr-input.search", { type: "search", placeholder: "Search: #number or title", title: tableMode() ? "The view's search: Save keeps it with the view" : undefined, value: view.query,
    oninput: () => setQuery(search.value),
    onkeydown: (e) => e.key === "Escape" && ((search.value = ""), setQuery("")) });
  const hadFocus = document.activeElement?.classList?.contains("search");
  const hiddenBtn = hidden.length
    ? iconButton("eye-off", "Hidden tasks", (e) => hiddenMenu(hidden, e.currentTarget),
      { title: `${hidden.length} hidden: show them faded, or unhide them`, badge: hidden.length })
    : null;
  if (hiddenBtn && view.showHidden) hiddenBtn.classList.add("on");
  header.replaceChildren(
    modeSwitch(global.mode, (mode) => pickMode(mode, global.awayHours).then(load)),
    projectSelect,
    search,
    h("span.grow"),
    hiddenBtn,
    tableMode() ? null : settledButton(projectsById, byId),
    tableMode() ? null : iconButton("sort", "Sort", (e) => sortMenu(e.currentTarget),
      { title: `Sort order: ${SORTS[view.sort]}` }),
    onPhone() ? null : tableMode()
      ? iconButton("columns", "Columns", () => switchMode(), { title: "Show the columns" })
      : iconButton("table", "Table", () => switchMode(), { title: "Show a table" }),
    iconButton("branch", "Worktrees", () => worktreesDialog(), { title: "Branches & worktrees: what each holds, what can go, disk space" }),
    iconButton("inbox", "Decide", () => layr.panels.open("decide", {}), { title: `Decide: ${decide} waiting for you`, badge: decide, hot: true }),
    h("span.tool-pair", {},
      iconButton("zap", "Decide round", () => decideRound(), { title: "Decide round: a Claude thread answers what it can, lists what's safe to land and merges the open questions into one list" }),
      roundsButton()),
    iconButton("users", "Crew", () => layr.panels.open("settings", { tab: "crew" }), { title: "Crew: scouts, the orchestrator, updates, the test lane" }),
    iconButton("gear", "Settings", () => layr.panels.open("settings", {}), { title: "Pipeline settings" }),
    button([icon("plus"), "New task"], () => taskDialog(board, null, { projectId: view.project || undefined }), { kind: "primary.new-task", small: false }),
  );
  if (hadFocus) {
    search.focus();
    search.setSelectionRange(search.value.length, search.value.length);
  }

  // Info bar
  const warn = global.mode === "stop" || status.limitUntil || status.lastError;
  info.className = `infobar${warn ? " warn" : ""}`;
  const away = status.away;
  info.replaceChildren(
    global.mode === "stop" ? h("span", {}, "❚❚") : h(`span.pulse${status.running ? ".live" : ""}`),
    h("span", {}, status.headline),
    away ? h("button.chip.tone.tone-accent.away", { onclick: () => layr.panels.open("decide", {}), title: `Away ${clock(away.from)}–${clock(away.to)}: open Decide` },
      `While away: ${[away.landed ? `${away.landed} landed` : "", away.toTry ? `${away.toTry} to try` : "", away.ask ? `${away.ask} ask you` : ""].filter(Boolean).join(" · ") || "nothing ran"}`) : null,
    status.backAt ? chip(`🌙 back at ${clock(status.backAt)}`, "accent", "When you said you're back: pacing fits Ready into the time until then") : null,
    status.limitUntil ? chip(`usage limit until ${clock(status.limitUntil)}`, "warning") : null,
    status.lastError ? chip(`✕ ${status.lastError}`, "danger") : null,
    status.landingChecks ? chip("landing checks run", "accent") : null,
    status.scouts?.running || status.scouts?.waiting ? chip(`🔭 ${status.scouts.running} scout${status.scouts.running === 1 ? "" : "s"}${status.scouts.waiting ? ` · ${status.scouts.waiting} waiting` : ""}`, "accent") : null,
    status.orchestrator ? chip(`🧭 ${status.orchestrator}`, "neutral") : null,
    ...Object.entries(status.lanes ?? {}).filter(([, l]) => l.you).map(([pid]) => chip(`🧪 you hold the lane of ${projectsById[pid]?.title ?? pid}`, "warning")),
    !board.projects.length ? h("span", {}, "No projects yet: ", h("a", { href: "#", onclick: (e) => (e.preventDefault(), layr.panels.open("settings", {})) }, "add one in Settings")) : null,
  );
  renderBody(projectsById, byId);
}

/** Columns and the table: the table's search is its view's; the columns start with an empty search. */
function switchMode() {
  view.mode = tableMode() ? "columns" : "table";
  view.query = tableMode() ? tableShown().current.query : "";
  keep();
  render();
}

/** ✓ Settled: shows or hides the Settled column (hidden, it takes no room at all; a search still finds its tasks). */
function settledButton(projectsById, byId) {
  const b = iconButton("check-circle", "Settled", () => {
    view.settledOpen = !view.settledOpen;
    if (!view.settledOpen && view.column === "settled") view.column = "stopped";
    keep();
    b.classList.toggle("on", view.settledOpen);
    renderColumns(projectsById, byId);
  }, { title: "Show or hide the Settled column" });
  b.classList.toggle("on", view.settledOpen);
  return b;
}

function hiddenMenu(hidden, el) {
  return menuAt([
    { label: "Show them faded", checked: view.showHidden, run: () => ((view.showHidden = !view.showHidden), render()) },
    { label: `Unhide all ${hidden.length}`, run: () => act(async () => { for (const t of hidden) await api("edit", { number: t.number, hidden: false }); }, "Back on the board") },
    "-",
    ...hidden.slice(0, 40).map((t) => ({ label: `Unhide #${t.number} ${t.title}`, run: () => act(() => api("edit", { number: t.number, hidden: false })) })),
  ], el);
}

function sortMenu(el) {
  return menuAt(Object.entries(SORTS).map(([k, label]) => ({ label, checked: view.sort === k, run: () => ((view.sort = k), keep(), render()) })), el);
}

async function decideRound() {
  const r = await act(() => api("decide_round"), "A Decide round started");
  if (r?.thread) await openThread(r.thread);
}

/** The ready-made rounds (backend ROUNDS): each a Claude thread that opens next to the board. */
const ROUNDS = [
  ["stuck", "What's stuck?", "What waits, fails or keeps stopping, and what would get it moving"],
  ["land_safe", "Land the safe ones", "Lists the finished tasks that are safe to land and asks you before it lands any"],
  ["running", "Brief me on what's running", "What each running task is doing and how far it is"],
  ["scout", "Send a scout…", "Asks what to look for, then a thread sends the scout"],
];

/** ▾ next to Decide round: the other ready-made rounds. */
function roundsButton() {
  const b = iconButton("chevron", "More rounds", (e) => menuAt(ROUNDS.map(([kind, label]) => ({ label, run: () => startRound(kind) })), e.currentTarget), {
    title: "More rounds: What's stuck?, Land the safe ones, Brief me on what's running, Send a scout",
  });
  b.classList.add("rounds");
  return b;
}

/** Start a round; Send a scout asks what to look for first. */
async function startRound(kind) {
  let focus;
  if (kind === "scout") {
    focus = await promptMenu("Send a scout: what should it look for (and where, if you know)?", { ok: "Send", placeholder: "e.g. slow queries in the sync code", multiline: true });
    if (!focus?.trim()) return;
  }
  const label = ROUNDS.find(([k]) => k === kind)?.[1].replace("…", "") ?? kind;
  const r = await act(() => api("round", { kind, ...(focus ? { focus } : {}), ...(kind === "scout" && view.project ? { projectId: view.project } : {}) }), `${label}: a thread started`);
  if (r?.thread) await openThread(r.thread);
}

/** "1.2 GB": a size in bytes. */
function bytesText(n) {
  if (!Number.isFinite(n)) return "";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let i = 0;
  while (n >= 1024 && i < units.length - 1) (n /= 1024), i++;
  return `${n >= 10 || i === 0 ? Math.round(n) : n.toFixed(1)} ${units[i]}`;
}

/**
 * Branches & worktrees: each project's worktrees (and task branches that aren't landed): their task, ahead/behind
 * the base, size, and whether removing one loses anything; Remove for one, Remove all that are safe; free space.
 */
async function worktreesDialog() {
  const shown = view.project ? board.projects.filter((p) => p.projectId === view.project) : board.projects.filter((p) => p.enabled);
  const back = h("div.backdrop", { onclick: (e) => e.target === back && close() });
  const box = h("div.dialog.wide", { onkeydown: (e) => e.key === "Escape" && close(), tabindex: "-1" });
  back.append(box);
  let off = null;
  const close = () => (back.remove(), off?.());
  const fill = async (measure = false) => {
    const lists = await act(() => Promise.all(shown.map(async (p) => [p, await api("worktrees", { projectId: p.projectId, measure })])));
    if (!lists) return;
    const remove = async (p, args, text) => {
      if (!(await confirmMenu(text, { ok: "Remove", danger: true, title: "Remove worktrees" }))) return;
      const r = await act(() => api("remove_worktree", { projectId: p.projectId, ...args }));
      if (!r) return;
      const kept = r.kept.length ? ` · ${r.kept.length} kept: ${r.kept.map((k) => `${k.path.split(/[\/]/).at(-1)} (${k.why})`).join("; ")}` : "";
      layr.ui.notify(`Removed ${r.removed.length} worktree(s)${kept}`, r.kept.length ? "warning" : "success");
      await fill();
    };
    const sections = lists.flatMap(([p, data]) => {
      const safe = data.rows.filter((r) => r.removable);
      const sized = data.rows.filter((r) => Number.isFinite(r.bytes));
      const total = sized.reduce((n, r) => n + r.bytes, 0);
      const drive = data.drive ? `${data.drive.drive ?? ""} ${bytesText(data.drive.free)} free of ${bytesText(data.drive.total)}`.trim() : "";
      const safeBytes = safe.reduce((n, r) => n + (r.bytes ?? 0), 0);
      return [
        h("h3.group", {}, projectLabel(p), h("span.count", {}, data.rows.filter((r) => r.kind === "worktree").length)),
        h("div.row.dim", { style: "font-size:12px;gap:12px" },
          drive ? h("span", {}, `💾 ${drive}`) : null,
          sized.length ? h("span", {}, `worktrees: ${bytesText(total)}${data.measuring ? " (measuring…)" : ""}`) : h("span", {}, data.measuring ? "measuring sizes…" : ""),
          h("span.grow"),
          safe.length
            ? button(`Remove all that are safe (${safe.length}${safeBytes ? `, ${bytesText(safeBytes)}` : ""})`, () =>
                remove(p, { all: true }, h("div", {},
                  h("div", {}, `These ${safe.length} worktree(s) and their local branches go. Their commits are on ${data.base}, and they have no uncommitted or untracked files; ignored files (build output, dependencies, local settings files) go with them. Tasks keep their card and thread, and a message to the thread makes the worktree again.`),
                  h("ul.mono", { style: "font-size:12px" }, safe.map((r) => h("li", {}, r.path.split(/[\/]/).at(-1)))))), { kind: "danger" })
            : null),
        data.rows.length
          ? h("table.branches", {}, h("tr", {}, ["Worktree", "Branch", "Task", "State", "Ahead", "Behind", "Size", ""].map((x) => h("th", {}, x))),
              data.rows.map((r) => h("tr", {},
                h("td.mono", { title: r.path ?? "" }, r.path ? r.path.split(/[\/]/).at(-1) : h("span.dim", {}, "none")),
                h("td.mono.dim", {}, r.branch ?? "detached"),
                h("td", {}, r.task ? h("a", { href: "#", onclick: (e) => (e.preventDefault(), close(), reveal(r.task.number)) }, `#${r.task.number} ${r.task.title}`) : h("span.dim", {}, "no task")),
                h("td", {}, r.task?.state ?? ""),
                h("td", {}, r.ahead ?? ""),
                h("td", { class: r.behind > 20 ? "warn-text" : undefined }, r.behind ?? ""),
                h("td.dim", { title: r.measuredAt ? `measured ${clock(r.measuredAt)}` : "" }, bytesText(r.bytes)),
                h("td", {}, r.removable
                  ? button("Remove", () => remove(p, { path: r.path }, `Remove ${r.path}? Its commits are on ${data.base} and nothing in it is uncommitted; ignored files (build output) go too.${r.task ? " The task keeps its card and thread; a message makes the worktree again." : ""}`), { kind: "danger" })
                  : h("span.dim", { style: "font-size:11px" }, r.why ?? "")))))
          : h("div.dim", {}, "No worktrees, and every task branch is landed."),
      ];
    });
    box.replaceChildren(
      h("h2", {}, "Branches & worktrees"),
      h("div.dim", { style: "font-size:12px" }, "Each worktree and each task branch that isn't landed. Only worktrees that lose nothing can be removed: their commits are on the base branch and nothing in them is uncommitted."),
      ...sections,
      h("div.row", {}, button("Measure sizes again", () => fill(true), { small: false }), h("span.grow"), button("Close", close, { small: false })));
  };
  box.append(h("h2", {}, "Branches & worktrees"), h("div.dim", {}, "Looking…"));
  document.body.append(back);
  box.focus();
  off = layr.events.on("pipeline:worktrees", () => back.isConnected && fill());
  await fill();
}

function ctxFor(projectsById, byId) {
  return {
    projects: projectsById,
    byId,
    multi: !view.project && board.projects.length > 1,
    lanes: board.status.lanes,
    worktreeMark: board.global.showWorktreeMark !== false,
    linked,
    folded: view.folded,
    onEdit: (t) => taskDialog(board, t),
    onFold: (t) => {
      view.folded.has(t.id) ? view.folded.delete(t.id) : view.folded.add(t.id);
      keep();
      renderBody(projectsById, byId);
    },
  };
}

function visibleTasks() {
  // A batch member found by search shows as its batch's card.
  const shownBatches = new Set(board.tasks.filter((t) => t.inBatch && view.query.trim() && match(t)).map((t) => t.inBatch));
  return board.tasks.filter((t) => !t.inBatch && (match(t) || shownBatches.has(t.id)));
}

function renderBody(projectsById, byId) {
  columns.classList.toggle("table-mode", tableMode());
  if (tableMode()) {
    tabs.replaceChildren();
    renderTable(projectsById, byId);
  } else renderColumns(projectsById, byId);
  if (flashing && Date.now() < flashing.until) columns.querySelector(`[data-id="${CSS.escape(flashing.id)}"]`)?.classList.add("flash");
}

function renderColumns(projectsById, byId) {
  const multi = !view.project && board.projects.length > 1;
  const groups = board.global.groupByProject && multi;
  const visible = visibleTasks();
  const ctx = ctxFor(projectsById, byId);
  // Settled hidden takes no room at all (searching shows it).
  const shown = COLUMNS.filter((c) => c !== "settled" || view.settledOpen || view.query.trim());
  // A redraw keeps where each column (and the board) was scrolled to.
  const scrolled = Object.fromEntries([...columns.querySelectorAll(".column-body")].map((b) => [b.dataset.column, b.scrollTop]));
  const boardScroll = [columns.scrollTop, columns.scrollLeft];
  tabs.replaceChildren(...shown.map((c) => h(`button${view.column === c ? ".on" : ""}`, { onclick: () => ((view.column = c), keep(), renderColumns(projectsById, byId)) },
    `${COLUMN_TITLE[c]} ${visible.filter((t) => t.column === c).length}`)));
  columns.replaceChildren(
    ...shown.map((col) => {
      let list = sortColumn(col, visible.filter((t) => t.column === col));
      const total = list.length;
      if (col === "settled" && !view.settledAll && !view.query) list = list.slice(0, 12);
      const body = h("div.column-body", { "data-column": col });
      if (!list.length) body.append(h("div.empty-col", {}, EMPTY[col]));
      if (groups) {
        const byProject = new Map();
        for (const t of list) byProject.set(t.projectId, [...(byProject.get(t.projectId) ?? []), t]);
        for (const [pid, items] of [...byProject].sort(([a], [b]) => (projectsById[a]?.title ?? "").localeCompare(projectsById[b]?.title ?? ""))) {
          const p = projectsById[pid];
          body.append(h("div.project-group", { style: p?.color ? `--project:${p.color}` : undefined }, h("div.group-head", {}, projectLabel(p) ?? pid, h("span.count", {}, items.length)), items.map((t) => card(t, ctx))));
        }
      } else body.append(...list.map((t) => card(t, ctx)));
      if (col === "settled" && total > 12 && !view.query) {
        body.append(button(view.settledAll ? "Show fewer" : `Show all ${total}`, () => ((view.settledAll = !view.settledAll), renderColumns(projectsById, byId))));
      }
      if (col === "running" && total > 1 && view.sort === "column") body.prepend(h("div.hint", {}, "Drag to set the order: the top gets the next free slot."));
      if (col === "ready" && total > 1 && view.sort === "column") body.prepend(h("div.hint", {}, "Drag to set the order: Away sends the top first."));
      if (col === "ready") {
        const line = paceLine(board.status?.pacing);
        if (line) body.prepend(line);
      }
      if ((col === "running" || col === "ready") && view.sort === "column") dragOrder(body);
      const fold = col === "settled" && view.settledOpen ? h("button.fold", { title: "Hide Settled", onclick: () => ((view.settledOpen = false), keep(), render()) }, "✕") : null;
      return h(`section.column.tone-${COLUMN_TONE[col]}${view.column === col ? ".on" : ""}`, { "data-column": col },
        h("div.column-head", {}, h("span.sq"), COLUMN_TITLE[col], h("span.count", {}, total), h("span.grow"), fold), body);
    }),
  );
  for (const b of columns.querySelectorAll(".column-body")) b.scrollTop = scrolled[b.dataset.column] ?? 0;
  [columns.scrollTop, columns.scrollLeft] = boardScroll;
}

function renderTable(projectsById, byId) {
  const { views, current, dirty } = tableShown();
  drawTable({
    host: columns,
    tasks: visibleTasks(),
    projects: projectsById,
    ctx: { ...ctxFor(projectsById, byId), onFold: undefined, multi: false },
    oneProject: !!view.project || board.projects.length <= 1,
    views,
    current,
    dirty,
    change: (patch) => tableChange(patch),
    select: tableSelect,
    saveViews: tableSave,
    reset: () => {
      delete view.table.drafts[current.id];
      view.query = tableShown().current.query;
      keep();
      render();
    },
    folded: view.table.folded,
    toggleFold: (key) => {
      view.table.folded.has(key) ? view.table.folded.delete(key) : view.table.folded.add(key);
      keep();
      renderBody(projectsById, byId);
    },
    redraw: () => (renderLater ? render() : renderBody(projectsById, byId)),
    notify: (text, kind) => layr.ui.notify(text, kind),
  });
}

/** Ready's pacing line: what it needs, the room until you're back, and whether it all fits (red when not). */
function paceLine(pacing) {
  if (!pacing?.on || !pacing.line) return null;
  const sizes = pacing.sizes ? `A task costs about S ${pacing.sizes.S}% · M ${pacing.sizes.M}% · L ${pacing.sizes.L}% of a 5-hour window` : "";
  const learned = pacing.measured?.tasks ? ` (learned from ${pacing.measured.tasks} landed task${pacing.measured.tasks === 1 ? "" : "s"})` : " (defaults until tasks have landed)";
  const tip = [sizes + learned, pacing.runningPct ? `Running work still needs ~${pacing.runningPct}%` : "", pacing.nextRoom ? `Another account has room at ${clock(pacing.nextRoom.at)}` : "", "Away sends Ready in its order only as far as there is room now; the rest waits for a window to reset."].filter(Boolean).join("\n");
  return h(`div.pace-line.tone.tone-${pacing.ok ? "accent" : "danger"}`, { title: tip }, pacing.line);
}

/** Drag cards in Running (who gets the next free slot) or Ready (what Away sends first). */
function dragOrder(body) {
  let dragged = null;
  const cards = () => [...body.querySelectorAll(".card")];
  for (const el of cards()) {
    el.draggable = true;
    el.ondragstart = (e) => {
      dragged = el;
      el.classList.add("dragging");
      body.classList.add("drop-target");
      e.dataTransfer.effectAllowed = "move";
    };
    el.ondragend = () => {
      el.classList.remove("dragging");
      body.classList.remove("drop-target");
      for (const c of cards()) c.classList.remove("drop-before");
    };
    el.ondragover = (e) => {
      if (!dragged || dragged === el) return;
      e.preventDefault();
      for (const c of cards()) c.classList.toggle("drop-before", c === el);
    };
  }
  body.ondragover = (e) => dragged && e.preventDefault();
  body.ondrop = (e) => {
    if (!dragged) return;
    e.preventDefault();
    const target = e.target.closest?.(".card");
    if (target && target !== dragged) body.insertBefore(dragged, target);
    else if (!target) body.append(dragged);
    const order = cards().map((c) => c.dataset.id);
    localOrder = order;
    setTimeout(() => (localOrder = null), 15_000);
    dragged = null;
    void act(() => api("act", { action: "reorder", order: order.map(Number) }));
  };
}

/**
 * Reveal a task (a task link): its project, its column (on a phone), unfolded, unhidden, Settled open; scroll to its
 * card (or row) and flash it. A batch member shows as its batch's card.
 */
async function reveal(number) {
  if (!board) {
    pendingReveal = number;
    return;
  }
  let t = board.tasks.find((x) => String(x.number) === String(number));
  if (!t) return layr.ui.notify(`Task #${number} is no longer on the board`, "error");
  if (t.inBatch) t = board.tasks.find((x) => x.id === t.inBatch) ?? t;
  flashing = { id: t.id, until: Date.now() + 2600 };
  if (t.hidden) {
    await act(() => api("edit", { number: t.number, hidden: false }));
    t.hidden = false;
  }
  if (view.project && view.project !== t.projectId) view.project = "";
  view.query = "";
  if (tableMode()) {
    // The view shown gets its stage and loses its search (changes Reset takes back); its group unfolds.
    const { current } = tableShown();
    tableChange({ query: "", ...(current.stages.includes(t.column) ? {} : { stages: [...current.stages, t.column] }) }, { redraw: false });
    for (const key of [`project:${t.projectId}`, `stage:${t.column}`]) view.table.folded.delete(key);
    selectRow(t.id);
  }
  view.column = t.column;
  view.folded.delete(t.id);
  if (t.column === "settled") {
    view.settledOpen = true;
    view.settledAll = true;
  }
  keep();
  render();
  const el = columns.querySelector(`[data-id="${CSS.escape(t.id)}"]`);
  if (!el) return;
  el.scrollIntoView({ block: "center", behavior: "smooth" });
  el.classList.remove("flash");
  void el.offsetWidth;
  el.classList.add("flash");
  setTimeout(() => columns.querySelector(".flash")?.classList.remove("flash"), 2600);
}

/** The task number a task link's params name: {task: N}, or {link: "layr://pipeline/task/N"}; else null. */
function linkedTask(params) {
  if (params?.task !== undefined && params.task !== null && params.task !== "") return String(params.task).replace(/^#/, "");
  return /\/task\/#?(\d+)/.exec(String(params?.link ?? ""))?.[1] ?? null;
}

/** Opened with {new: true} (New task), {edit: id} or {task: N} / {link} (a task link: reveal it). */
function fromParams(params) {
  if (!params) return;
  const linked = linkedTask(params);
  if (linked) return void reveal(linked);
  if (params.round && ROUNDS.some(([k]) => k === params.round)) return void startRound(params.round);
  if (!board) return;
  if (params.new) taskDialog(board);
  if (params.worktrees) worktreesDialog();
  const t = params.edit && board.tasks.find((x) => x.id === String(params.edit));
  if (t) taskDialog(board, t);
}
layr.panel.onParams?.(fromParams);
onChanged(load);
pendingReveal = linkedTask(layr.info.params);
await load();
if (!linkedTask(layr.info.params)) fromParams(layr.info.params);
columns.addEventListener("contextmenu", (e) => {
  if (e.target.closest(".card, tr.task-row")) return;
  if (e.target.closest(".column, .table-scroll")) contextMenu([{ label: "+ New task", run: () => taskDialog(board, null, { projectId: view.project || undefined }) }], e);
});
document.addEventListener("keydown", (e) => tableKeys(e, () => !!board && tableMode()));
document.addEventListener("keydown", (e) => {
  if ((e.key === "f" && e.ctrlKey) || (e.key === "/" && !/INPUT|TEXTAREA/.test(document.activeElement?.tagName))) {
    e.preventDefault();
    header.querySelector(".search")?.focus();
  }
});
setInterval(() => board && render(), 30_000);
