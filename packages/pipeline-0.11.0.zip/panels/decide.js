// Decide: what waits for you, phone-first. Questions (with their forms, answered here), To try, To approve (proposals
// and plans), Problems, Put off. A card's click opens its Claude thread (a proposal: its Edit dialog); Approve can go
// with the picks of a reply's questions; the prompt cache says how long a message stays cheap.
import { asks, card, dropProposal } from "./card.js";
import { act, api, approvalForm, briefView, button, cacheOf, chip, h, layr, markdown, onChanged, projectOption, renderReply } from "./common.js";
import { taskDialog } from "./dialog.js";

await layr.ready;
const saved = layr.info.state ?? {};
const view = { project: saved.project ?? "", folded: new Set(saved.folded ?? []) };
const bar = h("div.header");
const page = h("div.page");
document.body.append(bar, page);
let board = null;
let updates = {};
/** Each section's tasks, the highest stakes first (then as the board has them). */
const byStakes = (list) => [...list].sort((a, b) => (b.stakes?.score ?? -1) - (a.stakes?.score ?? -1));

function keep() {
  void layr.panel.setState({ project: view.project, folded: [...view.folded] });
}

async function load() {
  try {
    board = await api("board");
    updates = (await api("updates").catch(() => ({ updates: {} }))).updates ?? {};
  } catch (error) {
    page.replaceChildren(h("div.layr-error", {}, error.message));
    return;
  }
  render();
}

function render() {
  const projects = Object.fromEntries(board.projects.map((p) => [p.projectId, p]));
  const tasks = board.tasks.filter((t) => (!view.project || t.projectId === view.project) && !t.inBatch && !t.hidden);
  const sections = [
    ["questions", "Questions", byStakes(tasks.filter((t) => (t.why === "question" || asks(t)) && !t.later))],
    ["try", "To try", byStakes(tasks.filter((t) => t.column === "stopped" && ["finished", "landed", "idle"].includes(t.why) && !asks(t) && !t.later))],
    ["approve", "To approve", byStakes(tasks.filter((t) => (t.column === "proposed" && t.why === "proposal" && t.start !== "agents" && !t.later) || (t.approvable && t.why !== "question" && !asks(t) && !t.later)))],
    ["problems", "Problems", byStakes(tasks.filter((t) => ["failed", "note", "missing", "interrupted"].includes(t.why) && !t.later))],
    ["later", "Put off", tasks.filter((t) => t.later && !t.settledAt)],
  ];
  // Project folders Keep up to date can't bring up to date by itself (or that wait for Update now).
  const folders = Object.entries(updates).filter(([pid, u]) => (!view.project || pid === view.project) && (u.needsYou || u.ready || u.status === "failed"));
  const waiting = sections.slice(0, 4).reduce((n, [, , list]) => n + list.length, 0);
  void layr.panel.setTitle(waiting ? `Decide (${waiting})` : "Decide");
  const select = board.projects.length > 1
    ? h("select.layr-select", { style: "width:auto", onchange: () => ((view.project = select.value), keep(), render()) },
        h("option", { value: "" }, "All projects"), board.projects.map((p) => h("option", { value: p.projectId, selected: p.projectId === view.project }, projectOption(p))))
    : null;
  bar.replaceChildren(
    h("span.title", {}, "Decide"),
    select,
    h("span.grow"),
    button(view.folded.size ? "Unfold all" : "Fold all", () => {
      view.folded = view.folded.size ? new Set() : new Set(sections.map(([k]) => k));
      keep();
      render();
    }, { small: false }),
    button("+ New task", () => taskDialog(board, null, { projectId: view.project || undefined }), { kind: "primary", small: false }),
  );
  const ctx = { projects, multi: !view.project && board.projects.length > 1, byId: Object.fromEntries(board.tasks.map((t) => [t.id, t])), onEdit: (t) => taskDialog(board, t), inline: true };
  const parts = [];
  for (const [key, title, list] of sections) {
    if (!list.length) continue;
    const folded = view.folded.has(key);
    const head = h("h2", { onclick: () => (folded ? view.folded.delete(key) : view.folded.add(key), keep(), render()) }, folded ? "▸" : "▾", title, h(`span.count${key !== "later" ? ".hot" : ""}`, {}, list.length));
    const items = h("div.items", { hidden: folded }, list.map((t) => item(key, t, ctx)));
    parts.push(h("section.decide-section", { "data-section": key }, head, items));
  }
  if (folders.length) {
    const folded = view.folded.has("updates");
    const head = h("h2", { onclick: () => (folded ? view.folded.delete("updates") : view.folded.add("updates"), keep(), render()) }, folded ? "▸" : "▾", "Project folders", h("span.count.hot", {}, folders.length));
    const items = h("div.items", { hidden: folded }, folders.map(([pid, u]) =>
      h("div.crew-item", {}, h("b", {}, projects[pid]?.title ?? pid), h("span.grow", {}, u.detail), u.output ? h("details", {}, h("summary", {}, "output"), h("pre.mono", { style: "white-space:pre-wrap;font-size:11px" }, u.output)) : null,
        !u.needsYou ? button("Update now", () => act(() => api("updates", { projectId: pid, now: true }), "Updating…").then(load), { kind: "primary" }) : null)));
    parts.push(h("section.decide-section", { "data-section": "updates" }, head, items));
  }
  if (!parts.length) parts.push(h("div.all-clear", {}, h("div", { style: "font-size:28px" }, "✓"), "All clear. Nothing waits for you."));
  page.replaceChildren(...parts);
}

/** A task in Decide: its card, and under it what deciding needs (the question form, the reply, the proposal). */
function item(section, t, ctx) {
  const el = card(t, ctx);
  const extra = h("div", { style: "margin-top:8px; display:flex; flex-direction:column; gap:8px", onclick: (e) => e.stopPropagation() });
  // 🌙 When away on (and not planning): what you send waits for Away.
  const waits = !!t.whenAway && !t.planning;
  const send = (answer) => act(() => api("send", { number: t.number, ...answer }), waits ? "Waits for Away" : "Sent");
  for (const a of t.thread?.pending ?? []) extra.append(approvalForm(a, send));
  if (section !== "approve" || t.approvable) {
    if (t.thread?.lastMessage && !(t.thread?.pending ?? []).length) {
      const answer = (text) => act(() => api("send", { number: t.number, text }), waits ? "Waits for Away" : "Sent");
      const approve = t.approvable ? (text) => act(() => api("act", { action: "approve", number: t.number, text }), t.whenAway ? "Approved: waits for Away" : "Approved") : null;
      const reply = renderReply(t.thread.lastMessage, t.thread.replyStatus, asks(t) || t.why === "question" || t.approvable ? answer : null, `${t.id}:${t.thread.turnEndedAt}`, approve);
      reply.style.maxHeight = "320px";
      reply.style.overflow = "auto";
      extra.append(reply);
      // Its questions and status line are at the end.
      requestAnimationFrame(() => (reply.scrollTop = reply.scrollHeight));
    }
  }
  if (t.brief) extra.append(briefView(t));
  const cache = cacheOf(t);
  if (cache && (section === "questions" || t.approvable)) {
    extra.append(h(`div.cache-line${cache.warm ? "" : ".cold"}`, {}, cache.warm ? `Prompt cache ends in ${cache.leftMin} min: answering now is cheaper` : "❄ Prompt cache is cold: the next message re-reads the whole thread"));
  }
  if (section === "approve" && !t.threadId) {
    extra.append(markdown((t.prompt ?? "").slice(0, 400) || "_(no description)_"));
  }
  const row = h("div.row");
  if (section === "later") row.append(button("Back to Decide", () => act(() => api("edit", { number: t.number, later: null }))));
  else row.append(button("Later", () => act(() => api("edit", { number: t.number, later: new Date().toISOString() })), { title: "Put it off: it stays on the board" }));
  if (section === "approve" && !t.threadId) {
    row.append(button("Drop…", () => dropProposal(t), { kind: "danger" }));
  }
  extra.append(row);
  el.append(extra);
  return el;
}

onChanged(load);
await load();
