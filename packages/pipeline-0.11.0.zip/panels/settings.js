// Pipeline settings: Global, then one tab per project (and adding a project: a git repository folder), and Crew: the
// background jobs (the orchestrator, scouts, Keep up to date, test lanes). Everything saves on change; a changed value
// says so and has ↺ to put it back. A project's icon and colour show on its tab, cards and groups.
import { act, api, button, chip, clock, confirmMenu, h, layr, onChanged, openThread, projectLabel } from "./common.js";

await layr.ready;
const LABELS = {
  mode: "Mode", maxRunning: "Running at once", limitBackoffMin: "After a usage limit (min)",
  verifierModel: "Verifier model", groupByProject: "Group by project", pollSec: "Look at threads every (s)", enabled: "Enabled",
  baseBranch: "Base branch", branchPrefix: "Branch prefix", workerModel: "Model", workerEffort: "Effort",
  workerPermissionMode: "Permission mode", checks: "Checks", checksTimeoutMin: "Checks time (min)", landing: "Landing",
  remote: "Remote", squash: "One commit", autoMerge: "Auto-merge", agentLands: "Agent lands", askPaths: "Always ask paths",
  verify: "Verify", afterLanding: "After landing", afterLandingTimeoutMin: "After landing time (min)",
  removeWorktrees: "Remove merged worktrees", removeWorktreesAfterHours: "Remove them after (hours)",
  settleLandedAfterDays: "Settle landed tasks after (days)", showWorktreeMark: "Show ⌀ worktree on cards", instructions: "Instructions",
  briefs: "Briefs", briefModel: "Brief model", scouts: "Scouts",
  scoutsAtOnce: "Scouts at once", scoutModel: "Scout model", orchestrator: "Orchestrator", icon: "Icon", color: "Colour",
  tryCommand: "▶ Try command",
  orchestratorModel: "Orchestrator model", orchestratorEffort: "Orchestrator effort",
  orchestratorLookMin: "Looks every (min)", orchestratorRun: "May run proposals", orchestratorAnswer: "May answer workers",
  orchestratorScouts: "May send scouts and propose", orchestratorSettings: "May change mode and settings",
  orchestratorWakeOnEnd: "Away: wake when work ends", orchestratorAwayEveryMin: "Away: check in every (min)",
  orchestratorRules: "Standing rules", laneSetup: "Lane setup", laneRun: "Lane: start the app", laneE2e: "Lane: e2e tests",
  laneUrl: "Lane URL", laneTimeoutMin: "Lane time (min)", laneHoldMaxMin: "Hold lane at most (min)",
  updateMain: "Keep up to date", updateApprove: "Wait for Update now", updateCommand: "Update command",
  updateTimeoutMin: "Update time (min)", scoutFeatures: "Scouts file into (concept node)",
  orchestratorWake: "Wakes the orchestrator", keepAwake: "Keep the PC awake", projectNode: "Project node",
  featureMap: "Feature map (older)", pacing: "Pacing", pacingReserve: "Keep free for your chats (%)",
  awayHours: "Away without a time: hours",
  newPlan: "Plan first", newWhenAway: "When away", newStart: "Who starts it", newWorktree: "Own worktree",
};
/** Settings whose value is a concept node's id: a picker when the concepts plugin is there. */
const NODE_KEYS = new Set(["projectNode", "featureMap", "scoutFeatures"]);
const nodeLink = (id) => `layr://concepts/node/${id}`;
/** Whether the concepts plugin is there (asked once per load). */
let concepts = false;
/** Model aliases Claude Code takes (as backend/settings.js MODEL_ALIASES); "Other…" takes any model id. */
const MODEL_ALIASES = ["opus", "sonnet", "haiku"];
const OTHER = "__other__";
const isModel = (key) => key.endsWith("Model");
const MULTILINE = new Set(["askPaths", "instructions", "afterLanding", "updateCommand", "orchestratorRules", "tryCommand"]);
/** The colour swatches (as backend/settings.js COLORS). */
const COLORS = ["#e5484d", "#f76b15", "#ffc53d", "#46a758", "#12a594", "#0090ff", "#3e63dd", "#8e4ec6", "#d6409f", "#8d8d8d"];
const ICONS = ["🚀", "🧩", "📦", "🛠️", "🌐", "📱", "🧪", "📚", "🎨", "⚙️", "🔒", "💡"];
/** A heading before these settings (Global and a project's tab share it). */
const GROUPS = {
  workerModel: "Task threads", newPlan: "New tasks: how the task dialog starts them", groupByProject: "Board and timing", checks: "Checks and landing",
  pacing: "Pacing and Away", briefs: "Briefs", scouts: "Scouts", orchestrator: "Orchestrator", icon: "Look", tryCommand: "▶ Try",
  laneSetup: "Test lane", removeWorktrees: "Worktrees", updateMain: "Keep up to date", projectNode: "Concept map",
  scoutFeatures: "Scouts and the orchestrator",
};
let tab = layr.info.params?.tab ?? layr.info.state?.tab ?? "global";
const tabs = h("div.tabs");
const page = h("div.page");
document.body.append(tabs, page);

async function load() {
  let data;
  let projects;
  try {
    let found;
    [data, { projects }, found] = await Promise.all([api("settings"), api("projects"), api("concepts").catch(() => null)]);
    concepts = !!found?.available;
  } catch (error) {
    page.replaceChildren(h("div.layr-error", {}, error.message));
    return;
  }
  if (!["global", "add", "crew"].includes(tab) && !projects.some((p) => p.projectId === tab)) tab = "global";
  const pick = (t) => () => {
    tab = t;
    void layr.panel.setState({ tab });
    load();
  };
  tabs.replaceChildren(
    h(`button${tab === "global" ? ".on" : ""}`, { onclick: pick("global") }, "Global"),
    ...projects.map((p) => h(`button${tab === p.projectId ? ".on" : ""}`, { onclick: pick(p.projectId), title: p.path }, projectLabel({ ...p, title: p.title }), p.enabled ? h("span.on-dot") : null)),
    h(`button${tab === "add" ? ".on" : ""}`, { onclick: pick("add") }, "+ Add project"),
    h(`button${tab === "crew" ? ".on" : ""}`, { onclick: pick("crew") }, "Crew"),
  );
  if (tab === "add") return renderAdd();
  if (tab === "crew") return renderCrew(projects, data.global);
  if (tab === "global") {
    renderSettings(data.global, (set) => api("configure", { global: true, ...set }));
    page.prepend(importSection(data.layrCodeImport));
    return;
  }
  const project = projects.find((p) => p.projectId === tab);
  const settings = data.projects.find((p) => p.projectId === tab)?.settings ?? [];
  const inherited = Object.fromEntries(data.global.map((s) => [s.key, s.value]));
  renderSettings(settings, (set) => api("configure", { projectId: tab, ...set }), project, inherited);
}

function renderAdd() {
  const path = h("input.layr-input", { placeholder: "C:\\path\\to\\a\\git\\repository" });
  const checks = h("input.layr-input", { placeholder: "e.g. npm test (optional)" });
  const add = async () => {
    const r = await act(() => api("project_add", { path: path.value.trim(), ...(checks.value.trim() ? { checks: checks.value.trim() } : {}) }), "Project added");
    if (r?.project) {
      tab = r.project.projectId;
      load();
    }
  };
  page.replaceChildren(
    h("div.section", {},
      h("h3", {}, "Add a project"),
      h("div.dim", { style: "margin-bottom:8px" }, "A git repository on this PC. Its tasks run in worktrees next to it and land on its base branch (the branch it is on now, unless you change it)."),
      h("div.field", {}, h("label", {}, "Folder"), path),
      h("div.field", { style: "margin-top:8px" }, h("label", {}, "Checks before landing"), checks),
      h("div.row", { style: "margin-top:10px" }, button("Add", add, { kind: "primary", small: false })),
    ),
  );
  path.focus();
}

/** Settings rows. `inherited`: on a project's tab, the global values its empty settings stand for. */
function renderSettings(list, save, project, inherited) {
  const rows = list.flatMap((s) => [GROUPS[s.key] ? h("h3.group", { style: "margin:14px 0 4px" }, GROUPS[s.key]) : null, settingRow(s, save, inherited, project)]);
  const head = project
    ? h("div.section", {}, h("h3", {}, project.title), h("div.mono.dim", {}, project.path),
        h("div.row", { style: "margin-top:8px" }, button("Take off the pipeline", async () => {
          if (!(await confirmMenu(`Take ${project.title} off the pipeline? Its pipeline settings go; its folder, claude project and threads stay.`, { ok: "Take it off", danger: true }))) return;
          if (await act(() => api("project_remove", { projectId: project.projectId }))) {
            tab = "global";
            load();
          }
        }, { kind: "danger" })))
    : null;
  page.replaceChildren(...[head, h("div", {}, rows)].filter(Boolean));
}

/** What a value means in words; empty ones say what they stand for. */
function shown(key, value) {
  if (typeof value === "boolean") return value ? "on" : "off";
  if (value !== null && value !== "") return String(value);
  return isModel(key) ? "the claude project's default" : key.endsWith("Effort") ? "the model's default" : "none";
}

/** The label of a setting's empty value: the global value it stands for on a project's tab, else the default. */
function emptyLabel(key, inherited) {
  if (inherited && key in inherited) return `the global value: ${shown(key, inherited[key])}`;
  return isModel(key) || key.endsWith("Effort") ? shown(key, null) : "default";
}

/** A model setting: default or the global value (when it may be empty), the aliases, and Other… with a model id. */
function modelControl(s, commit, empty) {
  const custom = s.value !== null && !MODEL_ALIASES.includes(s.value);
  const id = h("input.layr-input", {
    value: custom ? s.value : "",
    placeholder: "a model id, e.g. opus[1m] or claude-opus-4-1",
    hidden: !custom,
    onchange: () => {
      const v = id.value.trim();
      if (v) commit(v);
      else if (s.nullable) commit(null);
    },
  });
  const sel = h("select.layr-select", {
    onchange: () => {
      if (sel.value !== OTHER) return commit(sel.value === "" ? null : sel.value);
      id.hidden = false;
      id.focus();
    },
  },
    s.nullable ? h("option", { value: "", selected: s.value === null }, empty) : null,
    MODEL_ALIASES.map((m) => h("option", { value: m, selected: m === s.value }, m)),
    h("option", { value: OTHER, selected: custom }, "Other…"));
  return h("div.model-pick", {}, sel, id);
}

/**
 * A concept node setting: the node's id with Open (its link) and, for the project node, Set up project map; a search
 * box that lists nodes (concepts__nodes) to pick from. Without the concepts plugin: the id as text.
 */
function nodeControl(s, commit, project) {
  const box = h("div.node-pick");
  const current = s.value
    ? h("div.row", {},
        h("span.chip.tone.tone-accent.mono", { title: s.value }, `◆ ${s.value.slice(0, 8)}`),
        concepts ? button("Open", () => act(() => layr.links.open(nodeLink(s.value))), { title: "Open it in Concepts" }) : null,
        concepts && s.key === "projectNode" && project
          ? button("Set up project map", async () => {
              const r = await act(() => api("setup_project_map", { projectId: project.projectId }));
              if (r) layr.ui.notify(r.made?.length ? `Made: ${r.made.join(", ")}` : "The project map has everything already", "success");
            }, { title: "Give the node the sections it lacks: Rules, Brainstorm, Features (with an Inbox), Plan" })
          : null,
        button("Clear", () => commit(null)))
    : null;
  if (!concepts) {
    const input = h("input.layr-input.mono", { value: s.value ?? "", placeholder: "a concept node's id (the concepts plugin isn't there)", onchange: () => commit(input.value.trim() || null) });
    box.append(current, input);
    return box;
  }
  const results = h("div.node-results");
  let timer = null;
  const search = h("input.layr-input", {
    type: "search",
    placeholder: s.value ? "Search to pick another node" : "Search the concept map for the node",
    oninput: () => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        const q = search.value.trim();
        if (!q) return results.replaceChildren();
        const r = await act(() => api("concepts", { query: q }));
        results.replaceChildren(...(r?.nodes ?? []).slice(0, 12).map((n) =>
          h("button.node-hit", { title: n.id, onclick: () => commit(n.id) }, h("b", {}, n.label), n.in?.length ? h("span.dim", {}, ` · ${n.in.join(" › ")}`) : null)),
          r?.nodes && !r.nodes.length ? h("div.dim", {}, "No node matches.") : null);
      }, 250);
    },
  });
  box.append(current, search, results);
  return box;
}

/** Global › Import from layr_code: what it would fill first, then fill it. */
function importSection(done) {
  const box = h("div.section.import", {},
    h("h3", {}, "Import from layr_code"),
    h("div.dim", { style: "font-size:12px" },
      "Reads layr_code's pipeline settings with your account (read-only) and fills only the settings that are empty here, " +
        "of the projects in the same folder, and empty global ones.",
      done ? ` Imported on ${new Date(done.at).toLocaleString()} (${done.filled} values).` : ""));
  const show = h("div.import-result");
  box.append(h("div.row", { style: "margin-top:6px" }, button("Import from layr_code", async () => {
    const plan = await act(() => api("import_layr_code", { dryRun: true }));
    if (!plan) return;
    show.replaceChildren(importList(plan));
    if (!plan.filled) return layr.ui.notify("Nothing to fill: every setting it has is set here already", "info");
    if (!(await confirmMenu(`Fill ${plan.filled} empty setting(s) from layr_code? (listed below the button)`, { ok: "Fill them" }))) return;
    const r = await act(() => api("import_layr_code", {}), `Filled ${plan.filled} setting(s)`);
    if (r) {
      await load();
      page.querySelector(".import-result")?.replaceChildren(importList(r));
    }
  }, { small: false })), show);
  return box;
}

/** What an import fills, per project, and the projects it found no folder for. */
function importList(plan) {
  const lines = (fill) => Object.entries(fill).map(([k, v]) => h("li", {}, h("b", {}, LABELS[k] ?? k), ": ", h("span.mono", {}, typeof v === "string" ? v.split("\n")[0].slice(0, 80) : JSON.stringify(v))));
  return h("div", { style: "margin-top:8px" },
    Object.keys(plan.global.fill).length ? h("div", {}, h("div", {}, "Global"), h("ul", {}, lines(plan.global.fill))) : null,
    plan.projects.map((x) => h("div", {}, h("div", {}, `${x.title} (from layr_code's ${x.from.title})`),
      Object.keys(x.fill).length ? h("ul", {}, lines(x.fill)) : h("div.dim", {}, "nothing empty to fill"),
      x.skipped.length ? h("div.dim", {}, `left out: ${x.skipped.join("; ")}`) : null)),
    plan.unmatched.length ? h("div.dim", {}, `No project here in the folder of: ${plan.unmatched.map((u) => `${u.title}${u.path ? ` (${u.path})` : ""}`).join(", ")}`) : null);
}

function settingRow(s, save, inherited, project) {
  const commit = (value) => act(() => save({ set: { [s.key]: value } })).then(load);
  const empty = emptyLabel(s.key, inherited);
  let control;
  if (NODE_KEYS.has(s.key)) {
    control = nodeControl(s, commit, project);
  } else if (s.key === "color") {
    control = h("div.swatches", {}, h("button.swatch.none", { title: "No colour", class: s.value ? undefined : "on", onclick: () => commit(null) }, "∅"),
      COLORS.map((c) => h("button.swatch", { title: c, style: `background:${c}`, class: s.value === c ? "on" : undefined, onclick: () => commit(c) })));
  } else if (s.key === "icon") {
    const input = h("input.layr-input", { value: s.value ?? "", placeholder: "an emoji or up to 3 letters", style: "max-width:120px", onchange: () => commit(input.value) });
    control = h("div.icons", {}, input, ICONS.map((i) => h(`button.icon-pick${s.value === i ? ".on" : ""}`, { onclick: () => commit(i) }, i)));
  } else if (isModel(s.key)) {
    control = modelControl(s, commit, empty);
  } else if (s.options) {
    const sel = h("select.layr-select", { onchange: () => commit(sel.value === "" ? null : sel.value) },
      s.nullable || s.value === null ? h("option", { value: "", selected: s.value === null }, empty) : null,
      s.options.map((o) => h("option", { value: o, selected: o === s.value }, o)));
    control = sel;
  } else if (s.nullable && typeof inherited?.[s.key] === "boolean") {
    // A project's on/off that may be empty: the global value.
    const sel = h("select.layr-select", { onchange: () => commit(sel.value === "" ? null : sel.value === "on") },
      h("option", { value: "", selected: s.value === null }, empty),
      ["on", "off"].map((o) => h("option", { value: o, selected: s.value !== null && shown(s.key, s.value) === o }, o)));
    control = sel;
  } else if (typeof (s.default ?? s.value) === "boolean" || typeof s.value === "boolean") {
    const box = h("input", { type: "checkbox", checked: !!s.value, onchange: () => commit(box.checked) });
    control = h("label.switch", {}, box, s.value ? "on" : "off");
  } else if (typeof s.value === "number" || ["maxRunning"].includes(s.key)) {
    const input = h("input.layr-input", { type: "number", value: s.value ?? "", placeholder: s.value === null ? empty : "", onchange: () => commit(input.value === "" ? null : Number(input.value)) });
    control = input;
  } else if (MULTILINE.has(s.key)) {
    const area = h("textarea.layr-textarea", { rows: 3, onchange: () => commit(area.value) });
    area.value = s.value ?? "";
    control = area;
  } else {
    const input = h("input.layr-input", { value: s.value ?? "", placeholder: s.value === null ? "default" : "", onchange: () => commit(input.value.trim() === "" && s.value === null ? null : input.value) });
    control = input;
  }
  return h("div.setting", { "data-key": s.key },
    h("div", {}, h("div.name", {}, LABELS[s.key] ?? s.key, s.changed ? h("span.tag-changed", {}, "changed") : null), h("div.about", {}, s.about)),
    h("div.control", {}, control, s.changed ? resetButton(s, save, empty) : null));
}

function resetButton(s, save, empty) {
  const back = s.default === null ? empty : JSON.stringify(s.default);
  const b = button("↺", () => act(() => save({ reset: [s.key] })).then(load), { title: `Back to ${back}` });
  b.classList.add("reset");
  return b;
}

// ---------------------------------------------------------------- Crew

const value = (list, key) => list.find((s) => s.key === key)?.value;
const ago = (iso) => (iso ? new Date(iso).toLocaleString([], { dateStyle: "short", timeStyle: "short" }) : "never");

async function renderCrew(projects, global) {
  let crew;
  try {
    crew = await api("crew");
  } catch (error) {
    page.replaceChildren(h("div.layr-error", {}, error.message));
    return;
  }
  const title = (pid) => projects.find((p) => p.projectId === pid)?.title ?? pid;
  const refresh = () => load();
  page.replaceChildren(
    orchestratorSection(crew.orchestrator, value(global, "orchestrator")),
    scoutsSection(crew.scouts, projects, value(global, "scouts"), title, refresh),
    updatesSection(crew.updates, title, refresh),
    lanesSection(crew.lanes, projects, title, refresh),
  );
}

function orchestratorSection(o, enabled) {
  const box = h("div.section", {}, h("h3", {}, "Orchestrator"));
  box.append(h("div", {}, enabled ? o.headline : "Off (turn it on in Global › Orchestrator). Check now still works."),
    h("div.dim", { style: "font-size:12px" }, `Last look ${ago(o.checkedAt)} · last check-in ${ago(o.ranAt)}${o.nextLook ? ` · next look ${clock(o.nextLook)}` : ""}`));
  if (o.wake) box.append(h("div.row", {}, chip(`⏰ ${clock(o.wake.at)}: ${o.wake.note}`, "info"), button("Cancel", () => act(() => api("orchestrator", { action: "cancel_wake" })).then(load))));
  box.append(h("div.row", { style: "margin:6px 0" }, button("Check in now", () => act(() => api("orchestrator", { action: "check" }), "Checking in…").then(load), { kind: "primary" })));
  const list = h("div.crew-list");
  for (const t of o.threads ?? []) {
    list.append(h("div.crew-item", {}, h("span.dim.mono", {}, ago(t.at)), h("span.grow", {}, t.log ?? t.why),
      chip(t.status, t.status === "running" ? "progress" : t.status === "done" ? (t.quiet ? "muted" : "success") : "danger"),
      button("Open thread ↗", () => openThread(t.threadId))));
  }
  if (!o.threads?.length) list.append(h("div.dim", {}, "No check-ins yet."));
  box.append(list);
  return box;
}

function scoutsSection(s, projects, mode, title, refresh) {
  const box = h("div.section", {}, h("h3", {}, "Scouts"));
  const enabled = projects.filter((p) => p.enabled);
  const project = h("select.layr-select", { style: "width:auto" }, enabled.map((p) => h("option", { value: p.projectId }, p.title)));
  const kind = h("select.layr-select", { style: "width:auto" }, h("option", { value: "" }, "the next kind"), h("option", { value: "code" }, "Code scout"), h("option", { value: "friction" }, "Friction scout"));
  const focus = h("input.layr-input", { placeholder: "What to look for (optional)", style: "width:auto;flex:1;min-width:160px" });
  const area = h("input.layr-input", { placeholder: "Where (optional)", style: "width:auto;flex:1;min-width:120px" });
  const send = () => act(() => api("scout", { projectId: project.value, ...(kind.value ? { kind: kind.value } : {}), ...(focus.value.trim() ? { focus: focus.value } : {}), ...(area.value.trim() ? { area: area.value } : {}) }), "Scout sent").then(refresh);
  box.append(h("div.dim", { style: "font-size:12px" }, mode === "off" ? "Scouts are off (Global › Scouts)." : mode === "auto" ? "They also run by themselves while you're Away and nothing runs." : "They run when you or the orchestrator send one."));
  if (enabled.length && mode !== "off") box.append(h("div.row", { style: "margin:6px 0;flex-wrap:wrap" }, project, kind, focus, area, button("Send a scout", send, { kind: "primary" })));
  const list = h("div.crew-list");
  for (const a of s.active ?? []) {
    list.append(h("div.crew-item", {}, chip(a.waiting ? "waiting" : "running", a.waiting ? "info" : "progress"), h("b", {}, a.kind), h("span", {}, title(a.projectId)),
      h("span.grow.dim", {}, [a.focus, a.doing, a.filed ? `${a.filed} filed` : ""].filter(Boolean).join(" · ")),
      a.threadId ? button("Open thread ↗", () => openThread(a.threadId)) : null, button(a.waiting ? "Take out" : "Stop", () => act(() => api("scouts", { stop: a.id })).then(refresh))));
  }
  for (const r of [...(s.runs ?? [])].reverse().slice(0, 10)) {
    list.append(h("div.crew-item", {}, h("span.dim.mono", {}, ago(r.at)), h("b", {}, r.kind), h("span", {}, title(r.projectId)),
      h("span.grow", {}, r.error ? `failed: ${r.error}` : `${r.filed} filed${r.area ? ` in ${r.area}` : ""}: ${r.summary}`), r.threadId ? button("Open thread ↗", () => openThread(r.threadId)) : null));
  }
  if (!s.active?.length && !s.runs?.length) list.append(h("div.dim", {}, "No scout runs yet."));
  box.append(list);
  return box;
}

function updatesSection(updates, title, refresh) {
  const box = h("div.section", {}, h("h3", {}, "Keep up to date"));
  const entries = Object.entries(updates ?? {});
  if (!entries.length) box.append(h("div.dim", {}, "No project has Keep up to date on (a project's settings › Keep up to date)."));
  for (const [pid, u] of entries) {
    box.append(h("div.crew-item", {}, h("b", {}, title(pid)), chip(u.status, { current: "success", running: "progress", waiting: u.needsYou ? "warning" : "info", failed: "danger" }[u.status] ?? "neutral"),
      h("span.grow", {}, u.detail, u.head ? h("span.dim.mono", {}, ` · ${u.head.slice(0, 8)} ${u.headTitle ?? ""}`) : null),
      u.output ? h("details", {}, h("summary", {}, "output"), h("pre.mono", { style: "white-space:pre-wrap;font-size:11px" }, u.output)) : null,
      button("Update now", () => act(() => api("updates", { projectId: pid, now: true }), "Updating…").then(refresh))));
  }
  return box;
}

function lanesSection(lanes, projects, title, refresh) {
  const withLane = projects.filter((p) => p.laneSetup?.trim() || p.laneRun?.trim() || p.laneE2e?.trim());
  const box = h("div.section", {}, h("h3", {}, "Test lanes"));
  if (!withLane.length) box.append(h("div.dim", {}, "No project has a test lane (a project's settings › Test lane)."));
  for (const p of withLane) {
    const lane = lanes?.[p.projectId] ?? {};
    const who = lane.you ? `you hold it until ${clock(lane.you.until)}` : lane.taskId ? `#${lane.taskId}${lane.offer ? " (kept for it)" : ""}${lane.until ? ` until ${clock(lane.until)}` : ""}` : "free";
    box.append(h("div.crew-item", {}, h("b", {}, title(p.projectId)), h("span.grow", {}, who, lane.queue?.length ? ` · waiting: ${lane.queue.map((n) => `#${n}`).join(", ")}` : ""),
      button(lane.you ? "Release" : "Hold lane", () => act(() => api("hold_lane", { projectId: p.projectId, release: !!lane.you })).then(refresh))));
  }
  return box;
}

layr.panel.onParams?.((params) => {
  if (params?.tab) {
    tab = params.tab;
    load();
  }
});
onChanged(() => tab === "crew" && load());
await load();
