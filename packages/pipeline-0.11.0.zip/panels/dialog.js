// The task dialog: one element for a new task and for a proposal's Edit (a proposal has no task page), the same
// fields and buttons in both. What you change is kept as you type: a new task's as a draft (plugin data, until it is
// made or cleared), a proposal's saved to it.
// Its layout: the editor (title, description, files), Sub-tasks, then every option in a compact grid of small
// controls (Plan, When away, who starts it, starts after, model, effort, worktree, landing), each explained by a ?
// tip rather than text on the dialog.
// Sub-tasks make it a batch: one thread does them all in one worktree, each keeping its own number. They are made with
// a new task; in an Edit, the ones you add are made on Save, Run or close (a proposal then becomes a batch, its own
// description saying what the whole batch is about). A batch's Edit lists its tasks: while the batch is open each is
// a line to edit right there (its title, then its description; a sub-task has no options of its own, the batch's
// count), its × deletes it on Save, Run or close; once the batch has started, each opens read-only. Opening a sub-task
// opens its batch's Edit at that line. Files can be picked, pasted into the description or dropped onto it.
import { act, api, attachPicker, button, byNumber, confirmMenu, contextMenu, h, helpTip, hideTips, icon, layr, projectOption } from "./common.js";
import { batchOpen, dropProposal, memberRow, runLabel } from "./card.js";

/** The New task dialog's unsent fields (plugin data), kept until the task is made or the dialog is cleared. */
const DRAFT_KEY = "draft:new-task";
/** Staged files nothing names go after a day (backend/attachments.js), so an older draft forgets its files. */
const DRAFT_FILES_MS = 20 * 60 * 60_000;
const MODEL_ALIASES = ["opus", "sonnet", "haiku"];
const EFFORTS = ["low", "medium", "high", "xhigh", "max"];
const OTHER = "__other__";
const STARTS = [["either", "You or agents"], ["agents", "Agents"], ["manual", "Only you"]];
/** A new task's toggles that take the "New tasks" settings (state keys). */
const TOGGLES = ["plan", "whenAway", "start", "noWorktree", "autoMerge", "agentLands"];

/** What each option does: its ? tip. */
const HELP = {
  plan: "Run makes its worker plan and ask you first. It stays in Proposed until you Approve the plan; then the work starts.",
  whenAway: "Its work waits until you're Away and the accounts have room. On a running thread, what you send it waits " +
    "too. Nothing runs by itself before.",
  start: "Who may start it. You or agents: you, or an agent whose rules allow it. Agents: approved in advance. " +
    "Only you: nothing but your Run.",
  after: "It waits for that task instead of starting when a running slot is free.",
  model: "The worker's model. Empty: the project's default.",
  effort: "How hard the worker thinks. Empty: the project's default.",
  worktree: "Its own branch and worktree. Off: it works in the project's checkout.",
  autoMerge: "It lands by itself as soon as its work is committed.",
  agentLands: "Its worker starts the landing itself when it is done and everything went well; layr then lands it as " +
    "your Land button does.",
  subtasks: "Several small changes done together: one thread does them all in one worktree, and each keeps its own " +
    "task number. The first line of each is its title. Enter adds the next one, Shift+Enter a line of details.",
};

/** The task's ancestors (its `after` chain), nearest first; stops at a missing task or a loop. */
export function ancestors(id, byId) {
  const seen = [];
  for (let at = byId[id]?.after; at && !seen.includes(at) && at !== id; at = byId[at]?.after) seen.push(at);
  return seen;
}

/** Whether `childId` (null: a new task) may start after `parent`: same project, not settled unlanded, no loop. */
export function canFollow(childId, parent, projectId, byId) {
  if (!parent || parent.projectId !== projectId || parent.id === childId) return false;
  if (parent.batch || parent.inBatch || parent.discarded || (parent.settledAt && !parent.landed)) return false;
  return !childId || !ancestors(parent.id, byId).includes(childId);
}

/** A small switch. `onChange(on)`; `.set(on)` changes it without calling it. */
function miniSwitch(on, onChange, label) {
  const el = h(`button.mini-switch${on ? ".on" : ""}`, { type: "button", role: "switch", "aria-checked": String(on), "aria-label": label },
    h("span.knob"));
  el.set = (next) => (el.classList.toggle("on", next), el.setAttribute("aria-checked", String(next)));
  el.addEventListener("click", (e) => {
    e.preventDefault();
    const next = !el.classList.contains("on");
    el.set(next);
    onChange(next);
  });
  return el;
}

/** One option in the grid: its label with a ? tip, and its control. A switch's row toggles it on a click anywhere. */
function prop(label, help, control, { cls = "" } = {}) {
  const row = h(`div.prop${cls}`, {}, h("span.prop-label", {}, h("span", {}, label), help ? helpTip(help) : null), h("div.prop-control", {}, control));
  if (control.classList?.contains("mini-switch")) {
    row.classList.add("prop-switch");
    row.addEventListener("click", (e) => (e.target === row || e.target.closest(".prop-label > span:not(.help-tip)") ? control.click() : null));
  }
  return row;
}

/** A textarea that grows with its text. */
function autoGrow(el) {
  const grow = () => ((el.style.height = "auto"), (el.style.height = `${el.scrollHeight + 2}px`));
  el.addEventListener("input", grow);
  requestAnimationFrame(grow);
  return el;
}

/** The dialog to make a task (`task` null) or edit a proposal or batch. `board`: the board data. */
export async function taskDialog(board, task = null, { projectId, at = null } = {}) {
  // A batch's sub-task is edited in its batch's Edit, at its line.
  const batchOf = task?.inBatch ? board.tasks.find((t) => t.id === task.inBatch && t.batch) : null;
  if (batchOf) return taskDialog(board, batchOf, { at: task.id });
  const projects = board.projects;
  if (!projects.length) {
    layr.ui.notify("Add a project first (Pipeline settings)", "error");
    layr.panels.open("settings", {});
    return;
  }
  const byId = Object.fromEntries(board.tasks.map((t) => [t.id, t]));
  const saved = task ? null : await layr.data.get(DRAFT_KEY).catch(() => null);
  const known = (id) => (projects.some((p) => p.projectId === id) ? id : undefined);
  const firstProject = () => known(projectId) ?? projects.find((p) => p.enabled)?.projectId ?? projects[0].projectId;
  const fresh = () => ({
    projectId: task?.projectId ?? firstProject(),
    title: task?.title ?? "",
    prompt: task?.prompt ?? "",
    start: task?.start && task.start !== "plan" ? task.start : "either",
    plan: !!(task?.plan || task?.start === "plan"),
    whenAway: !!task?.whenAway,
    noWorktree: !!task?.noWorktree,
    // A new task's toggles come from its project's (else the global) "New tasks" settings: applyDefaults below.
    autoMerge: !!task?.autoMerge,
    agentLands: !!task?.agentLands,
    after: task?.after ?? "",
    model: task?.model ?? "",
    effort: task?.effort ?? "",
    attachments: [...(task?.attachments ?? [])],
    // New sub-tasks, {title, prompt}: a new task's, or the ones an Edit adds.
    subtasks: [],
  });
  const state = fresh();
  // The toggles you changed in a new task: those keep your value; the others follow its project's defaults.
  const touched = new Set();
  /** A new task's untouched toggles take the "New tasks" settings of the project it is in (else the global ones). */
  const applyDefaults = () => {
    if (task) return;
    const d = projects.find((p) => p.projectId === state.projectId)?.newTask;
    if (!d) return;
    const values = { plan: !!d.plan, whenAway: !!d.whenAway, start: STARTS.some(([v]) => v === d.start) ? d.start : "either",
      noWorktree: d.worktree === false, autoMerge: !!d.autoMerge, agentLands: !!d.agentLands };
    for (const k of TOGGLES) if (!touched.has(k)) state[k] = values[k];
  };
  if (saved && typeof saved === "object") {
    for (const k of ["title", "prompt", "model", "effort", "after"]) if (typeof saved[k] === "string") state[k] = saved[k];
    // A draft keeps the toggles you changed in it (an older draft, which didn't say, keeps them all).
    const keep = Array.isArray(saved.touched) ? saved.touched.filter((k) => TOGGLES.includes(k)) : TOGGLES;
    for (const k of keep) {
      if (k === "start" ? typeof saved[k] !== "string" : typeof saved[k] !== "boolean") continue;
      state[k] = saved[k];
      touched.add(k);
    }
    if (state.start === "plan") Object.assign(state, { start: "either", plan: true });
    if (Array.isArray(saved.subtasks)) state.subtasks = saved.subtasks.filter((x) => x && typeof x.title === "string").map((x) => ({ title: x.title, prompt: String(x.prompt ?? "") }));
    // The project you opened it from wins over the draft's; the text stays either way.
    if (!known(projectId) && known(saved.projectId)) state.projectId = saved.projectId;
    if (Array.isArray(saved.attachments) && Date.now() - (saved.savedAt ?? 0) < DRAFT_FILES_MS) state.attachments = saved.attachments;
  }
  applyDefaults();
  const member = !!task?.inBatch;
  const members = task?.batch ? (task.members ?? []).map((m) => byId[m.id] ?? m) : [];
  // An open batch's sub-tasks are edited here: what you typed in each ({title, prompt}, by id), the ones whose × you
  // pressed (deleted on Save, Run or close).
  const editMembers = !!task?.batch && batchOpen(task);
  const memberEdits = new Map();
  const removed = new Set();
  const liveMembers = () => members.filter((m) => !removed.has(m.id));
  /** The sub-tasks that will be made: those with a title or details (a title then comes from the details). */
  const newSubs = () => state.subtasks.filter((x) => x.title.trim() || x.prompt.trim());
  const isBatch = () => !!task?.batch || state.subtasks.length > 0;
  // Sub-tasks can be added unless it is in a batch, or a batch that has started.
  const canAddSubs = () => !member && (task?.batch ? batchOpen(task) : !task?.threadId) && (!!task?.batch || (!state.noWorktree && !state.after));

  // ------------------------------------------------------------ saving as you type
  let saveTimer = null;
  let made = false;
  const keepDraft = () => {
    if (task || made) return;
    clearTimeout(saveTimer);
    saveTimer = null;
    const empty = !state.title.trim() && !state.prompt.trim() && !state.attachments.length && !newSubs().length;
    void (empty ? layr.data.delete(DRAFT_KEY) : layr.data.set(DRAFT_KEY, { ...state, touched: [...touched], savedAt: Date.now() })).catch(() => {});
  };
  const changed = () => {
    render();
    clearTimeout(saveTimer);
    saveTimer = setTimeout(task ? autosave : keepDraft, task ? 600 : 400);
  };
  let closed = false;
  const close = () => {
    if (closed) return;
    closed = true;
    if (task) void autosave().then(addSubs).then(deleteRemoved);
    else if (saveTimer) keepDraft();
    hideTips();
    back.remove();
  };
  // Only a click that both starts and ends on the backdrop closes it: a text selection dragged out of the dialog
  // ends with a mouseup (and a click) on the backdrop, and that must not close it.
  let downOnBack = false;
  const back = h("div.backdrop", {
    onmousedown: (e) => (downOnBack = e.target === back),
    onclick: (e) => {
      if (e.target === back && downOnBack) close();
      downOnBack = false;
    },
  });

  // ------------------------------------------------------------ the editor: title, description, files
  // A batch stays in its project; a proposal may move (out of its batch, its chain link dropped).
  const project = h("select.layr-select.project-select", {
    disabled: !!task?.batch,
    title: task?.batch ? "A batch stays in its project" : "Project",
    onchange: () => ((state.projectId = project.value), applyDefaults(), showToggles(), renderModel(), changed()),
  }, projects.map((p) => h("option", { value: p.projectId, selected: p.projectId === state.projectId }, `${projectOption(p)}${p.enabled ? "" : " (not enabled)"}`)));
  const title = h("input.layr-input.title-input", { value: state.title, placeholder: "Title", oninput: () => ((state.title = title.value), changed()) });
  const prompt = autoGrow(h("textarea.layr-textarea.desc-input", { rows: 5, placeholder: "Add a description…", oninput: () => ((state.prompt = prompt.value), changed()) }));
  prompt.value = state.prompt;
  const picker = attachPicker(state.attachments, changed);
  picker.pasteInto(prompt);
  const editor = h("div.editor", {}, title, prompt, h("div.editor-bar", {}, picker));

  // ------------------------------------------------------------ sub-tasks (a batch)
  const subList = h("div.subtasks");
  const addSubRow = (at = state.subtasks.length) => {
    state.subtasks.splice(at, 0, { title: "", prompt: "" });
    renderSubs();
    changed();
    subList.querySelectorAll("textarea")[at]?.focus();
  };
  const addSub = h("button.ghost-add", { type: "button", onclick: (e) => (e.preventDefault(), addSubRow()) }, icon("plus"), "Add sub-task");
  /** A saved sub-task of an open batch: one line to edit (its title, then its description), × deletes it. */
  const memberEditor = (m) => {
    const e = memberEdits.get(m.id) ?? { title: m.title ?? "", prompt: m.prompt ?? "" };
    const box = autoGrow(h("textarea.sub-input", {
      rows: 1,
      placeholder: "What should this sub-task do?",
      oninput: () => {
        const [first, ...rest] = box.value.split("\n");
        memberEdits.set(m.id, { title: first, prompt: rest.join("\n") });
        changed();
      },
      onkeydown: (ev) => {
        if (ev.key === "Enter" && !ev.shiftKey && !ev.ctrlKey && canAddSubs()) {
          ev.preventDefault();
          addSubRow(0);
        } else if (ev.key === "Backspace" && !box.value) {
          ev.preventDefault();
          removeMember(m);
        }
      },
    }));
    box.value = e.prompt ? `${e.title}\n${e.prompt}` : e.title;
    const takeOut = async () => {
      const ok = await act(() => api("edit", { number: m.number, batch: false }),
        "Out of the batch: it is a proposal of its own");
      if (!ok) return;
      members.splice(members.indexOf(m), 1);
      memberEdits.delete(m.id);
      renderSubs();
      render();
    };
    return h("div.subtask", {
      "data-member": m.id,
      oncontextmenu: (ev) => (ev.preventDefault(), contextMenu([{ label: "Take out of the batch", run: takeOut },
        { label: "Delete", danger: true, run: () => removeMember(m) }], ev)),
    }, h("span.sub-num", {}, `#${m.number}`), box,
      h("button.icon-button.sub-remove", { type: "button", "aria-label": "Delete this sub-task",
        title: "Delete (when you save or close)", onclick: (ev) => (ev.preventDefault(), removeMember(m)) },
      icon("x")));
  };
  const removeMember = (m) => {
    removed.add(m.id);
    renderSubs();
    changed();
  };
  const renderSubs = () => {
    const report = new Map((task?.batchReport ?? []).map((r) => [r.number, r]));
    subList.replaceChildren(...liveMembers().map((m) => (editMembers && m.prompt !== undefined
      ? memberEditor(m)
      : memberRow(m, task, null, report))));
    state.subtasks.forEach((x, i) => {
      const box = autoGrow(h("textarea.sub-input", {
        rows: 1,
        placeholder: i ? "Next sub-task" : "What should this sub-task do?",
        oninput: () => {
          const [first, ...rest] = box.value.split("\n");
          x.title = first;
          x.prompt = rest.join("\n");
          changed();
        },
        onkeydown: (e) => {
          if (e.key === "Enter" && !e.shiftKey && !e.ctrlKey) {
            e.preventDefault();
            addSubRow(i + 1);
          } else if (e.key === "Backspace" && !box.value) {
            e.preventDefault();
            state.subtasks.splice(i, 1);
            renderSubs();
            changed();
            const boxes = subList.querySelectorAll("textarea");
            boxes[Math.max(0, i - 1)]?.focus();
          }
        },
      }));
      box.value = x.prompt ? `${x.title}\n${x.prompt}` : x.title;
      // The number it will get: the batch's next ones (#84-3), the way the backend numbers them.
      const next = task ? `#${task.number}-${(task.subs ?? 0) + i + 1}` : `${i + 1}`;
      subList.append(h("div.subtask", {}, h("span.sub-num", { title: "Its number once it is saved" }, next), box,
        h("button.icon-button.sub-remove", { type: "button", "aria-label": "Remove this sub-task", title: "Remove",
          onclick: (e) => (e.preventDefault(), state.subtasks.splice(i, 1), renderSubs(), changed()) }, icon("x"))));
    });
  };
  const subCount = h("span.count");
  const subNote = h("span.sub-note");
  const subSection = h("div.td-section.subtask-section", {},
    h("div.section-head", {}, h("h3", {}, "Sub-tasks"), subCount, helpTip(HELP.subtasks), h("span.grow"), subNote),
    subList, addSub);

  // ------------------------------------------------------------ the options
  /** You set a toggle: it keeps your value when the project changes. */
  const toggle = (k, v) => ((state[k] = v), touched.add(k));
  const planSwitch = miniSwitch(state.plan, (on) => (toggle("plan", on), changed()), "Plan first");
  const awaySwitch = miniSwitch(state.whenAway, (on) => (toggle("whenAway", on), changed()), "When away");
  const startSelect = h("select.layr-select", { onchange: () => (toggle("start", startSelect.value), changed()) },
    STARTS.map(([v, label]) => h("option", { value: v, selected: state.start === v }, label)));
  const worktreeSwitch = miniSwitch(!state.noWorktree, (on) => (toggle("noWorktree", !on), renderAfter(), changed()), "Own worktree");
  const autoSwitch = miniSwitch(state.autoMerge, (on) => (toggle("autoMerge", on), changed()), "Auto-merge");
  const agentSwitch = miniSwitch(state.agentLands, (on) => (toggle("agentLands", on), changed()), "Agent lands");
  /** The toggles show what `state` holds (after the project or Clear changed it). */
  const showToggles = () => {
    planSwitch.set(state.plan);
    awaySwitch.set(state.whenAway);
    startSelect.value = state.start;
    worktreeSwitch.set(!state.noWorktree);
    autoSwitch.set(state.autoMerge);
    agentSwitch.set(state.agentLands);
    renderAfter();
  };

  // Starts after: only tasks it may follow; hidden when there are none.
  let canChain = false;
  const after = h("select.layr-select", { onchange: () => ((state.after = after.value), changed()) });
  const renderAfter = () => {
    const options = board.tasks.filter((t) => canFollow(task?.id ?? null, t, state.projectId, byId) && !t.settledAt).sort((a, b) => byNumber(b.number, a.number));
    // The task it waits for now may be one it can no longer follow (settled without landing, gone): show it, so
    // picking "nothing" is a change that saves.
    const kept = task?.after && String(state.after) === String(task.after) && !options.some((t) => String(state.after) === t.id);
    if (!kept && !options.some((t) => String(state.after) === t.id)) state.after = "";
    const parent = kept ? byId[String(task.after)] : null;
    after.replaceChildren(h("option", { value: "" }, "nothing: when a slot is free"),
      kept ? h("option", { value: String(task.after), selected: true }, `#${parent?.number ?? task.after} ${parent?.title ?? ""} (${parent ? "settled without landing" : "gone"}: it never starts)`) : null,
      options.map((t) => h("option", { value: t.id, selected: String(state.after) === t.id }, `#${t.number} ${t.title}`)));
    canChain = options.length > 0 || !!kept;
    afterRow.hidden = !canChain || member || isBatch();
  };

  // Model and effort: "project default (x)", the aliases, Other… (a model id).
  const projectOf = () => projects.find((p) => p.projectId === state.projectId) ?? {};
  const defaultModel = () => projectOf().workerModel || board.global.workerModel || "";
  const defaultEffort = () => projectOf().workerEffort || board.global.workerEffort || "";
  const defaultLabel = (value) => (value ? `Default (${value})` : "Default");
  const modelId = h("input.layr-input.model-id", { placeholder: "model id, e.g. opus[1m]", oninput: () => ((state.model = modelId.value.trim()), changed()) });
  const model = h("select.layr-select", { onchange: () => {
    modelId.hidden = model.value !== OTHER;
    if (model.value === OTHER) modelId.focus();
    else state.model = model.value;
    changed();
  } });
  const effort = h("select.layr-select", { onchange: () => ((state.effort = effort.value), changed()) });
  const renderModel = () => {
    const custom = !!state.model && !MODEL_ALIASES.includes(state.model);
    model.replaceChildren(h("option", { value: "", selected: !state.model }, defaultLabel(defaultModel())),
      MODEL_ALIASES.map((m) => h("option", { value: m, selected: state.model === m }, m)),
      h("option", { value: OTHER, selected: custom }, "Other…"));
    modelId.value = custom ? state.model : "";
    modelId.hidden = !custom;
    effort.replaceChildren(h("option", { value: "", selected: !state.effort }, defaultLabel(defaultEffort())),
      EFFORTS.map((x) => h("option", { value: x, selected: state.effort === x }, x)));
  };

  const planRow = prop("Plan first", HELP.plan, planSwitch, { cls: ".plan" });
  const awayRow = prop("When away", HELP.whenAway, awaySwitch, { cls: ".away" });
  const afterRow = prop("Starts after", HELP.after, after);
  const worktreeRow = prop("Own worktree", HELP.worktree, worktreeSwitch);
  const autoRow = prop("Auto-merge", HELP.autoMerge, autoSwitch);
  const agentRow = prop("Agent lands", HELP.agentLands, agentSwitch);
  const props = h("div.props", {},
    planRow,
    awayRow,
    prop("Model", HELP.model, h("div.model-pick", {}, model, modelId)),
    prop("Effort", HELP.effort, effort),
    prop("Who starts it", HELP.start, startSelect),
    afterRow,
    worktreeRow,
    autoRow,
    agentRow);
  const memberNote = member ? h("div.member-note", {}, `Runs with batch #${byId[task.inBatch]?.number ?? "?"}, in its worktree: Plan and When away are the batch's.`) : null;

  // ------------------------------------------------------------ what it sends
  const draft = () => ({
    projectId: state.projectId,
    title: state.title.trim(),
    prompt: state.prompt,
    start: state.start,
    plan: state.plan,
    whenAway: state.whenAway,
    noWorktree: isBatch() ? false : state.noWorktree,
    autoMerge: state.noWorktree && !isBatch() ? false : state.autoMerge,
    agentLands: state.noWorktree && !isBatch() ? false : state.agentLands,
    after: state.after && !isBatch() ? (byId[state.after]?.number ?? Number(state.after)) : null,
    model: state.model.trim() || null,
    effort: state.effort || null,
    attachments: state.attachments.map((f) => f.id),
  });
  const subsToSend = () => newSubs().map((x) => ({ title: x.title.trim(), description: x.prompt }));
  // A proposal's edits are kept as you make them: only what changed since the last save goes to edit.
  let sent = task ? draft() : null;
  let saving = Promise.resolve();
  const status = h("span.save-status");
  const changes = () => {
    const next = draft();
    const patch = {};
    for (const [k, v] of Object.entries(next)) if (JSON.stringify(v) !== JSON.stringify(sent[k])) patch[k] = v;
    if (!next.title) delete patch.title;
    // A task in a batch has no toggles of its own.
    if (member) {
      delete patch.plan;
      delete patch.whenAway;
    }
    return patch;
  };
  const sendEdit = (patch) => {
    const { prompt: description, ...rest } = patch;
    return api("edit", { number: task.number, ...rest, ...(description !== undefined ? { description } : {}) });
  };
  const autosave = () => {
    clearTimeout(saveTimer);
    saveTimer = null;
    saving = saving.then(async () => {
      const patch = changes();
      const own = Object.keys(patch).length > 0;
      if (!own && !memberPatches().length) return;
      status.textContent = "Saving…";
      const ok = await act(async () => {
        if (own) await sendEdit(patch);
        await saveMembers();
        return true;
      });
      if (ok) sent = { ...sent, ...patch };
      status.textContent = ok ? "Saved" : "Not saved";
    });
    return saving;
  };
  /** The sub-tasks you changed: [{m, e, title, prompt}] (no title: the description's first line is it). */
  const memberPatches = () => liveMembers().flatMap((m) => {
    const e = memberEdits.get(m.id);
    if (!e) return [];
    let title = e.title.trim();
    let prompt = e.prompt;
    if (!title) {
      const lines = prompt.split("\n");
      const first = lines.findIndex((l) => l.trim());
      if (first < 0) return [];
      title = lines[first].trim();
      prompt = lines.slice(first + 1).join("\n");
    }
    return title === m.title && prompt === (m.prompt ?? "") ? [] : [{ m, e, title, prompt }];
  });
  /** Save the sub-tasks you changed; with `deletes`, delete the ones whose × you pressed too. Throws on a failure. */
  const saveMembers = async ({ deletes = false } = {}) => {
    for (const { m, e, title, prompt } of memberPatches()) {
      await api("edit", { number: m.number, title, description: prompt });
      Object.assign(m, { title, prompt });
      if (memberEdits.get(m.id) === e) memberEdits.delete(m.id);
    }
    if (!deletes) return;
    for (const id of [...removed]) {
      const m = members.find((x) => x.id === id);
      await api("delete", { number: m.number });
      members.splice(members.indexOf(m), 1);
      removed.delete(id);
    }
  };
  const deleteRemoved = async () => {
    if (!removed.size) return;
    const n = removed.size;
    await act(() => saveMembers({ deletes: true }), `${n} sub-task${n > 1 ? "s" : ""} deleted`);
  };
  /** An Edit's new sub-tasks are made (a proposal becomes a batch with them). */
  const addSubs = async () => {
    const tasks = subsToSend();
    if (!task || !tasks.length) return true;
    const ok = await act(() => api("edit", { number: task.number, tasks }), `${tasks.length} sub-task${tasks.length > 1 ? "s" : ""} added`);
    if (ok) state.subtasks = [];
    return !!ok;
  };
  const save = async ({ run = false } = {}) => {
    // No title: the description's first line, then a small model writes a short one (the backend's titles.js).
    if (!task && !state.title.trim() && !state.prompt.trim()) {
      return layr.ui.notify(isBatch() ? "A batch needs a title or a description" : "A task needs a title or a description", "error");
    }
    const ok = await act(async () => {
      if (task) {
        clearTimeout(saveTimer);
        saveTimer = null;
        await saving;
        const patch = changes();
        if (Object.keys(patch).length) await sendEdit(patch);
        sent = { ...sent, ...patch };
        await saveMembers({ deletes: true });
        const tasks = subsToSend();
        if (tasks.length) await api("edit", { number: task.number, tasks });
        state.subtasks = [];
        if (run) await api("run", { number: task.number });
      } else {
        const d = draft();
        if (!d.attachments.length) delete d.attachments;
        const subs = subsToSend();
        await api("create", { ...d, ...(subs.length ? { tasks: subs } : {}), ...(run ? { run: true } : {}) });
        made = true;
        clearTimeout(saveTimer);
        await layr.data.delete(DRAFT_KEY).catch(() => {});
      }
      return true;
    });
    if (ok) close();
  };

  // ------------------------------------------------------------ buttons
  const editable = !task || (task.column === "proposed" || task.column === "ready") && !task.threadId;
  const runBtn = button("Run", () => save({ run: true }), { kind: "primary", small: false });
  const saveBtn = button("Save", () => save(), { small: false });
  const menuBtn = task ? h("button.icon-button.menu-btn", { type: "button", title: "More: drop, delete", "aria-label": "More", onclick: (e) => (e.preventDefault(), taskMenu(e)) }, icon("more")) : null;
  const taskMenu = (e) => {
    const items = [];
    if (member) items.push({ label: "Take out of the batch", run: async () => (await act(() => api("edit", { number: task.number, batch: false }), "Out of the batch: it is a proposal of its own")) && close() });
    if (items.length) items.push("-");
    items.push({ label: "Drop…", danger: true, run: async () => (await dropProposal(task)) && close() });
    items.push({ label: "Delete", danger: true, run: async () => {
      if (!(await confirmMenu(`Delete ${task.batch ? "batch" : "proposal"} #${task.number} “${task.title}”?`, { ok: "Delete", danger: true }))) return;
      if (await act(() => api("delete", { number: task.number }))) close();
    } });
    contextMenu(items, e);
  };
  const clearBtn = task ? null : h("button.text-button", { type: "button", title: "Empty the fields and forget the draft", onclick: (e) => {
    e.preventDefault();
    const files = state.attachments;
    files.length = 0;
    Object.assign(state, fresh(), { projectId: state.projectId, attachments: files });
    touched.clear();
    applyDefaults();
    title.value = state.title;
    prompt.value = state.prompt;
    showToggles();
    picker.redraw();
    renderModel();
    renderSubs();
    render();
    keepDraft();
    title.focus();
  } }, "Clear");

  const heading = h("h2");
  /** What changes with the fields: the heading, the buttons' labels and tips, what is hidden. */
  function render() {
    const batch = isBatch();
    heading.textContent = !task ? (batch ? "New batch" : "New task") : `${batch ? "Batch" : "Task"} #${task.number}`;
    title.placeholder = (batch ? "Batch title, e.g. Pipeline polish" : "Title, e.g. Add a dark/light theme switch") +
      (task ? "" : " (or empty: written from the description)");
    worktreeRow.hidden = batch;
    afterRow.hidden = !canChain || member || batch;
    autoRow.hidden = agentRow.hidden = state.noWorktree && !batch;
    planRow.hidden = awayRow.hidden = member;
    const adding = canAddSubs();
    subSection.hidden = member || (!members.length && !state.subtasks.length && !adding);
    addSub.hidden = !adding;
    const count = liveMembers().length + newSubs().length;
    subCount.textContent = count ? String(count) : "";
    subNote.textContent = task?.batch && !batchOpen(task) ? "Started: its tasks can't change now" : "";
    const away = state.whenAway && !state.plan;
    runBtn.textContent = away ? "Run now" : runLabel({ plan: state.plan, batch });
    runBtn.title = (away
      ? "It runs now after all: When away goes off."
      : state.plan && state.whenAway
        ? "Its worker plans now and asks you; it stays in Proposed. Approve then puts the work in Ready, to start when you're Away."
        : state.plan
          ? "Its worker plans now and asks you; the work starts when you Approve the plan."
          : "It gets its own thread as soon as a running slot is free, and asks you in the thread when something is yours to decide.") +
      " (Ctrl+Enter)";
    runBtn.className = `layr-button${away ? "" : " primary"}`;
    saveBtn.textContent = !task ? (away ? "Save to Ready" : "Save as proposal") : "Save";
    saveBtn.title = !task ? (away ? "It waits in Ready and starts when you're Away" : "It waits in Proposed until you run it") : "Your changes are saved as you type; this also closes it";
    saveBtn.className = `layr-button${away && !task ? " primary" : ""}`;
    runBtn.hidden = !editable || member || (task?.batch && !liveMembers().length && !newSubs().length);
    if (!status.textContent || /as you type/.test(status.textContent)) status.textContent = task ? "Saved as you type" : "Draft kept as you type";
  }

  const dialog = h("div.dialog.task-dialog", { onkeydown: (e) => {
    if (e.key === "Escape") close();
    if (e.key === "Enter" && e.ctrlKey && !member && editable) save({ run: true });
  } },
    h("div.dialog-head", {}, heading, h("span.grow"), project,
      h("button.icon-button.icon-close", { type: "button", title: "Close (your changes are kept)", "aria-label": "Close", onclick: close }, icon("x"))),
    memberNote,
    editor,
    subSection,
    h("div.td-section", {}, h("div.section-head", {}, h("h3", {}, "Options")), props),
    h("div.dialog-foot", {}, menuBtn, clearBtn, status, h("span.grow"), saveBtn, runBtn),
  );
  renderAfter();
  renderModel();
  renderSubs();
  render();
  picker.dropInto(dialog);
  back.append(dialog);
  document.body.append(back);
  const line = at && subList.querySelector(`[data-member="${CSS.escape(at)}"] textarea`);
  if (line) {
    line.focus();
    line.setSelectionRange(line.value.length, line.value.length);
  } else title.focus();
}
