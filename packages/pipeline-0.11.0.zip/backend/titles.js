// Titles written for you (task #99-2). A task or sub-task made without a title takes its description's first line at
// once (`titleAuto`), and a small model (claude__ask: haiku, effort low, one turn, no tools) writes a short one that
// says what the task is. It replaces the first line only while the title is still the one it had: a title you (or an
// agent) wrote stays. The ⋯ menu's "New title" (edit with `retitle`) writes a new one any time.
import { errorText } from "./util.js";

export const TITLE_MODEL = "haiku";
export const TITLE_EFFORT = "low";
export const TITLE_MAX = 80;

export const TITLE_SYSTEM =
  "You name coding tasks on a board. Read the task's description and reply with only its title: 3 to 8 plain words " +
  "that say exactly what the task changes or fixes, so it is recognised at a glance among many others. No quotes, no " +
  "task number, no full stop at the end, no words like 'Task' or 'Request'. Keep the description's language.";

/** The title to start with when none was given: the description's first line, at most 120 characters. */
export function firstLineTitle(prompt) {
  return String(prompt ?? "").trim().split("\n")[0].trim().slice(0, 120);
}

/** What the model's reply gives as a title (its first non-empty line, unquoted, without a closing full stop); "": none. */
export function titleOf(text) {
  const line = String(text ?? "").split("\n").map((l) => l.trim()).find(Boolean) ?? "";
  const clean = line
    .replace(/^(title|#+)\s*:?\s*/i, "")
    .replace(/^["'“”‘’`*]+|["'“”‘’`*]+$/g, "")
    .replace(/\.$/, "")
    .trim();
  return clean.length > TITLE_MAX ? `${clean.slice(0, TITLE_MAX - 1).trimEnd()}…` : clean;
}

/** The titles' writer. `p`: the pipeline. */
export function createTitles(p) {
  const { store } = p;
  const writing = new Set();

  /** Write task `id` a title now, in the background; the promise gives the new title, or null when it stayed. */
  async function write(id) {
    const task = store.get(id);
    if (!task || writing.has(id) || !String(task.prompt ?? "").trim()) return null;
    writing.add(id);
    const before = task.title;
    try {
      const answer = await p.claude.ask({
        prompt: `Task description:\n${String(task.prompt).slice(0, 4000)}`,
        system: TITLE_SYSTEM,
        model: TITLE_MODEL,
        effort: TITLE_EFFORT,
      });
      const title = titleOf(answer?.text);
      const now = store.get(id);
      // Only while nobody changed the title meanwhile.
      if (!title || !now || !now.titleAuto || now.title !== before) return null;
      store.mutate(id, () => ({ title }));
      return title;
    } catch (error) {
      p.log?.(`title for #${task.number}:`, errorText(error));
      return null;
    } finally {
      writing.delete(id);
    }
  }

  return { write };
}
