// Small helpers shared by the backend modules.
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import path from "node:path";

/** Log to stderr: the core keeps it in logs/pipeline.log (stdout is MCP). */
export function log(...args) {
  const text = args.map((a) => (typeof a === "string" ? a : a instanceof Error ? a.stack || a.message : safeJson(a)));
  process.stderr.write(`[pipeline ${new Date().toISOString()}] ${text.join(" ")}\n`);
}

export function safeJson(value) {
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

export function errorText(error) {
  if (error instanceof Error) return error.message;
  return typeof error === "string" ? error : safeJson(error);
}

export const nowIso = () => new Date().toISOString();

export function ensureDir(dir) {
  mkdirSync(dir, { recursive: true });
  return dir;
}

/** Write a file so readers never see half of it: a temporary file first, then a rename. */
export function writeFileAtomic(file, text) {
  ensureDir(path.dirname(file));
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  writeFileSync(tmp, text);
  renameSync(tmp, file);
}

export function readJson(file, fallback) {
  try {
    if (!existsSync(file)) return fallback;
    return JSON.parse(readFileSync(file, "utf8"));
  } catch (error) {
    log(`could not read ${file}:`, errorText(error));
    return fallback;
  }
}

/** Lowercase words joined by dashes, at most `max` characters: "Fix the login!" → "fix-the-login". */
export function slugify(text, max = 40) {
  const slug = String(text ?? "")
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return slug.slice(0, max).replace(/-+$/g, "");
}

/** One line, at most `max` characters. */
export function snippet(text, max = 160) {
  const t = String(text ?? "").replace(/\s+/g, " ").trim();
  return t.length > max ? `${t.slice(0, max - 1).trimEnd()}…` : t;
}

export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** Words of a text, for a rough likeness of two tasks (duplicates on propose). */
function words(text) {
  return new Set(
    String(text ?? "")
      .toLowerCase()
      .split(/[^a-z0-9áéíóöőúüű]+/)
      .filter((w) => w.length > 2),
  );
}

/** Jaccard likeness of the words of two texts, 0 to 1. */
export function similarity(a, b) {
  const x = words(a);
  const y = words(b);
  if (!x.size || !y.size) return 0;
  let both = 0;
  for (const w of x) if (y.has(w)) both++;
  return both / (x.size + y.size - both);
}

/** Two tasks this alike are likely the same. */
export const LOOKALIKE = 0.45;
