// The pipeline's settings: global ones and one set per project (a claude plugin project that is a git repository).
// Defaults, what each means, and checks for values agents and panels set (see docs/pipeline in layr_code for the
// design these come from).

export const MODES = ["stop", "here", "away"];
export const PERMISSION_MODES = ["default", "acceptEdits", "bypassPermissions", "plan"];
export const EFFORTS = ["low", "medium", "high", "xhigh", "max"];
export const DEFAULT_ASK_PATHS = ["supabase/migrations/**", "**/migrations/**", "**/*.sql"].join("\n");
export const SCOUT_MODES = ["off", "ask", "auto"];
/** How far the orchestrator may go with each of its abilities: quietly, and tell; ask first; never (tools taken away). */
export const LEEWAYS = ["quiet", "tell", "ask", "never"];
export const LANDINGS = ["local", "push", "pr"];
/** Model aliases Claude Code takes for `model` (the claude plugin passes it on; a full model id works too). */
export const MODEL_ALIASES = ["opus", "sonnet", "haiku"];
/** Who may start a task (`start`): you or agents, agents approved in advance, only you. */
export const STARTS = ["either", "agents", "manual"];

/** Global settings: [default, description, check]. */
export const GLOBAL = {
  mode: ["here", "stop (Soft stop: nothing new starts, what runs finishes), here (you're at the PC), away (planned and approved work goes; nobody answers)", oneOf(MODES)],
  maxRunning: [2, "Turns running at once, over all projects. Threads waiting for you don't count.", int(0, 10)],
  workerModel: [null, "Model of the task threads; a project or a task can set its own. Empty: the claude project's default model.", nstr()],
  workerEffort: [null, "Effort of the task threads; a project or a task can set its own. Empty: the model's default.", nullable(oneOf(EFFORTS))],
  verifierModel: ["sonnet", "Model of the verifier (it checks a task's work before it lands), unless a project sets its own.", str()],
  newPlan: [false, "New tasks start with Plan first on in the task dialog: Run makes the worker plan and ask you first (each project and task can change it).", bool()],
  newWhenAway: [false, "New tasks start with When away on in the task dialog: their work waits until you're Away (each project and task can change it).", bool()],
  newStart: ["either", "Who may start a new task, as the task dialog starts it: either (you or agents), agents (approved in advance), manual (only you).", oneOf(STARTS)],
  newWorktree: [true, "New tasks start with Own worktree on in the task dialog; off: they work in the project's checkout (each project and task can change it).", bool()],
  autoMerge: [false, "New tasks land by themselves when their turn ends with the work committed (each project and task can change it).", bool()],
  agentLands: [false, "New tasks' workers may start their own landing: when the work is done and everything went well the worker asks layr (pipeline__land), and layr lands it after the turn as your Land button does (each project and task can change it).", bool()],
  groupByProject: [false, "The board shows each column's tasks in a box per project.", bool()],
  showWorktreeMark: [true, "Cards and table rows of tasks whose worktree was removed say so (⌀ worktree).", bool()],
  pollSec: [5, "Seconds between looks at the threads when nothing happens and thread events don't come (thread_wait wakes it sooner); with thread events, at least 30.", int(1, 120)],
  limitBackoffMin: [15, "After a usage limit, minutes before trying again when neither the error nor the account says when it resets.", int(1, 600)],
  keepAwake: [true, "Keep the PC awake while the pipeline has work: turns running, landings, messages waiting for a slot (layr keeps Windows from sleeping; the screen may still turn off).", bool()],
  pacing: [true, "Pacing: every task gets a guess of what it costs (a small model guesses the size of tasks without one; costs are learned from what landed tasks spent), and in Away, Ready goes in its order only as far as the Claude accounts have room for it; the rest waits for a window to reset.", bool()],
  pacingReserve: [15, "Pacing: percent of the active account's 5-hour window kept free for your own chats.", int(0, 100)],
  awayHours: [8, "Pacing: when going Away without a time you're back, it counts on this many hours.", int(1, 24)],
  briefs: [true, "A small model writes a brief (what it is, what it asks you, what a wrong answer costs, stakes 1–10) for each task that waits for you and each proposal you didn't write.", bool()],
  briefModel: ["haiku", "Model of the briefs (one-shot claude__ask).", str()],
  scouts: ["ask", "Scouts look for ideas with evidence and propose them: off, ask (when you or the orchestrator send one), auto (also by themselves while you're Away and nothing runs).", oneOf(SCOUT_MODES)],
  scoutsAtOnce: [3, "Scouts running at once; more wait in a queue.", int(1, 10)],
  scoutModel: ["sonnet", "Model of the scouts' threads.", str()],
  orchestrator: [false, "The orchestrator: every few minutes layr looks at the board without Claude, and wakes a Claude thread (a check-in) only when something it can act on changed.", bool()],
  orchestratorModel: ["haiku", "Model of the orchestrator's check-ins.", str()],
  orchestratorEffort: ["high", "Effort of the orchestrator's check-ins; empty: the model's default.", nullable(oneOf(EFFORTS))],
  orchestratorLookMin: [10, "Minutes between the orchestrator's looks at the board (no Claude).", int(5, 120)],
  orchestratorRun: ["tell", "Running proposals: quiet, tell (do it and say so), ask (only suggest), never.", oneOf(LEEWAYS)],
  orchestratorAnswer: ["tell", "Answering workers' questions: quiet, tell, ask, never.", oneOf(LEEWAYS)],
  orchestratorScouts: ["tell", "Sending scouts and proposing tasks: quiet, tell, ask, never.", oneOf(LEEWAYS)],
  orchestratorSettings: ["tell", "Changing the mode and pipeline settings: quiet, tell, ask, never.", oneOf(LEEWAYS)],
  orchestratorWakeOnEnd: [true, "While you're Away, a task or scout ending wakes it.", bool()],
  orchestratorAwayEveryMin: [30, "While you're Away, a check-in at least this often (minutes); 0: only on changes.", int(0, 720)],
  orchestratorRules: ["", "Standing rules for the orchestrator, in your words (e.g. keep sending scouts all night).", str()],
};

/** Per-project settings: [default, description, check]. */
export const PROJECT = {
  enabled: [false, "The pipeline works in this project: tasks launch, land and clean up.", bool()],
  icon: ["", "An emoji (or up to 3 letters) shown with the project's tasks, groups and tabs; empty: none.", icon()],
  color: [null, "The project's colour on its tasks, groups and tabs; empty: none.", nullable(color())],
  baseBranch: ["main", "The branch tasks start from and land on.", branch()],
  branchPrefix: ["layr/", "Task branches are <prefix><number>-<title>.", str()],
  workerModel: [null, "Model of the task threads here; empty: the global value. A task's own model wins.", nstr()],
  workerEffort: [null, "Effort of the task threads here; empty: the global value. A task's own effort wins.", nullable(oneOf(EFFORTS))],
  workerPermissionMode: ["bypassPermissions", "Permission mode of the task threads (they work in their own worktree).", oneOf(PERMISSION_MODES)],
  maxRunning: [null, "Turns running at once in this project; empty: the global value (it can only lower it).", nullable(int(0, 10))],
  instructions: ["", "Added to every launch message of this project.", str()],
  newPlan: [null, "New tasks here start with Plan first on (or off) in the task dialog; empty: the global value.", nullable(bool())],
  newWhenAway: [null, "New tasks here start with When away on (or off) in the task dialog; empty: the global value.", nullable(bool())],
  newStart: [null, "Who may start a new task here (either, agents, manual), as the task dialog starts it; empty: the global value.", nullable(oneOf(STARTS))],
  newWorktree: [null, "New tasks here start with Own worktree on (or off) in the task dialog; empty: the global value.", nullable(bool())],
  autoMerge: [null, "New tasks here land by themselves when their turn ends with the work committed; empty: the global value (each task can change it).", nullable(bool())],
  agentLands: [null, "New tasks' workers here may start their own landing (pipeline__land; layr lands it after the turn as your Land button does); empty: the global value (each task can change it).", nullable(bool())],
  checks: ["", "A command layr runs in the worktree before landing (e.g. `npm test`); empty: none.", str()],
  checksTimeoutMin: [15, "Minutes the checks may take.", int(1, 240)],
  landing: ["local", "local: fast-forward the base branch in the repository on the PC; push: also push it to the remote (no force); pr: push the task's branch, open a pull request with gh and merge it once CI is green.", oneOf(LANDINGS)],
  remote: ["origin", "The remote `push` landing pushes to.", str()],
  squash: [true, "Land as one commit.", bool()],
  askPaths: [DEFAULT_ASK_PATHS, "Files (globs, one per line) whose change always waits for you: no auto-merge, agents can't land it.", str()],
  verify: ["off", "off, autoMerge (tasks that auto-merge, or whose agent lands them) or always: a verifier thread checks the work before it lands.", oneOf(["off", "autoMerge", "always"])],
  verifierModel: [null, "The verifier's model here; empty: the global one.", nstr()],
  tryCommand: ["", "▶ Try: what starts a task's result from its worktree, in a PowerShell window on the PC (a free port in $env:LAYR_TRY_PORT; one try per project at a time: the next one stops it). Empty: no ▶ Try.", str()],
  afterLanding: ["", "A command run in the task's worktree once it landed (LAYR_COMMIT, LAYR_TASK, LAYR_BASE set).", str()],
  afterLandingTimeoutMin: [30, "Minutes After landing may take.", int(1, 240)],
  removeWorktrees: [true, "Remove the worktree (and its local branch) of a settled task once its work is on the base branch and nothing in it is uncommitted; the card and thread stay, and the worktree is made again when the thread gets a message.", bool()],
  removeWorktreesAfterHours: [0, "Hours after settling before a merged task's worktree is removed.", int(0, 720)],
  settleLandedAfterDays: [1, "Days after landing before a landed task settles by itself (it leaves Stopped); empty: never.", nullable(int(0, 365))],
  laneSetup: ["", "Test lane, for what only one task may use at a time (a fixed port, a device, a shared database): the setup command a worker runs on it in its worktree. All lane commands empty: no lane.", str()],
  laneRun: ["", "Test lane: the command that starts the app.", str()],
  laneE2e: ["", "Test lane: the end-to-end tests.", str()],
  laneUrl: ["", "Test lane: where the app runs.", str()],
  laneTimeoutMin: [20, "Minutes a worker may keep the lane; then it goes to the next one.", int(1, 240)],
  laneHoldMaxMin: [120, "Minutes Hold lane (you take it) lasts at most.", int(1, 720)],
  updateMain: [false, "Keep up to date: every few minutes and after a landing, bring the project's own folder to the newest base branch (fast-forward, only when it is clean and on the base branch) and run the update command.", bool()],
  updateApprove: [false, "Keep up to date waits for Update now instead of updating by itself.", bool()],
  updateCommand: ["", "Run in the project's folder after it was brought up to date (PowerShell on Windows, sh elsewhere; LAYR_COMMIT, LAYR_FROM, LAYR_BASE set).", str()],
  updateTimeoutMin: [30, "Minutes the update command may take.", int(1, 240)],
  projectNode: [null, "The project's node on the concept map (the concepts plugin): its sections (Rules, Brainstorm, Features, Plan) and their rules go into every launch message; Set up project map makes the sections it lacks. Empty: none.", nstr()],
  featureMap: [null, "Before project nodes: a concept node holding the project's features, which workers keep current. Counts only while Project node is empty.", nstr()],
  scoutFeatures: [null, "A concept-map node (the concepts plugin) scouts file their ideas into with concepts__file; empty: they propose tasks on the board.", nstr()],
  orchestratorWake: ["events", "When this project wakes the orchestrator: events (something it can act on changed), asked (only when you ask), off.", oneOf(["events", "asked", "off"])],
};

/** The project has a test lane (some lane command set). */
export const hasLane = (s) => !!(s.laneSetup.trim() || s.laneRun.trim() || s.laneE2e.trim());

export function globalDefaults() {
  return Object.fromEntries(Object.entries(GLOBAL).map(([k, [v]]) => [k, v]));
}

export function projectDefaults() {
  return Object.fromEntries(Object.entries(PROJECT).map(([k, [v]]) => [k, v]));
}

/** Check one value against its definition; gives the value to store or throws why not. */
export function checkValue(defs, key, value) {
  const def = defs[key];
  if (!def) throw new Error(`There is no setting "${key}" (settings: ${Object.keys(defs).join(", ")})`);
  return def[2](value, key);
}

/** The choices of settings that have a fixed list (for the Settings panel). */
export const OPTIONS = {
  mode: MODES,
  workerEffort: EFFORTS,
  workerPermissionMode: PERMISSION_MODES,
  landing: LANDINGS,
  verify: ["off", "autoMerge", "always"],
  newStart: STARTS,
  scouts: SCOUT_MODES,
  orchestratorEffort: EFFORTS,
  orchestratorRun: LEEWAYS,
  orchestratorAnswer: LEEWAYS,
  orchestratorScouts: LEEWAYS,
  orchestratorSettings: LEEWAYS,
  orchestratorWake: ["events", "asked", "off"],
};

/** Settings as agents read them: value, default, changed, what it means. */
export function describe(defs, values = {}) {
  return Object.entries(defs).map(([key, [dflt, about, check]]) => {
    // A saved null is a value of its own (e.g. orchestratorEffort: the model's default), not the default.
    const value = values?.[key] !== undefined ? values[key] : dflt;
    return {
      key,
      value,
      ...(OPTIONS[key] ? { options: OPTIONS[key] } : {}),
      ...(check.nullable ? { nullable: true } : {}),
      ...(JSON.stringify(value) !== JSON.stringify(dflt) ? { changed: true, default: dflt } : {}),
      about,
    };
  });
}

/**
 * The model and effort a task's thread starts with: the task's own, else its project's, else the global ones. null
 * leaves it to the claude plugin (the claude project's default model; the model's default effort).
 */
export function workerSettings(task, project, global) {
  return {
    model: task?.model || project?.workerModel || global?.workerModel || null,
    effort: task?.effort || project?.workerEffort || global?.workerEffort || null,
  };
}

/**
 * How a new task starts (the task dialog's toggles, and auto-merge and agent lands for every new task): the project's
 * value, else the global one, else the default.
 */
export function newTaskDefaults(project, global) {
  const pick = (key) => project?.[key] ?? global?.[key] ?? GLOBAL[key][0];
  return {
    plan: pick("newPlan"),
    whenAway: pick("newWhenAway"),
    start: pick("newStart"),
    worktree: pick("newWorktree"),
    autoMerge: pick("autoMerge"),
    agentLands: pick("agentLands"),
  };
}

// ---------------------------------------------------------------- checks

function oneOf(list) {
  return (v, key) => {
    if (!list.includes(v)) throw new Error(`${key} is one of ${list.join(", ")}`);
    return v;
  };
}

function int(min, max) {
  return (v, key) => {
    const n = typeof v === "string" && v.trim() ? Number(v) : v;
    if (!Number.isInteger(n) || n < min || n > max) throw new Error(`${key} is a whole number from ${min} to ${max}`);
    return n;
  };
}

function bool() {
  return (v, key) => {
    if (typeof v !== "boolean") throw new Error(`${key} is true or false`);
    return v;
  };
}

function str() {
  return (v, key) => {
    if (typeof v !== "string") throw new Error(`${key} is text`);
    return v;
  };
}

/** Text, or null for empty. */
function nstr() {
  return Object.assign((v, key) => {
    if (v === null || v === undefined) return null;
    if (typeof v !== "string") throw new Error(`${key} is text, or null`);
    return v.trim() || null;
  }, { nullable: true });
}

function nullable(check) {
  return Object.assign((v, key) => (v === null || v === "" ? null : check(v, key)), { nullable: true });
}

/** The swatches the Settings panel offers for a project's colour (any #rrggbb works). */
export const COLORS = ["#e5484d", "#f76b15", "#ffc53d", "#46a758", "#12a594", "#0090ff", "#3e63dd", "#8e4ec6", "#d6409f", "#8d8d8d"];

/** An emoji or a few letters: at most 3 characters as people see them. */
function icon() {
  return (v, key) => {
    if (typeof v !== "string") throw new Error(`${key} is text`);
    const t = v.trim();
    const shown = [...new Intl.Segmenter(undefined, { granularity: "grapheme" }).segment(t)].length;
    if (shown > 3) throw new Error(`${key} is an emoji or at most 3 letters`);
    return t;
  };
}

function color() {
  return (v, key) => {
    if (typeof v !== "string" || !/^#[0-9a-f]{6}$/i.test(v.trim())) throw new Error(`${key} is a colour like #3e63dd`);
    return v.trim().toLowerCase();
  };
}

function branch() {
  return (v, key) => {
    if (typeof v !== "string" || !/^[\w./-]+$/.test(v) || v.includes("..")) throw new Error(`${key} is a branch name`);
    return v;
  };
}
