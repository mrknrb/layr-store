// `landing: pr` (ported from layr_code's backend/pr.ts): the checked commit goes to the task's branch on the remote,
// layr opens (or reuses) its pull request with `gh`, and merges it itself once CI is green and GitHub says it can be
// merged (`gh pr merge --match-head-commit`, so nothing layr didn't check gets merged). Failing CI and a base that
// moved go back to the thread; a review that is required is waited for, changes requested stop the landing.
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { gh } from "./git.js";

/** After a push, CI gets this long to show up before "no checks" means there are none. */
export const CI_GRACE_MS = 90_000;
/** How often a pull request is read while it lands. */
export const PR_POLL_MS = 25_000;

const FAILED = new Set(["FAILURE", "ERROR", "CANCELLED", "TIMED_OUT", "ACTION_REQUIRED", "STARTUP_FAILURE"]);
const checkName = (c) => (c.__typename === "CheckRun" ? c.name : c.context);
const checkUrl = (c) => (c.__typename === "CheckRun" ? c.detailsUrl : c.targetUrl) ?? null;
const checkFailed = (c) => (c.__typename === "CheckRun" ? c.status === "COMPLETED" && FAILED.has(c.conclusion ?? "") : FAILED.has(c.state));
const checkPending = (c) => (c.__typename === "CheckRun" ? c.status !== "COMPLETED" : c.state === "PENDING" || c.state === "EXPECTED");

/**
 * What a pull request needs next, for the commit layr pushed (`head`) at `pushedAt`. Pure. Kinds: merged {commit},
 * closed, foreign {head}, failed {checks}, rebase {why}, changes, wait {why}, ready.
 */
export function prVerdict(view, head, pushedAt, now = Date.now()) {
  if (view.state === "MERGED") return { kind: "merged", commit: view.mergeCommit?.oid ?? head };
  if (view.state === "CLOSED") return { kind: "closed" };
  if (view.headRefOid !== head) {
    if (now - Date.parse(pushedAt) < CI_GRACE_MS) return { kind: "wait", why: "GitHub updates the pull request" };
    return { kind: "foreign", head: view.headRefOid };
  }
  const checks = view.statusCheckRollup ?? [];
  const failed = checks.filter(checkFailed);
  if (failed.length) return { kind: "failed", checks: failed.map((c) => ({ name: checkName(c), url: checkUrl(c) })) };
  if (checks.some(checkPending)) return { kind: "wait", why: "CI runs" };
  if (!checks.length && now - Date.parse(pushedAt) < CI_GRACE_MS) return { kind: "wait", why: "waits for CI to start" };
  if (view.mergeStateStatus === "DIRTY") return { kind: "rebase", why: "it conflicts with the base branch" };
  if (view.mergeStateStatus === "BEHIND") return { kind: "rebase", why: "the base branch moved on" };
  if (view.reviewDecision === "CHANGES_REQUESTED") return { kind: "changes" };
  if (view.reviewDecision === "REVIEW_REQUIRED") return { kind: "wait", why: "waits for a review" };
  if (view.mergeStateStatus === "DRAFT") return { kind: "wait", why: "it is a draft" };
  if (view.mergeStateStatus === "BLOCKED") return { kind: "wait", why: "GitHub blocks the merge (branch rules)" };
  if (view.mergeStateStatus === "UNKNOWN") return { kind: "wait", why: "GitHub is still checking it" };
  return { kind: "ready" };
}

const FIELDS = "number,url,state,mergeStateStatus,reviewDecision,statusCheckRollup,headRefOid,mergeCommit";

export async function viewPr(repo, number) {
  return JSON.parse(await gh(repo, "pr", "view", String(number), "--json", FIELDS));
}

/** The open pull request of `branch`, if there is one. */
export async function findPr(repo, branch) {
  const list = JSON.parse(await gh(repo, "pr", "list", "--head", branch, "--state", "open", "--json", "number,url", "--limit", "1"));
  return list[0] ?? null;
}

/** Open a pull request of `branch` into `base`; the body goes through a file (newlines, backticks). */
export async function createPr(repo, { base, branch, title, body }) {
  const dir = mkdtempSync(path.join(os.tmpdir(), "layr-pr-"));
  try {
    const file = path.join(dir, "body.md");
    writeFileSync(file, body);
    const out = await gh(repo, "pr", "create", "--base", base, "--head", branch, "--title", title, "--body-file", file);
    const url = out.trim().split("\n").at(-1).trim();
    const number = Number(/\/pull\/(\d+)/.exec(url)?.[1]);
    if (!number) throw new Error(`gh pr create gave no pull request URL: ${out.trim()}`);
    return { number, url };
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}

/** Merge it, but only if its head is still the commit layr checked. */
export const mergePr = (repo, number, head, squash) =>
  gh(repo, "pr", "merge", String(number), squash ? "--squash" : "--merge", "--match-head-commit", head);

export const closePr = (repo, number, comment) => gh(repo, "pr", "close", String(number), "--comment", comment);
