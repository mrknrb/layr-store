// "Not landed" (ported from layr_code's Git lanes panel, without its graph): a project's task branches whose work
// isn't on the base branch, so stranded work shows: the branch, its task (and the task's state), how far it is ahead
// of and behind the base, and its worktree. Branches of tasks that were discarded are gone already; a branch without a
// task on the board is listed as such.
import { aheadBehind, branchesWith, isAncestor, worktreesByBranch } from "./git.js";
import { baseRef, taskLink } from "./prompts.js";

/** The project's branches not landed: [{ branch, ahead, behind, worktree, date, task?: {number, title, column, state, link} }]. */
export async function notLanded(p, projectId) {
  const settings = p.store.project(projectId);
  const repo = p.repoOf(projectId);
  const ref = baseRef(settings);
  const byBranch = new Map();
  for (const [id, t] of p.store.entries()) if (t.projectId === projectId && t.branch) byBranch.set(t.branch, id);
  const worktrees = await worktreesByBranch(repo).catch(() => new Map());
  const out = [];
  for (const b of await branchesWith(repo, "").catch(() => [])) {
    if (b.branch === settings.baseBranch) continue;
    if (!b.branch.startsWith(settings.branchPrefix) && !byBranch.has(b.branch)) continue;
    if (await isAncestor(repo, b.head, ref).catch(() => false)) continue;
    const { ahead, behind } = await aheadBehind(repo, b.branch, ref).catch(() => ({ ahead: 0, behind: 0 }));
    const id = byBranch.get(b.branch);
    const v = id ? p.view(id) : null;
    out.push({
      branch: b.branch,
      ahead,
      behind,
      date: b.date,
      worktree: worktrees.get(b.branch) ?? null,
      ...(v ? { task: { number: v.number, title: v.title, column: v.column, state: v.state, link: taskLink(v.id) } } : {}),
    });
  }
  return out.sort((a, b) => String(b.date).localeCompare(String(a.date)));
}
