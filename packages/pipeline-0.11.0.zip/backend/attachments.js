// Attachments (layr_code staged files with a task or a message and uploaded them to T3 when it was sent). Here a file
// is staged with `pipeline__attach` into the plugin's folder (attachments/<id>), named in a task (`attachments` on
// create / edit) or a message (`attachments` on send), and goes when that is delivered: images (PNG, JPEG, GIF, WebP)
// as images of the claude plugin's thread_start / thread_send; other files by their path on the PC, in the text.
// Images are dropped once sent (the claude plugin keeps its own copy); other files stay until the task is cleaned up.
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { randomUUID } from "node:crypto";
import path from "node:path";

export const IMAGE_TYPES = new Set(["image/png", "image/jpeg", "image/gif", "image/webp"]);
export const MAX_BYTES = 5 * 1024 * 1024;
export const MAX_PER_TASK = 10;
/** Staged files nothing names after this long are removed. */
const ORPHAN_MS = 24 * 60 * 60_000;

export function createAttachments(dataDir) {
  const dir = path.join(dataDir, "attachments");
  const fileOf = (a) => path.join(dir, `${a.id}${path.extname(a.name) || ""}`);

  /** Stage a file: { name, mediaType, data (base64 or a data: URL) } → { id, name, mediaType, size }. */
  function stage({ name, mediaType, data }) {
    const clean = path.basename(String(name ?? "").trim()).replace(/[^\w.() -]+/g, "_").slice(0, 120);
    if (!clean) throw new Error("A file needs a name");
    const buffer = Buffer.from(String(data ?? "").replace(/^data:[^;]+;base64,/, ""), "base64");
    if (!buffer.length) throw new Error("The file is empty");
    if (buffer.length > MAX_BYTES) throw new Error("A file is larger than 5 MB");
    mkdirSync(dir, { recursive: true });
    const a = { id: `f_${randomUUID().slice(0, 12)}`, name: clean, mediaType: String(mediaType || "application/octet-stream"), size: buffer.length };
    writeFileSync(fileOf(a), buffer);
    writeFileSync(path.join(dir, `${a.id}.json`), JSON.stringify(a));
    return a;
  }

  /** A staged file's record, or throws. */
  function get(id) {
    const meta = path.join(dir, `${String(id).replace(/[^\w-]/g, "")}.json`);
    if (!existsSync(meta)) throw new Error(`There is no staged file ${id}: stage it with attach first`);
    return JSON.parse(readFileSync(meta, "utf8"));
  }

  /** Check a list of ids (what a task or message names) and give their records. */
  function check(ids) {
    const list = [...new Set(ids ?? [])];
    if (list.length > MAX_PER_TASK) throw new Error(`At most ${MAX_PER_TASK} files at once`);
    return list.map(get);
  }

  /** What goes with a message: images for the claude plugin, and a note naming the other files' paths. */
  function payload(list) {
    const images = [];
    const others = [];
    for (const a of list ?? []) {
      if (!existsSync(fileOf(a))) continue;
      if (IMAGE_TYPES.has(a.mediaType)) images.push({ mediaType: a.mediaType, data: readFileSync(fileOf(a)).toString("base64") });
      else others.push(`- ${a.name}: ${fileOf(a)}`);
    }
    const note = others.length ? `\n\nFiles the user attached (on this PC; read them from there):\n${others.join("\n")}` : "";
    return { images, note };
  }

  /** Drop files: the images once sent (`imagesOnly`), or all of them. */
  function drop(list, { imagesOnly = false } = {}) {
    for (const a of list ?? []) {
      if (imagesOnly && !IMAGE_TYPES.has(a.mediaType)) continue;
      rmSync(fileOf(a), { force: true });
      rmSync(path.join(dir, `${a.id}.json`), { force: true });
    }
  }

  /** Staged files nobody named for a day (`named`: ids tasks still hold). */
  function sweep(named, now = Date.now()) {
    if (!existsSync(dir)) return;
    for (const f of readdirSync(dir)) {
      if (!f.endsWith(".json")) continue;
      const id = f.slice(0, -5);
      if (named.has(id)) continue;
      if (now - statSync(path.join(dir, f)).mtimeMs < ORPHAN_MS) continue;
      try {
        drop([get(id)]);
      } catch {
        rmSync(path.join(dir, f), { force: true });
      }
    }
  }

  return { stage, get, check, payload, drop, sweep, dir };
}
