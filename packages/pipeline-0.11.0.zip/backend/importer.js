// One-time import of layr_code's pipeline settings: read-only, from layr_code's Supabase table `plugin_records`
// (plugin `pipeline`: collection `settings`, ids `global` and `project:<T3 project id>`; collection `meta`, id
// `catalog`, whose `projects` give each T3 project's folder), through the user's own session
// (`layr__supabase_session`, docs/ARCHITECTURE.md › Supabase for plugins), so its row level security applies. A
// project here gets the settings of the layr_code project in the same folder, and only where its own are empty
// (never saved, or saved empty). Nothing is ever written to layr_code's records: the only requests are GETs.
import { checkValue, EFFORTS, GLOBAL, MODEL_ALIASES, PROJECT } from "./settings.js";
import { errorText } from "./util.js";

/** layr_code's landing `direct` pushed onto the base branch: here that is `push`. */
export const LANDING = { direct: "push", pr: "pr" };
/** T3 Code's runtime modes as Claude Code's permission modes. */
export const PERMISSION = {
  "full-access": "bypassPermissions",
  "auto-accept-edits": "acceptEdits",
  auto: "default",
  "approval-required": "default",
};
/** layr_code's project colours (as concept tags') as this layr's swatches. */
export const COLOR = {
  gray: "#8d8d8d",
  red: "#e5484d",
  orange: "#f76b15",
  yellow: "#ffc53d",
  green: "#46a758",
  teal: "#12a594",
  blue: "#0090ff",
  purple: "#8e4ec6",
  pink: "#d6409f",
};

/** A T3 model ref ({instanceId, model}) as a model id Claude Code takes; null for none or another provider's model. */
export function modelId(ref) {
  const model = typeof ref === "string" ? ref : ref?.model;
  if (typeof model !== "string" || !model.trim()) return null;
  const m = model.trim();
  return MODEL_ALIASES.includes(m) || /^claude[-\w.[\]]*$/i.test(m) || /^(opus|sonnet|haiku)\[/.test(m) ? m : null;
}

/** A folder for comparing: one kind of slash, no slash at the end, any case (Windows). */
export const folderKey = (dir) => String(dir ?? "").replace(/\\/g, "/").replace(/\/+$/, "").toLowerCase();

/** layr_code's project settings record in this layr's names (only what it holds; other values are left out). */
export function mapProject(old) {
  const o = old ?? {};
  const lane = o.lane ?? {};
  const out = {
    baseBranch: o.baseBranch,
    branchPrefix: o.branchPrefix,
    workerModel: o.workerModel === undefined ? undefined : modelId(o.workerModel),
    workerEffort: EFFORTS.includes(o.workerOptions?.effort) ? o.workerOptions.effort : undefined,
    workerPermissionMode: PERMISSION[o.workerRuntimeMode],
    maxRunning: o.maxRunning !== undefined ? o.maxRunning : o.maxCoders,
    checks: o.checks,
    checksTimeoutMin: o.checksTimeoutMin,
    landing: LANDING[o.landing],
    squash: o.squash,
    laneSetup: lane.setup,
    laneRun: lane.run,
    laneE2e: lane.e2e,
    laneUrl: lane.url,
    laneTimeoutMin: lane.timeoutMin,
    laneHoldMaxMin: lane.holdMaxMin,
    afterLanding: o.afterLanding,
    afterLandingTimeoutMin: o.afterLandingTimeoutMin,
    updateMain: o.updateMain,
    updateApprove: o.updateApprove,
    updateCommand: o.updateCommand,
    updateTimeoutMin: o.updateTimeoutMin,
    instructions: o.instructions,
    askPaths: o.askPaths,
    tryCommand: o.tryCommand,
    projectNode: o.projectNode?.id,
    featureMap: o.featureMap?.id,
    verify: o.verify,
    verifierModel: o.verifierModel === undefined ? undefined : modelId(o.verifierModel),
    icon: typeof o.icon?.emoji === "string" ? o.icon.emoji : undefined,
    color: COLOR[o.color],
    orchestratorWake: o.policy?.wake,
  };
  return Object.fromEntries(Object.entries(out).filter(([, v]) => v !== undefined && v !== null && v !== ""));
}

/** layr_code's global settings record in this layr's names. */
export function mapGlobal(old) {
  const o = old ?? {};
  const out = {
    maxRunning: o.maxRunning ?? o.maxCoders,
    limitBackoffMin: o.limitBackoffMin,
    keepAwake: o.keepAwake,
    groupByProject: o.groupByProject,
    scouts: o.scouts,
    scoutsAtOnce: o.scoutsAtOnce,
  };
  return Object.fromEntries(Object.entries(out).filter(([, v]) => v !== undefined && v !== null && v !== ""));
}

/** A setting this layr has no value of its own for: never saved, or saved empty. */
export const isEmpty = (saved, key) => saved?.[key] === undefined || saved[key] === null || saved[key] === "";

/** The values of `mapped` whose setting is empty in `saved` and that pass its check: {fill, skipped}. */
function fillOf(defs, mapped, saved) {
  const fill = {};
  const skipped = [];
  for (const [key, value] of Object.entries(mapped)) {
    if (!isEmpty(saved, key)) continue;
    try {
      const checked = checkValue(defs, key, value);
      if (checked === null || checked === "") continue;
      fill[key] = checked;
    } catch (error) {
      skipped.push(`${key}: ${errorText(error)}`);
    }
  }
  return { fill, skipped };
}

/**
 * What the import would fill. `records`: layr_code's rows [{collection, id, data}]; `projects`: this layr's pipeline
 * projects [{projectId, title, path, saved}]; `global`: the global settings saved here. Gives {projects: [{projectId,
 * title, from: {id, title}, fill, skipped}], global: {fill, skipped}, unmatched: [{id, title, path}], found}.
 */
export function planImport({ records, projects, global }) {
  const settings = new Map(records.filter((r) => r.collection === "settings").map((r) => [r.id, r.data ?? {}]));
  const catalog = records.find((r) => r.collection === "meta" && r.id === "catalog")?.data ?? {};
  const known = new Map((catalog.projects ?? []).map((x) => [x.id, x]));
  const out = { projects: [], global: fillOf(GLOBAL, mapGlobal(settings.get("global")), global), unmatched: [], found: 0 };
  for (const [id, data] of settings) {
    if (!id.startsWith("project:")) continue;
    out.found++;
    const oldId = id.slice("project:".length);
    const info = known.get(oldId);
    const here = info ? projects.find((x) => folderKey(x.path) === folderKey(info.workspaceRoot)) : null;
    if (!here) {
      out.unmatched.push({ id: oldId, title: info?.title ?? oldId, path: info?.workspaceRoot ?? null });
      continue;
    }
    const { fill, skipped } = fillOf(PROJECT, mapProject(data), here.saved ?? {});
    out.projects.push({ projectId: here.projectId, title: here.title, from: { id: oldId, title: info.title }, fill, skipped });
  }
  return out;
}

/** layr_code's pipeline rows, read with the user's session: GET only. Throws a clear reason when it can't. */
export async function readLayrCode(session, fetchFn = globalThis.fetch) {
  if (!session?.url || !session.accessToken) throw new Error("Not signed in: sign in to layr (Settings › Account) to read layr_code's settings");
  const base = `${String(session.url).replace(/\/+$/, "")}/rest/v1/plugin_records`;
  const headers = { apikey: session.key, Authorization: `Bearer ${session.accessToken}`, Accept: "application/json" };
  const get = async (query) => {
    const response = await fetchFn(`${base}?select=collection,id,data&plugin_id=eq.pipeline&${query}`, { method: "GET", headers });
    const text = await response.text();
    if (response.status === 401 || response.status === 403) {
      throw new Error(`This session can't read layr_code's records (HTTP ${response.status}: ${text.slice(0, 200)}): the database's row level security or grants refuse it`);
    }
    if (!response.ok) throw new Error(`Reading layr_code's records failed (HTTP ${response.status}: ${text.slice(0, 200)})`);
    return JSON.parse(text);
  };
  const [settings, meta] = await Promise.all([get("collection=eq.settings"), get("collection=eq.meta&id=eq.catalog")]);
  return [...settings, ...meta];
}
