#!/usr/bin/env node
// layr plugin "pipeline": coding tasks as Claude threads (the claude plugin) in their own worktrees, a running cap,
// questions for the user, and landing on the base branch. An MCP server on stdio (the core is its client); it calls
// the claude plugin's tools through the hub. Environment: LAYR_HUB_URL, LAYR_HUB_TOKEN, LAYR_DATA_DIR.
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import os from "node:os";
import path from "node:path";
import { createActions } from "./actions.js";
import { ClaudeClient } from "./claude.js";
import { Hub } from "./hub.js";
import { Pipeline } from "./pipeline.js";
import { Store } from "./store.js";
import { INSTRUCTIONS, registerTools } from "./tools.js";
import { log } from "./util.js";

const dataDir = process.env.LAYR_DATA_DIR || path.join(os.homedir(), ".layr-pipeline-dev");
const store = new Store(dataDir);
const hub = new Hub({ url: process.env.LAYR_HUB_URL, token: process.env.LAYR_HUB_TOKEN });
const pipeline = new Pipeline({ store, claude: new ClaudeClient(hub), hub });
const actions = createActions(pipeline);

const server = new McpServer({ name: "pipeline", version: "0.4.0" }, { capabilities: { tools: {} }, instructions: INSTRUCTIONS });
registerTools(server, pipeline, actions);
// Events come as MCP notifications (docs/ARCHITECTURE.md › Backends hearing events): the claude plugin's thread
// changes, after pipeline.listen() subscribed to them.
server.server.fallbackNotificationHandler = async (notification) => {
  if (notification.method === "notifications/layr/event") pipeline.heard(notification.params?.topic);
};

async function main() {
  await server.connect(new StdioServerTransport());
  log(`pipeline backend up (data ${dataDir}, hub ${hub.available ? "on" : "off"})`);
  await pipeline.listen();
  // Give the core a moment to finish connecting before the first look at the threads.
  setTimeout(() => pipeline.start(), 1500).unref?.();
}

let stopping = false;
async function stop(code = 0) {
  if (stopping) return;
  stopping = true;
  try {
    pipeline.stop();
    store.saveNow();
    await hub.close();
  } finally {
    process.exit(code);
  }
}
process.on("SIGINT", () => void stop(0));
process.on("SIGTERM", () => void stop(0));
process.stdin.on("end", () => void stop(0));
process.stdin.on("close", () => void stop(0));
process.on("uncaughtException", (error) => log("uncaught:", error));
process.on("unhandledRejection", (error) => log("unhandled rejection:", error));

main().catch((error) => {
  log("could not start:", error);
  process.exit(1);
});
