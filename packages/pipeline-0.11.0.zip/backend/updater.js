// Keep up to date (ported from layr_code's shared/update.ts and backend/updater.ts): for each project with
// `updateMain`, at the backend's start, every few minutes and right after a landing there, compare the project's own
// folder with the base branch (the remote's for push and pr landing, else the local branch), and when it is behind,
// clean, on the base branch and nothing runs there, fast-forward it and run the project's update command in it (with
// `updateApprove`, only once you press Update now). Nothing is remembered between a landing and its update: the next
// comparison finds it again. What it found is kept per project (`updates`), for Settings and Decide.
// layr_code's own-repository steps (install, migrations, build, restarting its host) are not ported: the new layr's
// core and plugins update through the store, and nothing here restarts the server the user works on.
import { spawn } from "node:child_process";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { behindAhead, currentBranch, fetchBase, git, headOf, revParse, trackedClean } from "./git.js";
import { remoteLanding } from "./prompts.js";
import { errorText, nowIso, snippet } from "./util.js";

export const CHECK_MS = 5 * 60_000;
const plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;

/**
 * What the folder's state says to do next, pure: current, failed, wait {why, you}, ready (waits for Update now) or
 * update {goal}. Facts: base, branch, head, target, behind, ahead, clean, busy, doneOn, failedOn, forced, approve,
 * approved.
 */
export function decideUpdate(f) {
  const goal = f.behind > 0 ? f.target : f.head;
  const doneOn = f.doneOn ?? (f.behind === 0 ? f.head : undefined);
  if (!f.forced && f.behind === 0 && doneOn === f.head) return { kind: "current" };
  if (!f.forced && f.failedOn === goal) return { kind: "failed" };
  if (f.branch !== f.base) return { kind: "wait", you: true, why: `The project's folder is on \`${f.branch}\`, not \`${f.base}\`: switch back.` };
  if (f.ahead > 0) return { kind: "wait", you: true, why: `The project's folder has ${plural(f.ahead, "commit")} that ${f.targetName} doesn't: push or land them.` };
  if (!f.clean) return { kind: "wait", you: true, why: "The project's folder has uncommitted changes: layr doesn't touch them. Commit or undo them and it goes on." };
  if (f.approve && !f.approved && !f.forced) return { kind: "ready" };
  if (f.busy) return { kind: "wait", you: false, why: `Waits until nothing runs here: ${f.busy}.` };
  return { kind: "update", goal };
}

/**
 * The script file's text: Windows PowerShell stops at a cmdlet's error and fails with the exit code of a native
 * command that failed last (a failing `npm` is a failure), and gets a BOM so it reads the file as UTF-8 (paths with
 * accents); `sh` stops at the first failing command.
 */
export function updateScriptText(script, windows = process.platform === "win32") {
  if (!windows) return `set -e\n${script}\n`;
  const body = ["$ErrorActionPreference = 'Stop'", script.replace(/\r?\n/g, "\r\n"), "if ($LASTEXITCODE) { exit $LASTEXITCODE }", ""];
  return `﻿${body.join("\r\n")}`;
}

/** Run the update command: Windows PowerShell from a temporary .ps1 (stops at errors), `sh` elsewhere. */
export function runUpdateScript(script, cwd, timeoutMs, env) {
  const dir = mkdtempSync(path.join(os.tmpdir(), "layr-update-"));
  const windows = process.platform === "win32";
  const file = path.join(dir, windows ? "update.ps1" : "update.sh");
  writeFileSync(file, updateScriptText(script, windows), "utf8");
  const [command, args] = windows
    ? ["powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", file]]
    : ["sh", [file]];
  return new Promise((resolve) => {
    let output = "";
    const child = spawn(command, args, { cwd, env: { ...process.env, ...env }, windowsHide: true });
    const keep = (d) => (output = (output + d).slice(-8000));
    child.stdout.on("data", keep);
    child.stderr.on("data", keep);
    const timer = setTimeout(() => {
      keep(`\nTimed out after ${Math.round(timeoutMs / 60_000)} min.`);
      child.kill();
    }, timeoutMs);
    const done = (ok) => {
      clearTimeout(timer);
      rmSync(dir, { recursive: true, force: true });
      resolve({ ok, output: output.trim().slice(-4000) });
    };
    child.on("error", (error) => (keep(`\n${error.message}`), done(false)));
    child.on("close", (code) => done(code === 0));
  });
}

/** Keep up to date on the PC. `p`: the pipeline. */
export function createUpdater(p) {
  const { store } = p;
  const lastCheck = new Map();
  const soonSet = new Set();
  const forced = new Set();
  const approved = new Set();
  const working = new Set();
  const all = () => store.crew("updates", {});
  const save = (projectId, next) => store.setCrew("updates", { ...all(), [projectId]: next });

  /** What runs in the project's own folder now: a landing, a task without a worktree whose turn runs. */
  function busyIn(projectId) {
    for (const [, t] of store.entries()) {
      if (t.projectId !== projectId) continue;
      if (t.landing) return `#${t.number} is landing`;
      if (t.noWorktree && t.threadId && !t.settledAt && ["starting", "running", "waiting"].includes(t.thread?.status)) return `#${t.number} works in it`;
    }
    return p.lander.busy() ? "landing checks run" : null;
  }

  async function check(projectId) {
    const settings = store.project(projectId);
    const repo = p.projectInfo(projectId)?.path;
    if (!repo) return;
    const prev = all()[projectId] ?? {};
    const base = settings.baseBranch;
    let target;
    let targetName;
    if (remoteLanding(settings)) {
      target = await fetchBase(repo, settings.remote, base);
      targetName = `${settings.remote}/${base}`;
    } else {
      target = await revParse(repo, `refs/heads/${base}`);
      targetName = base;
    }
    if (!target) throw new Error(`There is no ${targetName}`);
    const head = await headOf(repo);
    const branch = (await currentBranch(repo)) ?? "(detached)";
    const { behind, ahead } = await behindAhead(repo, target);
    const clean = await trackedClean(repo);
    const facts = { base, branch, head, target, targetName, behind, ahead, clean, busy: busyIn(projectId), doneOn: prev.doneOn, failedOn: prev.failedOn, forced: forced.has(projectId), approve: settings.updateApprove, approved: approved.has(projectId) };
    const decision = decideUpdate(facts);
    const headTitle = (await git(repo, "log", "-1", "--format=%s", head).catch(() => "")).trim();
    const common = { head, headTitle, behind, base, doneOn: prev.doneOn ?? (behind === 0 ? head : undefined), failedOn: prev.failedOn, last: prev.last, checkedAt: nowIso() };
    switch (decision.kind) {
      case "current":
        return save(projectId, { ...common, status: "current", detail: "Up to date" });
      case "failed":
        return save(projectId, { ...common, status: "failed", detail: prev.detail ?? "The update failed on this commit", output: prev.output });
      case "wait":
        return save(projectId, { ...common, status: "waiting", detail: decision.why, needsYou: decision.you });
      case "ready":
        return save(projectId, { ...common, status: "waiting", ready: true, detail: behind ? `${plural(behind, "new commit")}: waits for Update now` : "Waits for Update now" });
      case "update":
        return update(projectId, repo, settings, facts, decision.goal, common);
    }
  }

  async function update(projectId, repo, settings, facts, goal, common) {
    forced.delete(projectId);
    approved.delete(projectId);
    working.add(projectId);
    save(projectId, { ...common, status: "running", detail: facts.behind ? `Bringing it to ${goal.slice(0, 8)}` : "Running the update command" });
    try {
      if (facts.behind > 0) await git(repo, "merge", "--ff-only", "--no-edit", goal);
      const command = settings.updateCommand.trim();
      if (command) {
        const env = { LAYR_COMMIT: goal, LAYR_FROM: facts.head, LAYR_BASE: settings.baseBranch };
        const result = await runUpdateScript(command, repo, settings.updateTimeoutMin * 60_000, env);
        if (!result.ok) {
          save(projectId, { ...common, head: goal, status: "failed", failedOn: goal, detail: "The update command failed", output: result.output, last: { at: nowIso(), commit: goal, ok: false } });
          p.hub.notify(`Keep up to date failed in ${p.projectInfo(projectId)?.name ?? projectId}: ${snippet(result.output, 120)}`, "error");
          return;
        }
      }
      save(projectId, { ...common, head: goal, behind: 0, status: "current", detail: "Up to date", doneOn: goal, failedOn: undefined, last: { at: nowIso(), commit: goal, ok: true } });
    } catch (error) {
      save(projectId, { ...common, status: "failed", failedOn: goal, detail: "Bringing it up to date failed", output: snippet(errorText(error), 2000), last: { at: nowIso(), commit: goal, ok: false } });
    } finally {
      working.delete(projectId);
    }
  }

  /** Once a look: projects due (every CHECK_MS, or soon after a landing or Update now). */
  async function tick(now = Date.now()) {
    for (const projectId of Object.keys(store.settings.projects)) {
      const settings = store.project(projectId);
      if (!settings.updateMain) {
        if (all()[projectId]) store.setCrew("updates", Object.fromEntries(Object.entries(all()).filter(([k]) => k !== projectId)));
        continue;
      }
      if (working.has(projectId)) continue;
      const due = soonSet.has(projectId) || forced.has(projectId) || approved.has(projectId) || now - (lastCheck.get(projectId) ?? 0) > CHECK_MS;
      if (!due) continue;
      soonSet.delete(projectId);
      lastCheck.set(projectId, now);
      await check(projectId).catch((error) => {
        save(projectId, { ...(all()[projectId] ?? {}), status: "failed", detail: `Couldn't look: ${snippet(errorText(error), 300)}`, checkedAt: nowIso() });
      });
    }
  }

  /** A task landed there: look soon. */
  function soon(projectId) {
    if (store.project(projectId).updateMain) {
      soonSet.add(projectId);
      p.wake(200);
    }
  }

  /** Update now: what waited for it goes (`approved`), or the whole update runs once possible (`forced`). */
  function now(projectId) {
    const settings = store.project(projectId);
    if (!settings.updateMain) throw new Error("Keep up to date is off in this project");
    if (all()[projectId]?.ready) approved.add(projectId);
    else forced.add(projectId);
    p.wake(50);
    return { projectId, queued: true };
  }

  return { tick, soon, now, all, check };
}
