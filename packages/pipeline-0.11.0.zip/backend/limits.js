// Usage limits: when a task's turn fails on the Claude account's usage limit, it waits for the limit's real reset
// time (as layr_code did), not a fixed back-off: from the error's own text (`…limit reached|1731000000`, `resets 4pm`,
// `try again in 20 minutes`), else from the claude plugin's `usage` (a rejection's end, or the window that is full),
// else `limitBackoffMin`. Waiting for a limit is no failed try: it never counts toward the tries a task stops after.
// While the gate is closed for a limit, the account is read now and then: room again (another account, or the window
// reset) opens it before that time. The last reading also goes to the orchestrator's look.
import { errorText } from "./util.js";

/** How often the account's usage is read while a limit holds the gate (the claude plugin caches it as long). */
export const READ_MS = 5 * 60_000;
/** After the reset time, a little more, so the first try doesn't meet the limit's last second. */
export const SLACK_MS = 60_000;
const WEEK_MS = 7 * 86_400_000;
const MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];

/**
 * When the limit an error names resets, from the error's text alone (ISO), or null. `now` decides what "resets 4pm"
 * means: the next 4 pm on the PC's clock.
 */
export function resetFromText(text, now = Date.now()) {
  const s = String(text ?? "");
  const epoch = /\|\s*(\d{10,13})\b/.exec(s);
  if (epoch) {
    const n = Number(epoch[1]);
    return new Date(n < 1e12 ? n * 1000 : n).toISOString();
  }
  const inMin = /try again in (\d+)\s*(minutes?|mins?|hours?|h)\b/i.exec(s);
  if (inMin) return new Date(now + Number(inMin[1]) * (/^h/i.test(inMin[2]) ? 3_600_000 : 60_000)).toISOString();
  const m = /resets?\s+(?:at\s+)?(?:([a-z]{3})[a-z]*\.?\s+(\d{1,2}),?\s+(?:at\s+)?)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i.exec(s);
  if (!m) return null;
  let hour = Number(m[3]);
  const minute = Number(m[4] ?? 0);
  const ampm = m[5]?.toLowerCase();
  if (!ampm && !m[4]) return null;
  if (ampm === "pm" && hour < 12) hour += 12;
  if (ampm === "am" && hour === 12) hour = 0;
  if (hour > 23 || minute > 59) return null;
  const at = new Date(now);
  at.setSeconds(0, 0);
  at.setHours(hour, minute);
  const month = m[1] ? MONTHS.indexOf(m[1].toLowerCase()) : -1;
  if (month >= 0) {
    at.setMonth(month, Number(m[2]));
    if (at.getTime() < now - 86_400_000) at.setFullYear(at.getFullYear() + 1);
  } else if (at.getTime() <= now) at.setDate(at.getDate() + 1);
  return at.toISOString();
}

/** When the account's limit resets, from a `usage` answer (ISO), or null: a rejection's end, else a full window's. */
export function resetFromUsage(usage, now = Date.now()) {
  const l = usage?.limits;
  if (!l) return null;
  const future = (iso) => !!iso && Date.parse(iso) > now;
  if (future(l.rejectedUntil)) return l.rejectedUntil;
  const full = [l.fiveHour, l.sevenDay].filter((w) => w && Number(w.utilization) >= 100 && future(w.resetsAt));
  if (!full.length) return null;
  return full.map((w) => w.resetsAt).sort((a, b) => Date.parse(b) - Date.parse(a))[0];
}

/** A reading of the claude plugin's `usage`: { account, fiveHour: {pct, resetsAt}, weekly, rejectedUntil, at }. */
export function readingOf(usage, at = new Date().toISOString()) {
  const l = usage?.limits;
  const w = (x) => (x && x.utilization !== null && x.utilization !== undefined ? { pct: Number(x.utilization), resetsAt: x.resetsAt ?? null } : null);
  const fiveHour = w(l?.fiveHour);
  const weekly = w(l?.sevenDay);
  if (!fiveHour && !weekly) return null;
  return { account: usage.account?.email ?? null, fiveHour, weekly, at: usage.updatedAt ?? at, rejectedUntil: l?.rejectedUntil ?? null };
}

const pctOf = (w, now) => (!w || w.pct === null || w.pct === undefined || (w.resetsAt && Date.parse(w.resetsAt) <= now) ? 0 : w.pct);

/** Limits on the PC. `p`: the pipeline. */
export function createLimits(p) {
  const { store } = p;
  let usage = store.crew("usage")?.answer ?? null;
  let readAt = 0;
  let reading_ = null;

  /** Read the account's usage (at most every READ_MS unless `force`); gives the last answer. */
  async function read(force = false) {
    if (reading_) return reading_;
    if (!force && Date.now() - readAt < READ_MS) return usage;
    readAt = Date.now();
    reading_ = (async () => {
      try {
        const next = await p.claude.usage();
        if (next?.limits) {
          usage = next;
          store.setCrew("usage", { answer: next });
        }
      } catch (error) {
        p.log("reading usage:", errorText(error));
      }
      return usage;
    })().finally(() => (reading_ = null));
    return reading_;
  }

  /** When a limit that failed a turn with `error` ends (ISO): the text's, the account's, or the back-off's. */
  async function resetAt(error, now = Date.now()) {
    const said = resetFromText(error, now) ?? resetFromUsage(await read(true), now);
    const until = said && Date.parse(said) > now ? Math.min(Date.parse(said) + SLACK_MS, now + WEEK_MS) : null;
    return new Date(until ?? now + store.global().limitBackoffMin * 60_000).toISOString();
  }

  /** After a usage limit: the account shows room again (switched accounts, or the window reset). */
  function limitOver(limitAt) {
    const r = readingOf(usage);
    if (!r || !limitAt || Date.parse(r.at) <= Date.parse(limitAt)) return false;
    const now = Date.now();
    const rejected = r.rejectedUntil && Date.parse(r.rejectedUntil) > now;
    return pctOf(r.fiveHour, now) < 100 && pctOf(r.weekly, now) < 100 && !rejected;
  }

  return { read, resetAt, limitOver, reading: () => readingOf(usage) };
}
