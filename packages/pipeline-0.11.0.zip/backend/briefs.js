// Briefs and stakes (ported from layr_code's shared/brief.ts and backend/briefs.ts). A small model (claude__ask, one
// turn without tools, haiku by default) writes a brief for each task that waits for you, and each proposal you didn't
// write: what it is, what it asks you, what a wrong answer costs, stakes 1-10. Written once, again when what it says
// changes (`briefKey`); `pipeline__brief` writes one now. The stakes come from what the reply says (its Risk line, how
// controversial its questions are, questions waiting, problems, the verifier, size), blended with the brief's guess.
// Decide sorts by them.
import { errorText, nowIso } from "./util.js";

const PER_TICK = 3;
const RETRY_MS = 60 * 60_000;

/** Whys that wait for you: a brief is written for them by itself. */
const STOPPED = new Set(["question", "finished", "failed", "interrupted", "note", "missing", "idle", "ready"]);
const PROBLEMS = new Set(["failed", "interrupted", "note", "missing"]);

/** A short stable hash of a text, to tell when it changed. */
export function hashText(text) {
  let h = 5381;
  for (let i = 0; i < text.length; i++) h = ((h << 5) + h + text.charCodeAt(i)) | 0;
  return (h >>> 0).toString(36);
}

/** What a brief is written for: a proposal's text, or a stopped task's latest reply and questions; null: none due. */
export function briefKey(task, why) {
  if (why === "proposal") return `p:${hashText(`${task.title}\n${task.prompt}`)}`;
  if (!STOPPED.has(why)) return null;
  const pending = (task.thread?.pending ?? []).map((p) => p.requestId).join(",");
  return `s:${hashText(`${task.thread?.lastMessage ?? ""}\n${pending}\n${task.stopNote ?? ""}`)}`;
}

/** Whether a brief is written by itself: for what waits for you, and proposals you didn't write. */
export function wantsBrief(task, why) {
  if (task.inBatch || task.source?.kind === "batch") return false;
  if (why === "proposal") return task.source?.kind !== "you" && !task.later;
  return STOPPED.has(why);
}

export function originText(task) {
  switch (task.source?.kind) {
    case "you":
      return "You made it";
    case "agent":
      return "An agent proposed it";
    case "scout":
      return "A scout proposed it";
    case "orchestrator":
      return "The orchestrator proposed it";
    case "adopted":
      return "A Claude thread you added to the pipeline";
    case "batch":
      return "A batch of small tasks";
    default:
      return "Unknown";
  }
}

export const BRIEF_SYSTEM =
  "You write a brief for a busy person deciding about a coding task in their own project. They may not have " +
  "proposed it and don't remember it. Write plain words, no jargon, no file paths unless they matter. Reply with " +
  'only one JSON object: {"what": string, "ask": string, "cost": string, "stakes": number}. `what`: what the task ' +
  "does or did, in one or two sentences. `ask`: what they must decide now (answer its questions, try and land its " +
  "result, run the proposal, look at a failure), in one sentence. `cost`: what goes wrong if they decide wrong, in " +
  "one sentence; say so when little is at stake. `stakes`: 1 to 10, how much the decision matters: 1-3 cosmetic or " +
  "easily undone, 4-6 a visible change or some lost work, 7-10 data, database, money, security or hard to undo.";

/** What the brief's writer reads. */
export function briefInput(task, why, project) {
  const cut = (text, max) => (text.length > max ? `${text.slice(0, max)}\n…(cut)` : text);
  const questions = (task.thread?.pending ?? []).flatMap((p) => p.questions ?? []).map((q) => {
    const options = (q.options ?? []).map((o) => o.label).join(" / ");
    return `- ${q.question}${options ? ` (${options})` : ""}`;
  });
  return [
    `Project: ${project}`,
    `Task #${task.number}: ${task.title}`,
    `Who made it: ${originText(task)}`,
    `Where it stands: ${why === "proposal" ? "a proposal, not started" : why}`,
    "",
    "Its description:",
    cut(task.prompt || "(none)", 4000),
    ...(task.stopNote ? ["", `Why layr stopped it: ${task.stopNote}`] : []),
    ...(task.verify?.report ? ["", `The verifier (${task.verify.state}):`, cut(task.verify.report, 1500)] : []),
    ...(task.thread?.lastMessage ? ["", "Its worker's last reply:", cut(task.thread.lastMessage, 8000)] : []),
    ...(questions.length ? ["", "Questions it waits on:", ...questions] : []),
  ].join("\n");
}

/** The first JSON object in a text (a ```json block, or the whole text), or null. */
export function jsonOf(text) {
  const s = String(text ?? "");
  const blocks = [...s.matchAll(/```(?:json)?\s*\n([\s\S]*?)\n```/g)].map((m) => m[1]);
  const braces = s.indexOf("{") >= 0 ? [s.slice(s.indexOf("{"), s.lastIndexOf("}") + 1)] : [];
  for (const candidate of [...blocks.reverse(), s, ...braces]) {
    try {
      const v = JSON.parse(candidate);
      if (v && typeof v === "object") return v;
    } catch {
      // not this one
    }
  }
  return null;
}

/** The model's answer as a brief, or null. */
export function briefOf(json, key, at = nowIso()) {
  const j = json;
  if (!j || typeof j.what !== "string" || typeof j.ask !== "string" || typeof j.cost !== "string") return null;
  const stakes = Math.min(10, Math.max(1, Math.round(Number(j.stakes) || 5)));
  return { what: j.what.trim(), ask: j.ask.trim(), cost: j.cost.trim(), stakes, key, at };
}

/** How controversial a reply's questions are, at most (`1. 7 🟠 Where…`, the user's question format); 0: unsaid. */
export function maxControversy(text) {
  let max = 0;
  for (const m of String(text ?? "").matchAll(/^\s*\d+\.\s+(?:☑️\s*)?(?:🚩\s*)?(\d{1,2})\s*(?:🔴|🟠|⚪)/gmu)) {
    max = Math.max(max, Math.min(10, Number(m[1])));
  }
  return max;
}

const RISK_WEIGHT = { database: 40, data: 40, security: 35, breaking: 30, usage: 10, ui: 8 };

/** How much the decision matters: { score 0-100, level, reasons }, for what waits for you; null for the rest. */
export function stakesOf(task, why) {
  if (!STOPPED.has(why) && why !== "proposal") return null;
  const thread = task.thread;
  const reasons = [];
  let score = 0;
  const add = (points, reason) => {
    score += points;
    reasons.push(reason);
  };
  const risks = new Set([...(thread?.replyStatus?.risks ?? []), ...(task.ask?.risks ?? [])]);
  if (task.ask?.paths?.length) risks.add("database");
  for (const risk of risks) if (RISK_WEIGHT[risk]) add(RISK_WEIGHT[risk], `Risk: ${risk}`);
  const controversy = maxControversy(thread?.lastMessage);
  if (controversy >= 5) add(controversy * 4, `A question rated ${controversy}/10`);
  else if (controversy) add(controversy * 2, `Questions rated up to ${controversy}/10`);
  if (thread?.pending?.length) add(15, "Its worker waits on a question");
  if (why === "question" && !thread?.pending?.length && !controversy) add(10, "It asks you something");
  if (PROBLEMS.has(why)) add(20, "Something went wrong");
  const status = thread?.replyStatus?.status;
  if (status === "blocked" || status === "partial") add(12, `Its worker says ${status}`);
  if (task.verify?.state === "you") add(15, "The verifier wants you to look");
  if (task.verify?.state === "passed" && why === "finished") {
    score -= 15;
    reasons.push("The verifier passed it");
  }
  if (why === "proposal") {
    if (task.size === "L") add(10, "A large task");
    if (task.source?.kind !== "you") add(5, "You didn't write it");
  }
  let total = Math.max(0, Math.min(100, score));
  if (task.brief) {
    total = Math.round(total * 0.6 + task.brief.stakes * 10 * 0.4);
    reasons.push(`The brief rates it ${task.brief.stakes}/10`);
  }
  return { score: total, level: total >= 50 ? "high" : total >= 25 ? "medium" : "low", reasons };
}

/** Briefs on the PC. `p`: the pipeline. */
export function createBriefs(p) {
  const { store } = p;
  let running = false;
  const failed = new Map();

  async function write(id) {
    const task = p.need(id);
    const { why } = p.placement(id, task);
    const key = briefKey(task, why) ?? `n:${task.updatedAt}`;
    const project = p.projectInfo(task.projectId)?.name ?? "a project";
    const answer = await p.claude.ask({ prompt: briefInput(task, why, project), system: BRIEF_SYSTEM, model: store.global().briefModel });
    const brief = briefOf(jsonOf(answer?.text), key);
    if (!brief) throw new Error("The brief didn't come back in shape");
    store.mutate(id, () => ({ brief }));
    return brief;
  }

  function due(now = Date.now()) {
    return store
      .entries()
      .filter(([id, task]) => {
        if (!store.project(task.projectId).enabled) return false;
        const { why } = p.placement(id, task);
        if (!wantsBrief(task, why)) return false;
        const key = briefKey(task, why);
        if (!key || task.brief?.key === key) return false;
        return now - (failed.get(key) ?? 0) > RETRY_MS;
      })
      .map(([id]) => id);
  }

  async function tick() {
    if (running || !store.global().briefs || store.global().mode === "stop") return;
    running = true;
    try {
      for (const id of due().slice(0, PER_TICK)) {
        const task = store.get(id);
        if (!task) continue;
        const key = briefKey(task, p.placement(id, task).why);
        await write(id).catch((error) => {
          if (key) failed.set(key, Date.now());
          p.log(`brief #${task.number}:`, errorText(error));
        });
      }
    } finally {
      running = false;
    }
  }

  return { tick, write, due };
}
