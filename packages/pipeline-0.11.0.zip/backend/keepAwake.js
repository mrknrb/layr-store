// Keep the PC awake while the pipeline has work (turns running, landings, messages waiting for a slot): the core's
// hub tool `layr__keep_awake {on, reason?}` (per plugin; the core keeps Windows awake while any plugin has it on).
// Told when it changes, and renewed every few minutes while on (the core's lease is 10 minutes). A core without the tool: it is left alone from then on, nothing else changes.
import { errorText } from "./util.js";

const REASON = "Pipeline work runs";
/** Renewed this often while on: the core drops an entry that isn't renewed within 10 minutes. */
const RENEW_MS = 4 * 60_000;

/** `p`: the pipeline (its hub and logger). */
export function createKeepAwake(p) {
  let on = false;
  let missing = false;
  let pending = null;
  let warned = false;
  let sentAt = 0;

  function set(want) {
    want = !!want;
    if (missing || !p.hub?.available || !p.hub.call) return;
    if (want === on && !(on && Date.now() - sentAt >= RENEW_MS)) return;
    on = want;
    sentAt = Date.now();
    pending = p.hub
      .call("layr__keep_awake", { on: want, ...(want ? { reason: REASON } : {}) })
      .then(() => (warned = false))
      .catch((error) => {
        const text = errorText(error);
        if (/unknown tool|not found|no tool|-32601|method not found/i.test(text)) {
          missing = true;
          p.log("keep awake: this core has no layr__keep_awake (the PC may sleep while work runs)");
        } else {
          // Tried again on the next look.
          on = !want;
          if (!warned) p.log("keep awake failed (further failures not logged):", text);
          warned = true;
        }
      });
  }

  return {
    set,
    get on() {
      return on;
    },
    get missing() {
      return missing;
    },
    /** The last call (tests). */
    idle: () => pending,
  };
}
