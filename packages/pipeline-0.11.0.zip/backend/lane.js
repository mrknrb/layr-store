// Wake-ups and the test lane (ported from layr_code's backend/wake.ts and backend/lane.ts).
//
// Wake-ups: a worker waiting for something outside it (CI, a deploy, a long build) ends its turn and asks layr with
// `pipeline__wake` to message it again later; when the time comes its note is held for its thread like any message,
// so the gate still decides when it goes. One per task; Stop drops it. Timers: the scheduler's looks (at least every
// 30 s while the backend runs; `autoStart` keeps it running without a panel).
//
// The test lane: something only one task may use at a time (a fixed port, a device, a shared database). A worker takes
// it with `pipeline__lane` when its work needs it and gives it back when done; layr frees it when its time is up or
// the worker's turn ends. Busy: with `wait` it joins the queue and ends its turn; once the lane is free layr keeps it
// for the first one waiting and holds a message for its thread. Hold lane (board) takes it for you.
import { isActive } from "./columns.js";
import { hasLane } from "./settings.js";
import { nowIso } from "./util.js";

export const WAKE_MAX_MIN = 24 * 60;
/** A turn that only just took the lane may still read as idle: its turn's end counts after this long. */
const GRACE_MS = 60_000;
/** How long the lane is kept for a woken worker, from when its message went, before it goes to the next one. */
export const RESERVE_MIN = 5;
const FREED = { taskId: null, since: undefined, until: undefined, offer: undefined };

const clock = (iso) => {
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
};
const minutesUntil = (iso, now) => (iso ? Math.max(0, (Date.parse(iso) - now) / 60_000) : 0);

// ---------------------------------------------------------------- wake-ups

/** The task's worker is woken in `inMinutes` with its `note` (replacing a wake-up it had). */
export function setWake(p, id, inMinutes, note) {
  const task = p.need(id);
  if (!task.threadId) throw new Error("Only a started task's worker can be woken");
  if (!(inMinutes >= 1 && inMinutes <= WAKE_MAX_MIN)) throw new Error(`inMinutes is 1 to ${WAKE_MAX_MIN}`);
  if (!String(note ?? "").trim()) throw new Error("The note is empty: say what to do when woken");
  const setAt = new Date();
  const at = new Date(setAt.getTime() + inMinutes * 60_000).toISOString();
  p.store.mutate(id, () => ({ wake: { at, note: String(note).trim(), setAt: setAt.toISOString() } }));
  p.wakeAt(at);
  return {
    at,
    note: `layr messages you at about ${clock(at)} (once a slot is free) with your note. End your turn now; don't wait in it.`,
  };
}

/** Wake-ups whose time has come: their note is held for the thread. Gone or settled tasks lose theirs. */
export function dueWakes(p, now = Date.now()) {
  for (const [id, task] of p.store.entries()) {
    if (!task.wake) continue;
    if (!task.threadId || task.settledAt || task.thread?.missing) {
      p.store.mutate(id, () => ({ wake: undefined }));
      continue;
    }
    if (Date.parse(task.wake.at) > now) continue;
    const text = `The wake-up you asked for at ${clock(task.wake.setAt)}: ${task.wake.note}`;
    p.store.mutate(id, (t) => ({ wake: undefined, held: [...(t.held ?? []), { kind: "message", text, at: nowIso() }] }));
  }
}

// ---------------------------------------------------------------- the lane

const lanes = (p) => p.store.crew("lanes", {});
export const laneOf = (p, projectId) => lanes(p)[projectId] ?? { taskId: null, queue: [] };

function setLane(p, projectId, patch) {
  const all = { ...lanes(p) };
  const next = { ...laneOf(p, projectId), ...patch };
  for (const [k, v] of Object.entries(next)) if (v === undefined) delete next[k];
  all[projectId] = next;
  p.store.setCrew("lanes", all);
}

/** Who has the lane besides `id`, in a few words, or null when it is free for it. */
function holderBesides(p, lane, id) {
  if (lane.you) return `the user holds it until ${clock(lane.you.until)}`;
  if (lane.taskId && lane.taskId !== id) {
    const number = p.store.get(lane.taskId)?.number ?? "?";
    if (lane.offer) return `it is kept for #${number}, which waited for it`;
    return `#${number} has it${lane.until ? ` until ${clock(lane.until)}` : ""}`;
  }
  const first = lane.queue?.[0];
  if (!lane.taskId && first && first !== id) return `#${p.store.get(first)?.number ?? "?"} waits for it first`;
  return null;
}

function waitMinutes(lane, ahead, timeoutMin, now) {
  const current = lane.you
    ? minutesUntil(lane.you.until, now) + (lane.taskId ? timeoutMin : 0)
    : lane.offer
      ? RESERVE_MIN + timeoutMin
      : minutesUntil(lane.until, now);
  return Math.ceil(current + ahead * timeoutMin);
}

/** The task takes its project's lane, or (busy, `wait`) joins its queue. */
export function takeLane(p, id, wait = false) {
  const task = p.need(id);
  const settings = p.store.project(task.projectId);
  if (!hasLane(settings)) throw new Error("This project has no test lane (Pipeline settings › Test lane)");
  if (task.noWorktree || !task.worktreePath) throw new Error(`#${task.number} has no worktree: the test lane is for trying a task's worktree`);
  const lane = laneOf(p, task.projectId);
  const busy = holderBesides(p, lane, id);
  const timeoutMin = settings.laneTimeoutMin;
  if (busy) {
    const queue = lane.queue ?? [];
    const at = queue.indexOf(id);
    const ahead = at >= 0 ? at : queue.length;
    const waitMin = waitMinutes(lane, ahead, timeoutMin, Date.now());
    if (!wait) {
      return {
        granted: false,
        busy,
        waitMin,
        note:
          `The test lane is busy (${busy}), for at most ~${waitMin} min. To wait for it, call pipeline__lane again ` +
          "with `wait: true` and end your turn: layr messages you when it is yours. Or carry on without it.",
      };
    }
    if (at < 0) setLane(p, task.projectId, { queue: [...queue, id] });
    return {
      granted: false,
      busy,
      waitMin,
      queued: ahead + 1,
      note:
        `You wait for the test lane, number ${ahead + 1} in its queue (at most ~${waitMin} min). End your turn now: ` +
        "layr messages you when it is yours, then take it with pipeline__lane. `release: true` leaves the queue.",
    };
  }
  let until = lane.taskId === id && !lane.offer ? lane.until : undefined;
  if (!until) {
    const at = new Date();
    until = new Date(at.getTime() + timeoutMin * 60_000).toISOString();
    setLane(p, task.projectId, { taskId: id, since: at.toISOString(), until, offer: undefined, queue: (lane.queue ?? []).filter((x) => x !== id) });
  }
  const steps = { setup: settings.laneSetup.trim(), run: settings.laneRun.trim(), e2e: settings.laneE2e.trim(), url: settings.laneUrl.trim() };
  return {
    granted: true,
    until,
    ...Object.fromEntries(Object.entries(steps).filter(([, v]) => v)),
    note:
      `The test lane is yours until ${clock(until)}: no other task uses it meanwhile. In your worktree, set up, start ` +
      "the app and test as the commands given say, and try your change as a user would. When you're done, stop what " +
      "you started (the app, watchers) and give it back with pipeline__lane `release: true`. When your turn ends or " +
      "the time is up, layr gives it to the next one.",
  };
}

/** The task gives the lane back, or leaves its queue; whether it had it or waited. */
export function releaseLane(p, id) {
  const task = p.store.get(id);
  if (!task) return false;
  const lane = laneOf(p, task.projectId);
  const queued = !!lane.queue?.includes(id);
  if (lane.taskId !== id && !queued) return false;
  setLane(p, task.projectId, { ...(lane.taskId === id ? FREED : {}), ...(queued ? { queue: lane.queue.filter((x) => x !== id) } : {}) });
  offerNext(p, task.projectId);
  return true;
}

/** Hold lane: you take it (workers wait) for at most laneHoldMaxMin, or give it back (`release`). */
export function holdLane(p, projectId, release = false) {
  const settings = p.store.project(projectId);
  if (!hasLane(settings)) throw new Error("This project has no test lane");
  if (release) {
    setLane(p, projectId, { you: undefined });
    offerNext(p, projectId);
  } else {
    const until = new Date(Date.now() + settings.laneHoldMaxMin * 60_000).toISOString();
    setLane(p, projectId, { you: { since: nowIso(), until } });
  }
  return laneOf(p, projectId);
}

const offerMessage = (number) =>
  `The test lane is free and kept for you, since you waited for it. Take it with pipeline__lane (task #${number}) ` +
  `within ${RESERVE_MIN} minutes, or it goes to the next one; then go on with what you needed it for. If you no ` +
  "longer need it, give it back with `release: true`.";

/** A free lane goes to the first task waiting: kept for it, and its thread is messaged (through the gate). */
function offerNext(p, projectId) {
  const lane = laneOf(p, projectId);
  if (lane.taskId || lane.you || !lane.queue?.length) return;
  const [first, ...rest] = lane.queue;
  const task = p.store.get(first);
  if (!task) return setLane(p, projectId, { queue: rest });
  const at = nowIso();
  p.store.mutate(first, (t) => ({ held: [...(t.held ?? []), { kind: "message", text: offerMessage(t.number), at }] }));
  setLane(p, projectId, { taskId: first, since: at, until: undefined, offer: { at }, queue: rest });
}

/** Lanes whose time is up, whose holder's turn ended or is gone, offers not taken, holds run out: free again. */
export function freeLanes(p, now = Date.now()) {
  for (const projectId of Object.keys(lanes(p))) {
    const lane = laneOf(p, projectId);
    const gone = (id) => {
      const t = p.store.get(id);
      return !t || !t.threadId || t.settledAt || t.thread?.missing;
    };
    const queue = lane.queue?.filter((id) => !gone(id) && id !== lane.taskId);
    if (queue && queue.length !== lane.queue.length) setLane(p, projectId, { queue });
    let holderGone = false;
    if (lane.taskId && gone(lane.taskId)) holderGone = true;
    else if (lane.taskId && lane.offer) {
      const waiting = p.store.get(lane.taskId)?.held?.some((m) => m.kind === "message" && m.at === lane.offer.at);
      if (!waiting && !lane.offer.sentAt) setLane(p, projectId, { offer: { ...lane.offer, sentAt: new Date(now).toISOString() } });
      else if (!waiting && now - Date.parse(lane.offer.sentAt) > RESERVE_MIN * 60_000) holderGone = true;
    } else if (lane.taskId) {
      const task = p.store.get(lane.taskId);
      const past = now - Date.parse(lane.since ?? 0) > GRACE_MS;
      holderGone = (!!lane.until && Date.parse(lane.until) <= now) || (past && !isActive(task.thread));
    }
    const holdOver = !!lane.you && Date.parse(lane.you.until) <= now;
    if (holderGone || holdOver) setLane(p, projectId, { ...(holderGone ? FREED : {}), ...(holdOver ? { you: undefined } : {}) });
    offerNext(p, projectId);
  }
}

/** The task waits in a lane's queue (it doesn't auto-merge meanwhile). */
export const waitsForLane = (p, id, task) => !!laneOf(p, task.projectId).queue?.includes(id);
