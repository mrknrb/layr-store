// Landing a task on its base branch: the thread rebases and squashes, layr checks the worktree with plain git, runs
// the project's checks, then moves the base branch to exactly the checked commit, only forward: in the repository on
// the PC (`local`), and first on the remote for `push` landing (never forced). `pr` landing pushes the checked commit
// to the task's branch, opens its pull request with gh and merges it once CI is green (pr.js). Anything not right goes
// back to the same thread (a round); after MAX_ROUNDS the task stops with a note.
import { existsSync } from "node:fs";
import { inBackground, isActive, isStarting, waitsForAnswer } from "./columns.js";
import {
  commitMessage,
  commitsAhead,
  deleteRemoteBranch,
  fastForwardBase,
  fetchBase,
  headOf,
  isAncestor,
  pushBranch,
  pushToBase,
  runChecks,
  uncommitted,
} from "./git.js";
import { createPr, findPr, mergePr, PR_POLL_MS, prVerdict, viewPr } from "./pr.js";
import {
  baseMovedMessage,
  baseRef,
  checksFailedMessage,
  landMessage,
  notReadyMessage,
  prChecksFailedMessage,
  prRebaseMessage,
  remoteLanding,
} from "./prompts.js";
import { errorText, nowIso, snippet } from "./util.js";

export const MAX_ROUNDS = 3;

export function createLander(p) {
  /** Tasks whose checks run right now, and landed tasks whose After landing command runs. */
  const checking = new Set();
  const delivering = new Set();
  /** When each landing's pull request was last read. */
  const polled = new Map();

  const patchLanding = (id, patch) => p.store.mutate(id, (t) => (t.landing ? { landing: { ...t.landing, ...patch } } : null));
  const stop = (id, note) => p.store.mutate(id, () => ({ landing: undefined, stopNote: note }));

  /** Whether the worktree can land as it is: clean, on the newest base, (one commit with squash). */
  async function readyToLand(id) {
    const task = p.store.get(id);
    const dir = task?.worktreePath;
    if (!task || !dir) return { ok: false, problem: "its worktree isn't known" };
    if (!existsSync(dir)) return { ok: false, problem: "its worktree was removed: send its thread a message to make it again" };
    const settings = p.store.project(task.projectId);
    if (remoteLanding(settings)) await fetchBase(p.repoOf(task.projectId), settings.remote, settings.baseBranch);
    const ref = baseRef(settings);
    const dirty = await uncommitted(dir);
    if (dirty.length) {
      const shown = dirty.slice(0, 5).join(", ") + (dirty.length > 5 ? ", …" : "");
      return { ok: false, dirty: true, problem: `the worktree has uncommitted changes (${shown})` };
    }
    const ahead = await commitsAhead(dir, ref);
    if (ahead === 0) return { ok: false, nothing: true, problem: `the branch has no commits beyond ${ref}` };
    if (!(await isAncestor(dir, ref, "HEAD"))) return { ok: false, problem: `the branch isn't on the newest ${ref}` };
    if (settings.squash && ahead > 1) return { ok: false, problem: `${ahead} commits on top of ${ref}; squash them into one` };
    return { ok: true, head: await headOf(dir) };
  }

  /** Land pressed (its held `land` reached the gate): straight to the checks when ready, else the thread rebases. */
  async function begin(id) {
    const task = p.store.get(id);
    if (!task?.threadId || !task.worktreePath || task.noWorktree) {
      p.store.mutate(id, () => ({ stopNote: "Nothing to land: the task has no worktree of its own" }));
      return;
    }
    const at = nowIso();
    const ready = await readyToLand(id);
    if (ready.ok) {
      p.store.mutate(id, () => ({ stopNote: undefined, landing: { phase: "checks", rounds: 0, sentAt: at, since: at } }));
      return;
    }
    if (ready.nothing) return settleEmpty(id, ready.problem);
    const settings = p.store.project(task.projectId);
    await p.claude.send(task.threadId, landMessage(settings));
    p.store.mutate(id, () => ({
      stopNote: undefined,
      sentAt: at,
      landing: { phase: "rebase", rounds: 0, sentAt: at, since: at },
    }));
  }

  /** Its branch has no commits beyond the base (a plan, research, work already there): a normal finish. */
  async function settleEmpty(id, problem) {
    p.store.mutate(id, () => ({ landing: undefined, stopNote: undefined }));
    p.settle(id);
    p.log(`#${id}: nothing to land (${problem}), settled`);
  }

  /** Send the thread something to fix, or stop when it had its rounds. */
  async function round(id, message, problem) {
    const task = p.store.get(id);
    if (!task?.landing || !task.threadId) return;
    if (task.landing.rounds >= MAX_ROUNDS) return stop(id, `Landing stopped after ${MAX_ROUNDS} rounds: ${problem}`);
    await p.claude.send(task.threadId, message);
    const at = nowIso();
    p.store.mutate(id, (t) =>
      t.landing
        ? { sentAt: at, landing: { ...t.landing, phase: "rebase", rounds: t.landing.rounds + 1, sentAt: at, head: undefined, waits: undefined, problem } }
        : null,
    );
  }

  async function landed(id, head, pr) {
    const task = p.store.get(id);
    polled.delete(id);
    const landedAt = { commit: head, at: nowIso(), head: task.landing?.head ?? head, ...(pr ? { pr } : {}) };
    p.store.mutate(id, () => ({ landing: undefined, landed: landedAt, stopNote: undefined }));
    if (task.batch) p.batchLanded(id);
    // A pull request's branch was only for it: it goes on the remote once merged (the local one goes at cleanup).
    const branch = task.branch ?? task.thread?.branch;
    if (pr && branch) {
      const settings = p.store.project(task.projectId);
      await deleteRemoteBranch(p.repoOf(task.projectId), settings.remote, branch).catch((error) =>
        p.log(`#${id}: couldn't delete ${branch} on ${settings.remote}:`, errorText(error)),
      );
    }
    p.hub.notify(`Landed #${task.number} ${task.title}${pr ? ` (pull request #${pr.number})` : ""}`, "success");
    afterLanding(id, head);
    p.updater?.soon(task.projectId);
  }

  /** `pr`: push the checked commit to the task's branch and open its pull request (or reuse the open one). */
  async function openPr(id, task, landing, head) {
    const settings = p.store.project(task.projectId);
    const branch = task.branch ?? task.thread?.branch;
    if (!branch) return stop(id, "Landing stopped: the task has no branch to open a pull request from");
    const repo = p.repoOf(task.projectId);
    await pushBranch(task.worktreePath, settings.remote, branch, head);
    let pr = landing.pr ?? (await findPr(repo, branch));
    if (!pr) {
      const message = await commitMessage(task.worktreePath, head);
      const footer = `Task #${task.number} of the layr pipeline. layr merges this pull request once CI is green.`;
      pr = await createPr(repo, {
        base: settings.baseBranch,
        branch,
        title: message.subject || task.title,
        body: [message.body, "---", footer].filter(Boolean).join("\n\n"),
      });
    }
    polled.delete(id);
    patchLanding(id, { phase: "pr", head, pr: { number: pr.number, url: pr.url, pushedAt: nowIso() }, waits: "waits for CI to start", since: nowIso() });
  }

  /** `pr`: read the pull request now and then; merge it when it's green, send failures back to the thread. */
  async function pullRequest(id, task, landing) {
    const pr = landing.pr;
    if (!pr || !landing.head) return patchLanding(id, { phase: "checks", since: nowIso() });
    if (Date.now() - (polled.get(id) ?? 0) < (p.prPollMs ?? PR_POLL_MS)) return;
    polled.set(id, Date.now());
    const settings = p.store.project(task.projectId);
    const repo = p.repoOf(task.projectId);
    const verdict = prVerdict(await viewPr(repo, pr.number), landing.head, pr.pushedAt);
    switch (verdict.kind) {
      case "merged": {
        // The repository on the PC follows: fetch the base and fast-forward it (only forward, as local landing).
        const fetched = await fetchBase(repo, settings.remote, settings.baseBranch).catch(() => null);
        if (fetched) {
          const local = await fastForwardBase(repo, settings.baseBranch, fetched);
          if (!local.ok) p.log(`#${id} landed through #${pr.number}; the local ${settings.baseBranch} stays: ${local.message}`);
        }
        return landed(id, verdict.commit, { number: pr.number, url: pr.url });
      }
      case "closed":
        return stop(id, `Landing stopped: pull request #${pr.number} was closed`);
      case "foreign":
        return stop(id, `Landing stopped: pull request #${pr.number} has a commit layr didn't check (${verdict.head.slice(0, 8)})`);
      case "failed":
        return round(id, prChecksFailedMessage(pr, verdict.checks), `CI fails on pull request #${pr.number}`);
      case "rebase":
        return round(id, prRebaseMessage(verdict.why, settings), verdict.why);
      case "changes":
        return stop(id, `Changes were requested on pull request #${pr.number}: tell the thread what to do, then Land again`);
      case "wait":
        if (landing.waits !== verdict.why) patchLanding(id, { waits: verdict.why });
        return;
      case "ready":
        try {
          await mergePr(repo, pr.number, landing.head, settings.squash);
          polled.delete(id);
          p.wake();
        } catch (error) {
          patchLanding(id, { waits: `GitHub refused the merge: ${snippet(errorText(error), 160)}` });
        }
        return;
    }
  }

  /** The project's After landing command, in the worktree, in the background. */
  function afterLanding(id, commit) {
    const task = p.store.get(id);
    const settings = p.store.project(task.projectId);
    const command = settings.afterLanding.trim();
    if (!command || !task.worktreePath) return;
    delivering.add(id);
    p.store.mutate(id, () => ({ afterLanding: { state: "running", at: nowIso() } }));
    const env = { LAYR_TASK: String(task.number), LAYR_COMMIT: commit, LAYR_BASE: settings.baseBranch };
    void runChecks(command, task.worktreePath, settings.afterLandingTimeoutMin * 60_000, env)
      .then((result) =>
        p.store.mutate(id, () =>
          result.ok
            ? { afterLanding: { state: "done", at: nowIso() } }
            : {
                afterLanding: { state: "failed", at: nowIso(), output: result.output },
                stopNote: `After landing failed (\`${command}\`): ${snippet(result.output, 200)}`,
              },
        ),
      )
      .catch((error) => p.log(`after landing of #${id}:`, errorText(error)))
      .finally(() => {
        delivering.delete(id);
        p.wake();
      });
  }

  const stillAtIt = (task) =>
    isActive(task.thread) ||
    inBackground(task.thread) ||
    waitsForAnswer(task.thread) ||
    isStarting(task, task.thread) ||
    !!task.held?.some((m) => m.kind === "continue");

  /** Why the turn layr asked for didn't end well, if it didn't. */
  function endedBadly(task) {
    const t = task.thread;
    if (!t?.turnEndedAt || Date.parse(t.turnEndedAt) < Date.parse(task.landing.sentAt) - 2_000) return null;
    if (t.turnStatus === "interrupted") return "the thread was interrupted";
    if (t.turnStatus === "failed") return `the thread failed${t.lastError ? `: ${snippet(t.lastError, 200)}` : ""}`;
    return null;
  }

  async function advance(id) {
    const task = p.store.get(id);
    const landing = task?.landing;
    if (!task || !landing || checking.has(id)) return;
    if (!task.threadId || task.thread?.missing) return stop(id, "Landing stopped: the thread is gone");
    const settings = p.store.project(task.projectId);

    if (landing.phase === "rebase") {
      if (stillAtIt(task)) return;
      // The turn's end must have been seen (the thread read after it), so a reading from before doesn't count.
      if (!task.thread?.turnEndedAt || Date.parse(task.thread.turnEndedAt) < Date.parse(landing.sentAt) - 2_000) return;
      const bad = endedBadly(task);
      if (bad) return stop(id, `Landing stopped: ${bad}`);
      const ready = await readyToLand(id);
      if (ready.ok) patchLanding(id, { phase: "checks", since: nowIso() });
      else if (ready.nothing) await settleEmpty(id, ready.problem);
      else await round(id, notReadyMessage(ready.problem, settings), ready.problem);
      return;
    }

    if (landing.phase === "checks") {
      const dir = task.worktreePath;
      const head = await headOf(dir);
      const command = settings.checks.trim();
      if (!command) {
        patchLanding(id, { phase: "push", head, since: nowIso() });
        return advance(id);
      }
      checking.add(id);
      void runChecks(command, dir, settings.checksTimeoutMin * 60_000)
        .then(async (result) => {
          checking.delete(id);
          if (result.ok) patchLanding(id, { phase: "push", head, since: nowIso() });
          else await round(id, checksFailedMessage(command, result.output), "the checks fail");
        })
        .catch((error) => stop(id, `Landing stopped: ${errorText(error)}`))
        .finally(() => {
          checking.delete(id);
          p.wake();
        });
      return;
    }

    if (landing.phase === "pr") return pullRequest(id, task, landing);

    // push: exactly the commit the checks ran on.
    const dir = task.worktreePath;
    const head = landing.head ?? (await headOf(dir));
    if ((await headOf(dir)) !== head) return patchLanding(id, { phase: "checks", since: nowIso() });
    if (settings.landing === "pr") return openPr(id, task, landing, head);
    const repo = p.repoOf(task.projectId);
    if (settings.landing === "push") {
      const pushed = await pushToBase(dir, settings.remote, settings.baseBranch, head);
      if (!pushed.ok) {
        if (pushed.moved) return round(id, baseMovedMessage(settings), `${settings.baseBranch} moved on`);
        return stop(id, `Landing stopped: ${snippet(pushed.message, 300)}`);
      }
      const local = await fastForwardBase(repo, settings.baseBranch, head);
      if (!local.ok) p.log(`#${id} landed on ${settings.remote}; the local ${settings.baseBranch} stays: ${local.message}`);
      return landed(id, head);
    }
    const moved = await fastForwardBase(repo, settings.baseBranch, head);
    if (moved.ok) return landed(id, head);
    if (moved.moved) return round(id, baseMovedMessage(settings), `${settings.baseBranch} moved on`);
    return stop(id, `Landing stopped: ${snippet(moved.message, 300)}`);
  }

  return {
    begin,
    advance,
    readyToLand,
    busy: () => checking.size > 0 || delivering.size > 0,
    afterLandingRuns: (id) => delivering.has(id),
  };
}
