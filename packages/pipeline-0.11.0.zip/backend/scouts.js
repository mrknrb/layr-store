// Scouts (ported from layr_code's shared/scouts.ts and backend/scouts.ts). A scout looks for ideas with evidence in
// one area per run and files them: as proposals on the board (`pipeline__propose`, source scout), or into the
// project's Features on the concept map (`concepts__file`) when the project names a node (`scoutFeatures`). The code
// scout reads the repository; the friction scout reads where the pipeline got stuck lately (stop notes, verifier
// reports, landing rounds) and the code behind it. Each runs as a claude plugin thread in the project's folder, in
// `dontAsk` mode with only reading and filing tools allowed. The global Scouts setting says whether they run: off, ask
// (when you or the orchestrator send one), auto (also by themselves while you're Away and nothing runs, one per
// project, resting while too much waits for you). Up to Scouts at once run together; more wait in a queue.
// (layr_code's app scout clicked through the running app with T3 Code's preview tools; the claude plugin has none,
// so it isn't ported.)
import { randomUUID } from "node:crypto";
import { isActive } from "./columns.js";
import { jsonOf } from "./briefs.js";
import { errorText, nowIso, snippet } from "./util.js";

export const SCOUT_KINDS = ["code", "friction"];
export const SCOUT_LABEL = { code: "Code scout", friction: "Friction scout" };
/** Automatic scouts rest while more than this waits for you in Decide… */
export const FLOOD_IDEAS = 15;
/** …or the oldest has waited this long. */
export const FLOOD_DAYS = 2;
export const RUNS_KEPT = 40;
export const QUEUE_MAX = 20;
const FRICTION_DAYS = 14;
const FILED_TITLES_KEPT = 5;

/** What a scout's thread may use without asking (dontAsk denies the rest): read, and file. */
export const SCOUT_TOOLS = [
  "Read",
  "Grep",
  "Glob",
  "mcp__layr__pipeline__guide",
  "mcp__layr__pipeline__tasks",
  "mcp__layr__pipeline__task",
  "mcp__layr__pipeline__propose",
  "mcp__layr__concepts__guide",
  "mcp__layr__concepts__search",
  "mcp__layr__concepts__read",
  "mcp__layr__concepts__project",
  "mcp__layr__concepts__file",
  "mcp__layr__concepts__add",
];

export const runningScouts = (state) => (state.active ?? []).filter((a) => !a.waiting);
export const waitingScouts = (state) => (state.active ?? []).filter((a) => a.waiting);
const sameFocus = (a, b) => (a ?? "").trim().toLowerCase() === (b ?? "").trim().toLowerCase();

/** Why automatic scouts rest now, or null. `waiting`: [{at}] of what waits for you. */
export function floodReason(waiting, now = Date.now()) {
  if (waiting.length > FLOOD_IDEAS) return `${waiting.length} things wait for you in Decide`;
  const oldest = Math.min(...waiting.map((w) => Date.parse(w.at)).filter((t) => !Number.isNaN(t)));
  if (Number.isFinite(oldest) && now - oldest > FLOOD_DAYS * 86_400_000) {
    return `the oldest thing in Decide has waited more than ${FLOOD_DAYS} days`;
  }
  return null;
}

/** The kind to run next in a project: the one that ran longest ago. */
export function nextKind(runs, projectId) {
  const last = (kind) => Math.max(0, ...runs.filter((r) => r.projectId === projectId && r.kind === kind).map((r) => Date.parse(r.at)));
  return [...SCOUT_KINDS].sort((a, b) => last(a) - last(b))[0];
}

/** Areas this kind of scout looked at lately in the project, newest first. */
export const recentAreas = (runs, projectId, kind) =>
  [...new Set([...runs].reverse().filter((r) => r.projectId === projectId && r.kind === kind && r.area).map((r) => r.area))].slice(0, 8);

/** Where the pipeline got stuck lately: what the friction scout reads. */
export function frictionNotes(entries, since) {
  const lines = [];
  for (const [, t] of entries) {
    if (Date.parse(t.updatedAt) < since) continue;
    const head = `#${t.number} ${t.title}`;
    if (t.stopNote) lines.push(`- ${head}: stopped: ${t.stopNote.slice(0, 300)}`);
    if (t.verify?.state === "you" || (t.verify?.rounds ?? 0) > 0) {
      lines.push(`- ${head}: the verifier sent ${t.verify.rounds ?? 0} fix rounds: ${(t.verify.report ?? "").slice(0, 400)}`);
    }
    if ((t.landing?.rounds ?? 0) > 1) lines.push(`- ${head}: landing took ${t.landing.rounds} rounds`);
    if ((t.resumes ?? 0) > 1) lines.push(`- ${head}: resumed ${t.resumes} times after limits or network errors`);
    if (t.ask) lines.push(`- ${head}: waited for the user: ${[...(t.ask.paths ?? []), ...(t.ask.risks ?? [])].join(", ")}`);
  }
  return lines.join("\n").slice(0, 8000);
}

/** The scout's instructions: where to look, how to file, the limits, and the closing JSON. */
export function scoutPrompt(kind, { projectId, projectName, features, areasDone = [], friction, focus, area }) {
  const where = {
    code:
      "Read the repository (read-only, with Read, Grep and Glob) in one area, and look for bugs, fragile code, " +
      "missing tests where a bug would hurt, and small improvements users would notice. Evidence is file:line.",
    friction:
      "Read where the pipeline got stuck lately (below) and the code behind it, and look for what would make the " +
      "work flow better: a rule workers keep missing, a check that fails often, a step that keeps waiting. Evidence " +
      "is the tasks it happened in.",
  }[kind];
  const file = features
    ? "File every finding worth the user's time, as many as there are, each with the layr tool concepts__file " +
      `(features: "${features}", source: "Scout", its area, kind bug or idea, a one-sentence description and the ` +
      "evidence). Search first (concepts__search): what is already there gets your evidence added (concepts__add) " +
      "instead of a second node."
    : "File every finding worth the user's time, as many as there are, each as a proposal with the layr tool " +
      `pipeline__propose (projectId: "${projectId}", a short imperative title, a description with what, why and the ` +
      "evidence, and its size S, M or L; small unrelated ones with `batch: true`). Look at the proposals waiting " +
      "first (pipeline__tasks, column proposed): don't propose what is there; the first propose call shows likely " +
      "duplicates, call again with confirm: true only for what is new.";
  return [
    `You are a ${SCOUT_LABEL[kind].toLowerCase()} for the project ${projectName}: you look for ideas, you change nothing.`,
    where,
    ...(focus?.trim() ? [`Look for this in particular: ${focus.trim()}`] : []),
    area?.trim()
      ? `Look in this area: ${area.trim()}.`
      : "Pick one area of the code" +
        (focus?.trim() ? " where that is most likely" : "") +
        (areasDone.length ? `, not one of these, looked at lately: ${areasDone.join(", ")}` : "") +
        ".",
    file,
    "Nothing worth filing is a fine result. Don't change, commit or push any file, don't run commands, and don't " +
      "touch production data (those tools are not allowed here anyway).",
    'End your reply with your report for the user (what you looked at, and each idea you filed with one line on why ' +
      'it is worth their time), then one ```json block: {"area": "the area you looked at", "summary": "one line on ' +
      'what you found", "filed": number of ideas you filed}.',
    ...(friction ? ["", "Where the pipeline got stuck lately:", "", friction] : []),
  ].join("\n");
}

/** Scouts for the orchestrator: running, waiting, and the last week's runs, newest first. */
export function scoutLines(state, title, now = Date.now(), days = 7) {
  const what = (s) => `${SCOUT_LABEL[s.kind] ?? s.kind} in ${title(s.projectId)}${s.area ? `, area ${s.area}` : ""}${s.focus ? `, looking for "${snippet(s.focus, 120)}"` : ""}`;
  const active = (state.active ?? []).map((a) => `- ${what(a)}: ${a.waiting ? "waiting for room" : "running"}`);
  const since = now - days * 86_400_000;
  const runs = [...(state.runs ?? [])]
    .reverse()
    .filter((r) => Date.parse(r.at) >= since && !r.error?.startsWith("Rested"))
    .map((r) => `- ${what(r)} (${r.at.slice(0, 10)}): ${r.error ? `failed: ${snippet(r.error, 100)}` : `${r.filed} filed${r.summary ? `, ${snippet(r.summary, 120)}` : ""}`}`);
  return [...active, ...runs];
}

/** Scouts on the PC. `p`: the pipeline. */
export function createScouts(p) {
  const { store } = p;
  let pumping = false;
  const state = () => store.crew("scouts", { runs: [], active: [] });
  const active = () => state().active ?? [];
  const save = (next) => store.setCrew("scouts", next);
  const update = (id, patch) => save({ ...state(), active: active().map((a) => (a.id === id ? { ...a, ...patch } : a)) });
  const runOf = (a, rest) => ({
    projectId: a.projectId,
    kind: a.kind,
    at: a.since,
    filed: a.filed ?? 0,
    summary: "",
    ...(a.focus ? { focus: a.focus } : {}),
    ...(a.area ? { area: a.area } : {}),
    ...(a.threadId ? { threadId: a.threadId } : {}),
    ...rest,
  });

  /** A scout leaves the list, its run is kept, and the next in the queue may start. */
  function end(id, run) {
    const s = state();
    save({ runs: run ? [...(s.runs ?? []), run].slice(-RUNS_KEPT) : s.runs ?? [], active: active().filter((a) => a.id !== id) });
    void pump().catch((error) => p.log("scouts:", errorText(error)));
  }

  /** What waits for you in Decide, for flood control: stopped tasks and proposals you didn't write. */
  function waiting() {
    const out = [];
    for (const [id, t] of store.entries()) {
      if (t.later || t.inBatch || t.hidden) continue;
      const { column, why } = p.placement(id, t);
      if (column === "stopped" && why !== "landed") out.push({ at: t.thread?.turnEndedAt ?? t.updatedAt });
      else if (column === "proposed" && why === "proposal" && t.source?.kind !== "you") out.push({ at: t.createdAt });
    }
    return out;
  }

  function check(projectId, kind) {
    if (store.global().scouts === "off") throw new Error("Scouts are off (Pipeline settings › Global › Scouts)");
    if (!p.projectInfo(projectId) || !store.projectSaved(projectId)) throw new Error(`There is no pipeline project ${projectId}`);
    if (!store.project(projectId).enabled) throw new Error("Its project isn't enabled in Pipeline settings");
    const chosen = kind ?? nextKind(state().runs ?? [], projectId);
    if (!SCOUT_KINDS.includes(chosen)) throw new Error(`A scout is one of ${SCOUT_KINDS.join(", ")} (the app scout isn't ported)`);
    return chosen;
  }

  /**
   * Send a scout: it starts now when fewer than Scouts at once run, else waits in the queue (an automatic one only
   * takes free room, and rests when too much waits for you). Gives what happened; the run goes on in the background.
   */
  async function run(projectId, ask = {}, { auto = false, byYou = false, caller } = {}) {
    const kind = check(projectId, ask.kind);
    const focus = ask.focus?.trim() || undefined;
    const area = ask.area?.trim() || undefined;
    const at = nowIso();
    if (auto) {
      const flood = floodReason(waiting());
      if (flood) {
        end("", { projectId, kind, at, filed: 0, summary: "", error: `Rested: ${flood}` });
        throw new Error(`Scouts rest: ${flood}`);
      }
    }
    const twin = active().find((a) => a.projectId === projectId && a.kind === kind && sameFocus(a.focus, focus));
    if (twin) {
      throw new Error(`This ${SCOUT_LABEL[kind].toLowerCase()} ${twin.waiting ? "waits" : "runs"} already in this project${focus ? " with the same focus" : ": give it a focus to send another"}`);
    }
    const scout = { id: randomUUID(), projectId, kind, since: at, filed: 0, ...(focus ? { focus } : {}), ...(area ? { area } : {}), ...(byYou ? { byYou: true } : {}), ...(caller ? { caller } : {}) };
    const room = store.global().scoutsAtOnce - runningScouts(state()).length;
    if (room <= 0 || waitingScouts(state()).length) {
      if (auto) throw new Error("No room for a scout");
      if (waitingScouts(state()).length >= QUEUE_MAX) throw new Error(`${QUEUE_MAX} scouts wait already`);
      save({ ...state(), active: [...active(), { ...scout, waiting: true }] });
      const ahead = waitingScouts(state()).length - 1;
      void pump().catch((error) => p.log("scouts:", errorText(error)));
      return { id: scout.id, kind, waiting: true, summary: `Waits for room (Scouts at once)${ahead ? `, ${ahead} ahead of it` : ""}` };
    }
    save({ ...state(), active: [...active(), scout] });
    return start(scout);
  }

  async function start(scout) {
    const { projectId, kind, focus, area } = scout;
    const settings = store.project(projectId);
    const project = p.projectInfo(projectId);
    const at = nowIso();
    const prompt = scoutPrompt(kind, {
      projectId,
      projectName: project?.name ?? projectId,
      features: settings.scoutFeatures,
      areasDone: recentAreas(state().runs ?? [], projectId, kind),
      friction: kind === "friction" ? frictionNotes(store.entries(), Date.now() - FRICTION_DAYS * 86_400_000) : undefined,
      focus,
      area,
    });
    update(scout.id, { since: at, waiting: undefined, doing: "Starting" });
    try {
      const thread = await p.claude.start({
        project: projectId,
        prompt,
        title: `${SCOUT_LABEL[kind]}${focus ? `: ${snippet(focus, 60)}` : ""}`,
        workspace: "project",
        model: store.global().scoutModel,
        permissionMode: "dontAsk",
        allowedTools: SCOUT_TOOLS,
      });
      update(scout.id, { threadId: thread.id, doing: "Looking" });
      p.wake();
      return { id: scout.id, kind, threadId: thread.id, summary: "Started: what it files shows on the board (or the map)" };
    } catch (error) {
      end(scout.id, runOf({ ...scout, since: at }, { error: errorText(error) }));
      throw error;
    }
  }

  /** Threads the scheduler follows for the scouts. */
  function followed() {
    return active()
      .filter((a) => !a.waiting && a.threadId)
      .map((a) => ({ thread: a.threadId, see: (summary) => see(a.id, summary) }));
  }

  /** A scout's thread changed: once its turn is over, keep its run. */
  async function see(id, s) {
    const scout = active().find((a) => a.id === id);
    if (!scout) return;
    if (!s) return end(id, runOf(scout, { error: "Its thread is gone" }));
    if (isActive(s) || s.status === "waiting") return;
    const reply = (await p.claude.lastReply(s.id).catch(() => null)) ?? "";
    const out = jsonOf(reply.includes("```json") ? reply.slice(reply.lastIndexOf("```json")) : "") ?? {};
    const filed = Math.max(scout.filed ?? 0, Number.isFinite(Number(out.filed)) ? Number(out.filed) : 0);
    const run =
      s.status === "done"
        ? runOf(scout, { filed, area: String(out.area ?? "").trim() || scout.area, summary: snippet(String(out.summary ?? reply.split("\n")[0] ?? ""), 300) || "Nothing worth filing" })
        : runOf(scout, { filed, error: s.status === "interrupted" ? "Stopped" : snippet(s.error ?? `The scout ${s.status}`, 300) });
    end(id, run);
    if (scout.caller || scout.byYou) p.hub.notify(`${SCOUT_LABEL[scout.kind]}: ${run.error ? `failed: ${run.error}` : `${run.filed} filed. ${run.summary}`}`, run.error ? "error" : "info");
  }

  /** A proposal came from a thread: when it is a scout's, count it there and mark the task as the scout's. */
  function filedBy(threadId, title) {
    const scout = active().find((a) => a.threadId && a.threadId === threadId);
    if (!scout) return null;
    update(scout.id, { filed: (scout.filed ?? 0) + 1, filedTitles: [...(scout.filedTitles ?? []), snippet(title, 120)].slice(-FILED_TITLES_KEPT) });
    return scout.id;
  }

  /** Start waiting scouts while there is room: yours first, then in the order they were asked for. */
  async function pump() {
    if (pumping) return;
    pumping = true;
    try {
      while (runningScouts(state()).length < store.global().scoutsAtOnce) {
        const queue = waitingScouts(state());
        const next = queue.find((a) => a.byYou) ?? queue[0];
        if (!next) break;
        try {
          check(next.projectId, next.kind);
          await start(next);
        } catch (error) {
          if (active().some((a) => a.id === next.id)) end(next.id, runOf(next, { at: nowIso(), error: errorText(error) }));
        }
      }
    } finally {
      pumping = false;
    }
  }

  /** Stop a running scout (what it filed stays), or take a waiting one out of the queue. */
  async function stop(id) {
    const scout = active().find((a) => a.id === id);
    if (!scout) throw new Error("That scout isn't running any more");
    if (scout.waiting) return end(id);
    if (scout.threadId) await p.claude.interrupt(scout.threadId).catch(() => {});
    end(id, runOf(scout, { error: "Stopped by you" }));
  }

  /**
   * Once a look: start waiting scouts there is room for, and (auto) while you're Away and nothing runs or waits, one
   * scout per enabled project that had none since you went Away.
   */
  async function tick({ idle }) {
    await pump();
    const global = store.global();
    if (global.scouts !== "auto" || global.mode !== "away" || !idle) return;
    let room = global.scoutsAtOnce - active().length;
    const since = Date.parse(store.state().modeSince ?? "") || 0;
    for (const project of p.projectsCache) {
      if (room <= 0) return;
      if (!store.projectSaved(project.id) || !store.project(project.id).enabled) continue;
      if (active().some((a) => a.projectId === project.id)) continue;
      if ((state().runs ?? []).some((r) => r.projectId === project.id && Date.parse(r.at) >= since)) continue;
      room--;
      await run(project.id, {}, { auto: true }).catch((error) => p.log("scout:", errorText(error)));
    }
  }

  function lines() {
    const title = (projectId) => p.projectInfo(projectId)?.name ?? projectId;
    const flood = floodReason(waiting());
    const rest = flood ? [`(Automatic scouts rest now: ${flood}. A scout you send still runs.)`] : [];
    return [...rest, ...scoutLines(state(), title)];
  }

  return { run, stop, tick, lines, followed, filedBy, state, waiting };
}
