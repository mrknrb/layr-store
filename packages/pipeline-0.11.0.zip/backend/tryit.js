// Windows on the PC for a task (ported from layr_code's backend/tryIt.ts and the card's Open in…): ▶ Try runs the
// project's Try command from the task's worktree in a PowerShell window of its own, with a free port in
// `$env:LAYR_TRY_PORT`. One try per project at a time: starting one stops the window (and everything it started) of
// the project's previous try, by the process id the window wrote into `<data>/try/<project>.pid`. Open in VS Code and
// File Explorer open the task's worktree (a task without one: the project's own folder). These only make sense on
// the PC: the panels hide them when they're shown on a phone. Outside Windows, ▶ Try runs the command with `sh` in
// the background (its output in `<data>/try/<project>.log`), and the folder opens with `open` / `xdg-open`.
import { execFile, spawn } from "node:child_process";
import { mkdirSync, openSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { createServer } from "node:net";
import path from "node:path";

const windows = process.platform === "win32";

/** A port nothing listens on right now. */
export function freePort() {
  return new Promise((resolve, reject) => {
    const server = createServer();
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      const port = typeof address === "object" && address ? address.port : 0;
      server.close(() => resolve(port));
    });
  });
}

/** The PowerShell lines a try window runs: its process id for the next try, the port, the folder, the command. */
export function tryScript(command, pidFile, port, dir) {
  const q = (s) => s.replaceAll("'", "''");
  return [
    `$PID | Set-Content -Path '${q(pidFile)}'`,
    `$env:LAYR_TRY_PORT = '${port}'`,
    `Set-Location -LiteralPath '${q(dir)}'`,
    `$Host.UI.RawUI.WindowTitle = 'layr try: ' + (Split-Path -Leaf (Get-Location))`,
    command.replace(/\r\n/g, "\n").trim(),
  ].join("\r\n");
}

function kill(pid) {
  return new Promise((resolve) => {
    if (windows) execFile("taskkill", ["/T", "/F", "/PID", String(pid)], { windowsHide: true }, () => resolve());
    else {
      try {
        process.kill(-pid, "SIGTERM");
      } catch {
        try {
          process.kill(pid, "SIGTERM");
        } catch {
          // gone already
        }
      }
      resolve();
    }
  });
}

/** Windows on the PC. `p`: the pipeline; `dataDir`: where the try windows' process ids are kept. */
export function createWindows(p, dataDir) {
  const tries = path.join(dataDir, "try");

  /** The folder a task works in: its worktree, else the project's own folder. */
  function folderOf(task) {
    if (!task.noWorktree && task.worktreePath) return task.worktreePath;
    return p.repoOf(task.projectId);
  }

  async function stopPrevious(pidFile) {
    let pid = NaN;
    try {
      pid = Number(readFileSync(pidFile, "utf8").trim());
    } catch {
      return;
    }
    rmSync(pidFile, { force: true });
    if (Number.isInteger(pid) && pid > 0) await kill(pid);
  }

  /** ▶ Try a task: its result from its worktree, in a window of its own; stops the project's previous try. */
  async function tryTask(id) {
    const task = p.need(id);
    if (!task.threadId) throw new Error(`#${task.number} hasn't run yet: nothing to try`);
    if (task.noWorktree) throw new Error(`#${task.number} works in the project's own checkout: try it there`);
    if (!task.worktreePath) throw new Error(`#${task.number} has no worktree to try`);
    const command = p.store.project(task.projectId).tryCommand.trim();
    if (!command) throw new Error("Set the project's Try command in Pipeline settings first");
    mkdirSync(tries, { recursive: true });
    const name = encodeURIComponent(task.projectId);
    const pidFile = path.join(tries, `${name}.pid`);
    await stopPrevious(pidFile).catch((error) => p.log("stopping the previous try:", error));
    const port = await freePort();
    if (windows) {
      const script = path.join(tries, `${name}.ps1`);
      // With a BOM, so Windows PowerShell reads it as UTF-8 (paths with accents).
      writeFileSync(script, `﻿${tryScript(command, pidFile, port, task.worktreePath)}\r\n`, "utf8");
      const args = ["/c", "start", `"layr try #${task.number}"`, "powershell.exe", "-NoExit", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", `"${script}"`];
      // Verbatim: `start` takes the quoted title as is; the script's path is quoted by hand (it may hold spaces).
      spawn("cmd.exe", args, { cwd: task.worktreePath, detached: true, stdio: "ignore", windowsVerbatimArguments: true }).unref();
    } else {
      const out = openSync(path.join(tries, `${name}.log`), "w");
      const child = spawn("sh", ["-c", command], { cwd: task.worktreePath, detached: true, stdio: ["ignore", out, out], env: { ...process.env, LAYR_TRY_PORT: String(port) } });
      writeFileSync(pidFile, String(child.pid));
      child.unref();
    }
    p.store.mutate(id, () => ({ triedAt: new Date().toISOString() }));
    return { trying: task.number, port, folder: task.worktreePath };
  }

  /** Open the task's folder in VS Code or File Explorer on the PC. */
  function openIn(id, app) {
    const task = p.need(id);
    const dir = folderOf(task);
    if (app === "vscode") {
      // `code` is a .cmd on Windows: it needs a shell.
      const child = spawn(windows ? "code.cmd" : "code", [dir], { detached: true, stdio: "ignore", shell: windows });
      child.on("error", (error) => p.log("opening VS Code:", error.message));
      child.unref();
    } else {
      const [cmd, args] = windows ? ["explorer.exe", [dir]] : process.platform === "darwin" ? ["open", [dir]] : ["xdg-open", [dir]];
      const child = spawn(cmd, args, { detached: true, stdio: "ignore" });
      child.on("error", (error) => p.log("opening the folder:", error.message));
      child.unref();
    }
    return { opened: dir, app };
  }

  return { tryTask, openIn, folderOf };
}
