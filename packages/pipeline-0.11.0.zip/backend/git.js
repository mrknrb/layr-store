// git for the pipeline: worktrees come from the claude plugin; layr reads a worktree before landing, lands it on the
// base branch (fast-forward in the repository on the PC, and with `push` landing also on the remote, never forced),
// runs the project's checks, and removes worktrees of finished tasks.
import { exec as execShell, execFile } from "node:child_process";
import { existsSync } from "node:fs";
import { lstat, readdir, rm } from "node:fs/promises";
import path from "node:path";

const TIMEOUT_MS = 2 * 60_000;

function childEnv(extra = {}) {
  const { NODE_ENV: _, ...env } = process.env;
  return { ...env, GIT_TERMINAL_PROMPT: "0", GH_PROMPT_DISABLED: "1", ...extra };
}

function run(command, args, cwd, { timeout = TIMEOUT_MS, env } = {}) {
  return new Promise((resolve, reject) => {
    execFile(
      command,
      args,
      { cwd, timeout, maxBuffer: 32 * 1024 * 1024, windowsHide: true, env: childEnv(env) },
      (error, stdout, stderr) => {
        if (error) {
          const message = `${command} ${args.join(" ")}: ${String(stderr || stdout || error.message).trim()}`;
          reject(Object.assign(new Error(message), { exitCode: error.code }));
        } else resolve(String(stdout));
      },
    );
  });
}

export const git = (cwd, ...args) => run("git", args, cwd);

/**
 * The GitHub CLI: `LAYR_PIPELINE_GH` when set (a .js/.mjs file runs with node: tests use a fake), else `gh` on the
 * PATH, else the installer's folder on Windows.
 */
export function ghCommand() {
  const given = process.env.LAYR_PIPELINE_GH;
  if (given) return /\.(m?js)$/i.test(given) ? [process.execPath, [given]] : [given, []];
  const installed = "C:\\Program Files\\GitHub CLI\\gh.exe";
  if (process.platform === "win32" && !onPath("gh") && existsSync(installed)) return [installed, []];
  return ["gh", []];
}

function onPath(name) {
  const exts = process.platform === "win32" ? (process.env.PATHEXT ?? ".EXE").split(";") : [""];
  const dirs = (process.env.PATH ?? "").split(path.delimiter).filter(Boolean);
  return dirs.some((dir) => exts.some((e) => existsSync(path.join(dir, name + e.toLowerCase())) || existsSync(path.join(dir, name + e))));
}

export function gh(cwd, ...args) {
  const [command, pre] = ghCommand();
  return run(command, [...pre, ...args], cwd, { timeout: 3 * 60_000 });
}

/** Push `commit` to the task's own branch on the remote (`pr` landing), forced: the branch is the task's alone. */
export function pushBranch(dir, remote, branch, commit) {
  return run("git", ["push", "--force", remote, `${commit}:refs/heads/${branch}`], dir, { timeout: 5 * 60_000, env: { LAYR_LANDING: "1" } });
}

/** A commit's message: its first line, and the rest. */
export async function commitMessage(dir, commit) {
  const [subject = "", ...rest] = (await git(dir, "log", "-1", "--format=%B", commit)).trim().split(/\r?\n/);
  return { subject: subject.trim(), body: rest.join("\n").trim() };
}

/** Commits of `ref` that HEAD of `dir` lacks, and the other way round: { behind, ahead }. */
export async function behindAhead(dir, ref) {
  const out = (await git(dir, "rev-list", "--left-right", "--count", `HEAD...${ref}`)).trim().split(/\s+/).map(Number);
  return { ahead: out[0] ?? 0, behind: out[1] ?? 0 };
}

/** No uncommitted changes to tracked files (untracked ones don't count). */
export async function trackedClean(dir) {
  return !(await git(dir, "status", "--porcelain", "--untracked-files=no")).trim();
}

/** One git change at a time per repository: parallel worktree changes fight over the index lock. */
const locks = new Map();
function serialized(repo, work) {
  const key = path.resolve(repo).toLowerCase();
  const result = (locks.get(key) ?? Promise.resolve()).then(work, work);
  locks.set(
    key,
    result.catch(() => {}),
  );
  return result;
}

/** Run a command line through the shell; on failure the end of its output (stdout and stderr). */
export function runChecks(command, cwd, timeout, env) {
  const options = { cwd, timeout, maxBuffer: 64 * 1024 * 1024, windowsHide: true, env: childEnv(env) };
  return new Promise((resolve) => {
    execShell(command, options, (error, stdout, stderr) => {
      if (!error) return resolve({ ok: true, output: String(stdout).trim().slice(-2000) });
      const timedOut = error.killed || error.signal === "SIGTERM";
      const output = `${stdout}\n${stderr}`.trim().slice(-4000);
      const minutes = Math.round(timeout / 60_000);
      resolve({ ok: false, output: timedOut ? `Timed out after ${minutes} min.\n${output}` : output || error.message });
    });
  });
}

export async function isGitRepo(dir) {
  try {
    return (await git(dir, "rev-parse", "--is-inside-work-tree")).trim() === "true";
  } catch {
    return false;
  }
}

export async function currentBranch(dir) {
  try {
    const name = (await git(dir, "rev-parse", "--abbrev-ref", "HEAD")).trim();
    return name === "HEAD" ? null : name;
  } catch {
    return null;
  }
}

export const headOf = async (dir) => (await git(dir, "rev-parse", "HEAD")).trim();

export async function revParse(dir, ref) {
  try {
    return (await git(dir, "rev-parse", "--verify", "--quiet", `${ref}^{commit}`)).trim() || null;
  } catch {
    return null;
  }
}

/** Whether `commit` contains `ancestor`. */
export async function isAncestor(dir, ancestor, commit) {
  try {
    await git(dir, "merge-base", "--is-ancestor", ancestor, commit);
    return true;
  } catch (error) {
    if (error.exitCode === 1) return false;
    throw error;
  }
}

/** Uncommitted changes and untracked files (not ignored ones), one `git status --porcelain` line each. */
export async function uncommitted(dir) {
  return (await git(dir, "status", "--porcelain"))
    .split("\n")
    .map((l) => l.trimEnd())
    .filter(Boolean);
}

export const commitsAhead = async (dir, ref) => Number((await git(dir, "rev-list", "--count", `${ref}..HEAD`)).trim());

/** The files the commits on `dir`'s HEAD change since it left `ref`. */
export const changedFiles = async (dir, ref) =>
  (await git(dir, "diff", "--name-only", `${ref}...HEAD`))
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);

/** Fetch the base branch from the remote (push landing); gives its newest commit there. */
export function fetchBase(repo, remote, base) {
  return serialized(repo, async () => {
    await run("git", ["fetch", remote, base], repo, { timeout: 5 * 60_000 });
    return (await git(repo, "rev-parse", `${remote}/${base}`)).trim();
  });
}

/** The folder of the worktree that has `branch` checked out (the main checkout too), or null. */
export async function worktreeOf(repo, branch) {
  const list = await git(repo, "worktree", "list", "--porcelain");
  for (const entry of list.split(/\r?\n\r?\n/)) {
    const lines = entry.split(/\r?\n/);
    const dir = lines.find((l) => l.startsWith("worktree "))?.slice("worktree ".length);
    if (dir && lines.includes(`branch refs/heads/${branch}`)) return path.resolve(dir);
  }
  return null;
}

export async function branchExists(repo, branch) {
  return (await revParse(repo, `refs/heads/${branch}`)) !== null;
}

/**
 * Move the local base branch to `commit`, only forward. Where the base is checked out (the user's checkout), it is a
 * `merge --ff-only` there, so its files follow and uncommitted changes in the way stop it; elsewhere a compare-and-swap
 * of the ref. Gives { ok } or { ok: false, moved } (the base has commits `commit` lacks) or { ok: false, message }.
 */
export function fastForwardBase(repo, base, commit) {
  return serialized(repo, async () => {
    const old = await revParse(repo, `refs/heads/${base}`);
    if (!old) return { ok: false, message: `there is no branch ${base}` };
    if (old === commit) return { ok: true };
    if (!(await isAncestor(repo, old, commit))) return { ok: false, moved: true, message: `${base} moved on` };
    const dir = await worktreeOf(repo, base);
    try {
      if (dir) await run("git", ["merge", "--ff-only", "--no-edit", commit], dir, { env: { LAYR_LANDING: "1" } });
      else await git(repo, "update-ref", `refs/heads/${base}`, commit, old);
      return { ok: true };
    } catch (error) {
      return { ok: false, message: String(error.message ?? error).slice(-600) };
    }
  });
}

/** Push `commit` onto the base branch on the remote, without force: refused when the base moved on there. */
export async function pushToBase(dir, remote, base, commit) {
  try {
    await run("git", ["push", remote, `${commit}:refs/heads/${base}`], dir, {
      timeout: 5 * 60_000,
      env: { LAYR_LANDING: "1" },
    });
    return { ok: true };
  } catch (error) {
    const message = error.message ?? String(error);
    return { ok: false, moved: /non-fast-forward|fetch first|rejected/i.test(message), message };
  }
}

/** Remove a worktree (with its untracked files) and forget it. */
export function removeWorktree(repo, dir) {
  return serialized(repo, async () => {
    if (existsSync(path.join(dir, ".git"))) {
      await git(repo, "-c", "core.longpaths=true", "worktree", "remove", "--force", dir);
    } else if (existsSync(dir)) await rm(dir, { recursive: true, force: true, maxRetries: 3 });
    await git(repo, "worktree", "prune").catch(() => {});
  });
}

export function deleteBranch(repo, branch) {
  return serialized(repo, () => git(repo, "branch", "-D", branch));
}

/** Delete the task's branch on the remote (after its pull request merged). */
export function deleteRemoteBranch(repo, remote, branch) {
  return run("git", ["push", remote, "--delete", branch], repo, { timeout: 2 * 60_000, env: { LAYR_LANDING: "1" } });
}

/** Local branches starting with `prefix`: [{ branch, head, date }]. */
export async function branchesWith(repo, prefix) {
  const out = await git(repo, "for-each-ref", "--format=%(refname:short)%09%(objectname)%09%(committerdate:iso-strict)", "refs/heads");
  return out
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => {
      const [branch, head, date] = l.split("\t");
      return { branch, head, date };
    })
    .filter((b) => b.branch.startsWith(prefix));
}

/** Every worktree's folder by the branch it has checked out. */
export async function worktreesByBranch(repo) {
  const map = new Map();
  for (const entry of (await git(repo, "worktree", "list", "--porcelain")).split(/\r?\n\r?\n/)) {
    const lines = entry.split(/\r?\n/);
    const dir = lines.find((l) => l.startsWith("worktree "))?.slice("worktree ".length);
    const ref = lines.find((l) => l.startsWith("branch "))?.slice("branch refs/heads/".length);
    if (dir && ref) map.set(ref, path.resolve(dir));
  }
  return map;
}

/** Every worktree of the repository: [{ path, head, branch (null when detached), main (the repository's own) }]. */
export async function worktreeList(repo) {
  const out = [];
  for (const entry of (await git(repo, "worktree", "list", "--porcelain")).split(/\r?\n\r?\n/)) {
    const lines = entry.split(/\r?\n/);
    const dir = lines.find((l) => l.startsWith("worktree "))?.slice("worktree ".length);
    if (!dir) continue;
    const branch = lines.find((l) => l.startsWith("branch "))?.slice("branch refs/heads/".length) ?? null;
    const head = lines.find((l) => l.startsWith("HEAD "))?.slice("HEAD ".length) ?? null;
    out.push({ path: path.resolve(dir), head, branch, main: out.length === 0, bare: lines.includes("bare") });
  }
  return out;
}

/**
 * Whether removing a worktree loses nothing: its HEAD is in `base` (or is `landedHead`, a task that landed through a
 * squashed pull request, or each of its commits is in `base` as the same change), and nothing in it is uncommitted or
 * untracked (ignored files, build output, may go).
 * Gives { safe, why (when not), head, files (uncommitted and untracked) }.
 */
export async function removable(dir, base, landedHead = null) {
  if (!existsSync(dir)) return { safe: false, why: "it's gone already", gone: true };
  let head;
  try {
    head = (await git(dir, "rev-parse", "HEAD")).trim();
  } catch {
    return { safe: false, why: "it isn't a git checkout" };
  }
  const files = (await git(dir, "status", "--porcelain").catch(() => "?")).split(/\r?\n/).filter((l) => l.trim()).length;
  if (files) return { safe: false, why: `${files} uncommitted or untracked file(s)`, head, files };
  if (head !== landedHead && !(await isAncestor(dir, head, base).catch(() => false)) && !(await sameChanges(dir, base, head))) {
    return { safe: false, why: "its commits aren't on the base branch", head, files };
  }
  return { safe: true, head, files };
}

/** Every commit `head` has beyond `base` is in `base` as the same change (cherry-picked or rebased): `git cherry`. */
async function sameChanges(dir, base, head) {
  const lines = (await git(dir, "cherry", base, head).catch(() => "+")).split(/\r?\n/).filter((l) => l.trim());
  return lines.length > 0 && lines.every((l) => l.startsWith("-"));
}

/** A folder's size in bytes, all files under it (symbolic links not followed); slow for big build folders. */
export async function folderSize(dir) {
  let total = 0;
  const stack = [dir];
  while (stack.length) {
    const here = stack.pop();
    let entries;
    try {
      entries = await readdir(here, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const e of entries) {
      const full = path.join(here, e.name);
      if (e.isDirectory()) stack.push(full);
      else if (e.isFile()) total += (await lstat(full).catch(() => ({ size: 0 }))).size;
    }
  }
  return total;
}

/** Commits `ref` has that `branch` lacks, and the other way round: { behind, ahead }. */
export async function aheadBehind(repo, branch, ref) {
  const out = (await git(repo, "rev-list", "--left-right", "--count", `${branch}...${ref}`)).trim().split(/\s+/).map(Number);
  return { ahead: out[0] ?? 0, behind: out[1] ?? 0 };
}

export const samePath = (a, b) =>
  !!a && !!b && path.resolve(a).toLowerCase().replace(/[\\/]+$/, "") === path.resolve(b).toLowerCase().replace(/[\\/]+$/, "");
