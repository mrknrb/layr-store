// The claude plugin's tools (docs/ARCHITECTURE.md > The claude plugin), called through the hub as claude__<tool>.
// This replaces the old pipeline's whole T3 Code seam (t3.ts, threads.ts, turnWatch.ts). The scheduler only uses
// this interface, so tests give it a fake with the same methods.

export class ClaudeClient {
  constructor(hub) {
    this.hub = hub;
  }

  call(tool, args, options) {
    return this.hub.call(`claude__${tool}`, args, options);
  }

  async projects() {
    return (await this.call("projects_list", {})).projects ?? [];
  }

  async addProject(path, name) {
    return (await this.call("project_add", { path, ...(name ? { name } : {}) })).project;
  }

  async removeProject(project) {
    return this.call("project_remove", { project });
  }

  /** Start a thread; gives its summary ({id, status, workspace: {path, branch, base}, cwd...}). */
  async start(args) {
    return (await this.call("thread_start", args, { timeoutMs: 10 * 60_000 })).thread;
  }

  send(thread, text, mode = "queue", images = []) {
    return this.call("thread_send", { thread, text, mode, ...(images?.length ? { images } : {}) });
  }

  /** One question, one answer (claude__ask: one turn, no tools, haiku by default): { text }. */
  ask({ prompt, system, model, effort }) {
    return this.call("ask", { prompt, ...(system ? { system } : {}), ...(model ? { model } : {}), ...(effort ? { effort } : {}) }, { timeoutMs: 6 * 60_000 });
  }

  interrupt(thread) {
    return this.call("thread_interrupt", { thread });
  }

  /** Until the turn ends or waits for the user, at most `timeoutSec`: { thread, last, timedOut }. */
  wait(thread, timeoutSec = 300) {
    return this.call("thread_wait", { thread, timeoutSec }, { timeoutMs: (timeoutSec + 60) * 1000 });
  }

  /** { thread, approvals: [{requestId, kind, tool, input, questions?, plan?}], git } */
  status(thread) {
    return this.call("thread_status", { thread });
  }

  async list() {
    return (await this.call("thread_list", { limit: 500, archived: "all" })).threads ?? [];
  }

  /** The thread's latest reply, whole: its last assistant text after the last user message. */
  async lastReply(thread) {
    const read = await this.call("thread_read", { thread, limit: 60 });
    const messages = read.messages ?? [];
    let reply = null;
    for (const m of messages) {
      if (m.role === "user") reply = null;
      else if (m.role === "assistant" && m.text?.trim()) reply = m.text;
    }
    return reply;
  }

  archive(thread, archived = true) {
    return this.call("thread_archive", { thread, archived });
  }

  update(thread, patch) {
    return this.call("thread_update", { thread, ...patch });
  }

  /** Answer what a thread waits for: decision allow, allow_always or deny; `answers` for a question. */
  answer(thread, { requestId, decision = "allow", answers, message }) {
    return this.call("answer_approval", {
      thread,
      requestId,
      decision,
      ...(answers ? { answers } : {}),
      ...(message ? { message } : {}),
    });
  }

  /** Plan usage (5-hour and weekly) of the Claude account, when the claude plugin can read it. */
  usage() {
    return this.call("usage", {});
  }
}
