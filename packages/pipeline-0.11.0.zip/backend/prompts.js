// What layr sends to threads: the launch message, the messages of a landing, plan mode, Approve and the verifier. The repository's own CLAUDE.md holds the rules; these only say what is particular to the pipeline.
import { projectMapLines, sourcesLine } from "./concepts.js";

/** The ref a task lands on top of: the remote's base for `push` landing, else the local base branch. */
export const baseRef = (settings) => (remoteLanding(settings) ? `${settings.remote}/${settings.baseBranch}` : settings.baseBranch);

/** `push` and `pr` landing go through the remote. */
export const remoteLanding = (settings) => settings.landing === "push" || settings.landing === "pr";

export const taskLink = (id) => `layr://pipeline/task/${id}`;

/**
 * The first message of a task's thread. `branch`: null for a task without a worktree. `parent`: the landed task it
 * starts after. `members`: a batch's tasks. `away`: the user is away. `lane`: the project has a test lane. `map`: the
 * project node's sections and rules (concepts__project_map), null when it has none or the concepts plugin didn't
 * answer; `concepts`: the concepts plugin is there (the concept map lines are left out without it). `note`: the
 * attached files' line, kept with the task. The task itself comes first, under its title; layr's instructions follow
 * below a rule, so the user's own words are never buried among them.
 */
export function launchMessage({
  id,
  task,
  branch,
  settings,
  parent = null,
  members = [],
  away = false,
  lane = false,
  map = null,
  concepts = false,
  note = "",
}) {
  const base = settings.baseBranch;
  const stable = [
    ...(branch
      ? [`- Your own worktree: commit on your branch, never push to \`${base}\`.`]
      : [
          "- No worktree: you're in the project's own checkout on the PC, so what you change is live right away. layr " +
            "lands nothing: don't switch branches, commit or push unless the task asks. Other tasks without a " +
            "worktree wait until this one is settled.",
          `- Leave the checkout on \`${base}\`. When you stop, list the files you left uncommitted.`,
        ]),
    "- If something is the user's to decide (intent, a product choice, a risky trade-off), ask in your reply, all " +
      "questions at once. Small things: decide yourself and mention them.",
    "- When you're done, say what you did and how to test it, and end with the status line " +
      "(`Status: done · Risk: none · Try: ready`; Status: done, asks, blocked or partial), then stop.",
    `- Waiting for something outside you (CI, a deploy, a long build)? End your turn and ask layr to wake you: the ` +
      `layr tool pipeline__wake {number: ${task.number}, inMinutes, note}.`,
    "- Testing starts processes? Stop only the ones you started, by the process id you kept (`Start-Process " +
      "-PassThru`, then `Stop-Process -Id`): never by name or by tree (`taskkill /IM`, `Stop-Process -Name`, " +
      "`pkill`). The user's own programs run on this PC, layr among them: it is layr.exe, like a test core.",
    ...(settings.tryCommand?.trim() && branch
      ? [
          `- ▶ Try runs \`${settings.tryCommand.trim().replace(/\s*\n\s*/g, "; ")}\` from your worktree in ` +
            "PowerShell (a free port in `$env:LAYR_TRY_PORT`): when you stop with something to try, build it so that " +
            "works.",
        ]
      : []),
    ...(lane && branch
      ? [
          "- This project has a test lane (something only one task may use at a time). Don't run its commands without " +
            `it: take it with the layr tool pipeline__lane {number: ${task.number}} when your work needs it, and give ` +
            "it back with `release: true` when you're done.",
        ]
      : []),
    ...(concepts ? projectMapLines(settings, map) : []),
    ...(away ? [AWAY_LINE] : []),
  ];
  const own = [
    (branch ? `Branch \`${branch}\`. ` : "") +
      `This is pipeline task ${taskLink(id)}.` +
      (concepts
        ? ` On the concept map, pass \`thread: "${taskLink(id)}"\` to the tools that change or mention nodes: they ` +
          "are then linked to this task."
        : ""),
    ...(parent?.landed && branch
      ? [
          `It builds on task #${parent.number} (${parent.title}), which landed on \`${base}\` as ` +
            `\`${parent.landed.commit.slice(0, 8)}\`: your worktree starts from it. Read that commit first.`,
        ]
      : []),
    ...(concepts ? sourcesLine(withMembers(task, members)) : []),
    ...(task.autoMerge && branch
      ? [
          "Auto-merge is on: when your turn ends with your work committed and the worktree clean, layr lands it on " +
            `\`${base}\` right away, without review. Commit only work that is ready to ship; if you need a decision, ` +
            "leave your work uncommitted and ask in your reply: layr doesn't land it then.",
        ]
      : []),
    ...(task.agentLands && !task.autoMerge && branch
      ? [
          "Agent lands is on: you decide whether this work lands. Only when you are done and everything went well (the " +
            "work is complete and committed, the worktree clean, the checks pass, nothing is left for the user to " +
            `decide, no database, data or breaking risk), call the layr tool pipeline__land {number: ${task.number}} ` +
            `before you end your turn. Don't merge, rebase onto or push \`${base}\` yourself: layr lands it after your ` +
            "turn, as the user's Land button does, and only if your reply ends with Status: done. If anything went " +
            "wrong or you need the user, don't call it: ask in your reply.",
        ]
      : []),
  ];
  return [
    `Task #${task.number}: ${task.title}`,
    "",
    (task.batch ? batchPrompt(members, task.prompt) : task.prompt || "(no description)") + note,
    "",
    "---",
    "",
    "**How to work on it** (layr's pipeline instructions; the task is everything above the line)",
    "",
    ...(task.planning ? [...PLAN_LINES, ""] : []),
    ...stable,
    "",
    ...own,
    ...(settings.instructions.trim() ? ["", settings.instructions.trim()] : []),
  ].join("\n");
}

/** A batch's sources are its members' too: the nodes the worker gives a status. */
function withMembers(task, members) {
  if (!task.batch) return task;
  const links = [task.from, ...(task.alsoFrom ?? []), ...members.flatMap(([, t]) => [t.from, ...(t.alsoFrom ?? [])])];
  const [from, ...alsoFrom] = links.filter(Boolean);
  return { from, alsoFrom };
}

export const AWAY_LINE =
  "- The user is away: nobody answers until they are back. Decide small things yourself and list them under " +
  "## Decisions. When you need the user's decision, stop and ask in your reply: this task waits for them and the " +
  "next one starts. Never change the database without their yes.";

export const PLAN_LINES = [
  "**This task is in Plan mode: for now, only plan and ask.** Change nothing yet: no edits, no commits, nothing " +
    "that changes state. Read the task and the code, then reply with your plan (what you'll change, why, when it is " +
    "done, the files, the risks, and its size: S, M or L) and every question the user should answer before you " +
    "start, all at once. End with `Status: asks`, or `Status: done` when nothing is left to ask. Then stop.",
  "Every message the user sends you in this thread is still planning, however it reads (even \"go\" or \"start\"): " +
    "take the answers in, update the plan, ask what is still open, and stop again, with the same status line. " +
    "`Status: done` only tells the user you have nothing left to ask; the user approves the plan in layr. Don't " +
    "start the work until a message starts with **Start the work**.",
];

export const PLAN_REMINDER =
  "(Still Plan mode: take this in, update the plan and ask what is open; change nothing until **Start the work**.)";

/** Approve on a planning task: its work starts. */
export function startText(answers, away) {
  return [
    "**Start the work** now, as planned in this thread, following the user's answers.",
    ...(answers?.trim() ? ["", answers.trim(), ""] : []),
    "- Questions still open: decide them yourself and list them under ## Decisions.",
    "- A database change still waits for the user's yes.",
    ...(away ? [AWAY_LINE] : []),
    "- When you're done, say what you did and how to test it, then stop.",
  ].join("\n");
}

/** Approve on any other task that stopped with its work not done. */
export function goAheadText(answers, away) {
  return [
    "**Approved: go ahead** and finish the work, following the user's answers.",
    ...(answers?.trim() ? ["", answers.trim(), ""] : []),
    "- Questions without an answer: go with your recommended answers and list them under ## Decisions.",
    "- A database change still waits for the user's yes.",
    ...(away ? [AWAY_LINE] : []),
    "- When you're done, say what you did and how to test it, then stop.",
  ].join("\n");
}

/** A batch's own part of the launch message: its members, one after the other, and what the whole batch is about. */
export function batchPrompt(members, about = "") {
  const numbers = members.map(([, t]) => `#${t.number}`).join(", ");
  // The example lines use its own numbers (`#84-1`), so the worker writes them as they are.
  const [first = "#12", second = first] = members.map(([, t]) => `#${t.number}`);
  return [
    `This task is a batch of ${members.length} small tasks of this project (${numbers}), done together in this one ` +
      "worktree and landed together. Each is still a task of its own: do them one after the other. Skip one only " +
      "when it can't be done well here (it needs the user's decision, a database change, or is much bigger than it " +
      "looks), and go on with the others; ask about it in your reply.",
    `End your reply, just before the status line, with one line per task, each on its own line: \`${first} done\`, ` +
      `or \`${second} skipped: why\`. layr reads these lines: a skipped task goes back to the user's proposals.`,
    ...(about?.trim() ? ["", "## What the whole batch is about", "", about.trim()] : []),
    ...members.flatMap(([, t]) => ["", `## #${t.number}: ${t.title}`, "", t.prompt || "(no description)"]),
  ].join("\n");
}

const capital = (text) => text.charAt(0).toUpperCase() + text.slice(1);

const checksLine = (settings) =>
  settings.checks.trim() ? `run \`${settings.checks.trim()}\` and fix what fails` : "run the repository's checks";

const squashLine = (settings) =>
  settings.squash
    ? `squash everything into one commit on top of \`${baseRef(settings)}\` with a good commit message ` +
      "(what changed and why)"
    : "keep your commits tidy";

const landsLine = (settings) =>
  settings.landing === "pr"
    ? `pushes it to your branch, opens its pull request into \`${settings.baseBranch}\` and merges it once CI is green`
    : settings.landing === "push"
      ? `moves \`${settings.baseBranch}\` to it and pushes it to \`${settings.remote}\` itself`
      : `moves \`${settings.baseBranch}\` to it itself`;

/** Land: bring the branch up to date and make it ready to land. */
export function landMessage(settings) {
  const ref = baseRef(settings);
  const fetch = remoteLanding(settings) ? `\`git fetch ${settings.remote} ${settings.baseBranch}\`, then rebase` : "Rebase";
  return [
    `Land this task on \`${settings.baseBranch}\`:`,
    `1. ${fetch} this branch onto \`${ref}\`.`,
    "2. Fix conflicts keeping the intent of both sides. If a migration number collides with one on " +
      `\`${settings.baseBranch}\`, renumber yours to the next free one.`,
    `3. ${capital(squashLine(settings))}.`,
    `4. ${capital(checksLine(settings))}; commit any fix into that commit.`,
    `5. Leave the worktree clean and stop. Don't push: layr runs the checks again and ${landsLine(settings)}.`,
  ].join("\n");
}

export const notReadyMessage = (problem, settings) =>
  `Not ready to land yet: ${problem}\n\nFix it (${squashLine(settings)}, worktree clean, rebased onto the newest ` +
  `\`${baseRef(settings)}\`), then stop. Don't push.`;

export const checksFailedMessage = (command, output) =>
  `The checks failed before landing (\`${command}\`):\n\n\`\`\`\n${output}\n\`\`\`\n\nFix it, amend the commit, ` +
  "leave the worktree clean and stop. Don't push.";

export const baseMovedMessage = (settings) =>
  `\`${settings.baseBranch}\` moved on while landing. Rebase onto the newest \`${baseRef(settings)}\` again (same ` +
  "rules as before), then stop. Don't push.";

export const prChecksFailedMessage = (pr, checks) =>
  [
    `CI fails on pull request #${pr.number} (${pr.url}):`,
    ...checks.map((c) => `- ${c.name}${c.url ? `: ${c.url}` : ""}`),
    "",
    `Read the failures (\`gh pr checks ${pr.number}\`, \`gh run view <run id> --log-failed\`), fix them, amend the ` +
      "commit, leave the worktree clean and stop. Don't push: layr pushes the fix to the pull request.",
  ].join("\n");

export const prRebaseMessage = (why, settings) =>
  `The pull request can't be merged: ${why}. Fetch and rebase onto the newest \`${baseRef(settings)}\` (same rules ` +
  "as before), then stop. Don't push: layr pushes it to the pull request.";

export const continueMessage = () =>
  "Your last turn was cut off (usage limit or a network error). Continue where you stopped.";

/** The verifier's first message: check another agent's work in this worktree, change nothing. */
export function verifierMessage(task, branch, settings) {
  return [
    `You verify task #${task.number} "${task.title}", which another agent did in this worktree (branch \`${branch}\`). ` +
      "Don't change, commit or push anything: you only check.",
    "",
    "The task:",
    "",
    task.prompt || "(no description)",
    "",
    `1. Read what it changed: \`git diff ${baseRef(settings)}...HEAD\`.`,
    `2. ${settings.checks.trim() ? `Run \`${settings.checks.trim()}\`` : "Run the repository's tests and type checks"}.`,
    "3. Check that the change does what the task asks, and nothing it shouldn't.",
    "",
    "Then write what you found, and give one verdict on a line of its own: `Verdict: pass` when it is ready to land; " +
      "`Verdict: fix` with the fixes above it, each concrete (the file, what is wrong, what to do), for the agent who " +
      "did it; or `Verdict: you` when only the user can tell (taste, a product choice, something you couldn't run). " +
      "Small things you would merely do differently are no reason for fix.",
  ].join("\n");
}

export const VERIFY_ROUNDS = 2;

export const reverifyMessage = (round) =>
  `The agent made the fixes (round ${round} of ${VERIFY_ROUNDS}). Verify the latest commit again the same way, and ` +
  "end with the Verdict line.";

export const verifyFixesMessage = (round, report) =>
  `A verifier checked your work and asks for these fixes (round ${round} of ${VERIFY_ROUNDS}). Fix what is right, ` +
  `say why you leave out what isn't, commit, and reply as before:\n\n${report}`;

