// Reading what workers write: the status line a reply ends with (`Status: done · Risk: none · Try: ready`), a
// batch's per-task lines, the verifier's verdict, and why a turn failed. Pure.

/** Risks that make a change wait for you (no auto-merge, agents can't land it without naming the task). */
export const ASK_RISKS = ["database", "data"];
export const LAND_RISKS = ["database", "data", "breaking"];

/** The status line at the end of a reply: { status, risks, try } (lower case), or null. */
export function replyStatus(text) {
  const lines = String(text ?? "")
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);
  const last = lines.at(-1)?.replace(/^[*_`>\s]+|[*_`\s]+$/g, "");
  if (!last || !/^status\s*:/i.test(last)) return null;
  const clean = (s) => s.replace(/[*_`]/g, "").trim();
  const parts = new Map(
    last.split(/\s*[·|•]\s*/).map((part) => {
      const cut = part.indexOf(":");
      return [clean(part.slice(0, cut)).toLowerCase(), clean(part.slice(cut + 1))];
    }),
  );
  const risk = parts.get("risk") ?? parts.get("risks") ?? "";
  const risks = /^(none|no|-|—)?$/i.test(risk)
    ? []
    : risk
        .split(/\s*[,;/]\s*|\s+and\s+/)
        .map((r) => r.trim().toLowerCase())
        .filter(Boolean);
  const tryIt = parts.get("try")?.toLowerCase();
  return { status: (parts.get("status") ?? "").toLowerCase(), risks, ...(tryIt ? { try: tryIt } : {}) };
}

/** The `## Heading` sections of a reply, in order: [{ heading, body }] (text before the first heading: "") . */
export function replySections(text) {
  const sections = [];
  let current = { heading: "", body: [] };
  for (const line of String(text ?? "").split("\n")) {
    const m = /^#{1,3}\s+(.+?)\s*$/.exec(line);
    if (m) {
      if (current.heading || current.body.join("").trim()) sections.push(current);
      current = { heading: m[1].replace(/[^\p{L}\p{N} ;&/-]/gu, "").trim(), body: [] };
    } else current.body.push(line);
  }
  if (current.heading || current.body.join("").trim()) sections.push(current);
  return sections.map((s) => ({ heading: s.heading, body: s.body.join("\n").trim() }));
}

const BATCH_LINE = /^[-*•\s]*(?:task\s+)?#(\d+(?:-\d+)?)\b[^:\n]{0,80}?[\s:–—-]+\**(done|skipped|skip)\**\b[\s:–—-]*(.*)$/i;

/**
 * A batch worker's lines (`#84-1 done`, `#84-2 skipped: why`; older batches' members have plain numbers, `#12 done`)
 * for its members; the last line for a number wins. Each comes with the member's own number (`numbers`).
 */
export function batchReport(text, numbers) {
  const found = new Map();
  for (const raw of String(text ?? "").split("\n")) {
    const m = BATCH_LINE.exec(raw.trim().replace(/`/g, ""));
    if (!m) continue;
    const number = numbers.find((n) => String(n) === m[1]);
    if (number === undefined) continue;
    const done = m[2].toLowerCase() === "done";
    found.set(String(number), done ? { number, done } : { number, done, why: m[3].trim() || "no reason given" });
  }
  return [...found.values()];
}

/** The verifier's verdict: pass, fix or you (its last Verdict line), or null. */
export function verdictOf(text) {
  const re = /^[\s>*_`-]*verdict\s*:?[\s*_`]*(pass|fix|you)\b/gim;
  let last = null;
  for (let m = re.exec(String(text ?? "")); m; m = re.exec(String(text ?? ""))) last = m[1].toLowerCase();
  return last;
}

/** Why a turn failed, when layr should go on by itself: a usage limit, a network error, or neither (null). */
export function classifyError(text) {
  const s = String(text ?? "");
  if (/usage limit|limit reached|hit your limit|rate.?limit|\b429\b|quota/i.test(s)) return "limit";
  if (/network|ECONN|ETIMEDOUT|EAI_AGAIN|socket hang up|fetch failed|overloaded|\b52\d\b|\b50[234]\b/i.test(s)) {
    return "network";
  }
  return null;
}

/** A glob (`**` any folders, `*` within one name, `?` one character) as a test for repository paths. */
function globTest(glob) {
  const escape = (s) => s.replace(/[.+^${}()|[\]\\]/g, "\\$&");
  const source = glob
    .trim()
    .replace(/\\/g, "/")
    .replace(/^\.?\//, "")
    .split(/(\*\*\/?|\*|\?)/)
    .map((part) =>
      part === "**/" ? "(?:.*/)?" : part === "**" ? ".*" : part === "*" ? "[^/]*" : part === "?" ? "[^/]" : escape(part),
    )
    .join("");
  return new RegExp(`^${source}$`, "i");
}

/** The changed files on the Always ask paths (one glob per line; lines starting with # are notes). */
export function askPathHits(files, globs) {
  const tests = String(globs ?? "")
    .split("\n")
    .map((g) => g.trim())
    .filter((g) => g && !g.startsWith("#"))
    .map(globTest);
  return files.filter((file) => tests.some((t) => t.test(file.replace(/\\/g, "/"))));
}

/** Whether the user's words name task `n` (`#12`, `12`), for landing a risky one on their word. */
export function wordsName(words, n) {
  return new RegExp(`(^|[^\\d.])#?${n}(?![\\d.])`).test(String(words ?? ""));
}
