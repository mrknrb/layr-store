// The concepts plugin, when it is there: the project's node on the concept map (its sections and rules for launch
// messages and `projects`), tasks linked to the nodes they were made from, those nodes' Status following the task, and
// "needs" edges becoming chains (layr_code's projectMap.ts, conceptLinks.ts, needs.ts).
//
// Its tools are on the hub as concepts__* (docs/ARCHITECTURE.md › Tool access): `layr__plugins_list` says whether the
// plugin is installed and which of its tools the pipeline may call. Without it, or when a call is refused, nothing
// breaks: launch messages leave the map out, links aren't made, and the reason is logged once.
import { errorText } from "./util.js";
import { byNumber } from "./store.js";

export const NODE = "layr://concepts/node/";
export const nodeLink = (id) => `${NODE}${id}`;
/** A claude thread's link (the claude plugin's manifest `links`), for a forgotten task's links. */
export const threadLink = (id) => `layr://claude/thread/${id}`;
const taskLink = (id) => `layr://pipeline/task/${id}`;

/** How long launch messages and pickers wait for the concepts plugin (a call it must ask the user about waits). */
const READ_MS = 10_000;
/** How long a tool list from `layr__plugins_list` is trusted. */
const TOOLS_MS = 60_000;

/** The concept node a link points to, if it does. */
export function nodeOf(link) {
  if (typeof link !== "string" || !link.startsWith(NODE)) return undefined;
  try {
    return decodeURIComponent(link.slice(NODE.length)).replace(/^#/, "") || undefined;
  } catch {
    return undefined;
  }
}

/** Every concept node a task was made from (`from` and `alsoFrom`), as given. */
export const sourceNodes = (task) => [task?.from, ...(task?.alsoFrom ?? [])].map(nodeOf).filter(Boolean);

/** Whether two node ids (full or short) can be the same node. */
export const sameNode = (a, b) => {
  const [x, y] = [String(a).toLowerCase(), String(b).toLowerCase()];
  return x.startsWith(y) || y.startsWith(x);
};

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const short = (id) => `#${String(id).slice(0, 8)}`;

/** A task's title on the map's thread links. */
export const linkTitle = (task) => `#${task.number}${task.title ? ` ${task.title}` : ""}`;

/** What the nodes of a task an agent landed on the user's word say about it (`task.landedFor`). */
export function landedNote(task) {
  const asked = task.landedFor;
  const when = new Date(task.landed.at).toISOString().slice(0, 16).replace("T", " ");
  const by = asked.by ? ` by ${asked.by}` : " by an agent";
  return `Landed as ${task.landed.commit.slice(0, 8)} on ${when} UTC, asked${by} on the user's word: "${asked.words}"`;
}

// ---------------------------------------------------------------- the project map in launch messages

const TITLES = [
  ["rules", "the whole map"],
  ["brainstorm", "Brainstorm"],
  ["features", "Features"],
  ["plan", "Plan"],
];

/**
 * What a worker is told about the project's map (`settings.projectNode`; `map`: concepts__project_map's answer, null
 * when it didn't answer): the steps every task takes on Features, where bugs and ideas outside the task go, and the
 * rules it needs. The same for every task of the project. Without a project node, the feature map's line
 * (`settings.featureMap`), else nothing.
 */
export function projectMapLines(settings, map) {
  const node = settings.projectNode;
  if (!node) return settings.featureMap ? [featureMapLine(settings.featureMap)] : [];
  if (!map) {
    return [
      `- This project's node on the concept map is ${short(node)}: read its sections and their rules with ` +
        "concepts__project before changing it. Keep its Features current before you stop.",
    ];
  }
  const features = short(map.sections?.features ?? map.node);
  const inbox = map.sections?.inbox ? ` (or its Inbox ${short(map.sections.inbox)})` : "";
  const lines = [
    `- Concept map: project "${map.title}" (${short(map.node)}), Features ${features}. Before you stop, for each ` +
      "feature you built or changed: rewrite its description (first child) to say what it does now, add " +
      '"Task #<n>: what changed" to its History child, and tag it Done (a task that only plans adds Idea or Planned ' +
      "features and marks nothing Done). Read the map's rules with concepts__project before adding or moving " +
      "nodes, and check your changes with it.",
    `- A bug or idea outside your task: don't fix it, file it with concepts__file (features: ${features}) under the ` +
      `feature it concerns${inbox}, and list it under ## Problems.`,
  ];
  const rules = map.workerRules ?? map.rules ?? {};
  for (const [key, title] of TITLES) if (rules[key]?.length) lines.push(`- Rules for ${title}: ${rules[key].join(" ")}`);
  return lines;
}

/** The project's feature map (before project nodes): what the worker keeps current before it stops. */
export const featureMapLine = (id) =>
  `- This project's features are on the concept map under ${short(id)} (read it with concepts__read). Keep it ` +
  "current before you stop: give the feature you built or changed its new Status tag (Done once built), and add a " +
  "node for a new feature in its area, its first child a one-sentence description. A task that only plans or " +
  "answers a question may add Idea or Planned features, but marks nothing Done.";

/** The concept nodes the task was made from: the worker gives each its new status. */
export function sourcesLine(task) {
  const nodes = sourceNodes(task).map(short);
  if (!nodes.length) return [];
  const which = nodes.length > 1 ? `these concept nodes (${nodes.join(", ")}), one task for all of them` : nodes[0];
  return [`It was made from ${which}: when you're done, give each the Status tag it has earned (Done once built).`];
}

/** What `projects` says about a project's map: the node and section ids, and what is missing. */
export const mapSummary = (map) => ({
  node: map.node,
  title: map.title,
  ...(map.sections ?? {}),
  ...(map.missing?.length ? { missing: map.missing } : {}),
});

// ---------------------------------------------------------------- "needs" chains

/**
 * The parent from what the nodes need (`needs`: concepts__needs' answer, per node the nodes it needs): of the tasks in
 * the project made from a needed node that haven't landed (and aren't settled without landing), the newest. A task has
 * one parent, so the others are only noted, as are needed nodes not yet Done that have no such task.
 */
export function chainFromNeeds(needs, tasks, projectId) {
  const needed = new Map((needs ?? []).flatMap((n) => n.needs ?? []).map((n) => [n.id, n]));
  const open = tasks.filter(([, t]) => t.projectId === projectId && !t.landed && !t.settledAt);
  const found = [];
  const notes = [];
  for (const node of needed.values()) {
    const made = open.filter(([, t]) => sourceNodes(t).some((s) => sameNode(s, node.id))).sort(([, a], [, b]) => byNumber(b.number, a.number))[0];
    if (made) found.push({ id: made[0], task: made[1] });
    else if (node.status !== "Done") notes.push(`needs "${node.title}" (${short(node.id)}), which has no task`);
  }
  found.sort((a, b) => byNumber(b.task.number, a.task.number));
  const [parent, ...rest] = found;
  for (const other of rest) notes.push(`also needs #${other.task.number} ${other.task.title}`);
  return { ...(parent ? { after: parent.id } : {}), notes };
}

// ---------------------------------------------------------------- the plugin's tools

const within = (promise, ms) =>
  Promise.race([promise, new Promise((_, reject) => setTimeout(() => reject(new Error(`no answer in ${ms / 1000} s`)), ms).unref?.())]);

/** `p`: the pipeline (its hub, store and logger). */
export function createConcepts(p) {
  let tools = null;
  let checkedAt = 0;
  const warned = new Set();
  let queue = Promise.resolve();

  /** The concepts tools the pipeline may call now (none without the plugin or a hub). */
  async function toolNames() {
    if (!p.hub?.available || !p.hub.call) return new Set();
    if (tools && Date.now() - checkedAt < TOOLS_MS) return tools;
    try {
      const { plugins = [] } = (await p.hub.call("layr__plugins_list", {})) ?? {};
      const plugin = plugins.find((x) => x.id === "concepts");
      tools = new Set(plugin && plugin.status !== "failed" ? (plugin.tools ?? []).map((t) => (typeof t === "string" ? t : t.name)) : []);
    } catch (error) {
      warn("plugins_list", error);
      tools = new Set();
    }
    checkedAt = Date.now();
    return tools;
  }

  function warn(kind, error) {
    if (warned.has(kind)) return;
    warned.add(kind);
    p.log(`concepts (${kind}): ${errorText(error)} (further failures of it not logged)`);
  }

  /** Call concepts__<tool>; null when the plugin isn't there or the call failed (logged once per tool). */
  async function call(tool, args, { ms } = {}) {
    if (!(await toolNames()).has(tool)) return null;
    try {
      const work = p.hub.call(`concepts__${tool}`, args);
      const result = ms ? await within(work, ms) : await work;
      warned.delete(tool);
      return result;
    } catch (error) {
      warn(tool, error);
      return null;
    }
  }

  /** One at a time, so a rename can't overtake the link it renames. */
  function later(tool, args, then) {
    queue = queue.then(async () => {
      const result = await call(tool, args);
      if (result && then) await then(result);
    });
    return queue;
  }

  const listOf = (r) => (Array.isArray(r) ? r : Array.isArray(r?.result) ? r.result : null);

  /** The project node's sections and rules, or null. */
  async function projectMap(node) {
    if (!node) return null;
    const map = await call("project_map", { node }, { ms: READ_MS });
    return map && typeof map === "object" && map.node ? map : null;
  }

  /** The task to chain a new one to, from what its nodes need: {after?, notes}. */
  async function needsChain(projectId, nodes) {
    if (!nodes.length) return { notes: [] };
    const needs = listOf(await call("needs", { nodes }, { ms: READ_MS }));
    if (!needs?.length) return { notes: [] };
    return chainFromNeeds(needs, p.store.entries(), projectId);
  }

  /** Nodes for a picker: [{id, label, in}]. */
  async function nodes(query) {
    const found = listOf(await call("nodes", { query }, { ms: READ_MS }));
    if (found) return found;
    const hits = listOf(await call("search", { query }, { ms: READ_MS })) ?? [];
    return hits.map((h) => ({ id: h.id, label: String(h.text ?? h.label ?? "").split("\n")[0] || "(empty)", in: (h.path ?? []).slice(-2).map((x) => x.text ?? x) }));
  }

  /** The nodes linked to each task: {"<task number>": [{id, text}]}. */
  async function linkedNodes() {
    const r = await call("linked_nodes", { prefix: "layr://pipeline/task/" }, { ms: READ_MS });
    if (!r || typeof r !== "object") return {};
    const out = {};
    for (const [link, list] of Object.entries(r)) {
      const n = /\/task\/(\d+(?:-\d+)?)$/.exec(link)?.[1];
      if (n && Array.isArray(list)) out[n] = list;
    }
    return out;
  }

  /**
   * After every task change (`before` undefined: made; `after` undefined: forgotten): its links on the map and its
   * nodes' Status. A task made from nodes is linked to them, a renamed one's links get its new title, a forgotten one
   * passes them to its claude thread (or drops them without one). Its nodes go In progress once its thread exists
   * (a batch's members' too), Done once it lands; landed by an agent on the user's word, the nodes get a note.
   */
  function changed(id, before, after) {
    const link = taskLink(id);
    if (!after) {
      if (before) later("relink", { thread: link, to: before.threadId ? { thread: threadLink(before.threadId), title: linkTitle(before) } : null });
      return;
    }
    const node = nodeOf(after.from);
    const was = before && nodeOf(before.from);
    if (node && !(was && sameNode(was, node))) {
      later("link", { thread: link, title: linkTitle(after), nodes: [node] }, (r) => {
        const full = r?.nodes?.[0];
        if (full && full !== node && !UUID.test(node)) p.store.mutate(id, (t) => (t.from === after.from ? { from: nodeLink(full) } : null));
      });
    }
    const linked = (before?.alsoFrom ?? []).map(nodeOf).filter(Boolean);
    const more = (after.alsoFrom ?? []).map(nodeOf).filter((n) => n && !linked.includes(n));
    if (more.length) later("link", { thread: link, title: linkTitle(after), nodes: more });
    // Adopted: what its thread did on the map before is the task's now.
    if (after.threadId && !before?.threadId && after.source?.kind === "adopted") {
      later("relink", { thread: threadLink(after.threadId), to: { thread: link, title: linkTitle(after) } });
    }
    if (before && linkTitle(before) !== linkTitle(after)) later("relink", { thread: link, to: { thread: link, title: linkTitle(after) } });
    const sources = sourceNodes(after);
    if (after.threadId && !before?.threadId) {
      const all = [...sources, ...(after.batch ? p.members(id).flatMap(([, t]) => sourceNodes(t)) : [])];
      if (all.length) later("advance_status", { nodes: all, status: "In progress" });
    }
    if (sources.length && after.landed && !before?.landed) {
      later("advance_status", { nodes: sources, status: "Done" });
      if (after.landedFor?.words) later("link", { thread: link, title: linkTitle(after), nodes: sources, note: landedNote(after) });
    }
  }

  /** Built and ready to try (its reply ends with Try: ready): the nodes it was made from wait for the user to try it. */
  function readyToTry(task) {
    const nodes = sourceNodes(task);
    if (nodes.length && task.thread?.replyStatus?.try === "ready" && !task.landed) later("advance_status", { nodes, status: "To try" });
  }

  return {
    toolNames,
    available: async () => (await toolNames()).size > 0,
    call,
    projectMap,
    needsChain,
    nodes,
    linkedNodes,
    changed,
    readyToTry,
    setupProjectMap: (node) => call("setup_project_map", { node }),
    /** Waits for the queued link calls (tests). */
    idle: () => queue,
  };
}
