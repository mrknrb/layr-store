// The backend's link to the core's MCP hub (docs/ARCHITECTURE.md > The MCP hub): the claude plugin's tools
// (claude__*), events to the panels and notifications.
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { errorText, log } from "./util.js";

export class Hub {
  constructor({ url, token }) {
    this.url = url;
    this.token = token;
    this.client = null;
    this.connecting = null;
    this.warned = false;
  }

  get available() {
    return Boolean(this.url && this.token);
  }

  async connect() {
    if (this.client) return this.client;
    if (!this.available) throw new Error("No hub: LAYR_HUB_URL and LAYR_HUB_TOKEN are not set");
    this.connecting ??= (async () => {
      const client = new Client({ name: "layr-plugin-pipeline", version: "0.4.0" });
      const transport = new StreamableHTTPClientTransport(new URL(this.url), {
        requestInit: { headers: { Authorization: `Bearer ${this.token}` } },
      });
      client.onclose = () => {
        if (this.client === client) this.client = null;
      };
      await client.connect(transport);
      this.client = client;
      return client;
    })().finally(() => (this.connecting = null));
    return this.connecting;
  }

  /**
   * Call a hub tool; gives its structured content, or its text parsed as JSON when it is JSON. `timeoutMs`: how long
   * the call may take (thread_wait waits minutes; the MCP client's default is a minute).
   */
  async call(name, args = {}, { timeoutMs = 120_000 } = {}) {
    const options = { timeout: timeoutMs, resetTimeoutOnProgress: true };
    let client = await this.connect();
    let result;
    try {
      result = await client.callTool({ name, arguments: args }, undefined, options);
    } catch (error) {
      if (/timed out|timeout/i.test(errorText(error))) throw error;
      // The core may have restarted its HTTP session: connect once more.
      this.client = null;
      client = await this.connect();
      result = await client.callTool({ name, arguments: args }, undefined, options);
    }
    if (result.isError) {
      const text = (result.content ?? []).map((c) => c.text ?? "").join("\n");
      throw new Error(text || `${name} failed`);
    }
    if (result.structuredContent !== undefined) return result.structuredContent;
    const text = (result.content ?? []).filter((c) => c.type === "text").map((c) => c.text).join("\n");
    try {
      return JSON.parse(text);
    } catch {
      return text;
    }
  }

  /** Fire and forget: an event for the panels. Failures are logged once, not thrown. */
  emit(topic, data) {
    if (!this.available) return;
    this.call("layr__events_emit", { topic, data }).catch((error) => {
      if (!this.warned) {
        this.warned = true;
        log(`events_emit failed (further failures not logged): ${errorText(error)}`);
      }
    });
  }

  notify(text, kind = "info") {
    if (!this.available) return;
    this.call("layr__notify", { text, kind }).catch(() => {});
  }

  async close() {
    try {
      await this.client?.close();
    } catch {
      // closing anyway
    }
  }
}
