// Worktrees and disk space (0.8.0). A settled task whose work is on the base branch loses its worktree and local
// branch (Remove merged worktrees, a project setting): its card and thread stay, and the claude plugin makes the
// worktree again in the same folder, from the newest base, when the thread gets a message. Landed tasks settle by
// themselves some days after landing (Settle landed tasks after). "Branches & worktrees" lists a project's worktrees
// and its task branches that aren't landed: their task, whether removing them loses anything (and why), their size
// (measured in the background: build folders are slow to walk) and the drive's free space (the core's disk.free).
import { existsSync } from "node:fs";
import { isActive, usesSlot } from "./columns.js";
import { notLanded } from "./branches.js";
import { aheadBehind, deleteBranch, folderSize, removable, removeWorktree, samePath, worktreeList } from "./git.js";
import { baseRef, taskLink } from "./prompts.js";
import { errorText, nowIso } from "./util.js";

const DAY_MS = 86_400_000;
const HOUR_MS = 3_600_000;
/** A worktree's measured size is good for this long. */
const SIZE_TTL_MS = DAY_MS;

const key = (dir) => String(dir).toLowerCase().replace(/[\\/]+$/, "");
const ms = (iso) => (iso ? Date.parse(iso) || 0 : 0);

export function createWorktrees(p) {
  /** Measured sizes by folder: { bytes, at }. */
  const sizes = new Map();
  /** Folders waiting to be measured, and whether measuring runs. */
  const toMeasure = new Set();
  let measuring = false;

  /** A task that works now (or lands, or is checked): its worktree stays. */
  const busy = (id, t) =>
    p.busy.has(id) || usesSlot(t) || isActive(t.thread) || !!t.landing || t.verify?.state === "running" || !!t.held?.length;

  /** The commit a task landed as, while its worktree still is that commit (a squashed pull request isn't an ancestor). */
  const landedHead = (t) => (t.landed ? (t.landed.head ?? t.landed.commit ?? null) : null);

  /** Landed tasks in Stopped settle `settleLandedAfterDays` after landing (or after a later turn). */
  function settleLanded(now = Date.now()) {
    for (const [id, t] of p.store.entries()) {
      if (!t.landed || t.settledAt || t.inBatch || !t.threadId || busy(id, t)) continue;
      const days = p.store.project(t.projectId).settleLandedAfterDays;
      if (days === null || days === undefined) continue;
      // Unsettled after it landed: you took it back, it stays until it lands again.
      if (ms(t.unsettledAt) > ms(t.landed.at)) continue;
      const since = Math.max(ms(t.landed.at), ms(t.thread?.turnEndedAt));
      if (now - since < days * DAY_MS) continue;
      if (p.placement(id, t).column !== "stopped") continue;
      p.settle(id);
      p.store.mutate(id, () => ({ settledBy: "landed" }));
      p.log(`#${id}: landed ${days} day(s) ago, so it is settled`);
    }
  }

  /**
   * Remove a task's worktree and local branch when that loses nothing. `force`-less: never with uncommitted or
   * untracked files, or commits the base lacks. Gives { removed } or { removed: false, why }.
   */
  async function removeForTask(id) {
    const t = p.store.get(id);
    if (!t) return { removed: false, why: "there is no such task" };
    const repo = p.repoOf(t.projectId);
    const dir = t.worktreePath;
    if (!repo || !dir || t.noWorktree || samePath(repo, dir)) return { removed: false, why: "it has no worktree of its own" };
    if (busy(id, t)) return { removed: false, why: "its thread is working" };
    if (!existsSync(dir)) {
      if (!t.worktreeRemoved) p.store.mutate(id, () => ({ worktreeRemoved: { at: nowIso() }, worktreeProblem: undefined }));
      return { removed: false, why: "it's gone already" };
    }
    const check = await removable(dir, baseRef(p.store.project(t.projectId)), landedHead(t));
    if (!check.safe) return { removed: false, why: check.why };
    try {
      await removeWorktree(repo, dir);
    } catch (error) {
      const text = errorText(error).slice(-300);
      p.store.mutate(id, () => ({ worktreeProblem: { at: nowIso(), text } }));
      p.log(`#${id}: couldn't remove its worktree:`, text);
      return { removed: false, why: `couldn't remove it: ${text}` };
    }
    if (t.branch) await deleteBranch(repo, t.branch).catch(() => {});
    sizes.delete(key(dir));
    p.store.mutate(id, () => ({ worktreeRemoved: { at: nowIso(), head: check.head }, worktreeProblem: undefined }));
    p.log(`#${id}: its work is on the base branch, so its worktree ${dir} was removed`);
    return { removed: true };
  }

  /** Settled tasks whose work is on the base branch lose their worktree (projects with Remove merged worktrees). */
  async function removeMerged(now = Date.now()) {
    for (const [id, t] of p.store.entries()) {
      if (!t.threadId || t.noWorktree || !t.worktreePath || t.inBatch) continue;
      const there = existsSync(t.worktreePath);
      // Made again (its thread got a message): it's a worktree like any other again.
      if (there && t.worktreeRemoved) p.store.mutate(id, () => ({ worktreeRemoved: undefined }));
      if (!there || !t.settledAt || t.discarded) continue;
      const settings = p.store.project(t.projectId);
      if (!settings.removeWorktrees) continue;
      if (now - ms(t.settledAt) < settings.removeWorktreesAfterHours * HOUR_MS) continue;
      await removeForTask(id);
    }
  }

  /** One round of both, from the pipeline's cleanup. */
  async function tick() {
    settleLanded();
    await removeMerged();
  }

  function measureLater(dirs) {
    for (const dir of dirs) {
      const known = sizes.get(key(dir));
      if (!known || Date.now() - known.at > SIZE_TTL_MS) toMeasure.add(dir);
    }
    if (measuring || !toMeasure.size) return;
    measuring = true;
    void (async () => {
      try {
        while (toMeasure.size) {
          const [dir] = toMeasure;
          toMeasure.delete(dir);
          if (existsSync(dir)) sizes.set(key(dir), { bytes: await folderSize(dir), at: Date.now() });
        }
      } catch (error) {
        p.log("measuring worktrees failed:", errorText(error));
      } finally {
        measuring = false;
        p.hub.emit("pipeline:worktrees", { at: nowIso() });
      }
    })();
  }

  /** The drive's free space (the core's disk.free; null on a core without it). */
  async function drive(dir) {
    try {
      const d = await p.hub.call("layr__disk_free", { path: dir });
      return d && typeof d === "object" && Number.isFinite(d.free) ? d : null;
    } catch {
      return null;
    }
  }

  /**
   * A project's worktrees (not its own checkout) and its task branches that aren't landed and have none:
   * { projectId, drive, measuring, rows: [{ kind: worktree|branch, path?, branch, task?, ahead, behind, removable,
   * why?, bytes?, measuredAt? }] }. `measure`: measure every size again now (in the background).
   */
  async function list(projectId, { measure = false } = {}) {
    const settings = p.store.project(projectId);
    const repo = p.repoOf(projectId);
    if (!repo) throw new Error(`The project ${projectId} has no folder`);
    const ref = baseRef(settings);
    const byPath = new Map();
    const byBranch = new Map();
    for (const [id, t] of p.store.entries()) {
      if (t.projectId !== projectId) continue;
      if (t.worktreePath && !t.noWorktree) byPath.set(key(t.worktreePath), id);
      if (t.branch) byBranch.set(t.branch, id);
    }
    const taskOf = (id) => {
      if (!id) return null;
      const v = p.view(id);
      return { number: v.number, title: v.title, column: v.column, state: v.state, link: taskLink(id), landed: !!v.landed };
    };
    const rows = [];
    for (const tree of await worktreeList(repo)) {
      if (tree.main || tree.bare) continue;
      const id = byPath.get(key(tree.path)) ?? (tree.branch ? byBranch.get(tree.branch) : null);
      const t = id ? p.store.get(id) : null;
      const check = await removable(tree.path, ref, t ? landedHead(t) : null);
      const working = t && busy(id, t);
      const counts = tree.branch ? await aheadBehind(repo, tree.branch, ref).catch(() => null) : null;
      const size = sizes.get(key(tree.path));
      rows.push({
        kind: "worktree",
        path: tree.path,
        branch: tree.branch,
        ...(counts ?? {}),
        task: taskOf(id),
        removable: check.safe && !working,
        ...(working ? { why: "its thread is working" } : check.safe ? {} : { why: check.why }),
        ...(size ? { bytes: size.bytes, measuredAt: new Date(size.at).toISOString() } : {}),
      });
    }
    const listed = new Set(rows.map((r) => r.branch).filter(Boolean));
    for (const b of await notLanded(p, projectId)) {
      if (b.worktree || listed.has(b.branch)) continue;
      rows.push({ kind: "branch", branch: b.branch, ahead: b.ahead, behind: b.behind, task: b.task ?? null, removable: false, why: "no worktree; its work isn't on the base branch" });
    }
    if (measure) for (const r of rows) if (r.path) sizes.delete(key(r.path));
    measureLater(rows.filter((r) => r.path).map((r) => r.path));
    return { projectId, base: ref, drive: await drive(repo), measuring, rows };
  }

  /** Remove one worktree (`dir`), or every one that's safe (`all`): only those that lose nothing. Gives { removed, kept }. */
  async function remove(projectId, { dir, all = false } = {}) {
    if (!dir && !all) throw new Error("Which worktree? Give `path`, or `all: true` for every one that's safe to remove");
    const { rows } = await list(projectId);
    const chosen = all ? rows.filter((r) => r.kind === "worktree" && r.removable) : rows.filter((r) => r.path && samePath(r.path, dir));
    if (!all && !chosen.length) throw new Error(`${dir} isn't a worktree of this project`);
    const repo = p.repoOf(projectId);
    const removed = [];
    const kept = [];
    for (const r of chosen) {
      if (!r.removable) {
        kept.push({ path: r.path, why: r.why });
        continue;
      }
      const id = p.store.entries().find(([, t]) => t.projectId === projectId && t.worktreePath && samePath(t.worktreePath, r.path))?.[0];
      if (id) {
        const done = await removeForTask(id);
        (done.removed ? removed : kept).push(done.removed ? r.path : { path: r.path, why: done.why });
        continue;
      }
      try {
        await removeWorktree(repo, r.path);
        if (r.branch) await deleteBranch(repo, r.branch).catch(() => {});
        sizes.delete(key(r.path));
        removed.push(r.path);
      } catch (error) {
        kept.push({ path: r.path, why: `couldn't remove it: ${errorText(error).slice(-300)}` });
      }
    }
    if (removed.length) p.log(`removed ${removed.length} worktree(s) of ${projectId}`);
    p.emitChanged();
    return { removed, kept };
  }

  return { tick, settleLanded, removeMerged, removeForTask, list, remove, sizes };
}
