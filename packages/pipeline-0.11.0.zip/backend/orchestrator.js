// The orchestrator (ported from layr_code's plugins/chat orchestrator: shared/orchestrator.ts, backend/orchestrator.ts).
// Every few minutes layr looks at the board without Claude (`look`: the mode, proposals it may run, workers asking,
// tasks that look alike, and while proposals wait the running count and the account's usage), and wakes Claude in a
// new check-in thread only when something it can act on changed, a task or scout ended while you're Away, a while
// passed while you're Away, or work has waited three hours. One check-in at a time. In Soft stop it doesn't wake by
// itself. It can schedule a check-in for itself (`pipeline__orchestrator` wake).
//
// A check-in is a claude plugin thread in the pipeline's own folder (a claude project "Pipeline orchestrator"), in
// `dontAsk` mode with the pipeline's tools and read-only file tools allowed; abilities set to never lose their tools.
// You can read and answer it in the claude plugin's thread panel. layr_code's parts about the concept map (approved
// ideas, memory nodes), the accounts plugin and T3 Code are left out: the new layr's pipeline has none of them.
import { mkdirSync } from "node:fs";
import path from "node:path";
import { isActive } from "./columns.js";
import { errorText, LOOKALIKE, nowIso, similarity, snippet } from "./util.js";

export const FIRST_LOOK_MS = 2 * 60_000;
/** With proposals it may run waiting, a check-in at least this often, even when nothing changed. */
export const WAITING_MS = 3 * 60 * 60_000;
export const WAKE_MAX_MIN = 7 * 24 * 60;
const THREADS_KEPT = 50;
const LOG_LINES = 20;
const EVERY_SLACK_MS = 2 * 60_000;
const WEEKLY_STEP = 20;
const FIVE_HOUR_FULL = 90;
export const NOTHING = "nothing that wakes it changed";

const MODE = {
  stop: "Soft stop (nothing new starts: the user may shut the PC down or needs the tokens)",
  here: "Here (the user is at the PC: tasks marked Plan plan and ask them now)",
  away: "Away (the user is away: planned and approved work goes; nobody answers until they are back)",
};

/** Abilities: their setting, what they cover, and the tools they take away when set to never. */
export const ABILITIES = [
  { key: "orchestratorRun", label: "Running proposals", tools: ["run"] },
  { key: "orchestratorAnswer", label: "Answering workers' questions and messaging their threads", tools: ["send"] },
  { key: "orchestratorScouts", label: "Sending scouts and proposing tasks", tools: ["scout", "propose", "edit", "act"] },
  { key: "orchestratorSettings", label: "Switching the mode and changing pipeline settings", tools: ["mode", "configure"] },
];
const BASE_TOOLS = [
  "guide", "projects", "tasks", "task", "state", "settings", "propose", "edit", "run", "send", "act", "mode",
  "configure", "scout", "scouts", "brief", "orchestrator",
];
const LEEWAY_RULE = {
  quiet: "do it when it helps; your report needn't mention it",
  tell: "do it when it helps, and say in your report what you did and why",
  ask: "don't do it on your own: suggest it in your report, and do it only once the user says yes in this thread",
  never: "never: its tools are taken away; don't try a way around it",
};

/** The tools a check-in may use (dontAsk denies the rest). */
export function toolsFor(settings) {
  const never = new Set(ABILITIES.filter((a) => settings[a.key] === "never").flatMap((a) => a.tools));
  return ["Read", "Grep", "Glob", ...BASE_TOOLS.filter((t) => !never.has(t)).map((t) => `mcp__layr__pipeline__${t}`)];
}

// ---------------------------------------------------------------- the look (no Claude)

const runnable = (s) => s.tasks?.filter((t) => t.column === "proposed" && t.start !== "manual" && !t.plan && !t.whenAway) ?? [];
const runningCount = (s) => s.tasks?.filter((t) => t.column === "running").length ?? 0;
const asking = (s) => s.tasks?.filter((t) => t.asks) ?? [];
const weeklyStep = (u) => Math.floor((u?.weekly ?? 0) / WEEKLY_STEP);
const fiveHourFull = (u) => (u?.fiveHour ?? 0) >= FIVE_HOUR_FULL;
const pairKey = (p) => `${p.a}-${p.b}`;

/** What wakes Claude: only what it can act on (task #260 in layr_code). */
export function fingerprint(s) {
  const waiting = runnable(s);
  return JSON.stringify({
    mode: s.mode ?? null,
    asks: asking(s).map((t) => t.number).sort(),
    tasks: waiting.map((t) => `${t.number}${t.start === "agents" ? ":approved" : ""}`).sort(),
    running: waiting.length ? runningCount(s) : null,
    lookalikes: (s.lookalikes ?? []).map(pairKey).sort(),
    usage: waiting.length && s.usage ? [weeklyStep(s.usage), fiveHourFull(s.usage)] : null,
  });
}

/** What changed, in words (what `fingerprint` watches). */
export function changes(before, after) {
  if (!before) return ["first check-in"];
  const out = [];
  if (before.mode && after.mode && before.mode !== after.mode) out.push(`the user switched to ${MODE[after.mode]}`);
  const waiting = runnable(after);
  const was = new Map(runnable(before).map((t) => [t.number, t]));
  for (const t of waiting) {
    const earlier = was.get(t.number);
    if (!earlier) out.push(`#${t.number} proposed${t.start === "agents" ? ", approved for you to start" : ""}`);
    else if (t.start === "agents" && earlier.start !== "agents") out.push(`#${t.number} approved for you to start`);
  }
  const asked = new Set(asking(before).map((t) => t.number));
  for (const t of asking(after)) if (!asked.has(t.number)) out.push(`#${t.number} asks a question`);
  const [from, to] = [runningCount(before), runningCount(after)];
  if (waiting.length && to < from) out.push(`a running slot freed up (${to} running, was ${from})`);
  const had = new Set((before.lookalikes ?? []).map(pairKey));
  for (const p of after.lookalikes ?? []) if (!had.has(pairKey(p))) out.push(`#${p.a} and #${p.b} look alike`);
  if (waiting.length && before.usage && after.usage) {
    const [a, b] = [weeklyStep(before.usage), weeklyStep(after.usage)];
    if (b < a) out.push("the weekly window reset");
    else if (b > a) out.push(`weekly usage passed ${b * WEEKLY_STEP}%`);
    if (fiveHourFull(before.usage) !== fiveHourFull(after.usage)) out.push(`the 5-hour window ${fiveHourFull(after.usage) ? "is nearly full" : "has room again"}`);
  }
  return out.length ? out : [NOTHING];
}

/** Tasks that ran and scouts that were out at `before` and have ended since. */
export function endings(before, after) {
  if (!before) return [];
  const out = [];
  const now = new Map((after.tasks ?? []).map((t) => [t.number, t]));
  for (const t of before.tasks ?? []) {
    if (t.column !== "running") continue;
    const later = now.get(t.number);
    if (later?.column !== "running") out.push(`#${t.number} ended (${later ? later.column : "settled"})`);
  }
  const ended = (before.scoutIds ?? []).filter((id) => !(after.scoutIds ?? []).includes(id)).length;
  if (ended) out.push(ended === 1 ? "a scout ended" : `${ended} scouts ended`);
  return out;
}

export const workWaits = (s) => runnable(s).length > 0;

/** While you're Away, the every-so-often check-in is due. */
export function everyDue(settings, mode, ranAt, now = Date.now()) {
  const min = mode === "away" ? settings.orchestratorAwayEveryMin : 0;
  if (min <= 0) return false;
  return !ranAt || now - Date.parse(ranAt) > min * 60_000 - EVERY_SLACK_MS;
}

/** Pairs of proposals of one project that look like the same work (shared words). */
export function lookalikes(tasks) {
  const props = tasks.filter((t) => t.column === "proposed");
  const out = [];
  for (let i = 0; i < props.length; i++) {
    for (let j = i + 1; j < props.length; j++) {
      const [x, y] = [props[i], props[j]];
      if (x.projectId !== y.projectId) continue;
      const score = similarity(`${x.title} ${x.prompt}`, `${y.title} ${y.prompt}`);
      if (score >= LOOKALIKE) out.push({ a: Math.min(x.number, y.number), b: Math.max(x.number, y.number), score: Math.round(score * 100) / 100 });
    }
  }
  return out.slice(0, 10);
}

// ---------------------------------------------------------------- the prompt

const clock = (iso) => new Date(iso).toLocaleString("en-GB", { weekday: "short", hour: "2-digit", minute: "2-digit" });

export function describeState(s, extra = {}) {
  const startNote = (t) =>
    t.asks ? ", its worker asks a question" : t.start === "manual" ? ", the user starts it" : t.start === "agents" ? ", approved: start it when there is room" : t.plan ? ", plans first: its work waits for the user's Approve" : t.whenAway ? ", waits for the user's Away" : "";
  const tasks = s.tasks?.length ? s.tasks.map((t) => `- #${t.number} ${t.title} — ${t.column}${t.size ? `, size ${t.size}` : ""}${startNote(t)}`) : ["- none"];
  const titles = new Map((s.tasks ?? []).map((t) => [t.number, t.title]));
  const pairs = s.lookalikes?.length ? ["", "Tasks that look like the same work (guessed from shared words):", ...s.lookalikes.map((p) => `- #${p.a} ${titles.get(p.a) ?? ""} and #${p.b} ${titles.get(p.b) ?? ""}`)] : [];
  const usage = s.usage
    ? [`- 5-hour window ${s.usage.fiveHour ?? "?"}%${s.usage.fiveHourResets ? ` (resets ${clock(s.usage.fiveHourResets)})` : ""}, weekly ${s.usage.weekly ?? "?"}%${s.usage.weeklyResets ? ` (resets ${clock(s.usage.weeklyResets)})` : ""}`]
    : ["- not measured"];
  return [
    `The user's mode: ${s.mode ? MODE[s.mode] : "unknown"}`,
    "",
    "Pipeline tasks not settled:",
    ...tasks,
    ...pairs,
    ...(extra.scouts?.length ? ["", "Scouts (running, waiting, and the last week's runs):", ...extra.scouts] : []),
    ...(extra.pipeline ? ["", `The pipeline: ${extra.pipeline}`] : []),
    "",
    "The Claude account's usage (the user has two accounts and switches near the limit, so high usage alone is no reason to hold work back):",
    ...usage,
  ].join("\n");
}

export function checkInPrompt({ why, snapshot, settings, scouts, pipeline, log, projects }) {
  const abilities = ABILITIES.map((a) => `- ${a.label}: ${LEEWAY_RULE[settings[a.key]] ?? LEEWAY_RULE.tell}.`);
  return [
    "You are the orchestrator of the user's layr pipeline: coding tasks that run as Claude threads in their own " +
      "worktrees and land on the base branch. The pipeline's tools are yours (mcp__layr__pipeline__*): read " +
      "pipeline__guide once if you haven't. You also have Read, Grep and Glob on the PC; nothing else.",
    "",
    "What you may do, and how far the user lets you go (this wins over the rest):",
    ...abilities,
    "- Run proposals at a pace the accounts can carry (pipeline__pacing: what each task costs and the room left); " +
      "proposals the user approved for you (start agents) come first, " +
      "without weighing them again. Never run one the user starts themselves (start manual) or one that plans first. " +
      "Don't queue more than about two beyond what is running. In Soft stop nothing you run starts: don't run anything.",
    "- Workers' questions: answer (pipeline__send with requestId and answers, or a message) only what you can judge " +
      "from the task and the code; leave the user's decisions (intent, product choices, taste) to them.",
    "- Tasks that look alike: read both (pipeline__task); when they are the same work, move what the later proposal " +
      "adds into the other (pipeline__edit) and drop it (pipeline__act drop, with the reason).",
    "- Scouts (pipeline__scout): send one when it is worth it, each with a `focus` drawn from what you see (tasks that " +
      "failed or keep stopping, areas with bugs) and not one looked for lately (the Scouts list below).",
    "- Always ask the user first: database changes (schema, migrations, production data), anything that costs money. " +
      "Never land a task: landing is the user's.",
    ...(settings.orchestratorRules?.trim() ? ["", "The user's standing rules:", settings.orchestratorRules.trim()] : []),
    ...(projects?.length ? ["", "Projects that wake you:", ...projects.map((x) => `- ${x.name} (${x.id})`)] : []),
    ...(log?.length ? ["", "Your earlier check-ins (oldest first):", ...log.map((l) => `- ${l.at}: ${l.log}`)] : []),
    "",
    `Why you're awake now: ${why.join("; ")}.`,
    "",
    describeState(snapshot, { scouts, pipeline }),
    "",
    "Act on what woke you, as far as your leeway allows; then reply in a few lines: what you did and why, and what " +
      "the user should decide. To check in again at a set time (e.g. when a window resets), call pipeline__orchestrator " +
      "with action wake. End with one line `Log: <what you did, in a few words>` (start it with `Nothing to do` when " +
      "you did nothing, or `Quietly` when you only did what you may do quietly).",
  ].join("\n");
}

/** What a Decide round may use: read files, read the board, and answer workers (never land). */
export const ROUND_TOOLS = ["Read", "Grep", "Glob", ...["guide", "projects", "tasks", "task", "state", "send"].map((t) => `mcp__layr__pipeline__${t}`)];

export function decideRoundPrompt(lines) {
  return [
    "You run a Decide round for the user's layr pipeline: coding tasks that run as Claude threads in their own " +
      "worktrees and land on the base branch. Below is everything that waits for the user now. You have the " +
      "pipeline's tools (read pipeline__guide once) and Read, Grep and Glob on the PC; nothing else.",
    "",
    "1. Answer what you can judge yourself from the task and the code (pipeline__send to that task, with requestId " +
      "and answers for a waiting question, or a message): only questions with a clear answer the code or the task " +
      "gives. Leave the user's decisions (intent, product choices, taste, anything about the database or money) to " +
      "them. Never land, discard or settle anything.",
    "2. List what is safe to land: tasks whose reply says Status: done with no risky Risk (database, data, " +
      "breaking), each with one line on why, as `layr://pipeline/task/<number>` links.",
    "3. Merge the workers' open questions into one numbered list in the user's question format, under `## " +
      "Questions`: each question starts with the task (`#12:`), its answers lettered (`- A. ⭐ … (90%) **why**`), the " +
      "recommended one starred, so the user answers all of them at once in this thread.",
    "Reply with these, under the headings `## Summary`, `## Answered`, `## Safe to land` and `## Questions`. When the " +
      "user answers here, pass each answer on to its task with pipeline__send.",
    "",
    "## What waits",
    "",
    ...lines,
  ].join("\n");
}

/** The user's question format (their CLAUDE.md), for the ready-made rounds' questions. */
export const QUESTION_FORMAT =
  "Ask in the user's question format: under `## Questions`, numbered questions, each starting with how " +
  "controversial it is (1-10) and the task it is about (`[#12 Title](layr://pipeline/task/12)`), its answers as " +
  "indented items `- A. ⭐ The answer (80%) **why**`, a ⭐ on the recommended one; the user replies with numbers and " +
  'letters ("My answers: 1B, 2A", or "I agree with everything recommended").';

/**
 * The ready-made rounds next to the Decide round (layr_code's orchestrator commands): each a thread like the Decide
 * round's, in the orchestrator's folder: `label` (the board's menu), `tools` (beyond Read, Grep, Glob and reading the
 * board), `prompt(focus, projectId)`.
 */
export const ROUNDS = {
  stuck: {
    label: "What's stuck?",
    tools: ["send", "run", "act", "stop", "wake", "scouts", "updates", "branches"],
    prompt: () =>
      "What is stuck right now? Look at the pipeline's state (pipeline__state), the tasks waiting for a slot, failing, " +
      "stopped by layr or stopping again and again (pipeline__tasks, pipeline__task), branches not landed " +
      "(pipeline__branches), scouts and updates. For each: why it is stuck and what would get it moving. Do what " +
      "only needs the pipeline's own tools and no decision of the user's (send a worker the fact it lacks, run again " +
      "what failed on a network error), say what you did, and ask the user about the rest. " +
      QUESTION_FORMAT +
      " Reply under `## Summary`, `## Done`, `## Questions`.",
  },
  land_safe: {
    label: "Land the safe ones",
    tools: ["land"],
    prompt: (focus) =>
      "List the finished tasks that are safe to land: Status done, verifier passed (or off), Risk none, no open " +
      "questions, nothing on the project's always-ask paths (pipeline__task shows `asksFirst`). One line each with " +
      "its link (`layr://pipeline/task/<n>`) and what it changes. Land nothing yet" +
      (focus?.trim()
        ? `, unless the user's words below already say to land them (then land those, quoting them): "${focus.trim()}".`
        : ".") +
      " Then ask the user once whether to land them all (one question in their format, with the answers land all, " +
      "land some (say which), land none). " +
      QUESTION_FORMAT +
      " When they say yes, land each with pipeline__land, quoting their words, and say what landed.",
  },
  running: {
    label: "Brief me on what's running",
    tools: [],
    prompt: () =>
      "Brief me on what is running: each running task (pipeline__tasks column running) with its link, what it is " +
      "doing now (pipeline__task: its last reply; Read its worktree's recent changes when that helps), how far it " +
      "is, and anything I should know or decide. Short: a few lines per task, under `## Summary` and `## Running`; " +
      "anything to decide under `## Questions`. " +
      QUESTION_FORMAT,
  },
  scout: {
    label: "Send a scout",
    tools: ["scout", "scouts"],
    prompt: (focus, projectId) =>
      `The user wants a scout to look for: "${focus?.trim() || "(they didn't say)"}"` +
      (projectId ? ` in project ${projectId}.` : ".") +
      " Pick the project (pipeline__projects) and the kind (code or friction) that fit, write the scout a precise " +
      "`focus` and, when it is clear, an `area`, and send it with pipeline__scout. When what to look for or where " +
      "is unclear, don't guess: ask first. " +
      QUESTION_FORMAT +
      " Reply with what you sent (its project, kind, focus) and how to follow it (pipeline__scouts).",
  },
};

/** A ready-made round's whole first message: what it is for, its job, and the board as it is now. */
export function roundPrompt(kind, lines, { focus, projectId } = {}) {
  return [
    "You run a ready-made round for the user's layr pipeline: coding tasks that run as Claude threads in their own " +
      "worktrees and land on the base branch. You have the pipeline's tools named below (read pipeline__guide once) " +
      "and Read, Grep and Glob on the PC; nothing else. Never discard or delete anything.",
    "",
    ROUNDS[kind].prompt(focus, projectId),
    "",
    "## The board now",
    "",
    ...(lines.length ? lines : ["(no tasks)"]),
  ].join("\n");
}

/** A reply's `Log:` line (the last one counts) and the text without it. */
export function parseReply(text) {
  let log;
  const kept = String(text ?? "")
    .split("\n")
    .filter((line) => {
      const m = line.match(/^\s*\**Log:?\**:?\s*(.+)$/i);
      if (m) {
        log = m[1].trim().replace(/\*+$/, "").trim();
        return false;
      }
      return true;
    });
  return { text: kept.join("\n").trim(), ...(log ? { log } : {}) };
}

export const isQuiet = (log) => !!log && /^(nothing to do|quietly)/i.test(log);

// ---------------------------------------------------------------- on the PC

export function createOrchestrator(p, scouts, { dataDir }) {
  const { store } = p;
  let nextLook = Date.now() + FIRST_LOOK_MS;
  let lookMin = store.global().orchestratorLookMin;
  let starting = false;
  const st = () => store.crew("orchestrator", { status: { headline: "Not started yet" }, threads: [] });
  const save = (patch) => store.setCrew("orchestrator", { ...st(), ...patch });
  const saveStatus = (patch) => save({ status: { ...(st().status ?? {}), ...patch } });
  const running = () => (st().threads ?? []).find((t) => t.status === "running");

  /** Projects whose changes wake it (the rest are left out of the look). */
  function watched() {
    return p.projectsCache.filter((x) => store.projectSaved(x.id) && store.project(x.id).enabled && store.project(x.id).orchestratorWake === "events");
  }

  /** The state, without Claude. */
  function look() {
    const ids = new Set(watched().map((x) => x.id));
    const tasks = store
      .entries()
      .filter(([, t]) => ids.has(t.projectId) && !t.inBatch)
      .map(([id, t]) => ({ id, t, place: p.placement(id, t) }))
      .filter(({ place }) => place.column !== "settled")
      .map(({ t, place }) => ({
        number: t.number,
        title: t.title,
        column: place.column,
        projectId: t.projectId,
        prompt: (t.prompt ?? "").slice(0, 2000),
        ...(t.size ? { size: t.size } : {}),
        ...(!t.threadId ? { start: t.start } : {}),
        ...(t.plan || t.planning ? { plan: true } : {}),
        ...(t.whenAway ? { whenAway: true } : {}),
        ...(place.why === "question" ? { asks: true } : {}),
      }));
    const reading = p.limits.reading();
    const usage = reading
      ? { fiveHour: reading.fiveHour?.pct ?? null, fiveHourResets: reading.fiveHour?.resetsAt ?? null, weekly: reading.weekly?.pct ?? null, weeklyResets: reading.weekly?.resetsAt ?? null }
      : null;
    const scoutIds = (scouts.state().active ?? []).map((a) => a.id);
    const pairs = lookalikes(tasks);
    const lean = tasks.map(({ prompt: _p, projectId: _id, ...t }) => t);
    return { at: nowIso(), mode: store.global().mode, tasks: lean, usage, scoutIds, lookalikes: pairs };
  }

  /** The claude project its check-ins run in: the pipeline's own folder. */
  async function projectId() {
    const known = st().projectId;
    if (known && p.projectsCache.some((x) => x.id === known)) return known;
    const folder = path.join(dataDir, "orchestrator");
    mkdirSync(folder, { recursive: true });
    const project = await p.claude.addProject(folder, "Pipeline orchestrator");
    save({ projectId: project.id });
    return project.id;
  }

  function decisionLog() {
    return (st().threads ?? [])
      .filter((t) => t.log)
      .slice(-LOG_LINES)
      .map((t) => ({ at: clock(t.at), log: t.log }));
  }

  /** A check-in: a new thread with what woke it; its turn's end is seen by `see`. */
  async function checkIn(why, snapshot, trigger = "look") {
    if (running() || starting) return { started: false, why: "A check-in runs already" };
    starting = true;
    try {
      const settings = store.global();
      const prompt = checkInPrompt({
        why,
        snapshot,
        settings,
        scouts: scouts.lines(),
        pipeline: [p.status().headline, p.pacing.summary().line].filter(Boolean).join(" · "),
        log: decisionLog(),
        projects: watched(),
      });
      const thread = await p.claude.start({
        project: await projectId(),
        prompt,
        title: `Check-in: ${snippet(why.join("; "), 70)}`,
        workspace: "project",
        model: settings.orchestratorModel,
        ...(settings.orchestratorEffort ? { effort: settings.orchestratorEffort } : {}),
        permissionMode: "dontAsk",
        allowedTools: toolsFor(settings),
      });
      const entry = { threadId: thread.id, why: why.join("; "), trigger, at: nowIso(), status: "running", snapshot };
      save({ threads: [...(st().threads ?? []), entry].slice(-THREADS_KEPT) });
      saveStatus({ headline: `Checking in: ${snippet(why.join("; "), 120)}`, checkedAt: snapshot.at });
      p.wake();
      return { started: true, threadId: thread.id };
    } catch (error) {
      saveStatus({ headline: `Check-in failed: ${errorText(error)}`, ranAt: nowIso(), snapshot });
      throw error;
    } finally {
      starting = false;
    }
  }

  function followed() {
    return (st().threads ?? []).filter((t) => t.status === "running").map((t) => ({ thread: t.threadId, see: (s) => see(t.threadId, s) }));
  }

  /** A check-in's thread changed: once its turn is over, keep its log line and the state it left. */
  async function see(threadId, s) {
    const entry = (st().threads ?? []).find((t) => t.threadId === threadId);
    if (!entry || entry.status !== "running") return;
    if (s && (isActive(s) || s.status === "waiting")) return;
    const reply = s ? ((await p.claude.lastReply(threadId).catch(() => null)) ?? "") : "";
    const parsed = parseReply(reply);
    const status = !s ? "gone" : s.status === "done" ? "done" : s.status;
    const threads = (st().threads ?? []).map((t) =>
      t.threadId === threadId ? { ...t, status, endedAt: nowIso(), ...(parsed.log ? { log: parsed.log, quiet: isQuiet(parsed.log) } : {}), snapshot: undefined } : t,
    );
    save({ threads });
    const after = look();
    saveStatus({ headline: status === "done" ? `Checked in: ${parsed.log ?? "done"}` : `Check-in ${status}`, ranAt: nowIso(), snapshot: status === "done" ? after : entry.snapshot });
  }

  /** Once a look: a scheduled check-in whose time has come, else a look when one is due. */
  async function pulse(now = Date.now()) {
    const settings = store.global();
    if (settings.orchestratorLookMin !== lookMin) {
      nextLook = Math.min(nextLook, now + settings.orchestratorLookMin * 60_000);
      lookMin = settings.orchestratorLookMin;
    }
    const wake = st().wake;
    if (wake && Date.parse(wake.at) <= now && !running()) {
      save({ wake: undefined });
      await checkIn([`the check-in you scheduled: ${wake.note}`], look(), "scheduled").catch((error) => p.log("orchestrator:", errorText(error)));
      return;
    }
    if (!settings.orchestrator || now < nextLook) return;
    nextLook = now + lookMin * 60_000;
    await lookNow(false).catch((error) => p.log("orchestrator:", errorText(error)));
  }

  /** Look at the state; wake Claude when something it can act on changed (or `forced`). */
  async function lookNow(forced) {
    const settings = store.global();
    const status = st().status ?? {};
    const now = look();
    if (running()) {
      saveStatus({ checkedAt: now.at });
      return { started: false, why: "A check-in runs already" };
    }
    if (!forced && now.mode === "stop") {
      saveStatus({ headline: "Soft stop: not checking in", checkedAt: now.at, snapshot: status.snapshot ? { ...status.snapshot, mode: now.mode } : undefined });
      return { started: false, why: "Soft stop" };
    }
    const changed = !status.snapshot || fingerprint(status.snapshot) !== fingerprint(now);
    const ended = now.mode === "away" && settings.orchestratorWakeOnEnd ? endings(status.snapshot, now) : [];
    const overdue = workWaits(now) && (!status.ranAt || Date.now() - Date.parse(status.ranAt) > WAITING_MS);
    const due = everyDue(settings, now.mode, status.ranAt);
    if (!forced && !changed && !ended.length && !overdue && !due) {
      saveStatus({ headline: "Nothing changed", checkedAt: now.at });
      return { started: false, why: "Nothing changed" };
    }
    const why = forced
      ? ["the user asked for a check-in"]
      : changed || ended.length
        ? [...(changed ? changes(status.snapshot, now) : []).filter((w) => !ended.length || w !== NOTHING), ...ended]
        : overdue
          ? ["three hours since the last check-in, and work is waiting"]
          : [`${settings.orchestratorAwayEveryMin} minutes since the last check-in while the user is Away`];
    return checkIn(why, now, forced ? "you" : "look");
  }

  /** Schedule a check-in for itself (or `cancel`). */
  function scheduleWake(inMinutes, note) {
    if (!(inMinutes >= 1 && inMinutes <= WAKE_MAX_MIN)) throw new Error(`inMinutes is 1 to ${WAKE_MAX_MIN}`);
    if (!String(note ?? "").trim()) throw new Error("Say in `note` what to do then");
    const wake = { at: new Date(Date.now() + inMinutes * 60_000).toISOString(), note: String(note).trim() };
    save({ wake });
    return wake;
  }

  function status() {
    const s = st();
    return {
      enabled: store.global().orchestrator,
      headline: s.status?.headline ?? "Not started yet",
      checkedAt: s.status?.checkedAt ?? null,
      ranAt: s.status?.ranAt ?? null,
      nextLook: store.global().orchestrator ? new Date(nextLook).toISOString() : null,
      wake: s.wake ?? null,
      running: running()?.threadId ?? null,
      threads: [...(s.threads ?? [])].reverse().slice(0, 20).map(({ snapshot: _, ...t }) => t),
    };
  }

  /**
   * A Decide round: a thread like a check-in (the pipeline's tools, read-only files) that goes through what waits for
   * the user: answers what it can judge from the task and the code, lists what is safe to land, and merges the
   * workers' open questions into one numbered list in the user's question format. Gives its thread.
   */
  async function decideRound() {
    await p.limits.read().catch(() => null);
    const waiting = store
      .entries()
      .filter(([, t]) => !t.inBatch && !t.hidden && !t.later)
      .map(([id, t]) => ({ id, t, place: p.placement(id, t) }))
      .filter(({ t, place }) => place.column === "stopped" || (t.planning && place.why === "question"));
    if (!waiting.length) throw new Error("Nothing waits for you: no Decide round needed");
    const title = (pid) => p.projectInfo(pid)?.name ?? pid;
    const lines = waiting.map(({ t, place }) => {
      const reply = (t.thread?.lastMessage ?? "").slice(-2500);
      const pending = (t.thread?.pending ?? []).flatMap((a) => (a.questions ?? []).map((q) => `  - waits on: ${q.question} (${(q.options ?? []).map((o) => o.label).join(" / ")})`));
      return [`### #${t.number} ${t.title} (${title(t.projectId)}, ${place.why})`, ...pending, reply ? `Its last reply:\n${reply}` : "(no reply)"].join("\n");
    });
    const prompt = decideRoundPrompt(lines);
    const settings = store.global();
    const thread = await p.claude.start({
      project: await projectId(),
      prompt,
      title: `Decide round: ${waiting.length} task${waiting.length === 1 ? "" : "s"}`,
      workspace: "project",
      model: settings.orchestratorModel,
      ...(settings.orchestratorEffort ? { effort: settings.orchestratorEffort } : {}),
      permissionMode: "dontAsk",
      allowedTools: ROUND_TOOLS,
    });
    save({ rounds: [...(st().rounds ?? []), { threadId: thread.id, at: nowIso(), tasks: waiting.map(({ t }) => t.number) }].slice(-20) });
    return { thread: thread.id, tasks: waiting.map(({ t }) => t.number) };
  }

  /** A ready-made round (ROUNDS): a thread like the Decide round's. `focus`: the user's words (a scout: what to find). */
  async function round(kind, { focus, projectId: project } = {}) {
    const def = ROUNDS[kind];
    if (!def) throw new Error(`There is no round "${kind}": ${Object.keys(ROUNDS).join(", ")}`);
    if (kind === "scout" && store.global().scouts === "off") throw new Error("Scouts are off (Pipeline settings › Global › Scouts)");
    const title = (pid) => p.projectInfo(pid)?.name ?? pid;
    const lines = store
      .entries()
      .filter(([, t]) => !t.inBatch && !t.hidden && !t.settledAt)
      .map(([id, t]) => {
        const place = p.placement(id, t);
        const waits = p.waits(id, t);
        return `- #${t.number} ${t.title} (${title(t.projectId)}): ${place.column}, ${place.why}${waits ? ` (${waits})` : ""}`;
      });
    const settings = store.global();
    const tools = [...new Set([...ROUND_TOOLS, ...def.tools.map((t) => `mcp__layr__pipeline__${t}`)])];
    const thread = await p.claude.start({
      project: await projectId(),
      prompt: roundPrompt(kind, lines, { focus, projectId: project }),
      title: `${def.label}${kind === "scout" && focus?.trim() ? `: ${snippet(focus, 60)}` : ""}`,
      workspace: "project",
      model: settings.orchestratorModel,
      ...(settings.orchestratorEffort ? { effort: settings.orchestratorEffort } : {}),
      permissionMode: "dontAsk",
      allowedTools: tools,
    });
    save({ rounds: [...(st().rounds ?? []), { kind, threadId: thread.id, at: nowIso() }].slice(-20) });
    return { thread: thread.id, kind };
  }

  return { pulse, lookNow, look, scheduleWake, cancelWake: () => save({ wake: undefined }), status, followed, checkIn, decideRound, round };
}
