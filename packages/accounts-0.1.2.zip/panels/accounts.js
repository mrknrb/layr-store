// The Claude Accounts panel: every account's 5-hour and weekly usage, which one the PC's Claude Code uses, switching,
// logging in, and the settings. Everything comes from the backend's tools (`state` first, then the `accounts:state`
// event); nothing here sees a token.
import { nextHours, perDay } from "../shared/overview.js";
import { planLabel, pointsOf, windowPct } from "../shared/types.js";

const layr = window.layr;
const $ = (id) => document.getElementById(id);

const REASON = { you: "by you", threshold: "near the limit", limit: "limit hit", room: "the pipeline needed room" };

let state = null;
let nowMs = Date.now();
let busy = null;
/** The account whose own switch points are open, and the one asked "Remove?". */
let editing = null;
let removing = null;
/** The login this panel started: `{id, url, manualUrl, email?, manual, opened}`. */
let login = null;
let problem = null;

const esc = (value) =>
  String(value ?? "").replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );

function ago(at) {
  const min = Math.round((nowMs - Date.parse(at)) / 60_000);
  if (min < 1) return "just now";
  if (min < 60) return `${min} min ago`;
  const hours = Math.round(min / 60);
  return hours < 48 ? `${hours} h ago` : new Date(at).toLocaleDateString();
}

/** A time: today's as it is, within the week with its weekday (`Wed 12:30`), else with its date. */
function clock(at) {
  const date = new Date(at);
  const time = date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  if (date.toDateString() === new Date(nowMs).toDateString()) return time;
  const day =
    Math.abs(date.getTime() - nowMs) < 6 * 86_400_000
      ? date.toLocaleDateString([], { weekday: "short" })
      : date.toLocaleDateString([], { month: "short", day: "numeric" });
  return `${day} ${time}`;
}

/** A phone (or a touch screen): its browser can't come back to the PC, so the login page shows a code instead. */
const manualLogin = () => layr.info?.device?.kind === "phone" || window.matchMedia("(pointer: coarse)").matches;

// ------------------------------------------------------------------ rendering

const accounts = () => state?.accounts ?? [];
const activeId = () => state?.status?.activeId ?? null;
const settings = () => state?.settings ?? {};
const emailOf = (id) => (id ? (accounts().find((a) => a.id === id)?.email ?? "a removed account") : "another login");

/** ok, warn or over: how close `pct` is to the switch point `at`. */
const tone = (pct, at) => (pct === null ? "unknown" : pct >= at ? "over" : pct >= at - 15 ? "warn" : "ok");

/** A percent in the top bar, in a box as wide as three digits, with a gauge along its bottom. */
function pct({ name, used, value, at = 100, title, toneOf }) {
  const shown = value ?? used;
  const level = used === null ? null : Math.min(100, Math.max(0, used));
  const cls = toneOf ?? tone(level, at);
  return (
    `<span class="pct ${cls}" style="--level:${level ?? 0}%" title="${esc(title)}">` +
    (name ? `<span class="pct-name">${esc(name)}</span>` : "") +
    `<span class="pct-value">${shown === null ? "–" : Math.round(shown)}</span></span>`
  );
}

function renderOverview() {
  const list = accounts()
    .slice()
    .sort((a, b) => a.number - b.number);
  const usable = list.filter((a) => a.state === "ok").map((a) => a.usage);
  const day = perDay(usable, nowMs);
  const twoHours = nextHours(usable, 2, nowMs);
  // The totals against what that many fresh accounts would give at a steady pace.
  const readings = Math.max(1, usable.filter(Boolean).length);
  const short = (room, full) => {
    const level = 100 * (1 - Math.min(1, room / full));
    return level >= 80 ? "over" : level >= 50 ? "warn" : "ok";
  };
  const tiles = list.map((a) => {
    const points = pointsOf(settings(), a.id);
    const reset = a.usage?.fiveHour?.resetsAt;
    return (
      `<div class="tile${a.id === activeId() ? " active" : ""}${a.state !== "ok" ? " off" : ""}" ` +
      `title="${esc(`${a.email}${a.id === activeId() ? " (active)" : ""}`)}">` +
      `<span class="tile-name">${a.number}</span>` +
      pct({ used: windowPct(a.usage?.fiveHour, nowMs), at: points.fiveHour, title: "5-hour window, % used" }) +
      pct({ used: windowPct(a.usage?.sevenDay, nowMs), at: points.weekly, title: "Weekly window, % used" }) +
      (reset && Date.parse(reset) > nowMs
        ? `<span class="tile-reset layr-muted" title="5-hour window resets">${esc(clock(reset))}</span>`
        : "") +
      `</div>`
    );
  });
  if (day !== null || twoHours !== null) {
    tiles.push(
      `<div class="tile totals">` +
        (day !== null
          ? pct({
              name: "Day",
              used: day,
              toneOf: short(day, (100 / 7) * readings),
              title: "Weekly % you can use per day, all accounts together, and still last until each one resets",
            })
          : "") +
        (twoHours !== null
          ? pct({
              name: "2h",
              used: twoHours,
              toneOf: short(twoHours, 100 * readings),
              title: "5-hour % usable in the next 2 hours, all accounts together; one resetting by then adds 100",
            })
          : "") +
        `</div>`,
    );
  }
  $("overview").innerHTML = tiles.join("");
  const status = state?.status;
  $("headline").textContent = !status
    ? "Loading…"
    : status.liveEmail && !status.activeId
      ? `${status.headline} · The PC is signed in with ${status.liveEmail}`
      : status.headline;
  $("headline").title = $("headline").textContent;
}

function bar(name, window, at) {
  const used = windowPct(window, nowMs);
  const reset = window?.resetsAt && Date.parse(window.resetsAt) > nowMs ? `resets ${clock(window.resetsAt)}` : "";
  return (
    `<div class="usage"><span class="usage-name">${esc(name)}</span>` +
    `<span class="bar" role="meter" aria-label="${esc(name)}" aria-valuenow="${used ?? ""}" ` +
    `aria-valuemin="0" aria-valuemax="100">` +
    (used === null ? "" : `<span class="fill ${tone(used, at)}" style="width:${Math.min(100, used)}%"></span>`) +
    `<span class="mark" style="left:${at}%" title="Switch point ${at}%"></span></span>` +
    `<span class="usage-pct">${used === null ? "–" : `${Math.round(used)}%`}</span>` +
    `<span class="usage-reset layr-muted">${esc(reset)}</span></div>`
  );
}

const useTitle = "Auto-switch may move to it";
const skipTitle = "Auto-switch skips it; you can still switch to it";

function card(a) {
  const id = a.id;
  const active = id === activeId();
  const points = pointsOf(settings(), id);
  const own = settings().accountLimits?.[id] ?? {};
  const plan = planLabel(a);
  const disabled = busy ? " disabled" : "";
  const measured = [
    a.usage ? `Measured ${ago(a.usage.at)}` : "Not measured yet",
    a.usageError ? `last try failed (${a.usageError})` : null,
    a.windowStartedAt ? `5h window started by layr ${ago(a.windowStartedAt)}` : null,
  ]
    .filter(Boolean)
    .join(" · ");
  const buttons = [];
  if (a.state === "needs-login") {
    buttons.push(
      `<button class="layr-button small primary" data-action="login" data-email="${esc(a.email)}"${disabled} ` +
        `title="Log in with this account again in the browser">Log in</button>`,
    );
  }
  if (!active && a.state === "ok") {
    buttons.push(
      `<button class="layr-button small primary" data-action="switch" data-email="${esc(a.email)}"${disabled} ` +
        `title="Make the PC's Claude Code use this account">` +
        `${busy === `switch:${id}` ? "Switching…" : "Switch"}</button>`,
    );
  }
  buttons.push(
    removing === id
      ? `<span class="confirm small">Remove?</span>` +
          `<button class="layr-button small danger" data-action="remove" data-email="${esc(a.email)}"${disabled}>` +
          `Remove</button>` +
          `<button class="layr-button small" data-action="remove-cancel">Cancel</button>`
      : `<button class="layr-button small ghost icon" data-action="remove-ask" data-id="${esc(id)}"${disabled} ` +
          `title="Forget this account (layr deletes its stored login; Claude Code stays signed in as it is)" ` +
          `aria-label="Remove ${esc(a.email)}">×</button>`,
  );
  return (
    `<article class="card${active ? " active" : ""}${a.disabled ? " off" : ""}" data-id="${esc(id)}">` +
    `<div class="row card-head">` +
    `<span class="num-badge">#${a.number}</span>` +
    `<strong class="grow ellipsis" title="${esc(a.organizationName ?? a.email)}">${esc(a.email)}</strong>` +
    (plan ? `<span class="layr-muted small">${esc(plan)}</span>` : "") +
    (active ? `<span class="layr-badge accent" title="The PC's Claude Code uses it">active</span>` : "") +
    (a.state === "needs-login"
      ? `<span class="layr-badge danger" title="Its login has expired: press Log in">needs login</span>`
      : "") +
    `</div>` +
    bar("5 hours", a.usage?.fiveHour, points.fiveHour) +
    bar("Weekly", a.usage?.sevenDay, points.weekly) +
    `<div class="row small layr-muted wrap">` +
    `<span class="grow">Switches away at 5h ${points.fiveHour}% · weekly ${points.weekly}%` +
    `${Object.keys(own).length ? " (its own)" : ""}</span>` +
    `<label class="inline-toggle" title="${a.disabled ? skipTitle : useTitle}">` +
    `<input type="checkbox" class="toggle" data-action="use" data-email="${esc(a.email)}"` +
    `${a.disabled ? "" : " checked"}${disabled} />` +
    `<span>Use in auto-switch</span></label>` +
    `<button class="layr-button small ghost" data-action="limits" data-id="${esc(id)}" ` +
    `title="Give this account its own switch points">` +
    `${editing === id ? "Done" : "Limits…"}</button>` +
    `</div>` +
    (editing === id
      ? `<div class="own-limits">` +
        `<label class="setting"><span class="grow">5-hour switch point (%)</span>` +
        `<input class="layr-input num" type="number" min="10" max="100" placeholder="${settings().fiveHourAt}" ` +
        `value="${own.fiveHour ?? ""}" data-limit="fiveHour" data-email="${esc(a.email)}" /></label>` +
        `<label class="setting"><span class="grow">Weekly switch point (%)</span>` +
        `<input class="layr-input num" type="number" min="10" max="100" placeholder="${settings().weeklyAt}" ` +
        `value="${own.weekly ?? ""}" data-limit="weekly" data-email="${esc(a.email)}" /></label>` +
        `<p class="small layr-muted">Empty: the general value. Auto-switch moves away from this account at these ` +
        `points, and moves to it only while it is at least 5 points below both.</p></div>`
      : "") +
    `<div class="row small layr-muted wrap card-foot"><span class="grow">${esc(measured)}</span>` +
    `<span class="card-actions">${buttons.join("")}</span></div>` +
    `</article>`
  );
}

/** Regions with a focused field wait until it loses focus, so typing isn't cut off by a new reading. */
const pending = new Set();
const typing = (node) => node?.matches?.("textarea, select, input:not([type=checkbox]):not([type=radio])");
function region(el, html) {
  if (typing(document.activeElement) && el.contains(document.activeElement)) {
    pending.add(() => (el.innerHTML = html()));
    return;
  }
  el.innerHTML = html();
}
document.addEventListener("focusout", () =>
  setTimeout(() => {
    if (!pending.size) return;
    const work = [...pending];
    pending.clear();
    // A region still focused queues itself again.
    for (const fn of work) fn();
  }, 0),
);

function renderCards() {
  if (!state) return;
  const list = accounts()
    .slice()
    .sort((a, b) => (a.id === activeId() ? -1 : b.id === activeId() ? 1 : a.email.localeCompare(b.email)));
  region($("cards"), () =>
    list.length
      ? list.map(card).join("")
      : `<p class="layr-empty">No accounts yet. Press + Log in to add one in the browser, import them from cswap, or ` +
        `add the login Claude Code uses on the PC now (Add current login, below).</p>`,
  );
}

function renderBanners() {
  const status = state?.status ?? {};
  const out = [];
  if (problem) out.push(`<p class="banner danger">${esc(problem)}</p>`);
  if (status.cswapRunning) {
    const n = status.cswapRunning;
    out.push(
      `<p class="banner warn">cswap auto runs on the PC (${n} ${n === 1 ? "copy" : "copies"}). Close its windows, ` +
        `then ` +
        `press Import from cswap below. Until then layr doesn't switch by itself, so the two don't break each ` +
        `other's logins.</p>`,
    );
  }
  if (status.problem) out.push(`<p class="banner danger">${esc(status.problem.message)}</p>`);
  $("banners").innerHTML = out.join("");
}

function renderSwitches() {
  const switches = state?.status?.switches ?? [];
  $("switches-section").hidden = !switches.length;
  $("switches").innerHTML = switches
    .slice(0, 5)
    .map(
      (s) =>
        `<li>${esc(clock(s.at))} · ${esc(emailOf(s.from))} → ${esc(emailOf(s.to))} ` +
        `<span class="layr-muted">(${esc(REASON[s.reason] ?? s.reason)})</span></li>`,
    )
    .join("");
}

function renderSettings() {
  const s = settings();
  for (const input of document.querySelectorAll("[data-setting]")) {
    if (input === document.activeElement) continue;
    const value = s[input.dataset.setting];
    if (input.type === "checkbox") input.checked = !!value;
    else input.value = value ?? "";
  }
}

function renderLogin() {
  const box = $("login-box");
  box.hidden = !login;
  if (!login) return;
  const who = login.email ? ` Log in as ${esc(login.email)}.` : "";
  const link = login.manual ? login.manualUrl : login.url;
  $("login-text").innerHTML = login.opened
    ? (login.manual
        ? "Log in on the page that opened, then paste the code it shows here."
        : "Log in in the browser tab that opened: the account is added here as soon as you're through.") + who
    : `<a href="${esc(link)}" target="_blank" rel="noopener">Open Claude's login page</a>` +
      (login.manual ? ", log in, then paste the code it shows here." : " and log in.") +
      who;
  $("login-other").hidden = login.manual;
  $("login-other").innerHTML = login.manual
    ? ""
    : `Browser on another device? <a href="${esc(login.manualUrl)}" target="_blank" rel="noopener">Use this login ` +
      `page</a> there instead: it shows a code to paste here.`;
  const error = login.error;
  $("login-error").hidden = !error;
  $("login-error").textContent = error ?? "";
}

function renderButtons() {
  for (const button of document.querySelectorAll(".top-actions [data-action], .section [data-action]")) {
    button.disabled = !!busy || !state || (button.dataset.action === "best" && accounts().length < 2);
  }
  const label = { login: "Opening…", best: "Switching…", refresh: "…", "start-windows": "Starting…" };
  for (const [action, text] of Object.entries(label)) {
    const button = document.querySelector(`.top-actions [data-action="${action}"], .section [data-action="${action}"]`);
    if (!button) continue;
    button.dataset.label ??= button.textContent;
    button.textContent = busy === action ? text : button.dataset.label;
  }
}

function render() {
  renderOverview();
  renderBanners();
  renderLogin();
  renderCards();
  renderSwitches();
  renderSettings();
  renderButtons();
}

// ------------------------------------------------------------------ actions

/** Runs a backend tool; what failed shows as a banner and a notification. */
async function run(key, tool, args = {}) {
  busy = key;
  render();
  try {
    return await layr.tools.run(tool, args);
  } catch (error) {
    const message =
      error?.code === layr.errors?.NOT_AVAILABLE ? "Needs your PC: the accounts live there" : error.message;
    layr.ui.notify(message, "error").catch(() => {});
    return undefined;
  } finally {
    busy = null;
    render();
  }
}

async function load() {
  try {
    state = await layr.tools.run("state");
    problem = null;
  } catch (error) {
    problem =
      error?.code === layr.errors?.NOT_AVAILABLE
        ? "Needs your PC: the accounts and their logins live there."
        : `Couldn't reach the accounts backend: ${error.message}`;
  }
  render();
}

async function startLogin(email) {
  const links = await run("login", "login_start", email ? { email } : {});
  if (!links) return;
  const manual = manualLogin();
  let opened = false;
  try {
    // The shell opens it as a tab (or in the system browser); a plain browser opens a window.
    opened = !!window.open(manual ? links.manualUrl : links.url, "_blank", "noopener");
  } catch {
    opened = false;
  }
  login = { ...links, email, manual, opened, error: null };
  $("login-code").value = "";
  render();
}

async function pasteCode() {
  const current = login;
  const code = $("login-code").value.trim();
  if (!current || !code) return;
  const result = await run("login-code", "login_code", { id: current.id, code });
  if (result?.email && login?.id === current.id) {
    login = null;
    layr.ui.notify(`Logged in with ${result.email}`, "success").catch(() => {});
    render();
  }
}

function cancelLogin() {
  const current = login;
  login = null;
  render();
  if (current) layr.tools.run("login_cancel", { id: current.id }).catch(() => {});
}

const number = (value, min, max) => {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : undefined;
};

const RANGES = { fiveHourAt: [10, 100], weeklyAt: [10, 100], cooldownMin: [1, 120], idlePollMin: [5, 240] };

async function saveSetting(input) {
  const key = input.dataset.setting;
  let value;
  if (input.type === "checkbox") value = input.checked;
  else {
    value = number(input.value, ...RANGES[key]);
    if (value === undefined) return renderSettings();
    input.value = value;
  }
  const result = await run(`setting:${key}`, "settings", { set: { [key]: value } });
  if (result && state) state = { ...state, settings: { ...state.settings, [key]: value } };
  render();
}

async function saveLimit(input) {
  const raw = input.value.trim();
  const value = raw === "" ? null : number(raw, 10, 100);
  if (value === undefined) return;
  await run(`limit:${input.dataset.email}`, "settings", {
    limits: { [input.dataset.email]: { [input.dataset.limit]: value } },
  });
  await load();
}

document.addEventListener("click", async (event) => {
  const target = event.target.closest("[data-action]");
  if (!target || target.disabled || target.tagName === "INPUT") return;
  const { action, email, id } = target.dataset;
  switch (action) {
    case "login":
      return startLogin(email);
    case "login-code":
      return pasteCode();
    case "login-cancel":
      return cancelLogin();
    case "best":
      return run("best", "switch");
    case "refresh":
      return run("refresh", "refresh");
    case "switch":
      return run(`switch:${accounts().find((a) => a.email === email)?.id}`, "switch", { email });
    case "limits":
      editing = editing === id ? null : id;
      return renderCards();
    case "remove-ask":
      removing = id;
      return renderCards();
    case "remove-cancel":
      removing = null;
      return renderCards();
    case "remove":
      removing = null;
      return run(`remove:${email}`, "remove", { email });
    case "start-windows": {
      const result = await run("start-windows", "start_windows");
      if (result) {
        const text = result.started.length
          ? `Started ${result.started.join(", ")}`
          : "Every 5-hour window already runs";
        layr.ui.notify(text, "info").catch(() => {});
      }
      return;
    }
    case "add-current": {
      const result = await run("add-current", "add_current");
      if (result) layr.ui.notify(`Added ${result.email}`, "success").catch(() => {});
      return;
    }
    case "import-cswap": {
      const result = await run("import-cswap", "import_cswap");
      if (result) {
        const added = result.added.length ? `Added ${result.added.join(", ")}` : "Nothing new to add";
        layr.ui
          .notify([added, ...result.problems].join(". "), result.problems.length ? "error" : "info")
          .catch(() => {});
      }
      return;
    }
  }
});

document.addEventListener("change", (event) => {
  const input = event.target;
  if (input.dataset.setting) return void saveSetting(input);
  if (input.dataset.limit) return void saveLimit(input);
  if (input.dataset.action === "use") {
    return void run(`use:${input.dataset.email}`, "use", { email: input.dataset.email, enabled: input.checked });
  }
});

$("login-code").addEventListener("keydown", (event) => {
  if (event.key === "Enter") void pasteCode();
});

// ------------------------------------------------------------------ start

await layr.ready;
layr.events.on("accounts:state", (next) => {
  state = next;
  problem = null;
  // A login that came back to the PC (or failed there) shows up in the status.
  const done = next?.status?.login;
  if (login && done && done.id === login.id) {
    if (done.state === "done") {
      login = null;
      layr.ui.notify(`Logged in with ${done.email}`, "success").catch(() => {});
    } else if (done.state === "failed") {
      login = { ...login, error: done.error ?? "The login failed" };
    }
  }
  render();
});
window.addEventListener("layr:connection", () => layr.connected && void load());
setInterval(() => {
  nowMs = Date.now();
  if (state) {
    renderOverview();
    renderCards();
  }
}, 30_000);

await load();
// Opened by "Accounts: Log in to a Claude account" (params {login: true}), now or later.
if (layr.info?.params?.login) void startLogin();
layr.panel.onParams?.((params) => params?.login && void startLogin());
