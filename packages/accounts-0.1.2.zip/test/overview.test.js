// The totals in the panel's top bar, what agents see, and the status bar item.
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { statusBarItem } from "../backend/statusbar.js";
import { nextHours, perDay, usageOverview } from "../shared/overview.js";
import { numbersOf, settingsOf } from "../shared/types.js";

const HOUR = 3_600_000;
const now = Date.parse("2026-10-24T12:00:00Z");
const at = (ms) => new Date(now + ms).toISOString();
const usage = (fiveHour, sevenDay) => ({
  fiveHour: fiveHour && { pct: fiveHour[0], resetsAt: at(fiveHour[1]) },
  sevenDay: sevenDay && { pct: sevenDay[0], resetsAt: at(sevenDay[1]) },
  at: at(0),
});
const close = (a, b) => assert.ok(Math.abs(a - b) < 1e-6, `${a} ≈ ${b}`);

describe("perDay", () => {
  it("adds up the weekly percent left per day left", () => {
    const usages = [usage(null, [76, 48 * HOUR]), usage(null, [33, 48 * HOUR]), usage(null, [21, 48 * HOUR])];
    close(perDay(usages, now), 85);
  });

  it("counts at least one day, and seven for a window that isn't running", () => {
    assert.equal(perDay([usage(null, [50, 3 * HOUR])], now), 50);
    close(perDay([usage(null, [90, -HOUR])], now), 100 / 7);
  });

  it("skips accounts without a weekly reading", () => {
    assert.equal(perDay([undefined, usage([10, HOUR], null)], now), null);
    assert.equal(perDay([undefined, usage(null, [100, 24 * HOUR])], now), 0);
  });
});

describe("nextHours", () => {
  it("adds up what is left of the 5-hour windows", () => {
    const usages = [usage([26, 4 * HOUR], [76, 48 * HOUR]), usage([66, 3 * HOUR], [33, 48 * HOUR])];
    assert.equal(nextHours(usages, 2, now), 74 + 34);
  });

  it("adds a fresh window when one resets in time", () => {
    assert.equal(nextHours([usage([90, HOUR], [10, 48 * HOUR])], 2, now), 110);
    assert.equal(nextHours([usage([90, -HOUR], [10, 48 * HOUR])], 2, now), 100);
    assert.equal(nextHours([usage(null, [10, 48 * HOUR])], 2, now), 100);
  });

  it("counts nothing for a full weekly window, and null with no readings", () => {
    assert.equal(nextHours([usage([10, HOUR], [100, 48 * HOUR])], 2, now), 0);
    assert.equal(nextHours([undefined], 2, now), null);
  });
});

describe("usageOverview", () => {
  it("shows each account's windows (a reset one empty) and the totals", () => {
    const account = (email, u, patch = {}) => ({ email, state: "ok", usage: u, addedAt: at(0), ...patch });
    const result = usageOverview(
      [
        ["a", account("a@x", usage([40, HOUR], [50, 72 * HOUR]))],
        ["b", account("b@x", usage([99, -HOUR], [20, 24 * HOUR]), { disabled: true })],
      ],
      "a",
      settingsOf(null),
      now,
    );
    assert.deepEqual(
      [result.accounts[0].email, result.accounts[0].active, result.accounts[0].enabled, result.accounts[0].roomLeft],
      ["a@x", true, true, 47],
    );
    assert.equal(result.accounts[1].active, false);
    assert.equal(result.accounts[1].enabled, false);
    assert.deepEqual(result.accounts[1].fiveHour, { pct: 0, resetsAt: null });
    close(result.weeklyPerDay, 50 / 3 + 80);
    assert.equal(result.autoSwitch, true);
  });
});

describe("numbers and the status bar", () => {
  it("numbers accounts by when they were added", () => {
    const numbers = numbersOf([
      ["b", { email: "b@x", addedAt: "2026-02-01" }],
      ["a", { email: "a@x", addedAt: "2026-01-01" }],
    ]);
    assert.deepEqual([numbers.get("a"), numbers.get("b")], [1, 2]);
  });

  it("shows the active account's short name and 5-hour percent, and every account in the tooltip", () => {
    const state = {
      accounts: [
        { id: "a", number: 1, email: "kate@example.com", state: "ok", usage: usage([41.6, HOUR], [10, 48 * HOUR]) },
        { id: "b", number: 2, email: "bob@example.com", state: "needs-login" },
      ],
      status: { activeId: "a", liveEmail: "kate@example.com", headline: "Watching" },
    };
    const item = statusBarItem(state, now);
    assert.equal(item.text, "kate 42%");
    assert.equal(item.command, "open");
    assert.match(item.tooltip, /● #1 kate@example.com: 5h 42%, weekly 10%/);
    assert.match(item.tooltip, /#2 bob@example.com: 5h –, weekly – \(needs login\)/);
    assert.equal(statusBarItem({ accounts: [], status: { liveEmail: "x@y.z" } }, now).text, "x (not added)");
    assert.equal(statusBarItem({ accounts: [], status: {} }, now).text, "Claude accounts");
  });
});
