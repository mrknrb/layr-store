// When auto-switch moves, and where (pure: no files, no network).
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { bestOther, decide, FRESH_MS, nextRoom } from "../backend/auto.js";
import { DEFAULT_SETTINGS, planLabel, planWeight, settingsOf } from "../shared/types.js";

const NOW = Date.parse("2026-10-17T20:00:00Z");
const iso = (offsetMs) => new Date(NOW + offsetMs).toISOString();

const usage = (fiveHour, sevenDay = 10, at = iso(-60_000)) => ({
  fiveHour: fiveHour === null ? null : { pct: fiveHour, resetsAt: iso(3 * 3_600_000) },
  sevenDay: sevenDay === null ? null : { pct: sevenDay, resetsAt: iso(5 * 86_400_000) },
  at,
});

const account = (patch = {}) => ({ email: "x@example.com", state: "ok", addedAt: iso(-86_400_000), ...patch });
const defaults = settingsOf(null);

const input = (patch = {}) => ({
  now: NOW,
  settings: defaults,
  activeId: "a",
  activeUsage: usage(98),
  rejected: false,
  accounts: [
    ["a", account({ email: "a@example.com" })],
    ["b", account({ email: "b@example.com", usage: usage(20) })],
  ],
  ...patch,
});

describe("plans", () => {
  it("weighs Max accounts by their tier, and picks the account with most room counted in Pro windows", () => {
    assert.equal(planWeight({ subscription: "max", tier: "default_claude_max_20x" }), 20);
    assert.equal(planWeight({ subscription: "max", tier: "default_claude_max_5x" }), 5);
    assert.equal(planWeight({ subscription: "max" }), 5);
    assert.equal(planWeight({ subscription: "pro", tier: "default_claude_ai" }), 1);
    assert.equal(planLabel({ subscription: "max", tier: "default_claude_max_5x" }), "Max 5x");
    assert.equal(planLabel({ subscription: "pro" }), "Pro");
    const accounts = [
      ["a", account()],
      ["pro", account({ usage: usage(20) })],
      ["max", account({ usage: usage(60), subscription: "max", tier: "default_claude_max_5x" })],
    ];
    assert.equal(bestOther(accounts, "a", defaults, NOW), "max");
  });
});

describe("decide", () => {
  it("switches at a switch point without waiting for running turns", () => {
    assert.deepEqual(decide(input()).switchTo, { id: "b", reason: "threshold" });
  });

  it("stays below the threshold", () => {
    assert.deepEqual(decide(input({ activeUsage: usage(96) })), {
      headline: "Watching: switches at 5h 97% · weekly 97%",
    });
  });

  it("switches at the threshold to the account with the most room", () => {
    const accounts = [
      ["a", account()],
      ["b", account({ usage: usage(60) })],
      ["c", account({ usage: usage(30, 50) })],
    ];
    assert.deepEqual(decide(input({ accounts })).switchTo, { id: "c", reason: "threshold" });
  });

  it("also counts the 7-day window", () => {
    assert.deepEqual(decide(input({ activeUsage: usage(10, 97) })).switchTo, { id: "b", reason: "threshold" });
  });

  it("switches when a run was refused, even without readings", () => {
    const accounts = [
      ["a", account()],
      ["b", account()],
    ];
    const decision = decide(input({ activeUsage: null, rejected: true, accounts, remeasured: true }));
    assert.deepEqual(decision.switchTo, { id: "b", reason: "limit" });
  });

  it("measures stale accounts first, then trusts only fresh ones near the threshold", () => {
    const accounts = [
      ["a", account()],
      ["b", account({ usage: usage(20, 10, iso(-FRESH_MS - 1)) })],
    ];
    assert.deepEqual(decide(input({ accounts })).measure, ["b"]);
    assert.equal(decide(input({ accounts, remeasured: true })).switchTo, undefined);
    // At the limit an older reading is good enough.
    assert.equal(decide(input({ accounts, remeasured: true, activeUsage: usage(100) })).switchTo?.id, "b");
  });

  it("skips disabled accounts, ones that need a login, and ones near the threshold themselves", () => {
    const accounts = [
      ["a", account()],
      ["b", account({ usage: usage(10), disabled: true })],
      ["c", account({ usage: usage(10), state: "needs-login" })],
      ["d", account({ usage: usage(93) })],
    ];
    const decision = decide(input({ accounts }));
    assert.equal(decision.switchTo, undefined);
    assert.match(decision.headline, /^All accounts are near the limit until /);
  });

  it("counts a window that has reset as empty", () => {
    const reset = { ...usage(99), fiveHour: { pct: 99, resetsAt: iso(-1_000) } };
    const accounts = [
      ["a", account()],
      ["b", account({ usage: reset })],
    ];
    assert.equal(decide(input({ accounts })).switchTo?.id, "b");
  });

  it("waits out the cooldown after a switch", () => {
    const lastSwitch = { from: "b", to: "a", reason: "threshold", at: iso(-60_000) };
    assert.match(decide(input({ lastSwitch })).headline, /^Just switched/);
    const older = { ...lastSwitch, at: iso(-6 * 60_000) };
    assert.equal(decide(input({ lastSwitch: older })).switchTo?.id, "b");
  });

  it("does nothing when off or when the PC's login isn't known", () => {
    assert.equal(decide(input({ settings: { ...defaults, autoSwitch: false } })).switchTo, undefined);
    assert.equal(decide(input({ activeId: null })).switchTo, undefined);
  });

  it("has a switch point per window", () => {
    const settings = { ...defaults, fiveHourAt: 90, weeklyAt: 80 };
    assert.equal(decide(input({ settings, activeUsage: usage(89, 79) })).switchTo, undefined);
    assert.equal(decide(input({ settings, activeUsage: usage(90, 10) })).switchTo?.id, "b");
    assert.equal(decide(input({ settings, activeUsage: usage(10, 80) })).switchTo?.id, "b");
  });

  it("uses an account's own switch points, for leaving it and for choosing it", () => {
    const accounts = [
      ["a", account()],
      ["b", account({ usage: usage(60) })],
      ["c", account({ usage: usage(40) })],
    ];
    // a may run to 99%; c is kept below 50%, so it has less room than b.
    const settings = { ...defaults, accountLimits: { a: { fiveHour: 99 }, c: { fiveHour: 50 } } };
    assert.equal(decide(input({ settings, accounts, activeUsage: usage(98) })).switchTo, undefined);
    assert.equal(decide(input({ settings, accounts, activeUsage: usage(99) })).switchTo?.id, "b");
    // c at 46% is within 5 points of its own 50%: not a target near the threshold.
    const only = [
      ["a", account()],
      ["c", account({ usage: usage(46) })],
    ];
    assert.equal(decide(input({ settings, accounts: only, activeUsage: usage(99) })).switchTo, undefined);
  });
});

describe("settingsOf", () => {
  it("reads the old single switch point as both windows' default", () => {
    assert.equal(settingsOf({ threshold: 90 }).fiveHourAt, 90);
    assert.equal(settingsOf({ threshold: 90 }).weeklyAt, 90);
    assert.equal(settingsOf({ threshold: 90, weeklyAt: 80 }).weeklyAt, 80);
    const fresh = settingsOf(null);
    assert.deepEqual([fresh.fiveHourAt, fresh.weeklyAt, fresh.accountLimits], [97, 97, {}]);
    // The defaults themselves are never changed through a returned object.
    fresh.accountLimits.x = { fiveHour: 50 };
    assert.deepEqual(settingsOf(null).accountLimits, {});
    assert.deepEqual(DEFAULT_SETTINGS.accountLimits, {});
  });
});

describe("nextRoom", () => {
  const settings = settingsOf({ accountLimits: { b: { fiveHour: 80, weekly: 95 } } });
  const at = (fiveHour, fiveHourIn, weekly, weeklyIn) => ({
    fiveHour: { pct: fiveHour, resetsAt: iso(fiveHourIn) },
    sevenDay: { pct: weekly, resetsAt: iso(weeklyIn) },
    at: iso(-60_000),
  });

  it("is the soonest another account is below its own switch points", () => {
    const accounts = [
      // The active account resets later: it doesn't count.
      ["a", account({ usage: at(100, 3_600_000, 12, 86_400_000) })],
      // Held back by its 5-hour window only (93% weekly is below its own 95).
      ["b", account({ usage: at(100, 2 * 3_600_000, 93, 2 * 3_600_000) })],
      ["c", account({ usage: at(98, 3 * 3_600_000, 75, 86_400_000) })],
    ];
    assert.deepEqual(nextRoom(accounts, "a", settings, NOW), { id: "b", at: NOW + 2 * 3_600_000 });
  });

  it("waits for both windows when both hold an account back, and is now when one has room", () => {
    const both = [["b", account({ usage: at(100, 3_600_000, 96, 5 * 3_600_000) })]];
    assert.deepEqual(nextRoom(both, "a", settings, NOW), { id: "b", at: NOW + 5 * 3_600_000 });
    const room = [["b", account({ usage: at(50, 3_600_000, 10, 86_400_000) })]];
    assert.deepEqual(nextRoom(room, "a", settings, NOW), { id: "b", at: NOW });
  });

  it("skips disabled accounts, ones that need a login, and ones without readings", () => {
    const accounts = [
      ["b", account({ usage: at(10, 3_600_000, 10, 86_400_000), disabled: true })],
      ["c", account({ usage: at(10, 3_600_000, 10, 86_400_000), state: "needs-login" })],
      ["d", account()],
    ];
    assert.equal(nextRoom(accounts, "a", settings, NOW), null);
  });
});
