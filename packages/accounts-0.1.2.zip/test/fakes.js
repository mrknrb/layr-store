// Stand-ins for the tests: Anthropic's endpoints on a local port (LAYR_ACCOUNTS_API_ORIGIN points the backend at it,
// so nothing reaches Anthropic), a tiny MCP hub (the core's /mcp with the layr__* tools the backend uses and a fake
// claude__usage), and a temporary home with FAKE credential files. Not loaded in production.
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { isInitializeRequest } from "@modelcontextprotocol/sdk/types.js";
import { randomUUID } from "node:crypto";
import { mkdirSync, mkdtempSync, writeFileSync } from "node:fs";
import http from "node:http";
import os from "node:os";
import path from "node:path";
import { z } from "zod";

const HOUR = 3_600_000;

export const fakeLogin = (name, expiresIn = 5 * HOUR) => ({
  accessToken: `fake-access-${name}`,
  refreshToken: `fake-refresh-${name}`,
  expiresAt: Date.now() + expiresIn,
  subscriptionType: "pro",
});
export const fakeWho = (id, email = `${id}@example.com`) => ({ accountUuid: id, emailAddress: email });

/**
 * A temporary home: `.claude/.credentials.json` and `.claude.json` signed in as `live`, and a vault with `stored`
 * accounts (`[{id, email, subscription?, tier?, expired?}]`; `expired`: its token has run out, so it is refreshed
 * first, and an id with `dead` in it has its refresh refused). Every token in it is fake.
 */
export function fakeHome({ live, stored }) {
  const home = mkdtempSync(path.join(os.tmpdir(), "layr-accounts-home-"));
  mkdirSync(path.join(home, ".claude"), { recursive: true });
  mkdirSync(path.join(home, ".layr", "accounts"), { recursive: true });
  const byId = new Map(stored.map((a) => [a.id, a]));
  const oauth = (a) => ({
    ...fakeLogin(a.id, a.expired ? -HOUR : 5 * HOUR),
    ...(a.subscription ? { subscriptionType: a.subscription } : {}),
    ...(a.tier ? { rateLimitTier: a.tier } : {}),
  });
  if (live) {
    const a = byId.get(live);
    writeFileSync(
      path.join(home, ".claude", ".credentials.json"),
      JSON.stringify({ claudeAiOauth: oauth(a), mcpOAuth: {} }),
    );
    writeFileSync(
      path.join(home, ".claude.json"),
      JSON.stringify({ numStartups: 3, oauthAccount: fakeWho(a.id, a.email) }, null, 2),
    );
  }
  stored.forEach((a, i) => {
    writeFileSync(
      path.join(home, ".layr", "accounts", `${a.id}.json`),
      JSON.stringify({
        credentials: { claudeAiOauth: oauth(a) },
        oauthAccount: fakeWho(a.id, a.email),
        savedAt: new Date(Date.now() - (stored.length - i) * 86_400_000).toISOString(),
      }),
    );
  });
  return home;
}

/**
 * Anthropic's endpoints: usage by access token (`usage[token]`: the endpoint's JSON, or a status number), refreshes
 * that add `-r` to the tokens, profiles, and pings (recorded in `pings`).
 */
export async function startFakeAnthropic({ usage = {}, profile = {} } = {}) {
  const pings = [];
  const calls = [];
  const server = http.createServer((req, res) => {
    let body = "";
    req.on("data", (c) => (body += c));
    req.on("end", () => {
      const token = (req.headers.authorization ?? "").replace(/^Bearer /, "");
      calls.push({ method: req.method, url: req.url, token });
      const send = (status, data) => {
        res.writeHead(status, { "Content-Type": "application/json" });
        res.end(JSON.stringify(data));
      };
      if (req.url === "/api/oauth/usage") {
        const answer = usage[token];
        if (typeof answer === "number") return send(answer, { error: "fake" });
        if (!answer) return send(401, { error: "unknown token" });
        return send(200, answer);
      }
      if (req.url === "/api/oauth/profile") return send(200, profile[token] ?? { organization: {} });
      if (req.url === "/v1/messages") {
        pings.push(token);
        return send(200, { content: [{ type: "text", text: "Hi" }] });
      }
      if (req.url === "/v1/oauth/token") {
        const data = JSON.parse(body || "{}");
        if (data.grant_type === "refresh_token" && !data.refresh_token.includes("dead")) {
          return send(200, {
            access_token: data.refresh_token.replace("refresh", "access") + "-r",
            refresh_token: `${data.refresh_token}-r`,
            expires_in: 8 * 3600,
          });
        }
        return send(400, { error: "invalid_grant" });
      }
      send(404, { error: "no such fake endpoint" });
    });
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  return { origin, usage, pings, calls, close: () => new Promise((resolve) => server.close(resolve)) };
}

/** The usage endpoint's JSON for a reading: percents and hours until each window resets. */
export function usageJson(fiveHour, fiveHourIn, weekly, weeklyIn) {
  const at = (hours) => new Date(Date.now() + hours * HOUR).toISOString();
  return {
    five_hour: fiveHour === null ? null : { utilization: fiveHour, resets_at: at(fiveHourIn) },
    seven_day: weekly === null ? null : { utilization: weekly, resets_at: at(weeklyIn) },
  };
}

/** The core's MCP hub, enough for the backend: events, notifications, the status bar, and a fake claude__usage. */
export async function startFakeHub({ claudeUsage = null, settings = {} } = {}) {
  const emitted = [];
  const calls = [];
  const state = { claudeUsage, settings: { ...settings } };
  const makeServer = () => {
    const server = new McpServer({ name: "layr-fake-hub", version: "0.0.1" });
    const reply = (value) => ({
      content: [{ type: "text", text: JSON.stringify(value ?? null) }],
      ...(value && typeof value === "object" && !Array.isArray(value) ? { structuredContent: value } : {}),
    });
    const t = (name, shape, fn) =>
      server.registerTool(name, { description: name, inputSchema: shape }, async (args) => {
        calls.push({ name, args });
        try {
          return reply(await fn(args));
        } catch (error) {
          return { content: [{ type: "text", text: error.message }], isError: true };
        }
      });
    t(
      "layr__events_emit",
      { topic: z.string(), data: z.any() },
      ({ topic, data }) => (emitted.push({ topic, data }), null),
    );
    t("layr__notify", { text: z.string(), kind: z.string().optional() }, () => null);
    t(
      "layr__status_set",
      {
        id: z.string().optional(),
        text: z.string().optional(),
        tooltip: z.string().optional(),
        icon: z.string().optional(),
        command: z.string().optional(),
      },
      () => null,
    );
    t("layr__settings_get", { id: z.string().optional() }, ({ id }) =>
      id ? state.settings[id] : { ...state.settings },
    );
    t("layr__settings_set", { id: z.string(), value: z.any() }, ({ id, value }) => {
      state.settings[id] = value;
      return null;
    });
    t("claude__usage", { refresh: z.boolean().optional() }, () => {
      if (!state.claudeUsage) throw new Error("No plugin claude");
      return { ...state.claudeUsage, updatedAt: new Date().toISOString() };
    });
    return server;
  };
  const sessions = new Map();
  const httpServer = http.createServer(async (req, res) => {
    let body = "";
    for await (const chunk of req) body += chunk;
    const parsed = body ? JSON.parse(body) : undefined;
    const sid = req.headers["mcp-session-id"];
    let transport = sid ? sessions.get(sid) : undefined;
    if (!transport && req.method === "POST" && isInitializeRequest(parsed)) {
      transport = new StreamableHTTPServerTransport({
        sessionIdGenerator: () => randomUUID(),
        onsessioninitialized: (id) => sessions.set(id, transport),
      });
      await makeServer().connect(transport);
    }
    if (!transport) {
      res.writeHead(400).end();
      return;
    }
    await transport.handleRequest(req, res, parsed);
  });
  await new Promise((resolve) => httpServer.listen(0, "127.0.0.1", resolve));
  return {
    url: `http://127.0.0.1:${httpServer.address().port}/mcp`,
    token: "fake-plugin-token",
    emitted,
    calls,
    state,
    close: () => {
      httpServer.closeAllConnections?.();
      return new Promise((resolve) => httpServer.close(resolve));
    },
  };
}
