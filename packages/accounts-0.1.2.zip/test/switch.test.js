// switchTo against fake credential files in a temporary folder (never the real ones).
import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { mkdir, mkdtemp, readFile, rm, utimes, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, it } from "node:test";
import { switchTo } from "../backend/switch.js";
import { createVault } from "../backend/vault.js";

const HOUR = 3_600_000;
let root;
let paths;
let d;
let refreshed;

const login = (name, expiresIn = 5 * HOUR) => ({
  accessToken: `access-${name}`,
  refreshToken: `refresh-${name}`,
  expiresAt: Date.now() + expiresIn,
  subscriptionType: "pro",
});
const who = (id) => ({ accountUuid: id, emailAddress: `${id}@example.com`, organizationUuid: `org-${id}` });

const readText = (file) => readFile(file, "utf8");
const readCredentials = async () => JSON.parse(await readText(path.join(paths.claudeHome, ".credentials.json")));
const readConfig = async () => JSON.parse(await readText(paths.globalConfig));

/** The PC signed in as `id`, with an MCP server login and other settings in its files. */
async function signIn(id, oauth) {
  const credentials = { claudeAiOauth: oauth, organizationUuid: `org-${id}`, mcpOAuth: { server: { token: "mcp" } } };
  await writeFile(path.join(paths.claudeHome, ".credentials.json"), JSON.stringify(credentials));
  await writeFile(
    paths.globalConfig,
    JSON.stringify({ numStartups: 6, projects: { x: 1 }, oauthAccount: who(id) }, null, 2),
  );
}

beforeEach(async () => {
  root = await mkdtemp(path.join(os.tmpdir(), "layr-accounts-"));
  paths = {
    claudeHome: path.join(root, ".claude"),
    globalConfig: path.join(root, ".claude.json"),
    vault: path.join(root, "vault"),
    cswap: path.join(root, "cswap"),
  };
  await mkdir(paths.claudeHome, { recursive: true });
  refreshed = [];
  const net = {
    exchange: async () => {
      throw new Error("no login here");
    },
    refresh: async (old) => {
      refreshed.push(old.refreshToken);
      return {
        ...old,
        accessToken: `${old.accessToken}+`,
        refreshToken: `${old.refreshToken}+`,
        expiresAt: Date.now() + 8 * HOUR,
      };
    },
    usage: async () => ({ fiveHour: null, sevenDay: null, at: new Date().toISOString() }),
    plan: async () => ({}),
    ping: async () => {},
  };
  d = { paths, vault: createVault(paths), net };
});

afterEach(() => rm(root, { recursive: true, force: true }));

describe("switchTo", () => {
  it("swaps the login and the account, keeping the PC's MCP logins and other settings", async () => {
    await signIn("a", login("a"));
    await d.vault.put("a", { credentials: { claudeAiOauth: login("a-old") }, oauthAccount: who("a") });
    await d.vault.put("b", {
      credentials: { claudeAiOauth: login("b"), organizationUuid: "org-b" },
      oauthAccount: who("b"),
    });

    assert.deepEqual(await switchTo(d, "b"), { from: "a" });

    const credentials = await readCredentials();
    assert.equal(credentials.claudeAiOauth.refreshToken, "refresh-b");
    assert.equal(credentials.organizationUuid, "org-b");
    assert.deepEqual(credentials.mcpOAuth, { server: { token: "mcp" } });
    const config = await readConfig();
    assert.equal(config.oauthAccount.accountUuid, "b");
    assert.equal(config.numStartups, 6);
    assert.deepEqual(config.projects, { x: 1 });
    // The account left keeps the login Claude Code rotated last, without the PC's MCP logins.
    const left = await d.vault.get("a");
    assert.equal(left.credentials.claudeAiOauth.refreshToken, "refresh-a");
    assert.equal(left.credentials.mcpOAuth, undefined);
    // The locks are given back.
    assert.equal(existsSync(path.join(paths.claudeHome, ".oauth_refresh.lock")), false);
    assert.equal(existsSync(`${paths.claudeHome}.lock`), false);
    assert.equal(existsSync(`${paths.globalConfig}.lock`), false);
  });

  it("refreshes a target whose token is about to expire, saving it before it is used", async () => {
    await signIn("a", login("a"));
    await d.vault.put("a", { credentials: { claudeAiOauth: login("a") }, oauthAccount: who("a") });
    await d.vault.put("b", { credentials: { claudeAiOauth: login("b", 60_000) }, oauthAccount: who("b") });

    await switchTo(d, "b");

    assert.deepEqual(refreshed, ["refresh-b"]);
    assert.equal((await readCredentials()).claudeAiOauth.refreshToken, "refresh-b+");
    assert.equal((await d.vault.get("b")).credentials.claudeAiOauth.refreshToken, "refresh-b+");
    // The previous version stays next to it.
    const prev = JSON.parse(await readText(path.join(paths.vault, "b.json.prev")));
    assert.equal(prev.credentials.claudeAiOauth.refreshToken, "refresh-b");
  });

  it("does nothing when the target is already active", async () => {
    await signIn("a", login("a"));
    await d.vault.put("a", { credentials: { claudeAiOauth: login("a") }, oauthAccount: who("a") });
    assert.equal(await switchTo(d, "a"), undefined);
  });

  it("refuses to drop a live login that isn't stored", async () => {
    await signIn("stranger", login("stranger"));
    await d.vault.put("b", { credentials: { claudeAiOauth: login("b") }, oauthAccount: who("b") });
    await assert.rejects(switchTo(d, "b"), /stranger@example.com, which isn't stored/);
    assert.equal((await readCredentials()).claudeAiOauth.refreshToken, "refresh-stranger");
  });

  it("waits for a lock Claude Code holds, and takes over one left by a dead holder", async () => {
    await signIn("a", login("a"));
    await d.vault.put("a", { credentials: { claudeAiOauth: login("a") }, oauthAccount: who("a") });
    await d.vault.put("b", { credentials: { claudeAiOauth: login("b") }, oauthAccount: who("b") });
    const lock = path.join(paths.claudeHome, ".oauth_refresh.lock");
    await mkdir(lock);
    const old = new Date(Date.now() - 2 * 60_000);
    await utimes(lock, old, old);
    await switchTo(d, "b");
    assert.equal((await readConfig()).oauthAccount.accountUuid, "b");
    assert.equal(existsSync(lock), false);
  });

  it("signs a PC without a login in", async () => {
    await writeFile(path.join(paths.claudeHome, ".credentials.json"), JSON.stringify({ mcpOAuth: { s: 1 } }));
    await d.vault.put("b", { credentials: { claudeAiOauth: login("b") }, oauthAccount: who("b") });
    assert.deepEqual(await switchTo(d, "b"), { from: null });
    const credentials = await readCredentials();
    assert.equal(credentials.claudeAiOauth.refreshToken, "refresh-b");
    assert.deepEqual(credentials.mcpOAuth, { s: 1 });
    assert.equal((await readConfig()).oauthAccount.accountUuid, "b");
  });
});
