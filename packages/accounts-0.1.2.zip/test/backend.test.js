// The backend over stdio, as the core runs it: a temporary home with FAKE credential files, Anthropic's endpoints on
// a local fake, and (second part) a fake hub with the claude plugin's usage tool. Nothing here touches the real
// Claude login or calls Anthropic.
import assert from "node:assert/strict";
import { readFileSync, rmSync } from "node:fs";
import path from "node:path";
import { after, before, describe, it } from "node:test";
import { fileURLToPath } from "node:url";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { defaultPaths } from "../backend/files.js";
import { fakeHome, startFakeAnthropic, startFakeHub, usageJson } from "./fakes.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const pluginDir = path.resolve(here, "..");
const TOOLS = [
  "usage",
  "switch",
  "use",
  "start_windows",
  "refresh",
  "settings",
  "state",
  "next_room",
  "login_start",
  "login_code",
  "login_cancel",
  "add_current",
  "import_cswap",
  "remove",
];

/** The backend's environment: everything it touches is in `home`; refuses to go on otherwise. */
function envFor(home, extra = {}) {
  const env = {
    ...process.env,
    LAYR_ACCOUNTS_HOME: home,
    LAYR_DATA_DIR: path.join(home, "data"),
    LAYR_ACCOUNTS_CSWAP: "off",
    ...extra,
  };
  delete env.CLAUDE_CONFIG_DIR;
  delete env.LAYR_ACCOUNTS_VAULT;
  if (!extra.LAYR_HUB_URL) {
    delete env.LAYR_HUB_URL;
    delete env.LAYR_HUB_TOKEN;
  }
  const paths = defaultPaths(env);
  for (const p of Object.values(paths)) assert.ok(p.startsWith(home), `${p} is outside the test home`);
  return env;
}

async function startBackend(env) {
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [path.join(pluginDir, "backend", "server.js")],
    cwd: pluginDir,
    env,
    stderr: "pipe",
  });
  const logs = [];
  transport.stderr?.on("data", (d) => logs.push(String(d)));
  const client = new Client({ name: "test", version: "1" });
  await client.connect(transport);
  const call = async (name, args = {}) => {
    const r = await client.callTool({ name, arguments: args });
    if (r.isError) throw new Error(`${name}: ${r.content?.[0]?.text}`);
    return r.structuredContent ?? JSON.parse(r.content[0].text);
  };
  return { client, call, logs, close: () => client.close() };
}

const waitFor = async (fn, ms = 10_000) => {
  const end = Date.now() + ms;
  for (;;) {
    const value = await fn();
    if (value) return value;
    if (Date.now() > end) throw new Error("timed out");
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
};

const ALICE = { id: "acc-alice", email: "alice@example.com" };
const BOB = { id: "acc-bob", email: "bob@example.com", subscription: "max", tier: "default_claude_max_5x" };

describe("backend over stdio, without a hub", () => {
  let home;
  let anthropic;
  let backend;
  before(async () => {
    home = fakeHome({ live: ALICE.id, stored: [ALICE, BOB] });
    anthropic = await startFakeAnthropic({
      usage: { "fake-access-acc-alice": usageJson(30, 2, 40, 72), "fake-access-acc-bob": usageJson(20, 3, 10, 100) },
    });
    backend = await startBackend(envFor(home, { LAYR_ACCOUNTS_API_ORIGIN: anthropic.origin }));
  });
  after(async () => {
    await backend?.close();
    await anthropic?.close();
    rmSync(home, { recursive: true, force: true });
  });

  it("lists the tools, with the names today's layr gave agents", async () => {
    const { tools } = await backend.client.listTools();
    assert.deepEqual(tools.map((t) => t.name).sort(), [...TOOLS].sort());
    assert.match(tools.find((t) => t.name === "usage").description, /5-hour and weekly windows/);
  });

  it("takes in the stored accounts and measures them (the active one with the PC's login)", async () => {
    const overview = await backend.call("refresh");
    const alice = overview.accounts.find((a) => a.email === ALICE.email);
    const bob = overview.accounts.find((a) => a.email === BOB.email);
    assert.equal(alice.active, true);
    assert.equal(alice.fiveHour.pct, 30);
    assert.equal(bob.active, false);
    assert.equal(bob.fiveHour.pct, 20);
    assert.equal(bob.plan, "Max 5x");
    assert.equal(overview.autoSwitch, true);
    assert.ok(overview.nextTwoHours > 100);
    // Only fake tokens went out, only to the fake.
    assert.ok(anthropic.calls.every((c) => !c.token || c.token.startsWith("fake-access-")));
  });

  it("gives the panel's state without tokens", async () => {
    const state = await backend.call("state");
    assert.deepEqual(
      state.accounts.map((a) => [a.email, a.number]),
      [
        [ALICE.email, 1],
        [BOB.email, 2],
      ],
    );
    assert.equal(state.status.liveEmail, ALICE.email);
    assert.match(state.status.headline, /Watching|Starting/);
    assert.doesNotMatch(JSON.stringify(state), /fake-access|fake-refresh/);
  });

  it("reads and changes settings, and refuses bad values", async () => {
    const read = await backend.call("settings");
    assert.equal(read.settings.fiveHourAt, 97);
    assert.match(read.about.cooldownMin, /Minutes between two switches/);
    const changed = await backend.call("settings", {
      set: { cooldownMin: 10 },
      limits: { [BOB.email]: { fiveHour: 90 } },
    });
    assert.equal(changed.settings.cooldownMin, 10);
    assert.deepEqual(changed.settings.accountLimits, { [BOB.email]: { fiveHour: 90 } });
    const saved = JSON.parse(readFileSync(path.join(home, "data", "settings.json"), "utf8"));
    assert.deepEqual(saved.accountLimits, { [BOB.id]: { fiveHour: 90 } });
    await assert.rejects(backend.call("settings", { set: { fiveHourAt: 5 } }), /fiveHourAt: a number from 10 to 100/);
  });

  it("switches the PC's login in the fake home, keeping the account left", async () => {
    const result = await backend.call("switch", { email: BOB.email });
    assert.deepEqual(result, { switchedTo: BOB.email });
    const config = JSON.parse(readFileSync(path.join(home, ".claude.json"), "utf8"));
    assert.equal(config.oauthAccount.emailAddress, BOB.email);
    assert.equal(config.numStartups, 3);
    const credentials = JSON.parse(readFileSync(path.join(home, ".claude", ".credentials.json"), "utf8"));
    assert.equal(credentials.claudeAiOauth.refreshToken, "fake-refresh-acc-bob");
    assert.deepEqual(credentials.mcpOAuth, {});
    const state = await backend.call("state");
    assert.equal(state.status.activeId, BOB.id);
    assert.equal(state.status.switches[0].reason, "you");
    await assert.rejects(backend.call("switch", { email: "nobody@example.com" }), /No account nobody@example.com/);
    // Without an email: the one with the most room (alice is the only other).
    assert.deepEqual(await backend.call("switch"), { switchedTo: ALICE.email });
  });

  it("lets auto-switch skip an account and use it again", async () => {
    assert.deepEqual(await backend.call("use", { email: BOB.email, enabled: false }), {
      email: BOB.email,
      enabled: false,
    });
    assert.equal((await backend.call("usage")).accounts.find((a) => a.email === BOB.email).enabled, false);
    assert.equal((await backend.call("next_room")).next, null);
    await backend.call("use", { email: BOB.email, enabled: true });
    assert.equal((await backend.call("next_room")).next.email, BOB.email);
  });

  it("starts an idle 5-hour window with that account's own (fake) login", async () => {
    anthropic.usage["fake-access-acc-bob"] = usageJson(null, 0, 10, 100);
    const { started } = await backend.call("start_windows");
    assert.deepEqual(started, [BOB.email]);
    assert.deepEqual(anthropic.pings, ["fake-access-acc-bob"]);
  });

  it("starts a login and cancels it", async () => {
    const links = await backend.call("login_start", { email: BOB.email });
    assert.match(links.url, /^https:\/\/claude\.com\/cai\/oauth\/authorize\?/);
    assert.match(new URL(links.url).searchParams.get("redirect_uri"), /^http:\/\/localhost:\d+\/callback$/);
    assert.equal(new URL(links.manualUrl).searchParams.get("login_hint"), BOB.email);
    assert.equal((await backend.call("state")).status.login.state, "waiting");
    await backend.call("login_cancel", { id: links.id });
    await assert.rejects(backend.call("login_code", { id: links.id, code: "x" }), /ended/);
  });

  it("logs only to stderr, and says where its files are", async () => {
    const log = backend.logs.join("");
    assert.match(log, /accounts backend up/);
    assert.ok(log.includes(path.join(home, ".layr", "accounts")), "the vault in the test home");
    assert.doesNotMatch(log, /fake-access|fake-refresh/);
  });
});

describe("backend with a hub", () => {
  let home;
  let anthropic;
  let hub;
  let backend;
  before(async () => {
    home = fakeHome({ live: ALICE.id, stored: [ALICE, BOB] });
    anthropic = await startFakeAnthropic({ usage: { "fake-access-acc-bob": usageJson(20, 3, 10, 100) } });
    hub = await startFakeHub({
      claudeUsage: {
        account: { email: ALICE.email },
        limits: {
          fiveHour: { utilization: 55, resetsAt: new Date(Date.now() + 3_600_000).toISOString() },
          sevenDay: { utilization: 12, resetsAt: new Date(Date.now() + 90 * 3_600_000).toISOString() },
          rejectedUntil: null,
        },
      },
      settings: {
        autoSwitch: true,
        fiveHourAt: 90,
        weeklyAt: 97,
        cooldownMin: 5,
        idlePollMin: 30,
        startWindows: false,
      },
    });
    backend = await startBackend(
      envFor(home, {
        LAYR_ACCOUNTS_API_ORIGIN: anthropic.origin,
        LAYR_HUB_URL: hub.url,
        LAYR_HUB_TOKEN: hub.token,
        LAYR_ACCOUNTS_TICK_SEC: "1",
      }),
    );
  });
  after(async () => {
    await backend?.close();
    await hub?.close();
    await anthropic?.close();
    rmSync(home, { recursive: true, force: true });
  });

  it("reads the active account's usage from the claude plugin, not the endpoint", async () => {
    const overview = await backend.call("refresh");
    assert.equal(overview.accounts.find((a) => a.email === ALICE.email).fiveHour.pct, 55);
    assert.ok(hub.calls.some((c) => c.name === "claude__usage"));
    assert.ok(!anthropic.calls.some((c) => c.token === "fake-access-acc-alice" && c.url === "/api/oauth/usage"));
  });

  it("pushes its state to the panels and sets the status bar", async () => {
    const event = await waitFor(() =>
      hub.emitted.findLast((e) => e.topic === "accounts:state" && e.data.accounts.length),
    );
    assert.equal(event.data.status.activeId, ALICE.id);
    const bar = await waitFor(() => hub.calls.findLast((c) => c.name === "layr__status_set"));
    assert.match(bar.args.text, /^alice 55%$/);
    assert.equal(bar.args.command, "open");
  });

  it("keeps the general settings in the core's plugin settings, and its own switch points in its file", async () => {
    const read = await backend.call("settings");
    assert.equal(read.settings.fiveHourAt, 90);
    assert.equal(read.settings.startWindows, false);
    await backend.call("settings", { set: { cooldownMin: 7 }, limits: { [BOB.email]: { weekly: 70 } } });
    assert.equal(hub.state.settings.cooldownMin, 7);
    const file = JSON.parse(readFileSync(path.join(home, "data", "settings.json"), "utf8"));
    assert.deepEqual(file, { accountLimits: { [BOB.id]: { weekly: 70 } } });
    // A change on the shell's Settings page arrives as an event notification.
    await backend.client.notification({
      method: "notifications/layr/event",
      params: {
        topic: "accounts:settings",
        data: { id: "weeklyAt", value: 95, values: { ...hub.state.settings, weeklyAt: 95 } },
      },
    });
    await waitFor(async () => (await backend.call("settings")).settings.weeklyAt === 95);
  });

  it("switches by itself when the claude plugin says a run was refused", async () => {
    hub.state.claudeUsage = {
      ...hub.state.claudeUsage,
      limits: { ...hub.state.claudeUsage.limits, rejectedUntil: new Date(Date.now() + 3_600_000).toISOString() },
    };
    // The next check (every second here, every minute for real) decides.
    const switched = await waitFor(async () => {
      const state = await backend.call("state");
      return state.status.switches.length ? state : null;
    }, 15_000);
    assert.equal(switched.status.switches[0].reason, "limit");
    assert.equal(
      JSON.parse(readFileSync(path.join(home, ".claude.json"), "utf8")).oauthAccount.emailAddress,
      BOB.email,
    );
  });
});
