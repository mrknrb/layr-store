// The Accounts panel against a real `layr serve`, in headless Chromium, with a temporary home of FAKE credentials and
// Anthropic's endpoints on a local fake (the backend gets LAYR_ACCOUNTS_HOME and LAYR_ACCOUNTS_API_ORIGIN through the
// core's environment). Takes screenshots (dark and light, narrow and wide) into ../screenshots.
//
//   node test/panels.e2e.js [--layr <path to layr.exe>] [--keep]
// Playwright: from C:\Users\mrknr\pwtools (or env PLAYWRIGHT_MODULE). layr: ../../core/target/debug/layr.exe or
// env LAYR_BIN.
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdirSync, readFileSync, rmSync } from "node:fs";
import net from "node:net";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { defaultPaths } from "../backend/files.js";
import { fakeHome, startFakeAnthropic, usageJson } from "./fakes.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const pluginDir = path.resolve(here, "..");
const arg = (name, dflt) => {
  const i = process.argv.indexOf(`--${name}`);
  return i > 0 ? process.argv[i + 1] : dflt;
};
const LAYR = arg("layr", process.env.LAYR_BIN || path.resolve(pluginDir, "../../core/target/debug/layr.exe"));
const SHOTS = path.join(pluginDir, "screenshots");
const playwrightModule = process.env.PLAYWRIGHT_MODULE || "C:/Users/mrknr/pwtools/node_modules/playwright/index.mjs";
const { chromium } = await import(pathToFileURL(playwrightModule).href);
mkdirSync(SHOTS, { recursive: true });

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const freePort = () =>
  new Promise((resolve) => {
    const server = net.createServer();
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      server.close(() => resolve(port));
    });
  });

class Shell {
  constructor(url) {
    this.url = url;
    this.next = 1;
    this.pending = new Map();
    this.events = [];
  }
  open() {
    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(this.url);
      this.ws.onopen = resolve;
      this.ws.onerror = () => reject(new Error(`Can't connect to ${this.url}`));
      this.ws.onmessage = (m) => {
        const msg = JSON.parse(m.data);
        if (msg.id != null && this.pending.has(msg.id)) {
          const p = this.pending.get(msg.id);
          this.pending.delete(msg.id);
          msg.error ? p.reject(Object.assign(new Error(msg.error.message), msg.error)) : p.resolve(msg.result);
        } else if (msg.method === "event") this.events.push(msg.params);
      };
    });
  }
  call(method, params = {}) {
    const id = this.next++;
    this.ws.send(JSON.stringify({ jsonrpc: "2.0", id, method, params }));
    return new Promise((resolve, reject) => this.pending.set(id, { resolve, reject }));
  }
}

const results = [];
async function test(name, fn) {
  const t0 = Date.now();
  try {
    await fn();
    results.push({ name, ok: true });
    console.log(`ok   ${name} (${Date.now() - t0} ms)`);
  } catch (err) {
    results.push({ name, ok: false });
    console.log(`FAIL ${name}: ${err.stack || err.message}`);
  }
}

// ---------- the fake world ----------

const ALICE = { id: "acc-alice", email: "alice@example.com" };
const BOB = { id: "acc-bob", email: "bob.builder@example.com", subscription: "max", tier: "default_claude_max_5x" };
const CAROL = { id: "acc-dead-carol", email: "carol@example.com", expired: true };
const home = fakeHome({ live: ALICE.id, stored: [ALICE, BOB, CAROL] });
const anthropic = await startFakeAnthropic({
  usage: {
    "fake-access-acc-alice": usageJson(62, 2.5, 41, 70),
    "fake-access-acc-bob": usageJson(18, 4, 73, 30),
  },
});
const layrHome = path.join(home, "layr-home");
const port = await freePort();
const env = {
  ...process.env,
  LAYR_ACCOUNTS_HOME: home,
  LAYR_ACCOUNTS_API_ORIGIN: anthropic.origin,
  LAYR_ACCOUNTS_CSWAP: "off",
  LAYR_HOME: layrHome,
};
delete env.CLAUDE_CONFIG_DIR;
delete env.LAYR_ACCOUNTS_VAULT;
for (const p of Object.values(defaultPaths(env))) assert.ok(p.startsWith(home), `${p} is outside the test home`);

console.log(`home ${home}, layr serve on ${port}`);
const core = spawn(LAYR, ["serve", "--port", String(port), "--token", "dev", "--home", layrHome, "--link", pluginDir], {
  cwd: pluginDir,
  env,
  stdio: ["ignore", "pipe", "pipe"],
});
let coreLog = "";
core.stdout.on("data", (d) => (coreLog += d));
core.stderr.on("data", (d) => (coreLog += d));

const shell = new Shell(`ws://127.0.0.1:${port}/_layr/ws?token=dev`);
for (let i = 0; ; i++) {
  try {
    await shell.open();
    break;
  } catch (error) {
    if (i > 100 || core.exitCode !== null) throw new Error(`layr serve didn't start:\n${coreLog}`);
    await sleep(200);
  }
}
for (const topic of ["shell:notify", "shell:status", "shell:open"])
  await shell.call("events.subscribe", { topic }).catch(() => {});

const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 900, height: 760 }, deviceScaleFactor: 1 });
const errors = [];
const popups = [];
context.on("page", (p) => popups.push(p));

/** As the shell sends it: the mode with its accent (layr.css's default for that mode). */
async function setTheme(mode) {
  await shell.call("settings.set", { key: "theme", value: { mode, accent: mode === "light" ? "#3d63dd" : "#7c9cff" } });
}

async function openPanel(params) {
  const created = await shell.call("panels.create", {
    plugin: "accounts",
    panel: "main",
    ...(params ? { params } : {}),
  });
  const page = await context.newPage();
  page.on("console", (m) => m.type() === "error" && errors.push(m.text()));
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto(created.url);
  return page;
}

const liveEmail = () => JSON.parse(readFileSync(path.join(home, ".claude.json"), "utf8")).oauthAccount.emailAddress;

try {
  await setTheme("dark");
  const page = await openPanel();

  await test("shows every account with its bars, plan, and the active one first", async () => {
    // The backend measures the idle accounts on its first check; carol's refresh is refused.
    await page.waitForFunction(() => document.querySelectorAll(".card").length === 3, null, { timeout: 30_000 });
    await page.waitForFunction(() => /needs login/.test(document.getElementById("cards").textContent), null, {
      timeout: 30_000,
    });
    await page.waitForFunction(() => /18%/.test(document.getElementById("cards").textContent), null, {
      timeout: 30_000,
    });
    const cards = await page.$$eval(".card", (els) =>
      els.map((e) => ({ text: e.textContent, active: e.classList.contains("active") })),
    );
    assert.match(cards[0].text, /alice@example\.com/);
    assert.ok(cards[0].active, "the active account comes first");
    assert.match(cards[0].text, /62%/);
    assert.match(cards[0].text, /41%/);
    const bob = cards.find((c) => /bob\.builder/.test(c.text));
    assert.match(bob.text, /Max 5x/);
    assert.match(bob.text, /73%/);
    assert.match(bob.text, /Switch/);
    assert.match(cards.find((c) => /carol/.test(c.text)).text, /needs login.*Log in/s);
    const tiles = await page.$$eval(".tile", (els) => els.map((e) => e.textContent.replace(/\s+/g, " ").trim()));
    assert.equal(tiles.length, 4, "three accounts and the totals");
    assert.match(tiles.at(-1), /Day/);
    assert.match(await page.textContent(".intro"), /new turns of Claude threads in layr/);
  });

  await test("screenshots: dark wide and narrow", async () => {
    // Tall, so the whole panel (cards, switches, settings) is in the picture.
    await page.setViewportSize({ width: 900, height: 1250 });
    await sleep(200);
    await page.screenshot({ path: path.join(SHOTS, "accounts-dark-wide.png") });
    await page.setViewportSize({ width: 320, height: 1900 });
    await sleep(200);
    await page.screenshot({ path: path.join(SHOTS, "accounts-dark-narrow.png") });
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
    );
    assert.ok(overflow <= 0, `no sideways scrolling at 320 px (${overflow} px over)`);
  });

  await test("screenshots: light wide and narrow", async () => {
    await setTheme("light");
    await page.waitForFunction(() => document.documentElement.getAttribute("data-theme") === "light");
    await sleep(400); // the buttons' color transitions
    await page.screenshot({ path: path.join(SHOTS, "accounts-light-narrow.png") });
    await page.setViewportSize({ width: 900, height: 1250 });
    await sleep(200);
    await page.screenshot({ path: path.join(SHOTS, "accounts-light-wide.png") });
    await page.setViewportSize({ width: 900, height: 760 });
  });

  await test("the status bar shows the active account and opens the panel", async () => {
    const state = await shell.call("shell.state");
    if (!("statusBar" in state)) {
      console.log("     (this core has no status bar yet: skipped)");
      return;
    }
    const item = state.statusBar.find((i) => i.id === "accounts.account");
    assert.ok(item, "the accounts item is there");
    assert.equal(item.command, "accounts.open");
    assert.match(item.text, /^alice 62%$/);
    assert.match(item.tooltip, /bob\.builder@example\.com: 5h 18%, weekly 73%/);
  });

  await test("the general settings are on the shell's Settings page", async () => {
    const list = await shell.call("pluginSettings.list").catch(() => null);
    if (!list) {
      console.log("     (this core has no plugin settings yet: skipped)");
      return;
    }
    const ours = list.find((p) => p.plugin === "accounts");
    assert.deepEqual(
      ours.settings.map((s) => s.id),
      ["autoSwitch", "fiveHourAt", "weeklyAt", "startWindows", "cooldownMin", "idlePollMin"],
    );
  });

  await test("Switch moves the PC's login (in the fake home) and the card becomes active", async () => {
    await page.click('.card:has-text("bob.builder") [data-action="switch"]');
    await page.waitForFunction(
      () => document.querySelector(".card.active")?.textContent.includes("bob.builder"),
      null,
      {
        timeout: 15_000,
      },
    );
    assert.equal(liveEmail(), BOB.email);
    await page.waitForFunction(() =>
      /bob\.builder.*→|→.*bob\.builder/.test(document.getElementById("switches").textContent),
    );
    assert.match(await page.textContent("#switches"), /alice@example\.com → bob\.builder@example\.com \(by you\)/);
    // Back, so the screenshots above stay true to the next run.
    await page.click('.card:has-text("alice@example.com") [data-action="switch"]');
    await page.waitForFunction(() => document.querySelector(".card.active")?.textContent.includes("alice@"), null, {
      timeout: 15_000,
    });
    assert.equal(liveEmail(), ALICE.email);
  });

  await test("Use in auto-switch, own switch points, and the general settings go to the backend", async () => {
    const toggle = `input[data-action="use"][data-email="${BOB.email}"]`;
    await page.click(toggle);
    await page.waitForFunction(
      (sel) => !document.querySelector(sel).checked && document.querySelector(sel).closest(".card.off"),
      toggle,
    );
    await page.click(toggle);
    await page.waitForFunction((sel) => document.querySelector(sel).checked, toggle);

    await page.click('.card:has-text("bob.builder") [data-action="limits"]');
    await page.fill('.card:has-text("bob.builder") input[data-limit="fiveHour"]', "80");
    await page.press('.card:has-text("bob.builder") input[data-limit="fiveHour"]', "Tab");
    await page.waitForFunction(() =>
      /5h 80% · weekly 97% \(its own\)/.test(document.getElementById("cards").textContent),
    );
    await page.screenshot({ path: path.join(SHOTS, "accounts-light-limits.png") });

    await page.fill('input[data-setting="cooldownMin"]', "12");
    await page.press('input[data-setting="cooldownMin"]', "Tab");
    const read = await page.evaluate(() => layr.tools.run("settings"));
    assert.equal(read.settings.cooldownMin, 12);
    assert.deepEqual(read.settings.accountLimits, { [BOB.email]: { fiveHour: 80 } });
    const list = await shell.call("pluginSettings.list").catch(() => null);
    if (list) {
      const cooldown = list.find((p) => p.plugin === "accounts").settings.find((x) => x.id === "cooldownMin");
      assert.equal(cooldown.value, 12, "kept in the core's plugin settings");
    }
  });

  await test("a change on the shell's Settings page reaches the backend and the panel", async () => {
    const ok = await shell.call("pluginSettings.set", { plugin: "accounts", id: "weeklyAt", value: 95 }).then(
      () => true,
      () => false,
    );
    if (!ok) {
      console.log("     (this core has no plugin settings yet: skipped)");
      return;
    }
    await page.waitForFunction(() => document.querySelector('input[data-setting="weeklyAt"]').value === "95", null, {
      timeout: 10_000,
    });
    assert.match(await page.textContent("#cards"), /weekly 95%/);
    await shell.call("pluginSettings.set", { plugin: "accounts", id: "weeklyAt", value: null });
    await page.waitForFunction(() => document.querySelector('input[data-setting="weeklyAt"]').value === "97");
  });

  await test("commands run the backend's tools", async () => {
    const result = await shell.call("commands.run", { command: "accounts.refresh" });
    const value = result?.structuredContent ?? result;
    assert.ok(JSON.stringify(value).includes(ALICE.email), "refresh gives the overview");
  });

  await test("+ Log in opens Claude's login page and shows the code box; Cancel ends it", async () => {
    const before = popups.length;
    await page.click('.top-actions [data-action="login"]');
    await page.waitForSelector("#login-box:not([hidden])");
    const opened = popups.slice(before);
    for (const p of opened) {
      await p.waitForLoadState("commit").catch(() => {});
      await p.close().catch(() => {});
    }
    assert.match(await page.textContent("#login-box"), /Log in|login page/);
    const state = await page.evaluate(() => layr.tools.run("state"));
    assert.equal(state.status.login.state, "waiting");
    await page.click('[data-action="login-cancel"]');
    await page.waitForSelector("#login-box", { state: "hidden" });
  });

  await test("dark narrow with a login waiting", async () => {
    await setTheme("dark");
    await page.setViewportSize({ width: 320, height: 760 });
    await sleep(400);
    await page.evaluate(() => {
      // Show the box as the phone would (a code to paste), without opening anything.
      window.open = () => null;
    });
    await page.click('.top-actions [data-action="login"]');
    await page.waitForSelector("#login-box:not([hidden])");
    await page.screenshot({ path: path.join(SHOTS, "accounts-dark-narrow-login.png") });
    await page.click('[data-action="login-cancel"]');
  });

  await test("no errors in the page", async () => {
    assert.deepEqual(errors, []);
  });
} finally {
  await browser.close();
  shell.ws?.close();
  core.kill();
  await anthropic.close();
  if (!process.argv.includes("--keep")) {
    await sleep(500);
    rmSync(home, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 });
  }
}

const failed = results.filter((r) => !r.ok).length;
console.log(`\n${results.length - failed} passed, ${failed} failed; screenshots in ${SHOTS}`);
if (failed) console.log(`core log (end):\n${coreLog.slice(-3000)}`);
process.exit(failed ? 1 : 0);
