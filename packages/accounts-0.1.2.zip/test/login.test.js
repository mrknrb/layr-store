// Logging in from the panel (the PKCE flow and its local callback), and the HTTP calls with a fake fetch.
import assert from "node:assert/strict";
import { afterEach, describe, it } from "node:test";
import { createLogins, parseCode } from "../backend/login.js";
import { CallFailed, createNet, LoginExpired } from "../backend/oauth.js";

let logins;
afterEach(() => logins?.cancel());

function setup(finish, timeoutMs) {
  const changes = [];
  logins = createLogins({ finish, changed: (status) => changes.push(status), timeoutMs });
  return { logins, changes };
}

/** The browser coming back to the PC from the login page. */
const callback = (url, query) => {
  const redirect = new URL(new URL(url).searchParams.get("redirect_uri"));
  // `localhost` on the PC: the test asks the IPv4 address, which is always listened on.
  const target = new URL(`http://127.0.0.1:${redirect.port}${redirect.pathname}`);
  for (const [key, value] of Object.entries(query)) target.searchParams.set(key, value);
  return fetch(target, { redirect: "manual" });
};

describe("parseCode", () => {
  it("reads the code and state as the login page shows them, or the whole address", () => {
    assert.deepEqual(parseCode("  abc#xyz \n"), { code: "abc", state: "xyz" });
    assert.deepEqual(parseCode("abc"), { code: "abc" });
    assert.deepEqual(parseCode("https://platform.claude.com/oauth/code/callback?code=abc&state=xyz"), {
      code: "abc",
      state: "xyz",
    });
  });
});

describe("logins", () => {
  it("finishes when the browser comes back to the PC, then sends it to Claude's page", async () => {
    const grants = [];
    const { logins, changes } = setup(async (grant) => (grants.push(grant), "c@example.com"));
    const links = await logins.start();
    const state = new URL(links.url).searchParams.get("state");
    const response = await callback(links.url, { code: "the-code", state });
    assert.equal(response.status, 302);
    assert.match(response.headers.get("location"), /^https:\/\/platform\.claude\.com\/oauth\/code\/success/);
    assert.equal(grants[0].code, "the-code");
    assert.equal(grants[0].state, state);
    assert.equal(grants[0].redirectUri, new URL(links.url).searchParams.get("redirect_uri"));
    assert.deepEqual(
      changes.map((c) => c.state),
      ["waiting", "done"],
    );
    assert.equal(changes[1].id, links.id);
    assert.equal(changes[1].email, "c@example.com");
  });

  it("ignores a request without the login's state", async () => {
    const { logins, changes } = setup(async () => "c@example.com");
    const links = await logins.start();
    assert.equal((await callback(links.url, { code: "x", state: "other" })).status, 404);
    assert.deepEqual(
      changes.map((c) => c.state),
      ["waiting"],
    );
  });

  it("says when the login page came back without a login", async () => {
    const { logins, changes } = setup(async () => "c@example.com");
    const links = await logins.start();
    const state = new URL(links.url).searchParams.get("state");
    const response = await callback(links.url, { error: "access_denied", state });
    assert.equal(response.status, 400);
    assert.equal(changes[1].state, "failed");
    assert.match(changes[1].error, /access_denied/);
  });

  it("explains a refused code, and still takes a pasted one", async () => {
    let refuse = true;
    const { logins, changes } = setup(async () => {
      if (refuse) throw new CallFailed("http-400", "invalid_grant");
      return "c@example.com";
    });
    const links = await logins.start();
    await assert.rejects(logins.paste(links.id, "bad"), /refused the code/);
    assert.equal(changes[1].state, "failed");
    refuse = false;
    assert.equal(await logins.paste(links.id, "good"), "c@example.com");
  });

  it("ends a login nobody finished", async () => {
    const { logins, changes } = setup(async () => "c@example.com", 20);
    const links = await logins.start();
    await new Promise((resolve) => setTimeout(resolve, 60));
    assert.equal(changes[1].state, "failed");
    assert.match(changes[1].error, /timed out/);
    await assert.rejects(logins.paste(links.id, "code"), /ended/);
  });

  it("ends the one before when another starts", async () => {
    const { logins } = setup(async () => "c@example.com");
    const first = await logins.start();
    const second = await logins.start();
    await assert.rejects(logins.paste(first.id, "code"), /ended/);
    assert.equal(await logins.paste(second.id, "code"), "c@example.com");
  });

  it("asks for Claude Code's scopes with PKCE, and the email as a hint", async () => {
    const { logins } = setup(async () => "c@example.com");
    const links = await logins.start("me@example.com");
    const url = new URL(links.url);
    assert.equal(url.searchParams.get("code_challenge_method"), "S256");
    assert.equal(url.searchParams.get("login_hint"), "me@example.com");
    assert.match(url.searchParams.get("scope"), /user:inference/);
    assert.match(url.searchParams.get("redirect_uri"), /^http:\/\/localhost:\d+\/callback$/);
  });
});

describe("calls", () => {
  it("turns a 200 that isn't JSON into a CallFailed", async () => {
    const page = async () => new Response("<html><body>Sign in to the Wi-Fi</body></html>", { status: 200 });
    const failed = await createNet(page)
      .usage("at")
      .catch((error) => error);
    assert.ok(failed instanceof CallFailed);
    assert.equal(failed.kind, "bad-response");
    const empty = async () => new Response("", { status: 200 });
    await assert.rejects(createNet(empty).plan("at"), (error) => error.kind === "bad-response");
  });

  it("reads usage windows, and turns a refused refresh token into LoginExpired", async () => {
    const seen = [];
    const fakeFetch = async (url, init) => {
      seen.push({ url, auth: init.headers?.Authorization });
      if (url.endsWith("/api/oauth/usage")) {
        return new Response(JSON.stringify({ five_hour: { utilization: 42, resets_at: "2026-11-15T20:00:00Z" } }));
      }
      return new Response(JSON.stringify({ error: "invalid_grant" }), { status: 400 });
    };
    const net = createNet(fakeFetch, { api: "http://fake", platform: "http://fake" });
    const usage = await net.usage("token-1");
    assert.deepEqual(usage.fiveHour, { pct: 42, resetsAt: "2026-11-15T20:00:00Z" });
    assert.equal(usage.sevenDay, null);
    assert.equal(seen[0].url, "http://fake/api/oauth/usage");
    assert.equal(seen[0].auth, "Bearer token-1");
    await assert.rejects(net.refresh({ accessToken: "a", refreshToken: "r", expiresAt: 0 }), LoginExpired);
  });
});

describe("exchange", () => {
  it("trades the code and builds the login as Claude Code stores it", async () => {
    const calls = [];
    const answer = (data) => new Response(JSON.stringify(data), { status: 200 });
    const fakeFetch = async (url, init) => {
      calls.push({ url, body: init?.body ? JSON.parse(init.body) : undefined });
      if (url.endsWith("/v1/oauth/token")) {
        return answer({
          access_token: "at",
          refresh_token: "rt",
          expires_in: 3600,
          scope: "user:profile user:inference",
          account: { uuid: "acc", email_address: "c@example.com" },
          organization: { uuid: "org" },
        });
      }
      return answer({
        account: { uuid: "acc", email: "c@example.com", display_name: "C" },
        organization: { uuid: "org", organization_type: "claude_max", rate_limit_tier: "default_claude_max_5x" },
      });
    };
    const signedIn = await createNet(fakeFetch).exchange({
      code: "code",
      verifier: "v",
      state: "s",
      redirectUri: "https://platform.claude.com/oauth/code/callback",
    });
    assert.equal(calls[0].body.grant_type, "authorization_code");
    assert.equal(calls[0].body.code, "code");
    assert.equal(calls[0].body.code_verifier, "v");
    assert.equal(signedIn.credentials.organizationUuid, "org");
    const oauth = signedIn.credentials.claudeAiOauth;
    assert.equal(oauth.accessToken, "at");
    assert.equal(oauth.refreshToken, "rt");
    assert.deepEqual(oauth.scopes, ["user:profile", "user:inference"]);
    assert.equal(oauth.subscriptionType, "max");
    assert.equal(oauth.rateLimitTier, "default_claude_max_5x");
    assert.deepEqual(signedIn.oauthAccount, {
      accountUuid: "acc",
      emailAddress: "c@example.com",
      organizationUuid: "org",
      displayName: "C",
    });
  });
});
