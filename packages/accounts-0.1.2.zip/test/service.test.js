// The service against fake credential files in a temporary folder, a fake network and a store in memory.
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, it } from "node:test";
import { MANUAL_REDIRECT } from "../backend/login.js";
import { CallFailed, LoginExpired } from "../backend/oauth.js";
import { createService } from "../backend/service.js";
import { memoryStore } from "../backend/store.js";
import { createVault } from "../backend/vault.js";

const HOUR = 3_600_000;
let root;
let paths;
let store;
/** What the active account's measurer (the claude plugin) reports for the account the PC uses. */
let activeLimits;
/** Usage the endpoint answers per access token (or an error to throw). */
let idleUsage;
let refreshError;
/** Access tokens the idle accounts sent a message with, and the active account's messages. */
let pings;
let activePings;
/** What a login from the panel brings back, and the codes it was traded with. */
let signedIn;
let grants;
let changes;
const services = [];

const login = (name) => ({
  accessToken: `access-${name}`,
  refreshToken: `refresh-${name}`,
  expiresAt: Date.now() + 5 * HOUR,
});
const who = (id) => ({ accountUuid: id, emailAddress: `${id}@example.com` });
const usage = (pct) => ({
  fiveHour: { pct, resetsAt: new Date(Date.now() + 2 * HOUR).toISOString() },
  sevenDay: { pct: 10, resetsAt: new Date(Date.now() + 90 * HOUR).toISOString() },
  at: new Date().toISOString(),
});
const limits = (pct, account) => ({
  fiveHour: { utilization: pct, resetsAt: new Date(Date.now() + HOUR).toISOString() },
  sevenDay: { utilization: 10, resetsAt: null },
  rejectedUntil: null,
  updatedAt: new Date().toISOString(),
  account,
});

const liveEmail = async () => JSON.parse(await readFile(paths.globalConfig, "utf8")).oauthAccount.emailAddress;
const credentials = async () => JSON.parse(await readFile(path.join(paths.claudeHome, ".credentials.json"), "utf8"));

function net() {
  return {
    exchange: async (grant) => (grants.push(grant), signedIn),
    refresh: async (old) => {
      if (refreshError) throw refreshError;
      return { ...old, accessToken: `${old.accessToken}+`, expiresAt: Date.now() + 8 * HOUR };
    },
    usage: async (token) => {
      const answer = idleUsage[token];
      if (!answer) throw new CallFailed("http-401", "unknown token");
      if (answer instanceof Error) throw answer;
      return answer;
    },
    plan: async () => ({ subscription: "pro" }),
    ping: async (token) => void pings.push(token),
  };
}

function makeService(patch = {}) {
  const service = createService({
    store,
    paths,
    vault: createVault(paths),
    net: net(),
    limits: async () => activeLimits(await liveEmail().catch(() => null)),
    pingActive: async () => void activePings++,
    cswapCount: async () => 0,
    onChange: (state) => changes.push(state),
    ...patch,
  });
  services.push(service);
  return service;
}

async function setup(patch) {
  const vault = createVault(paths);
  // Signed in as a; a and b are stored.
  await writeFile(
    path.join(paths.claudeHome, ".credentials.json"),
    JSON.stringify({ claudeAiOauth: login("a"), mcpOAuth: {} }),
  );
  await writeFile(paths.globalConfig, JSON.stringify({ oauthAccount: who("a") }));
  for (const id of ["a", "b"])
    await vault.put(id, { credentials: { claudeAiOauth: login(id) }, oauthAccount: who(id) });
  for (const id of ["a", "b"])
    store.data.accounts[id] = { email: `${id}@example.com`, state: "ok", addedAt: `2026-01-0${id === "a" ? 1 : 2}` };
  const service = makeService(patch);
  await service.start();
  return service;
}

beforeEach(async () => {
  root = await mkdtemp(path.join(os.tmpdir(), "layr-accounts-"));
  paths = {
    claudeHome: path.join(root, ".claude"),
    globalConfig: path.join(root, ".claude.json"),
    vault: path.join(root, "vault"),
    cswap: path.join(root, "cswap"),
  };
  await mkdir(paths.claudeHome, { recursive: true });
  store = memoryStore();
  activeLimits = (email) => limits(email === "a@example.com" ? 98 : 5, email);
  idleUsage = { "access-b": usage(20) };
  refreshError = null;
  pings = [];
  activePings = 0;
  grants = [];
  changes = [];
  signedIn = {
    credentials: { claudeAiOauth: login("c"), organizationUuid: "org-c" },
    oauthAccount: { ...who("c"), organizationUuid: "org-c" },
  };
  idleUsage["access-c"] = usage(30);
});

afterEach(async () => {
  for (const service of services.splice(0)) service.stop();
  await rm(root, { recursive: true, force: true });
});

describe("service", () => {
  it("switches by itself near the limit and records why", async () => {
    const service = await setup();
    await service.check();
    assert.equal(await liveEmail(), "b@example.com");
    const status = service.status();
    assert.equal(status.activeId, "b");
    assert.deepEqual(
      [status.switches[0].from, status.switches[0].to, status.switches[0].reason],
      ["a", "b", "threshold"],
    );
    // The new account was measured right away.
    assert.equal(service.accounts().get("b").usage.fiveHour.pct, 5);
    // Nothing goes back and forth: b has room, so the next check stays.
    await service.check();
    assert.equal(await liveEmail(), "b@example.com");
  });

  it("stays while cswap auto runs", async () => {
    const service = await setup({ cswapCount: async () => 2 });
    await service.check();
    assert.equal(await liveEmail(), "a@example.com");
    assert.match(service.status().headline, /cswap auto runs/);
    assert.deepEqual(service.status().switches, []);
  });

  it("switches when a run was refused for a limit", async () => {
    activeLimits = (email) => ({ ...limits(50, email), rejectedUntil: new Date(Date.now() + HOUR).toISOString() });
    const service = await setup();
    await service.check();
    assert.equal(await liveEmail(), "b@example.com");
    assert.equal(service.status().switches[0].reason, "limit");
  });

  it("ignores a reading of another account than the PC's", async () => {
    activeLimits = () => limits(99, "someone-else@example.com");
    const service = await setup();
    await service.check();
    assert.equal(await liveEmail(), "a@example.com");
    assert.equal(service.accounts().get("a").usage, undefined);
  });

  it("marks an account whose login the server refused, and doesn't switch to it", async () => {
    const service = await setup();
    // b's token has expired and the server refuses its refresh token.
    const vault = createVault(paths);
    const b = await vault.get("b");
    await vault.put("b", { ...b, credentials: { claudeAiOauth: { ...login("b"), expiresAt: Date.now() - 1 } } });
    refreshError = new LoginExpired("invalid_grant");
    await service.check();
    assert.equal(service.accounts().get("b").state, "needs-login");
    assert.equal(await liveEmail(), "a@example.com");
    assert.match(service.state().status.problem.message, /b@example.com needs a new login/);
  });

  it("backs off after a 429 and keeps the last good reading", async () => {
    activeLimits = (email) => limits(50, email);
    const service = await setup();
    await service.check();
    assert.equal(service.accounts().get("b").usage.fiveHour.pct, 20);
    idleUsage["access-b"] = new CallFailed("http-429", "too many");
    await service.refresh();
    assert.equal(service.accounts().get("b").usageError, "http-429");
    assert.equal(service.accounts().get("b").usage.fiveHour.pct, 20);
  });

  it("keeps layr's copy of the live login as Claude Code rotates it", async () => {
    activeLimits = (email) => limits(50, email);
    const service = await setup();
    await writeFile(
      path.join(paths.claudeHome, ".credentials.json"),
      JSON.stringify({ claudeAiOauth: login("a2"), mcpOAuth: {} }),
    );
    await service.check();
    assert.equal((await createVault(paths).get("a")).credentials.claudeAiOauth.refreshToken, "refresh-a2");
  });

  it("takes in stored logins without a record, and forgets records without a stored login", async () => {
    const vault = createVault(paths);
    await writeFile(path.join(paths.claudeHome, ".credentials.json"), JSON.stringify({ claudeAiOauth: login("a") }));
    await writeFile(paths.globalConfig, JSON.stringify({ oauthAccount: who("a") }));
    await vault.put("a", {
      credentials: {
        claudeAiOauth: { ...login("a"), subscriptionType: "max", rateLimitTier: "default_claude_max_5x" },
      },
      oauthAccount: who("a"),
    });
    store.data.accounts.gone = { email: "gone@example.com", state: "ok", addedAt: "x" };
    const service = makeService();
    await service.start();
    assert.deepEqual([...service.accounts().keys()], ["a"]);
    const a = service.accounts().get("a");
    assert.equal(a.email, "a@example.com");
    assert.equal(a.tier, "default_claude_max_5x");
    assert.equal(service.status().activeId, "a");
    assert.deepEqual(Object.keys(store.data.accounts), ["a"]);
  });

  it("publishes what the panel shows, without tokens, when it changes", async () => {
    const reading = limits(50, "a@example.com");
    activeLimits = () => reading;
    const service = await setup();
    await service.check();
    const last = changes.at(-1);
    assert.deepEqual(
      last.accounts.map((a) => [a.id, a.number]),
      [
        ["a", 1],
        ["b", 2],
      ],
    );
    assert.equal(last.status.activeId, "a");
    assert.equal(last.settings.fiveHourAt, 97);
    assert.doesNotMatch(JSON.stringify(last), /access-|refresh-/);
    // Saved for the next start too.
    assert.equal(store.data.status.activeId, "a");
    assert.equal(store.data.accounts.b.usage.fiveHour.pct, 20);
    const count = changes.length;
    await service.check();
    assert.equal(changes.length, count, "nothing changed, nothing sent");
  });

  it("changes settings as agents may, and refuses values out of range", async () => {
    const service = await setup();
    const result = await service.configure({
      set: { fiveHourAt: 90.4, autoSwitch: false },
      limits: { "b@example.com": { weekly: 80 } },
    });
    assert.equal(result.settings.fiveHourAt, 90);
    assert.equal(result.settings.autoSwitch, false);
    assert.deepEqual(result.settings.accountLimits, { "b@example.com": { weekly: 80 } });
    assert.deepEqual(store.data.settings.accountLimits, { b: { weekly: 80 } });
    await assert.rejects(service.configure({ set: { cooldownMin: 500 } }), /cooldownMin: a number from 1 to 120/);
    await assert.rejects(service.configure({ set: { nope: 1 } }), /No setting "nope"/);
    await assert.rejects(
      service.configure({ limits: { "x@example.com": { weekly: 50 } } }),
      /No account x@example.com/,
    );
    await service.configure({ limits: { "b@example.com": { weekly: null } } });
    assert.deepEqual(store.data.settings.accountLimits, {});
    // Auto-switch off: a full account stays.
    await service.check();
    assert.equal(await liveEmail(), "a@example.com");
    assert.equal(service.status().headline, "Auto-switch is off");
  });

  it("switches by hand, to the best account, and refuses an unknown one", async () => {
    activeLimits = (email) => limits(50, email);
    const service = await setup();
    await service.switch("b");
    assert.equal(await liveEmail(), "b@example.com");
    assert.equal(service.status().switches[0].reason, "you");
    assert.equal(await service.switchBest(), "a@example.com");
    assert.equal(await liveEmail(), "a@example.com");
    await assert.rejects(service.switch("nobody"), /No such account/);
  });

  it("adds the current login, disables and removes accounts", async () => {
    activeLimits = (email) => limits(50, email);
    const service = await setup();
    await writeFile(path.join(paths.claudeHome, ".credentials.json"), JSON.stringify({ claudeAiOauth: login("d") }));
    await writeFile(paths.globalConfig, JSON.stringify({ oauthAccount: who("d") }));
    assert.deepEqual(await service.addCurrent(), { id: "d", email: "d@example.com" });
    assert.equal(service.status().activeId, "d");
    await service.setEnabled("b", false);
    assert.equal(service.accounts().get("b").disabled, true);
    await service.setEnabled("b", true);
    assert.equal(service.accounts().get("b").disabled, undefined);
    await service.remove("b");
    assert.equal(service.accounts().has("b"), false);
    assert.equal(await createVault(paths).get("b"), null);
  });

  it("imports cswap's logins once", async () => {
    const service = await setup();
    const cswap = paths.cswap;
    await mkdir(path.join(cswap, "configs"), { recursive: true });
    await mkdir(path.join(cswap, "credentials"), { recursive: true });
    await writeFile(
      path.join(cswap, "sequence.json"),
      JSON.stringify({ accounts: { 1: { email: "e@example.com" }, 2: { email: "a@example.com" } } }),
    );
    await writeFile(
      path.join(cswap, "configs", ".claude-config-1-e@example.com.json"),
      JSON.stringify({ oauthAccount: who("e") }),
    );
    await writeFile(
      path.join(cswap, "credentials", ".creds-1-e@example.com.enc"),
      Buffer.from(JSON.stringify({ claudeAiOauth: login("e") })).toString("base64"),
    );
    await writeFile(
      path.join(cswap, "configs", ".claude-config-2-a@example.com.json"),
      JSON.stringify({ oauthAccount: who("a") }),
    );
    idleUsage["access-e"] = usage(15);
    const result = await service.importCswap();
    assert.deepEqual(result, { added: ["e@example.com"], problems: [] });
    assert.equal(service.accounts().get("e").usage.fiveHour.pct, 15);
    assert.equal((await createVault(paths).get("e")).credentials.claudeAiOauth.refreshToken, "refresh-e");
  });

  it("tells when the PC can next move to an account with room", async () => {
    activeLimits = (email) => limits(50, email);
    const service = await setup();
    await service.check();
    assert.equal(service.nextRoom().email, "b@example.com");
    await service.configure({ set: { autoSwitch: false } });
    assert.equal(service.nextRoom(), null);
  });

  describe("logging in from the panel", () => {
    it("adds a new account with a pasted code, and leaves the PC's login alone", async () => {
      const service = await setup();
      const links = await service.login();
      const challenge = new URL(links.manualUrl).searchParams.get("code_challenge");
      assert.equal(new URL(links.manualUrl).searchParams.get("redirect_uri"), MANUAL_REDIRECT);
      assert.match(new URL(links.url).searchParams.get("redirect_uri"), /^http:\/\/localhost:\d+\/callback$/);
      assert.equal(await service.loginCode(links.id, "the-code#"), "c@example.com");
      assert.equal(grants.length, 1);
      assert.equal(grants[0].code, "the-code");
      assert.equal(grants[0].redirectUri, MANUAL_REDIRECT);
      // The verifier traded is the one the page was asked with.
      assert.equal(createHash("sha256").update(grants[0].verifier).digest("base64url"), challenge);

      assert.equal(service.accounts().get("c").email, "c@example.com");
      assert.equal(service.accounts().get("c").state, "ok");
      assert.equal(service.accounts().get("c").usage.fiveHour.pct, 30);
      assert.equal((await createVault(paths).get("c")).credentials.claudeAiOauth.refreshToken, "refresh-c");
      assert.equal(await liveEmail(), "a@example.com");
      assert.deepEqual(service.status().switches, []);
      assert.equal(service.state().status.login.state, "done");
      // The login is over: its code can't be used again.
      await assert.rejects(service.loginCode(links.id, "the-code"), /ended/);
    });

    it("puts a new login of the PC's own account in place of the live one", async () => {
      const service = await setup();
      signedIn = { credentials: { claudeAiOauth: login("a-new") }, oauthAccount: who("a") };
      const links = await service.login();
      await service.loginCode(links.id, "code");
      const live = await credentials();
      assert.equal(live.claudeAiOauth.refreshToken, "refresh-a-new");
      assert.deepEqual(live.mcpOAuth, {});
      assert.equal((await createVault(paths).get("a")).credentials.claudeAiOauth.refreshToken, "refresh-a-new");
      assert.deepEqual(service.status().switches, []);
      assert.equal(service.status().activeId, "a");
    });

    it("signs the PC in when it has no login", async () => {
      const service = await setup();
      await writeFile(path.join(paths.claudeHome, ".credentials.json"), JSON.stringify({ mcpOAuth: {} }));
      const links = await service.login();
      await service.loginCode(links.id, "code");
      assert.equal(await liveEmail(), "c@example.com");
      assert.equal((await credentials()).claudeAiOauth.refreshToken, "refresh-c");
      assert.equal(service.status().activeId, "c");
    });

    it("makes an account that needed a login work again", async () => {
      store.data.accounts.b = { email: "b@example.com", state: "needs-login", addedAt: "x" };
      const service = await setup();
      store.data.accounts.b = { email: "b@example.com", state: "needs-login", addedAt: "x" };
      await service.start();
      signedIn = { credentials: { claudeAiOauth: login("b2") }, oauthAccount: who("b") };
      idleUsage["access-b2"] = usage(40);
      const links = await service.login("b@example.com");
      assert.equal(new URL(links.url).searchParams.get("login_hint"), "b@example.com");
      await service.loginCode(links.id, "code");
      assert.equal(service.accounts().get("b").state, "ok");
      assert.equal(service.accounts().get("b").addedAt, "x");
      assert.equal(service.accounts().get("b").usage.fiveHour.pct, 40);
    });

    it("refuses a code from another login, and takes the right one after it", async () => {
      const service = await setup();
      const links = await service.login();
      await assert.rejects(service.loginCode(links.id, "a#wrong-state"), /another login/);
      assert.deepEqual(grants, []);
      const state = new URL(links.manualUrl).searchParams.get("state");
      assert.equal(await service.loginCode(links.id, `a#${state}`), "c@example.com");
    });
  });

  describe("5-hour windows", () => {
    const notStarted = () => ({ ...usage(0), fiveHour: { pct: 0, resetsAt: null } });

    it("starts an idle account's window with its own login, without switching", async () => {
      idleUsage["access-b"] = notStarted();
      activeLimits = (email) => limits(50, email);
      const service = await setup();
      await service.check();
      assert.deepEqual(pings, ["access-b"]);
      assert.equal(await liveEmail(), "a@example.com");
      const b = service.accounts().get("b");
      assert.ok(b.windowStartedAt);
      assert.ok(Date.parse(b.usage.fiveHour.resetsAt) > Date.now() + 4 * HOUR);
      // Seen as running now: no second message.
      await service.check();
      assert.deepEqual(pings, ["access-b"]);
    });

    it("starts the active account's window with the PC's login", async () => {
      activeLimits = (email) => ({ ...limits(0, email), fiveHour: { utilization: 0, resetsAt: null } });
      const service = await setup();
      await service.check();
      assert.equal(activePings, 1);
      assert.deepEqual(pings, []);
    });

    it("counts a window that has reset as not running", async () => {
      idleUsage["access-b"] = { ...usage(80), fiveHour: { pct: 80, resetsAt: new Date(Date.now() - 1).toISOString() } };
      activeLimits = (email) => limits(50, email);
      const service = await setup();
      await service.check();
      assert.deepEqual(pings, ["access-b"]);
    });

    it("starts an idle account unused for a week, whose reading has neither window", async () => {
      idleUsage["access-b"] = { fiveHour: null, sevenDay: null, at: new Date().toISOString() };
      activeLimits = (email) => limits(50, email);
      const service = await setup();
      await service.check();
      assert.deepEqual(pings, ["access-b"]);
    });

    it("waits for the active account's first reading", async () => {
      activeLimits = (email) => ({ ...limits(0, email), fiveHour: null, sevenDay: null });
      const service = await setup();
      await service.check();
      assert.equal(activePings, 0);
    });

    it("does nothing with the setting off, unless asked", async () => {
      idleUsage["access-b"] = notStarted();
      activeLimits = (email) => limits(50, email);
      store.data.settings = { startWindows: false };
      const service = await setup();
      await service.check();
      assert.deepEqual(pings, []);
      assert.deepEqual(await service.startWindows(), ["b@example.com"]);
      assert.deepEqual(pings, ["access-b"]);
    });

    it("leaves an account alone whose weekly window is full", async () => {
      idleUsage["access-b"] = { ...notStarted(), sevenDay: { pct: 100, resetsAt: null } };
      activeLimits = (email) => limits(50, email);
      const service = await setup();
      await service.check();
      assert.deepEqual(pings, []);
    });
  });
});
