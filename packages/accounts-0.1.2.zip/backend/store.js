// The plugin's own state, in files in its LAYR_DATA_DIR (never Supabase, never synced): the account records (emails,
// plans, readings; no tokens), the settings, and the service's status (switches, the last login, what went wrong).
// They are small and written whole, through a temporary file and a rename.

import path from "node:path";
import { readJson, writeJson } from "./files.js";

export function createStore(dir) {
  const file = (name) => path.join(dir, `${name}.json`);
  const read = async (name, fallback) => {
    try {
      return (await readJson(file(name))) ?? fallback;
    } catch {
      // A broken file (cut off by a crash) is started over rather than stopping the plugin.
      return fallback;
    }
  };
  return {
    dir,
    /** `{accounts: {id: Account}, settings: StoredSettings, status: ServiceStatus|null}` */
    async load() {
      const [accounts, settings, status] = await Promise.all([
        read("accounts", {}),
        read("settings", {}),
        read("status", null),
      ]);
      return { accounts, settings, status };
    },
    saveAccounts: (accounts) => writeJson(file("accounts"), accounts, 2),
    saveSettings: (settings) => writeJson(file("settings"), settings, 2),
    saveStatus: (status) => writeJson(file("status"), status, 2),
  };
}

/** A store in memory, for tests. */
export function memoryStore(initial = {}) {
  const data = { accounts: {}, settings: {}, status: null, ...structuredClone(initial) };
  return {
    data,
    async load() {
      return structuredClone(data);
    },
    async saveAccounts(accounts) {
      data.accounts = structuredClone(accounts);
    },
    async saveSettings(settings) {
      data.settings = structuredClone(settings);
    },
    async saveStatus(status) {
      data.status = structuredClone(status);
    },
  };
}
