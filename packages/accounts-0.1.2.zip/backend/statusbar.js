// The status bar item: the active account's short name and how full its 5-hour window is; the tooltip lists every
// account; clicking opens the Accounts panel.
import { shortName, windowPct } from "../shared/types.js";

const pctText = (w, now) => {
  const pct = windowPct(w, now);
  return pct === null ? "–" : `${Math.round(pct)}%`;
};

/** `state`: what service.state() gives. Returns `{text, tooltip, icon, command}`. */
export function statusBarItem(state, now = Date.now()) {
  const accounts = state?.accounts ?? [];
  const status = state?.status ?? {};
  const active = accounts.find((a) => a.id === status.activeId);
  const lines = accounts
    .slice()
    .sort((a, b) => (a.number ?? 0) - (b.number ?? 0))
    .map(
      (a) =>
        `${a.id === status.activeId ? "● " : ""}#${a.number} ${a.email}: 5h ${pctText(a.usage?.fiveHour, now)}, ` +
        `weekly ${pctText(a.usage?.sevenDay, now)}${a.state === "needs-login" ? " (needs login)" : ""}`,
    );
  let text;
  if (active) text = `${shortName(active.email)} ${pctText(active.usage?.fiveHour, now)}`;
  else if (status.liveEmail) text = `${shortName(status.liveEmail)} (not added)`;
  else text = accounts.length ? "Claude: signed out" : "Claude accounts";
  const tooltip = [
    active ? `The PC's Claude Code uses ${active.email}` : status.liveEmail ? `The PC uses ${status.liveEmail}` : null,
    ...lines,
    status.headline,
  ]
    .filter(Boolean)
    .join("\n");
  return { text, tooltip, icon: "switch_account", command: "open" };
}
