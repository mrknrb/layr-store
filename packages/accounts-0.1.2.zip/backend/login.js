// Logging an account in from the panel, as Claude Code's /login does (OAuth with PKCE, Claude Code's own client).
// The panel opens Claude's login page. When the browser runs on the PC, the page comes back to a port this backend
// listens on while the login lasts; anywhere else (the phone) the page shows a code, which is pasted into the panel.

import { createHash, randomBytes } from "node:crypto";
import { createServer } from "node:http";
import { CallFailed, CLIENT_ID } from "./oauth.js";

const AUTHORIZE_URL = "https://claude.com/cai/oauth/authorize";
/** Where the login page shows the code to paste, instead of coming back to the PC. */
export const MANUAL_REDIRECT = "https://platform.claude.com/oauth/code/callback";
/** Claude's "you're logged in" page, where the browser goes once the PC has the login. */
const SUCCESS_URL = "https://platform.claude.com/oauth/code/success?app=claude-code";
/** Claude Code's scopes for a claude.ai login. */
const SCOPES = [
  "org:create_api_key",
  "user:profile",
  "user:inference",
  "user:sessions:claude_code",
  "user:mcp_servers",
  "user:file_upload",
  "user:plugins",
];
const LOGIN_MS = 10 * 60_000;

const random = (bytes) => randomBytes(bytes).toString("base64url");
const errorText = (error) => (error instanceof Error ? error.message : String(error));

/** What the login page's answer says, pasted as the code (`code#state`) or as the whole address. */
export function parseCode(text) {
  const trimmed = String(text ?? "").trim();
  try {
    const url = new URL(trimmed);
    const code = url.searchParams.get("code");
    if (code) return { code, state: url.searchParams.get("state") ?? undefined };
  } catch {
    // Not an address.
  }
  const [code = "", state] = trimmed.split("#");
  return { code: code.trim(), ...(state ? { state: state.trim() } : {}) };
}

function authorizeUrl(challenge, state, redirectUri, hint) {
  const url = new URL(AUTHORIZE_URL);
  url.searchParams.append("code", "true");
  url.searchParams.append("client_id", CLIENT_ID);
  url.searchParams.append("response_type", "code");
  url.searchParams.append("redirect_uri", redirectUri);
  url.searchParams.append("scope", SCOPES.join(" "));
  url.searchParams.append("code_challenge", challenge);
  url.searchParams.append("code_challenge_method", "S256");
  url.searchParams.append("state", state);
  if (hint) url.searchParams.append("login_hint", hint);
  return url.toString();
}

function page(res, status, text) {
  const escaped = text.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  res.writeHead(status, { "Content-Type": "text/html; charset=utf-8" });
  res.end(
    `<!doctype html><meta charset="utf-8"><title>layr: Claude login</title>` +
      `<body style="font:16px system-ui;margin:3em"><p>${escaped}</p><p>You can close this tab.</p></body>`,
  );
}

/**
 * One login at a time: starting another ends the one before. `deps`: `finish(grant)` trades the code for the login
 * and stores the account (returns its email); `changed(status)` hears that the login started, ended or failed
 * (a LoginStatus); `timeoutMs`.
 */
export function createLogins(deps) {
  let current = null;
  const now = () => new Date().toISOString();

  const end = (flow = current) => {
    if (!flow || flow !== current) return;
    clearTimeout(flow.timer);
    for (const server of flow.servers) server.close();
    current = null;
  };

  const refused = (error) =>
    error instanceof CallFailed && /^http-4\d\d$/.test(error.kind)
      ? "Claude refused the code: a code works once, for a few minutes. Press Log in again."
      : errorText(error);

  async function finish(flow, code, redirectUri) {
    if (flow !== current) throw new Error("That login has ended: press Log in again");
    try {
      const email = await deps.finish({ code, verifier: flow.verifier, state: flow.state, redirectUri });
      end(flow);
      deps.changed({ id: flow.id, state: "done", email, at: now() });
      return email;
    } catch (error) {
      const message = refused(error);
      deps.changed({ id: flow.id, state: "failed", error: message, at: now() });
      throw new Error(message);
    }
  }

  return {
    /** Starts a login (`hint`: the email to log in with); gives the login page's addresses `{id, url, manualUrl}`. */
    async start(hint) {
      end();
      const id = random(6);
      const verifier = random(32);
      const state = random(32);
      const challenge = createHash("sha256").update(verifier).digest("base64url");
      let flow;
      let redirectUri;

      const handle = (req, res) => {
        const url = new URL(req.url ?? "/", "http://localhost");
        if (url.pathname !== "/callback" || url.searchParams.get("state") !== state) {
          res.writeHead(404).end();
          return;
        }
        const code = url.searchParams.get("code");
        if (!code) {
          const why = url.searchParams.get("error_description") ?? url.searchParams.get("error") ?? "no code";
          deps.changed({ id, state: "failed", error: `The login page came back without a login (${why})`, at: now() });
          page(res, 400, `The login didn't go through (${why}). Press Log in again in layr.`);
          return;
        }
        finish(flow, code, redirectUri).then(
          () => res.writeHead(302, { Location: SUCCESS_URL }).end(),
          (error) => page(res, 500, errorText(error)),
        );
      };

      // `localhost` may be either address to the browser: both are listened on, on the same port.
      const v4 = createServer(handle);
      await new Promise((resolve, reject) => {
        v4.once("error", reject);
        v4.listen(0, "127.0.0.1", () => resolve());
      });
      const port = v4.address().port;
      const v6 = createServer(handle);
      v6.on("error", () => {});
      v6.listen(port, "::1");
      redirectUri = `http://localhost:${port}/callback`;

      flow = {
        id,
        verifier,
        state,
        servers: [v4, v6],
        timer: setTimeout(() => {
          if (flow !== current) return;
          end(flow);
          deps.changed({ id, state: "failed", error: "The login timed out: press Log in again", at: now() });
        }, deps.timeoutMs ?? LOGIN_MS),
      };
      flow.timer.unref?.();
      current = flow;
      deps.changed({ id, state: "waiting", at: now() });
      return {
        id,
        url: authorizeUrl(challenge, state, redirectUri, hint),
        manualUrl: authorizeUrl(challenge, state, MANUAL_REDIRECT, hint),
      };
    },

    /** Finishes the login `id` with the code the login page showed; returns the account's email. */
    async paste(id, text) {
      const flow = current;
      if (!flow || flow.id !== id) throw new Error("That login has ended: press Log in again");
      const { code, state } = parseCode(text);
      if (!code) throw new Error("Paste the code the login page shows");
      if (state && state !== flow.state) throw new Error("That code is from another login: press Log in again");
      return finish(flow, code, MANUAL_REDIRECT);
    },

    cancel(id) {
      if (current && (!id || current.id === id)) end();
    },
  };
}
