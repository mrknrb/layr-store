// layr's copies of the logins: one file per account in the vault folder, with the previous version next to it.
// They hold refresh tokens, so they never leave the PC (the panel and agents get account records without them).
//
// Who may refresh a login: the live one belongs to Claude Code (layr only copies it), an idle one belongs to layr.
//
// A vault entry is `{credentials, oauthAccount, savedAt}`: `credentials` is `.credentials.json` without its
// machine-wide parts (`claudeAiOauth` and the account's own keys), `oauthAccount` is the block of `~/.claude.json`
// that says who the login is (`accountUuid`, `emailAddress`, `organizationUuid?`, `organizationName?`, …).

import { copyFile, readdir, rm } from "node:fs/promises";
import path from "node:path";
import { credentialsFile, readJson, writeJson } from "./files.js";

/** Keys of `.credentials.json` that belong to the PC, not to an account (`mcpOAuth`: MCP servers' logins). */
const MACHINE_KEYS = ["mcpOAuth"];

const fileOf = (paths, id) => {
  if (!/^[\w-]+$/.test(id)) throw new Error(`Not an account id: ${id}`);
  return path.join(paths.vault, `${id}.json`);
};

export function accountPart(credentials) {
  return Object.fromEntries(Object.entries(credentials).filter(([key]) => !MACHINE_KEYS.includes(key)));
}

/** The account's credentials with the PC's own parts of the live file kept. */
export function withMachinePart(stored, live) {
  const machine = Object.fromEntries(Object.entries(live ?? {}).filter(([key]) => MACHINE_KEYS.includes(key)));
  return { ...stored, ...machine };
}

export const isLogin = (value) =>
  !!value &&
  typeof value === "object" &&
  typeof value.accessToken === "string" &&
  typeof value.refreshToken === "string";

export function createVault(paths) {
  return {
    async get(id) {
      return readJson(fileOf(paths, id));
    },

    /** `entry`: `{credentials, oauthAccount}`. */
    async put(id, entry) {
      const file = fileOf(paths, id);
      // The version before stays next to it: a token lost to a bug can often be got back from there.
      await copyFile(file, `${file}.prev`).catch(() => {});
      await writeJson(file, { ...entry, savedAt: new Date().toISOString() }, 2);
    },

    async remove(id) {
      const file = fileOf(paths, id);
      await rm(file, { force: true });
      await rm(`${file}.prev`, { force: true });
    },

    async ids() {
      const names = await readdir(paths.vault).catch(() => []);
      return names.filter((n) => n.endsWith(".json")).map((n) => n.slice(0, -".json".length));
    },
  };
}

/**
 * What the PC's Claude Code is signed in with: `{credentials, config, oauthAccount}` (the whole `.credentials.json`
 * or null, the whole `~/.claude.json` or null, and its `oauthAccount` when it names an account). Throws when a file is
 * there but can't be read.
 */
export async function readLive(paths) {
  const [credentials, config] = await Promise.all([readJson(credentialsFile(paths)), readJson(paths.globalConfig)]);
  const account = config?.oauthAccount;
  return {
    credentials,
    config,
    oauthAccount: account && typeof account.accountUuid === "string" ? account : null,
  };
}
