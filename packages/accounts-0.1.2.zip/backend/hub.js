// The backend's link to the core's MCP hub (docs/ARCHITECTURE.md > The MCP hub): the claude plugin's usage reading,
// events to the panels, notifications. Without LAYR_HUB_URL (a test over stdio) it is simply not available.
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { errorMessage, log } from "./util.js";

export class Hub {
  constructor({ url, token }) {
    this.url = url;
    this.token = token;
    this.client = null;
    this.connecting = null;
    this.warned = new Set();
  }

  get available() {
    return Boolean(this.url && this.token);
  }

  async connect() {
    if (this.client) return this.client;
    if (!this.available) throw new Error("No hub: LAYR_HUB_URL and LAYR_HUB_TOKEN are not set");
    this.connecting ??= (async () => {
      const client = new Client({ name: "layr-plugin-accounts", version: "0.1.0" });
      const transport = new StreamableHTTPClientTransport(new URL(this.url), {
        requestInit: { headers: { Authorization: `Bearer ${this.token}` } },
      });
      client.onclose = () => {
        if (this.client === client) this.client = null;
      };
      await client.connect(transport);
      this.client = client;
      return client;
    })().finally(() => (this.connecting = null));
    return this.connecting;
  }

  /** Call a hub tool; gives its structured content, or its text parsed as JSON when it is JSON. */
  async call(name, args = {}, { timeout } = {}) {
    let client = await this.connect();
    let result;
    const options = timeout ? { timeout } : undefined;
    try {
      result = await client.callTool({ name, arguments: args }, undefined, options);
    } catch (error) {
      // The core may have restarted its HTTP session: connect once more.
      this.client = null;
      client = await this.connect();
      result = await client.callTool({ name, arguments: args }, undefined, options);
    }
    if (result.isError) {
      const text = (result.content ?? []).map((c) => c.text ?? "").join("\n");
      throw new Error(text || `${name} failed`);
    }
    if (result.structuredContent !== undefined) return result.structuredContent;
    const text = (result.content ?? [])
      .filter((c) => c.type === "text")
      .map((c) => c.text)
      .join("\n");
    try {
      return JSON.parse(text);
    } catch {
      return text;
    }
  }

  /** Fire and forget: failures are logged once per tool, not thrown. */
  quiet(name, args) {
    if (!this.available) return;
    this.call(name, args).catch((error) => {
      if (this.warned.has(name)) return;
      this.warned.add(name);
      log(`${name} failed (further failures not logged): ${errorMessage(error)}`);
    });
  }

  /** An event for the panels. */
  emit(topic, data) {
    this.quiet("layr__events_emit", { topic, data });
  }

  notify(text, kind = "info") {
    this.quiet("layr__notify", { text, kind });
  }

  async close() {
    try {
      await this.client?.close();
    } catch {
      // closing anyway
    }
  }
}
