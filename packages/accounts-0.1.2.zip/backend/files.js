// Where Claude Code, cswap and layr keep the files this plugin reads and writes, and how it writes them.

import { existsSync, statSync } from "node:fs";
import { mkdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";

/**
 * The paths, resolved as Claude Code resolves them: `.config.json` in the config home wins when it is a non-empty
 * file. Every one can be moved for tests (and a second profile) through the environment:
 * - `CLAUDE_CONFIG_DIR`: Claude Code's own config home (its `.credentials.json` and `.claude.json` live there then);
 * - `LAYR_ACCOUNTS_HOME`: the home folder in place of the user's (`~/.claude`, `~/.claude.json`, cswap's data, the
 *   vault);
 * - `LAYR_ACCOUNTS_VAULT`: layr's copies of the logins.
 *
 * Returns `{claudeHome, globalConfig, vault, cswap}`: Claude Code's config home (`.credentials.json` and its locks),
 * its global config with `oauthAccount` (`~/.claude.json`), layr's copies of the logins (one file per account), and
 * cswap's data (for the one-time import).
 */
export function defaultPaths(env = process.env) {
  const home = env.LAYR_ACCOUNTS_HOME || os.homedir();
  const configDir = env.CLAUDE_CONFIG_DIR;
  const claudeHome = configDir || path.join(home, ".claude");
  const legacy = path.join(claudeHome, ".config.json");
  const legacyUsed = existsSync(legacy) && statSync(legacy).isFile() && statSync(legacy).size > 0;
  return {
    claudeHome,
    globalConfig: legacyUsed ? legacy : path.join(configDir || home, ".claude.json"),
    // The same folder as today's layr (layr_code) keeps them in: its accounts show up here without a new login, and
    // the two share one copy of each refresh token instead of breaking each other's (a refresh token works once).
    vault: env.LAYR_ACCOUNTS_VAULT || path.join(home, ".layr", "accounts"),
    cswap: path.join(home, ".claude-swap-backup"),
  };
}

export const credentialsFile = (paths) => path.join(paths.claudeHome, ".credentials.json");

/** The file's JSON, `null` when it doesn't exist. Throws when it exists but can't be read or parsed. */
export async function readJson(file) {
  let text;
  try {
    text = await readFile(file, "utf8");
  } catch (error) {
    if (error?.code === "ENOENT") return null;
    throw error;
  }
  return JSON.parse(text);
}

/**
 * Write through a temporary file and a rename, so a reader never sees half a file. Windows refuses the rename while
 * another process has the file open for a moment, so it tries a few times.
 */
export async function writeAtomic(file, text) {
  await mkdir(path.dirname(file), { recursive: true });
  const temp = `${file}.layr-${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.tmp`;
  await writeFile(temp, text, { encoding: "utf8", mode: 0o600 });
  for (let attempt = 0; ; attempt++) {
    try {
      await rename(temp, file);
      return;
    } catch (error) {
      const code = error?.code;
      if (attempt >= 8 || (code !== "EPERM" && code !== "EBUSY" && code !== "EACCES")) {
        await rm(temp, { force: true });
        throw error;
      }
      await new Promise((resolve) => setTimeout(resolve, 50 * (attempt + 1)));
    }
  }
}

/** As Claude Code writes them: `.credentials.json` on one line, `.claude.json` with two-space indents. */
export const writeJson = (file, data, indent) => writeAtomic(file, JSON.stringify(data, null, indent));
