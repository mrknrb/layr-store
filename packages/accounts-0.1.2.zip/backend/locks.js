// Claude Code's own locks, held while a switch writes its files (the protocol as cswap documents it for Claude
// Code 2.1.x). They are `proper-lockfile` directories: `mkdir` is the mutex, holders touch the directory every few
// seconds, and a lock untouched for longer than its staleness belongs to a dead holder.
//
// Claude Code refreshes its token under `<config home>/.oauth_refresh.lock`, then `~/.claude.lock` (both stale after
// 60 s), and writes `~/.claude.json` under `~/.claude.json.lock` (stale after 10 s). Holding them means a refresh in
// Claude Code either finishes before the switch (and the switch copies the rotated token) or starts after it.

import { mkdir, rmdir, stat, utimes } from "node:fs/promises";
import path from "node:path";

const TOUCH_MS = 3_000;
const TIMEOUT_MS = 9_000;

export class LockTimeout extends Error {}

async function acquire(dir, staleMs, timeoutMs) {
  const start = Date.now();
  for (;;) {
    try {
      await mkdir(dir);
      break;
    } catch (error) {
      if (error?.code !== "EEXIST") throw error;
    }
    if (Date.now() - start > timeoutMs) {
      throw new LockTimeout(`${path.basename(dir)} stayed taken: Claude Code is busy with its login, try again`);
    }
    const held = await stat(dir).catch(() => null);
    if (held && Date.now() - held.mtimeMs > staleMs) {
      await rmdir(dir).catch(() => {});
      continue;
    }
    await new Promise((resolve) => setTimeout(resolve, 250 + Math.random() * 250));
  }
  const toucher = setInterval(() => {
    const now = new Date();
    void utimes(dir, now, now).catch(() => {});
  }, TOUCH_MS);
  return async () => {
    clearInterval(toucher);
    await rmdir(dir).catch(() => {});
  };
}

/** Runs `fn` holding Claude Code's credential locks and its config lock, taken in Claude Code's order. */
export async function withClaudeLocks(paths, fn, timeoutMs = TIMEOUT_MS) {
  const home = paths.claudeHome.replace(/[\\/]+$/, "");
  const locks = [
    { dir: path.join(home, ".oauth_refresh.lock"), staleMs: 60_000 },
    { dir: `${home}.lock`, staleMs: 60_000 },
    { dir: `${paths.globalConfig}.lock`, staleMs: 10_000 },
  ];
  const held = [];
  try {
    for (const lock of locks) held.push(await acquire(lock.dir, lock.staleMs, timeoutMs));
    return await fn();
  } finally {
    for (const release of held.reverse()) await release();
  }
}
