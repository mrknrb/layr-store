// Small helpers shared by the backend modules.

/** Log to stderr: the core keeps it in logs/accounts.log (stdout is MCP). Never log tokens. */
export function log(...args) {
  const text = args.map((a) => (typeof a === "string" ? a : a instanceof Error ? a.stack || a.message : safeJson(a)));
  process.stderr.write(`[accounts ${new Date().toISOString()}] ${text.join(" ")}\n`);
}

export function safeJson(value) {
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

export function errorMessage(error) {
  if (error instanceof Error) return error.message;
  return typeof error === "string" ? error : safeJson(error);
}
