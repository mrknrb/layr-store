// The active account's usage, and its one-word message. Today's layr had core AI measure the account the PC uses
// (`ctx.ai.limits`) and send its message (`ctx.ai.run`); here nothing in the core runs Claude, so:
// - usage comes from the `claude` plugin (`claude__usage`), which measures the PC's login anyway and also hears when
//   a thread was refused for a limit (`rejectedUntil`); without it (not installed, failing) from the usage endpoint
//   with the live token;
// - the message goes straight to the Messages API with the live token.
// The live login belongs to Claude Code: its access token is used while it is valid, and never refreshed here.

import { CallFailed } from "./oauth.js";
import { isLogin, readLive } from "./vault.js";
import { errorMessage } from "./util.js";

/** After the claude plugin failed to answer, it is asked again this much later. */
const CLAUDE_RETRY_MS = 10 * 60_000;
/** After a 429 the usage endpoint is left alone at least this long. */
const BACKOFF_MS = 15 * 60_000;
/** The live token must last this long to be used: Claude Code refreshes it near its end. */
const MIN_VALID_MS = 60_000;

/** `hub` (hub.js, may be unavailable), `net` (oauth.js), `paths` (files.js), `log`. */
export function createActive({ hub, net, paths, log = () => {} }) {
  let claudeOffUntil = 0;
  let direct = null;
  let backoffUntil = 0;

  async function fromClaude(maxAgeMs) {
    if (!hub?.available || Date.now() < claudeOffUntil) return null;
    try {
      const age = (u) => (u?.updatedAt ? Date.now() - Date.parse(u.updatedAt) : Infinity);
      // The claude plugin keeps its reading for 5 minutes; `refresh` measures again (it starts Claude Code idle).
      let u = maxAgeMs <= 0 ? null : await hub.call("claude__usage", {}, { timeout: 90_000 });
      if (!u || age(u) > maxAgeMs) u = await hub.call("claude__usage", { refresh: true }, { timeout: 90_000 });
      const l = u?.limits;
      if (!l || (!l.fiveHour && !l.sevenDay && !l.rejectedUntil)) return null;
      return {
        fiveHour: l.fiveHour ?? null,
        sevenDay: l.sevenDay ?? null,
        rejectedUntil: l.rejectedUntil ?? null,
        updatedAt: u.updatedAt ?? new Date().toISOString(),
        account: u.account?.email ?? null,
        source: "claude",
      };
    } catch (error) {
      claudeOffUntil = Date.now() + CLAUDE_RETRY_MS;
      log(`claude__usage unavailable, measuring the active account myself: ${errorMessage(error)}`);
      return null;
    }
  }

  async function fromEndpoint(maxAgeMs) {
    const live = await readLive(paths);
    const login = live.credentials?.claudeAiOauth;
    const account = live.oauthAccount?.emailAddress ?? null;
    const known = direct && direct.account === account ? direct.limits : null;
    if (known && Date.now() - direct.at < maxAgeMs) return known;
    if (Date.now() < backoffUntil) return known;
    if (!isLogin(login) || login.expiresAt - Date.now() < MIN_VALID_MS) return known;
    try {
      const usage = await net.usage(login.accessToken);
      const window = (w) => (w ? { utilization: w.pct, resetsAt: w.resetsAt } : null);
      const limits = {
        fiveHour: window(usage.fiveHour),
        sevenDay: window(usage.sevenDay),
        rejectedUntil: null,
        updatedAt: usage.at,
        account,
        source: "usage",
      };
      direct = { limits, at: Date.now(), account };
      return limits;
    } catch (error) {
      if (error instanceof CallFailed && error.kind === "http-429") backoffUntil = Date.now() + BACKOFF_MS;
      log(`usage of the active account: ${error instanceof CallFailed ? error.kind : ""} ${errorMessage(error)}`);
      return known;
    }
  }

  return {
    async limits({ maxAgeMs = 5 * 60_000 } = {}) {
      return (await fromClaude(maxAgeMs)) ?? fromEndpoint(maxAgeMs);
    },

    async ping() {
      const live = await readLive(paths);
      const login = live.credentials?.claudeAiOauth;
      if (!isLogin(login) || login.expiresAt - Date.now() < MIN_VALID_MS) {
        throw new Error("the PC's login is due for Claude Code to refresh it; tried again later");
      }
      await net.ping(login.accessToken);
    },
  };
}
