// When auto-switch moves the PC to another account, and to which one. Pure: the service gives it the readings.

import { atLimit, planWeight, pointsOf, roomAt, roomLeft, windowPct } from "../shared/types.js";

/** A reading this recent is trusted for a switch at a switch point. */
export const FRESH_MS = 15 * 60_000;
/** A target must be this far below its own switch points, so two accounts at the line don't swap back and forth. */
export const MARGIN = 5;

/**
 * The working, enabled account other than the active one with the most room before its own switch points, weighed by
 * its plan (a Max 5x point is worth five Pro points; one not measured yet comes last). `accounts`: [id, account].
 */
export function bestOther(accounts, activeId, settings, now = Date.now()) {
  const room = ([id, a]) => (roomLeft(a.usage, pointsOf(settings, id), now) ?? -Infinity) * planWeight(a);
  const others = accounts.filter(([id, a]) => id !== activeId && a.state === "ok" && !a.disabled);
  return others.sort((a, b) => room(b) - room(a))[0]?.[0];
}

/**
 * The soonest another working, enabled account has room below its own switch points (`at` is `now` when one has room
 * already), so auto-switch can move to it: `{id, at}`. `null` when none will.
 */
export function nextRoom(accounts, activeId, settings, now = Date.now()) {
  let best = null;
  for (const [id, a] of accounts) {
    if (id === activeId || a.state !== "ok" || a.disabled) continue;
    const at = roomAt(a.usage, pointsOf(settings, id), now);
    if (at !== null && (!best || at < best.at)) best = { id, at };
  }
  return best;
}

const clock = (at) => new Date(at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

/**
 * `input`: `{now, settings, activeId, activeUsage (the active account's usage), rejected (a run was refused for a
 * limit), accounts ([id, account]), lastSwitch?, remeasured? (accounts measured again for this decision already: their
 * readings stay as they are)}`. Gives `{headline, switchTo?: {id, reason}, measure?: [ids to measure, then decide
 * again]}`.
 */
export function decide(input) {
  const { now, settings, activeId, accounts } = input;
  if (!settings.autoSwitch) return { headline: "Auto-switch is off" };
  if (!activeId) return { headline: "The PC's login isn't one of these accounts: add it to switch from it" };

  const points = pointsOf(settings, activeId);
  const room = roomLeft(input.activeUsage, points, now);
  const limit = input.rejected || atLimit(input.activeUsage, now);
  if (!limit && (room === null || room > 0)) {
    return { headline: `Watching: switches at 5h ${points.fiveHour}% · weekly ${points.weekly}%` };
  }

  const cooldownEnds = input.lastSwitch ? Date.parse(input.lastSwitch.at) + settings.cooldownMin * 60_000 : 0;
  if (cooldownEnds > now) return { headline: `Just switched; checks again at ${clock(cooldownEnds)}` };

  const others = accounts.filter(([id, a]) => id !== activeId && a.state === "ok" && !a.disabled);
  const fresh = (a) => !!a.usage && now - Date.parse(a.usage.at) <= FRESH_MS;
  if (!input.remeasured) {
    const stale = others.filter(([, a]) => !fresh(a)).map(([id]) => id);
    if (stale.length) return { headline: "Measuring the other accounts", measure: stale };
  }

  // At the limit any account with room beats waiting, even one measured a while ago.
  const margin = limit ? 0 : MARGIN;
  const usable = others.filter(([id, a]) => {
    const left = roomLeft(a.usage, pointsOf(settings, id), now);
    return left === null ? limit : left > margin && (limit || fresh(a));
  });
  const best = bestOther(usable, activeId, settings, now);
  if (best) return { headline: "Switching", switchTo: { id: best, reason: limit ? "limit" : "threshold" } };

  // The soonest a window that holds an account back resets.
  const resets = [[activeId, input.activeUsage], ...others.map(([id, a]) => [id, a.usage])]
    .flatMap(([id, usage]) => {
      const at = pointsOf(settings, id);
      return [
        [usage?.fiveHour, at.fiveHour],
        [usage?.sevenDay, at.weekly],
      ];
    })
    .filter(([w, at]) => w?.resetsAt && (windowPct(w, now) ?? 0) >= at - margin && Date.parse(w.resetsAt) > now)
    .map(([w]) => Date.parse(w.resetsAt));
  const until = resets.length ? ` until ${clock(Math.min(...resets))}` : "";
  return { headline: `All accounts are near the limit${until}` };
}
