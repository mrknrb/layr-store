// Moving the PC's Claude Code to another login. Claude Code, layr's Claude threads (the `claude` plugin runs them
// with the PC's login) and any other Claude Code on the PC read `.credentials.json` again when it changes, so each of
// them goes on with the new account on its next request.

import { rm } from "node:fs/promises";
import { credentialsFile, readJson, writeJson } from "./files.js";
import { withClaudeLocks } from "./locks.js";
import { accountPart, isLogin, readLive, withMachinePart } from "./vault.js";

/** A target's token must last at least this long, so Claude Code doesn't refresh it the moment it gets it. */
const MIN_VALID_MS = 5 * 60_000;

/**
 * The idle account's entry with a token valid for `minMs` more, refreshed (and saved first) when needed. Never call
 * it for the live account: its login belongs to Claude Code, which rotates it on its own. `d`: `{paths, vault, net}`.
 */
export async function freshen(d, id, entry, minMs = MIN_VALID_MS) {
  const login = entry.credentials.claudeAiOauth;
  if (login.expiresAt - Date.now() > minMs) return entry;
  const next = await d.net.refresh(login);
  const updated = { credentials: { ...entry.credentials, claudeAiOauth: next }, oauthAccount: entry.oauthAccount };
  // A refresh token works once: the new one is saved before anything uses it.
  await d.vault.put(id, updated);
  return { ...updated, savedAt: new Date().toISOString() };
}

/**
 * Switches to `targetId`; returns `{from}` with the account left (`null`: none of yours), or `undefined` when it was
 * active. `replace`: also when it is active, putting its stored login in place of the live one (after a new login with
 * it); then it returns `targetId` as the account left.
 */
export async function switchTo(d, targetId, { replace = false } = {}) {
  const before = await readLive(d.paths);
  if (before.oauthAccount?.accountUuid === targetId && !replace) return undefined;
  const stored = await d.vault.get(targetId);
  if (!stored) throw new Error("That account isn't stored on the PC: add it again");
  const target = await freshen(d, targetId, stored);

  return withClaudeLocks(d.paths, async () => {
    // Read again under the locks: Claude Code may have rotated its token meanwhile.
    const live = await readLive(d.paths);
    const fromId = live.oauthAccount?.accountUuid ?? null;
    const same = fromId === targetId;
    if (same && !replace) return undefined;
    const leaving = fromId && !same ? await d.vault.get(fromId) : null;
    const liveLogin = isLogin(live.credentials?.claudeAiOauth);
    if (liveLogin && !leaving && !same) {
      const who = live.oauthAccount?.emailAddress ?? "an unknown account";
      throw new Error(`The PC is signed in with ${who}, which isn't stored: add it first, or its login would be lost`);
    }
    // The account being left keeps the login as Claude Code last rotated it.
    if (liveLogin && leaving && fromId && live.oauthAccount) {
      await d.vault.put(fromId, { credentials: accountPart(live.credentials), oauthAccount: live.oauthAccount });
    }

    const file = credentialsFile(d.paths);
    await writeJson(file, withMachinePart(target.credentials, live.credentials));
    try {
      const config = (await readJson(d.paths.globalConfig)) ?? {};
      await writeJson(d.paths.globalConfig, { ...config, oauthAccount: target.oauthAccount }, 2);
    } catch (error) {
      if (live.credentials) await writeJson(file, live.credentials);
      else await rm(file, { force: true });
      throw error;
    }
    return { from: same ? targetId : leaving ? fromId : null };
  });
}
