// The accounts service: every minute it reads the PC's live login, keeps layr's copy of it current, measures the
// idle accounts now and then, starts 5-hour windows that aren't running (setting `startWindows`), and (with
// auto-switch on) switches near the limit. It also adds accounts logged in from the panel (`login.js`). One thing at
// a time: checks and commands wait for each other, so two of them never write the same login.

import { usageOverview } from "../shared/overview.js";
import { NUMBERS, numbersOf, pointsOf, roomLeft, settingsOf, SWITCHES, windowIdle } from "../shared/types.js";
import { bestOther, decide, nextRoom } from "./auto.js";
import { cswapAutoCount, readCswap } from "./cswap.js";
import { createLogins } from "./login.js";
import { CallFailed, LoginExpired } from "./oauth.js";
import { freshen, switchTo } from "./switch.js";
import { accountPart, isLogin, readLive } from "./vault.js";

const TICK_MS = 60_000;
const CSWAP_CHECK_MS = 5 * 60_000;
/** After a 429 the usage endpoint is left alone at least this long. */
const BACKOFF_MS = 15 * 60_000;
const MAX_SWITCHES = 10;
/** A window that didn't start (or isn't seen as started yet) is tried again after this long. */
const START_RETRY_MS = 15 * 60_000;
/** How often an account's plan is read again from its profile (it changes when you upgrade). */
const PLAN_MS = 6 * 3_600_000;

const errorText = (error) => (error instanceof Error ? error.message : String(error));

/**
 * `d`:
 * - `store` (store.js), `paths`, `vault`, `net` (oauth.js);
 * - `limits({maxAgeMs})`: the active account's usage as someone who measures it anyway saw it (the `claude` plugin,
 *   else the usage endpoint with the live token), at most `maxAgeMs` old: `{fiveHour: {utilization, resetsAt},
 *   sevenDay, rejectedUntil, updatedAt, account (its email)}` or null. Was core AI's `ctx.ai.limits` in today's layr;
 * - `pingActive()`: sends the active account a one-word message (was `ctx.ai.run`);
 * - `coreSettings` (optional): `{get(): values|null, set(id, value)}`, the core's plugin settings for the general
 *   ones (autoSwitch, fiveHourAt, …; manifest `settings`); without it, or when it answers nothing, they live in the
 *   plugin's own settings file with the accounts' own switch points;
 * - `onChange(state)`: what the panel shows changed; `log(...)`; `cswapCount()` and `tickMs` (tests).
 */
export function createService(d) {
  const { vault, store } = d;
  const log = d.log ?? (() => {});
  const accounts = new Map();
  /** The plugin's own settings file: the accounts' own switch points (and everything when the core has no settings). */
  let stored = {};
  /** The general settings as the core keeps them (the shell's Settings page shows them); null: not available. */
  let general = null;
  let settings = settingsOf(null);
  const computeSettings = () => settingsOf(general ? { ...general, accountLimits: stored.accountLimits } : stored);
  let switches = [];
  let problem;
  let cswapRunning = 0;
  let cswapCheckedAt = 0;
  let headline = "Starting";
  let liveEmail = null;
  let activeId = null;
  let lastStatus = "";
  let lastStatusAt = 0;
  let lastState = "";
  let login;
  /** When each idle account is due to be measured again, and until when the usage endpoint refuses it (429). */
  const nextMeasure = new Map();
  const backoffUntil = new Map();
  /** When layr last tried to start each account's 5-hour window. */
  const startTried = new Map();
  let timer;

  // One thing at a time.
  let queue = Promise.resolve();
  const serial = (fn) => {
    const run = queue.then(fn, fn);
    queue = run.catch(() => {});
    return run;
  };

  const report = (message) => {
    log(message);
    problem = { message, at: new Date().toISOString() };
  };

  const saveAccount = async (id, patch) => {
    if (patch === null) {
      if (!accounts.delete(id)) return;
      await store.saveAccounts(Object.fromEntries(accounts));
      return;
    }
    const current = accounts.get(id);
    const next = { ...current, ...patch };
    for (const key of Object.keys(next)) if (next[key] === undefined) delete next[key];
    if (current && JSON.stringify(current) === JSON.stringify(next)) return;
    accounts.set(id, next);
    await store.saveAccounts(Object.fromEntries(accounts));
  };

  const statusOf = () => ({
    at: new Date().toISOString(),
    activeId,
    liveEmail,
    headline,
    switches,
    ...(cswapRunning ? { cswapRunning } : {}),
    ...(problem && Date.now() - Date.parse(problem.at) < 30 * 60_000 ? { problem } : {}),
    ...(login ? { login } : {}),
  });

  /** Everything the panel shows (never tokens): the accounts with their numbers, the status and the settings. */
  const state = () => {
    const numbers = numbersOf(accounts);
    return {
      accounts: [...accounts].map(([id, a]) => ({ id, number: numbers.get(id), ...a })),
      status: statusOf(),
      settings,
    };
  };

  const publish = async () => {
    const status = statusOf();
    // Written when something changed, and every 10 minutes anyway.
    const key = JSON.stringify({ ...status, at: undefined });
    if (key !== lastStatus || Date.now() - lastStatusAt >= 10 * 60_000) {
      lastStatus = key;
      lastStatusAt = Date.now();
      await store.saveStatus(status);
    }
    const now = state();
    const stateKey = JSON.stringify({ ...now, status: { ...now.status, at: undefined } });
    if (stateKey !== lastState) {
      lastState = stateKey;
      d.onChange?.(now);
    }
  };

  const recordFrom = (oauthAccount, credentials, addedAt) => {
    const oauth = credentials?.claudeAiOauth;
    return {
      email: oauthAccount.emailAddress,
      ...(oauthAccount.organizationName ? { organizationName: oauthAccount.organizationName } : {}),
      ...(oauth?.subscriptionType ? { subscription: oauth.subscriptionType } : {}),
      ...(typeof oauth?.rateLimitTier === "string" ? { tier: oauth.rateLimitTier } : {}),
      state: "ok",
      addedAt: addedAt ?? new Date().toISOString(),
    };
  };

  /** The live login; layr's copy of it follows Claude Code's rotations. */
  async function readActive() {
    const live = await readLive(d.paths);
    liveEmail = live.oauthAccount?.emailAddress ?? null;
    const id = live.oauthAccount?.accountUuid ?? null;
    activeId = id && accounts.has(id) ? id : null;
    if (activeId && live.credentials && isLogin(live.credentials.claudeAiOauth)) {
      const copy = (await vault.get(activeId))?.credentials.claudeAiOauth;
      const current = live.credentials.claudeAiOauth;
      if (!copy || copy.refreshToken !== current.refreshToken || copy.accessToken !== current.accessToken) {
        await vault.put(activeId, { credentials: accountPart(live.credentials), oauthAccount: live.oauthAccount });
      }
      // Logged in again in Claude Code: the account works again.
      if (accounts.get(activeId)?.state === "needs-login") await saveAccount(activeId, { state: "ok" });
    }
    return live;
  }

  /** The active account's usage, as last measured (only when it was this account that was measured). */
  async function activeLimits(maxAgeMs) {
    const limits = await Promise.resolve()
      .then(() => d.limits?.({ maxAgeMs }))
      .catch(() => null);
    if (!limits || (limits.account && limits.account !== liveEmail)) return null;
    return limits;
  }

  const usageOf = (limits) => ({
    fiveHour: limits.fiveHour ? { pct: limits.fiveHour.utilization, resetsAt: limits.fiveHour.resetsAt } : null,
    sevenDay: limits.sevenDay ? { pct: limits.sevenDay.utilization, resetsAt: limits.sevenDay.resetsAt } : null,
    at: limits.updatedAt ?? new Date().toISOString(),
  });

  /**
   * Reads the account's plan from its profile when due: Claude Code's own copy keeps the plan it logged in with, so an
   * upgrade shows only here. A failure waits for the next time.
   */
  async function readPlan(id, accessToken) {
    const account = accounts.get(id);
    if (!account || (account.planAt && Date.now() - Date.parse(account.planAt) < PLAN_MS)) return;
    try {
      const plan = await d.net.plan(accessToken);
      await saveAccount(id, { ...plan, planAt: new Date().toISOString() });
    } catch (error) {
      await saveAccount(id, { planAt: new Date().toISOString() });
      log(`plan of ${account.email}: ${errorText(error)}`);
    }
  }

  /** Measures an idle account when due (`now`: also before that, but never during a 429 back-off). */
  async function measure(id, now = false) {
    const account = accounts.get(id);
    if (!account || account.state !== "ok" || id === activeId) return;
    if ((backoffUntil.get(id) ?? 0) > Date.now() || (!now && (nextMeasure.get(id) ?? 0) > Date.now())) return;
    nextMeasure.set(id, Date.now() + settings.idlePollMin * 60_000);
    const entry0 = await vault.get(id);
    if (!entry0) return;
    try {
      let entry = await freshen(d, id, entry0, 60_000);
      let usage;
      try {
        usage = await d.net.usage(entry.credentials.claudeAiOauth.accessToken);
      } catch (error) {
        // Revoked before its time: one refresh, then once more.
        if (!(error instanceof CallFailed) || error.kind !== "http-401") throw error;
        entry = await freshen(d, id, entry, Number.POSITIVE_INFINITY);
        usage = await d.net.usage(entry.credentials.claudeAiOauth.accessToken);
      }
      await saveAccount(id, { usage, usageError: undefined });
      await readPlan(id, entry.credentials.claudeAiOauth.accessToken);
    } catch (error) {
      if (error instanceof LoginExpired) {
        await saveAccount(id, { state: "needs-login", usageError: undefined });
        report(`${account.email} needs a new login: press Log in on its card`);
        return;
      }
      const kind = error instanceof CallFailed ? error.kind : "error";
      if (kind === "http-429") backoffUntil.set(id, Date.now() + BACKOFF_MS);
      nextMeasure.set(
        id,
        Date.now() + (kind === "http-429" ? Math.max(BACKOFF_MS, settings.idlePollMin * 60_000) : 5 * 60_000),
      );
      await saveAccount(id, { usageError: kind });
      log(`usage of ${account.email}: ${kind} ${errorText(error)}`);
    }
  }

  /**
   * Starts the 5-hour window of every working account where it isn't running, with a one-word message: the active
   * account's with the PC's live login (never refreshed by layr), an idle one's straight with its stored token, so
   * nothing is switched. `force`: also when the setting is off or the last try was recent.
   */
  async function startWindows(force = false) {
    if (!force && !settings.startWindows) return [];
    const started = [];
    for (const [id, account] of accounts) {
      // An idle account's reading is the usage endpoint's own; the active one's may come from the claude plugin,
      // where no windows may only mean it hasn't measured yet.
      const idle = windowIdle(account.usage, Date.now(), id !== activeId);
      if (account.state !== "ok" || account.disabled || !idle) continue;
      if (!force && (startTried.get(id) ?? 0) > Date.now() - START_RETRY_MS) continue;
      startTried.set(id, Date.now());
      try {
        if (id === activeId) {
          await d.pingActive();
        } else {
          const entry0 = await vault.get(id);
          if (!entry0) continue;
          const entry = await freshen(d, id, entry0, 60_000);
          await d.net.ping(entry.credentials.claudeAiOauth.accessToken);
          // Read the new window soon.
          nextMeasure.set(id, Math.min(nextMeasure.get(id) ?? Infinity, Date.now() + 2 * 60_000));
        }
      } catch (error) {
        if (error instanceof LoginExpired) {
          await saveAccount(id, { state: "needs-login" });
          report(`${account.email} needs a new login: press Log in on its card`);
        } else {
          const kind = error instanceof CallFailed ? `${error.kind} ` : "";
          report(`could not start the 5-hour window of ${account.email}: ${kind}${errorText(error)}`);
        }
        continue;
      }
      log(`started the 5-hour window of ${account.email}`);
      // Until the next reading: the window runs from now.
      const at = new Date();
      const resetsAt = new Date(at.getTime() + 5 * 3_600_000).toISOString();
      await saveAccount(id, {
        windowStartedAt: at.toISOString(),
        usage: { ...(account.usage ?? { sevenDay: null, at: at.toISOString() }), fiveHour: { pct: 0, resetsAt } },
      });
      started.push(account.email);
    }
    return started;
  }

  /** `replace`: also when it is active, with its stored login (a new one) in place of the live one. */
  async function doSwitch(id, reason, replace = false) {
    const target = accounts.get(id);
    if (!target) throw new Error("No such account");
    const result = await switchTo(d, id, { replace });
    await readActive();
    if (!result || result.from === id) return;
    switches = [{ from: result.from, to: id, reason, at: new Date().toISOString() }, ...switches].slice(
      0,
      MAX_SWITCHES,
    );
    log(`switched to ${target.email} (${reason})`);
    // The active account's usage was the view of the account left; measure the new one now.
    const limits = await activeLimits(0);
    if (limits) await saveAccount(id, { usage: usageOf(limits) });
  }

  /**
   * Stores an account logged in from the panel. Claude Code goes on with it when the PC has no working login, or when
   * it is the account the PC uses (its copy would otherwise replace the new login at the next check).
   */
  async function addLogin({ credentials, oauthAccount }) {
    const id = oauthAccount.accountUuid;
    await vault.put(id, { credentials, oauthAccount });
    await saveAccount(id, {
      ...recordFrom(oauthAccount, credentials, accounts.get(id)?.addedAt),
      state: "ok",
      usageError: undefined,
    });
    const live = await readLive(d.paths);
    if (!isLogin(live.credentials?.claudeAiOauth) || live.oauthAccount?.accountUuid === id) {
      await doSwitch(id, "you", true);
    } else {
      await readActive();
    }
    backoffUntil.delete(id);
    await measure(id, true);
    log(`logged in with ${oauthAccount.emailAddress}`);
    return oauthAccount.emailAddress;
  }

  async function check() {
    if (Date.now() - cswapCheckedAt > CSWAP_CHECK_MS) {
      cswapCheckedAt = Date.now();
      cswapRunning = await (d.cswapCount ?? cswapAutoCount)();
    }
    const live = await readActive();
    if (activeId && live.credentials && isLogin(live.credentials.claudeAiOauth)) {
      await readPlan(activeId, live.credentials.claudeAiOauth.accessToken);
    }
    // Within 10 points of a switch point the active account is measured more often.
    const room = activeId ? roomLeft(accounts.get(activeId)?.usage, pointsOf(settings, activeId)) : null;
    const near = room !== null && room <= 10;
    const limits = activeId ? await activeLimits(near ? 2 * 60_000 : 5 * 60_000) : null;
    if (activeId && limits) await saveAccount(activeId, { usage: usageOf(limits), usageError: undefined });
    for (const id of accounts.keys()) await measure(id);
    await startWindows();

    if (cswapRunning) {
      headline = "cswap auto runs on the PC: auto-switch waits until it's stopped";
      return;
    }
    const input = () => ({
      now: Date.now(),
      settings,
      activeId,
      activeUsage: activeId ? (accounts.get(activeId)?.usage ?? null) : null,
      rejected: !!limits?.rejectedUntil && Date.parse(limits.rejectedUntil) > Date.now(),
      accounts: [...accounts],
      lastSwitch: switches[0],
    });
    let decision = decide(input());
    if (decision.measure) {
      for (const id of decision.measure) await measure(id, true);
      decision = decide({ ...input(), remeasured: true });
    }
    headline = decision.headline;
    if (decision.switchTo) {
      await doSwitch(decision.switchTo.id, decision.switchTo.reason);
      headline = `Switched to ${accounts.get(decision.switchTo.id)?.email} (${decision.switchTo.reason})`;
    }
  }

  const tick = () =>
    serial(async () => {
      try {
        await check();
      } catch (error) {
        report(`check failed: ${errorText(error)}`);
      }
      await publish().catch((error) => log("could not save status:", errorText(error)));
    });

  /** A command: done in turn, then the status is published. */
  const command = (fn) =>
    serial(async () => {
      try {
        return await fn();
      } finally {
        await publish().catch(() => {});
      }
    });

  const logins = createLogins({
    finish: (grant) => command(async () => addLogin(await d.net.exchange(grant))),
    changed: (status) => {
      login = status;
      void serial(publish).catch((error) => log("could not save status:", errorText(error)));
    },
  });

  const need = (id) => {
    const account = accounts.get(id);
    if (!account) throw new Error("No such account");
    return account;
  };

  /** The account's id by its email (as agents name accounts). */
  const idOf = (email) => {
    const wanted = String(email ?? "")
      .trim()
      .toLowerCase();
    for (const [id, a] of accounts) if (a.email.toLowerCase() === wanted) return id;
    throw new Error(`No account ${email}: see accounts__usage`);
  };

  return {
    async start() {
      const loaded = await store.load();
      for (const [id, account] of Object.entries(loaded.accounts ?? {})) accounts.set(id, account);
      stored = loaded.settings ?? {};
      general = await Promise.resolve()
        .then(() => d.coreSettings?.get())
        .catch((error) => (log(`the core's settings are unavailable: ${errorText(error)}`), null));
      if (general && typeof general !== "object") general = null;
      settings = computeSettings();
      switches = loaded.status?.switches ?? [];
      // Accounts without a stored login (removed by hand) are forgotten; stored logins without a record (the vault
      // today's layr filled, or a record file lost) are taken in.
      const ids = new Set(await vault.ids());
      for (const id of [...accounts.keys()]) if (!ids.has(id)) await saveAccount(id, null);
      for (const id of ids) {
        if (accounts.has(id)) continue;
        try {
          const entry = await vault.get(id);
          if (!entry?.oauthAccount?.emailAddress || !isLogin(entry.credentials?.claudeAiOauth)) continue;
          await saveAccount(id, recordFrom(entry.oauthAccount, entry.credentials, entry.savedAt));
        } catch (error) {
          log(`could not read the stored login ${id}: ${errorText(error)}`);
        }
      }
      await readActive().catch((error) => report(`could not read the PC's login: ${errorText(error)}`));
    },

    /** Checks now and then every minute. */
    run() {
      void tick();
      timer = setInterval(() => void tick(), d.tickMs ?? TICK_MS);
    },

    stop() {
      clearInterval(timer);
      logins.cancel();
    },

    idOf,

    switch: (id) =>
      command(async () => {
        need(id);
        await doSwitch(id, "you");
        headline = `Switched to ${accounts.get(id)?.email} by you`;
      }),

    switchBest: () =>
      command(async () => {
        for (const id of accounts.keys()) await measure(id, true);
        const best = bestOther([...accounts], activeId, settings);
        if (!best) throw new Error("No other account can take over");
        await doSwitch(best, "you");
        headline = `Switched to ${accounts.get(best)?.email} by you`;
        return accounts.get(best)?.email;
      }),

    addCurrent: () =>
      command(async () => {
        const live = await readLive(d.paths);
        if (!live.oauthAccount || !live.credentials || !isLogin(live.credentials.claudeAiOauth)) {
          throw new Error("Claude Code isn't signed in on the PC: run `claude`, then /login");
        }
        const id = live.oauthAccount.accountUuid;
        await vault.put(id, { credentials: accountPart(live.credentials), oauthAccount: live.oauthAccount });
        await saveAccount(id, {
          ...recordFrom(live.oauthAccount, live.credentials, accounts.get(id)?.addedAt),
          state: "ok",
        });
        await readActive();
        return { id, email: live.oauthAccount.emailAddress };
      }),

    importCswap: () =>
      command(async () => {
        cswapRunning = await (d.cswapCount ?? cswapAutoCount)();
        cswapCheckedAt = Date.now();
        if (cswapRunning) {
          throw new Error(
            `cswap auto runs on the PC (${cswapRunning}×): close its windows first, or it and layr would break each ` +
              "other's logins",
          );
        }
        const live = await readLive(d.paths);
        const { logins: found, problems } = await readCswap(d.paths, live);
        const added = [];
        for (const one of found) {
          if (accounts.has(one.id)) continue;
          await vault.put(one.id, { credentials: one.credentials, oauthAccount: one.oauthAccount });
          const isLive = live.oauthAccount?.accountUuid === one.id;
          await saveAccount(one.id, recordFrom(one.oauthAccount, isLive ? live.credentials : null));
          added.push(one.oauthAccount.emailAddress);
        }
        await readActive();
        for (const id of accounts.keys()) await measure(id, true);
        return { added, problems };
      }),

    setEnabled: (id, enabled) =>
      command(async () => {
        need(id);
        await saveAccount(id, { disabled: enabled ? undefined : true });
      }),

    remove: (id) =>
      command(async () => {
        need(id);
        await vault.remove(id);
        await saveAccount(id, null);
        await readActive();
      }),

    refresh: () =>
      command(async () => {
        await readActive();
        const limits = activeId ? await activeLimits(0) : null;
        if (activeId && limits) await saveAccount(activeId, { usage: usageOf(limits), usageError: undefined });
        for (const id of accounts.keys()) await measure(id, true);
      }),

    /** Starts a login from the panel (`email`: the account to log in with); returns the login page's addresses. */
    login: (email) => command(() => logins.start(email)),
    /** Finishes the login `id` with the code its page showed; returns the account's email. */
    loginCode: (id, code) => logins.paste(id, code),
    loginCancel: (id) => logins.cancel(id),

    /** Starts every idle 5-hour window now, also with the setting off; returns the emails started. */
    startWindows: () =>
      command(async () => {
        await readActive();
        const limits = activeId ? await activeLimits(0) : null;
        if (activeId && limits) await saveAccount(activeId, { usage: usageOf(limits), usageError: undefined });
        for (const id of accounts.keys()) await measure(id, true);
        return startWindows(true);
      }),

    /**
     * Reads or changes the settings: `set` (setting → value, checked against NUMBERS and SWITCHES) and `limits`
     * (email → {fiveHour, weekly}: an account's own switch points, null for the general one). Gives the settings
     * with account limits by email, and what each setting means.
     */
    configure: ({ set, limits } = {}) =>
      command(async () => {
        const next = { ...stored };
        const changed = {};
        for (const [key, value] of Object.entries(set ?? {})) {
          const range = NUMBERS[key];
          if (range) {
            if (typeof value !== "number" || !Number.isFinite(value) || value < range.min || value > range.max) {
              throw new Error(`${key}: a number from ${range.min} to ${range.max}`);
            }
            changed[key] = Math.round(value);
          } else if (key in SWITCHES) {
            if (typeof value !== "boolean") throw new Error(`${key}: true or false`);
            changed[key] = value;
          } else {
            throw new Error(`No setting "${key}" (${[...Object.keys(NUMBERS), ...Object.keys(SWITCHES)].join(", ")})`);
          }
        }
        if (limits) {
          const own = { ...settingsOf(next).accountLimits };
          for (const [email, points] of Object.entries(limits)) {
            const id = idOf(email);
            const merged = { ...own[id] };
            for (const key of ["fiveHour", "weekly"]) {
              const value = points?.[key];
              if (value === undefined) continue;
              if (value === null) delete merged[key];
              else if (typeof value !== "number" || value < 10 || value > 100) {
                throw new Error(`limits.${email}.${key}: a number from 10 to 100, or null`);
              } else merged[key] = Math.round(value);
            }
            if (Object.keys(merged).length) own[id] = merged;
            else delete own[id];
          }
          next.accountLimits = own;
        }
        if (set || limits) {
          if (general) {
            for (const [key, value] of Object.entries(changed)) await d.coreSettings.set(key, value);
            general = { ...general, ...changed };
          } else Object.assign(next, changed);
          stored = next;
          settings = computeSettings();
          await store.saveSettings(next);
        }
        const emails = new Map([...accounts].map(([id, a]) => [id, a.email]));
        return {
          settings: {
            ...settings,
            accountLimits: Object.fromEntries(
              Object.entries(settings.accountLimits).map(([id, points]) => [emails.get(id) ?? id, points]),
            ),
          },
          about: { ...Object.fromEntries(Object.entries(NUMBERS).map(([k, v]) => [k, v.about])), ...SWITCHES },
        };
      }),

    /**
     * From the last readings, without waiting for a check: when auto-switch can next move the PC to an account with
     * room (`at` is now or earlier when one has room already). `null`: auto-switch won't.
     */
    nextRoom() {
      if (!settings.autoSwitch || !activeId || cswapRunning) return null;
      const next = nextRoom([...accounts], activeId, settings);
      const email = next && accounts.get(next.id)?.email;
      return next && email ? { at: new Date(next.at).toISOString(), email } : null;
    },

    /** Each account's windows and the totals, from the last readings (`accounts__usage`). */
    overview: () => usageOverview([...accounts], activeId, settings),

    state,

    /** The core's settings changed (`<plugin>:settings` `{values}`, also from the shell's Settings page). */
    settingsChanged: (values) =>
      serial(async () => {
        if (!values || typeof values !== "object") return;
        general = { ...general, ...values };
        settings = computeSettings();
        await publish();
      }),

    /** One check now, published (tests; the timer runs `tick`, which also reports failures). */
    check: () =>
      serial(async () => {
        try {
          await check();
        } finally {
          await publish();
        }
      }),
    accounts: () => accounts,
    settings: () => settings,
    status: () => ({ activeId, liveEmail, headline, switches, cswapRunning }),
  };
}
