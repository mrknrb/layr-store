// The Anthropic endpoints a login needs outside Claude Code: logging in (trading the code the login page gives for
// tokens), refreshing an idle account's token, reading an account's plan usage, and sending it one tiny message
// (which starts its 5-hour window). They are what Claude Code itself calls (as cswap uses them); a subscription token
// on the Messages API is not a public API.
//
// `origins` moves the two hosts elsewhere (tests point them at a local fake; env LAYR_ACCOUNTS_API_ORIGIN in
// server.js), so nothing in a test ever reaches Anthropic.

const API = "https://api.anthropic.com";
const PLATFORM = "https://platform.claude.com";
/** The smallest model: the message costs next to nothing of the window it starts. */
const PING_MODEL = "claude-haiku-5-5";
/** Subscription tokens are only taken for Claude Code's own requests, which start with this system prompt. */
const CLAUDE_CODE_SYSTEM = "You are Claude Code, Anthropic's official CLI for Claude.";
/** Claude Code's OAuth client. */
export const CLIENT_ID = "9d1c250a-e61b-44d9-88ed-5944d1962f5e";
const USER_AGENT = "layr-accounts/1.0";

/** The server refused the refresh token for good: the account needs a new login. */
export class LoginExpired extends Error {}

/** A failed call, with a short kind for the panel (`http-429`, `network`, …). */
export class CallFailed extends Error {
  constructor(kind, message) {
    super(message);
    this.kind = kind;
  }
}

/** A plan's `organization_type` in the profile, as Claude Code names it in `subscriptionType`. */
const SUBSCRIPTIONS = {
  claude_max: "max",
  claude_pro: "pro",
  claude_enterprise: "enterprise",
  claude_team: "team",
};

/**
 * The calls, with `fetchImpl` injected (tests pass a fake). A login (`claudeAiOauth` in `.credentials.json`) is
 * `{accessToken, refreshToken, expiresAt (ms since 1970), scopes?, subscriptionType?, …}`. A grant (what a login
 * page's code is traded with) is `{code, verifier, state, redirectUri}`: the PKCE verifier and state it was asked
 * with, and where it came back.
 */
export function createNet(fetchImpl = fetch, { api = API, platform = PLATFORM } = {}) {
  const TOKEN_URL = `${platform}/v1/oauth/token`;
  const USAGE_URL = `${api}/api/oauth/usage`;
  const MESSAGES_URL = `${api}/v1/messages`;
  const PROFILE_URL = `${api}/api/oauth/profile`;

  const call = async (url, init) => {
    let response;
    try {
      response = await fetchImpl(url, { ...init, signal: AbortSignal.timeout(10_000) });
    } catch (error) {
      throw new CallFailed("network", error instanceof Error ? error.message : String(error));
    }
    const text = await response.text();
    if (!response.ok) throw Object.assign(new CallFailed(`http-${response.status}`, text.slice(0, 300)), { text });
    // A 200 that isn't JSON (a proxy's or captive portal's page, an empty body) is a failed call too.
    const data = safeJson(text);
    if (!data || typeof data !== "object") {
      throw Object.assign(new CallFailed("bad-response", `Not JSON: ${text.slice(0, 300) || "(empty)"}`), { text });
    }
    return data;
  };

  return {
    /**
     * Trades a login page's code for the account's tokens, and reads who it is. Gives the new login as Claude Code
     * would store it: `{credentials, oauthAccount}` (`.credentials.json` without `mcpOAuth`, and `oauthAccount`).
     */
    async exchange(grant) {
      const token = await call(TOKEN_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json", "User-Agent": USER_AGENT },
        body: JSON.stringify({
          grant_type: "authorization_code",
          code: grant.code,
          redirect_uri: grant.redirectUri,
          client_id: CLIENT_ID,
          code_verifier: grant.verifier,
          state: grant.state,
        }),
      });
      if (
        typeof token.access_token !== "string" ||
        typeof token.refresh_token !== "string" ||
        typeof token.expires_in !== "number"
      ) {
        throw new CallFailed("bad-response", "The token endpoint answered without a login");
      }
      // The profile says the plan; the token's answer only who it is.
      const profile = await call(PROFILE_URL, {
        headers: {
          Authorization: `Bearer ${token.access_token}`,
          "Content-Type": "application/json",
          "User-Agent": USER_AGENT,
        },
      }).catch(() => null);
      const account = profile?.account ?? {};
      const org = profile?.organization ?? {};
      const accountUuid = account.uuid ?? token.account?.uuid;
      const emailAddress = account.email ?? token.account?.email_address;
      const organizationUuid = org.uuid ?? token.organization?.uuid;
      if (typeof accountUuid !== "string" || typeof emailAddress !== "string") {
        throw new CallFailed("bad-response", "Claude didn't say which account logged in");
      }
      const now = Date.now();
      const subscriptionType = SUBSCRIPTIONS[org.organization_type];
      const login = {
        accessToken: token.access_token,
        refreshToken: token.refresh_token,
        expiresAt: now + token.expires_in * 1000,
        ...(typeof token.refresh_token_expires_in === "number"
          ? { refreshTokenExpiresAt: now + token.refresh_token_expires_in * 1000 }
          : {}),
        scopes: typeof token.scope === "string" ? token.scope.split(" ").filter(Boolean) : [],
        ...(subscriptionType ? { subscriptionType } : {}),
        ...(typeof org.rate_limit_tier === "string" ? { rateLimitTier: org.rate_limit_tier } : {}),
      };
      // Claude Code fills in the rest of `oauthAccount` from the profile itself when it finds it missing.
      const oauthAccount = Object.fromEntries(
        Object.entries({
          accountUuid,
          emailAddress,
          organizationUuid,
          organizationName: org.name,
          displayName: account.display_name,
          fullName: account.full_name,
          accountCreatedAt: account.created_at,
          billingType: org.billing_type,
          hasExtraUsageEnabled: org.has_extra_usage_enabled,
          subscriptionCreatedAt: org.subscription_created_at,
        }).filter(([, value]) => value !== undefined && value !== null && value !== ""),
      );
      return {
        credentials: {
          claudeAiOauth: login,
          ...(typeof organizationUuid === "string" ? { organizationUuid } : {}),
        },
        oauthAccount,
      };
    },

    async refresh(login) {
      let data;
      try {
        data = await call(TOKEN_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json", "User-Agent": USER_AGENT },
          body: JSON.stringify({
            grant_type: "refresh_token",
            refresh_token: login.refreshToken,
            client_id: CLIENT_ID,
          }),
        });
      } catch (error) {
        // Only an explicit verdict counts as a dead login; anything else may pass.
        if (error instanceof CallFailed && /^http-4\d\d$/.test(error.kind)) {
          const verdict = safeJson(error.text)?.error;
          if (verdict === "invalid_grant") throw new LoginExpired("The server refused the login (invalid_grant)");
        }
        throw error;
      }
      if (typeof data.access_token !== "string" || typeof data.expires_in !== "number") {
        throw new CallFailed("bad-response", "The token endpoint answered without a token");
      }
      return {
        ...login,
        accessToken: data.access_token,
        expiresAt: Date.now() + data.expires_in * 1000,
        ...(typeof data.refresh_token === "string" ? { refreshToken: data.refresh_token } : {}),
        ...(typeof data.scope === "string" ? { scopes: data.scope.split(" ").filter(Boolean) } : {}),
      };
    },

    /** The account's plan usage: `{fiveHour, sevenDay, at}` (see shared/types.js). */
    async usage(accessToken) {
      const data = await call(USAGE_URL, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "anthropic-beta": "oauth-2025-04-20",
          "User-Agent": USER_AGENT,
        },
      });
      const window = (w) =>
        w && typeof w === "object"
          ? { pct: typeof w.utilization === "number" ? w.utilization : null, resetsAt: w.resets_at ?? null }
          : null;
      return { fiveHour: window(data.five_hour), sevenDay: window(data.seven_day), at: new Date().toISOString() };
    },

    /** The account's plan, from its profile: `subscription` as Claude Code names it, `tier` its rate limit tier. */
    async plan(accessToken) {
      const profile = await call(PROFILE_URL, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
          "User-Agent": USER_AGENT,
        },
      });
      const org = profile?.organization ?? {};
      const subscription = SUBSCRIPTIONS[org.organization_type];
      return {
        ...(subscription ? { subscription } : {}),
        ...(typeof org.rate_limit_tier === "string" ? { tier: org.rate_limit_tier } : {}),
      };
    },

    /** Sends the account a one-word message, as Claude Code would: its 5-hour window starts. */
    async ping(accessToken) {
      await call(MESSAGES_URL, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "anthropic-version": "2023-06-01",
          "anthropic-beta": "oauth-2025-04-20",
          "Content-Type": "application/json",
          "User-Agent": USER_AGENT,
        },
        body: JSON.stringify({
          model: PING_MODEL,
          max_tokens: 1,
          system: CLAUDE_CODE_SYSTEM,
          messages: [{ role: "user", content: "hi" }],
        }),
      });
    },
  };
}

function safeJson(text) {
  try {
    return text ? JSON.parse(text) : null;
  } catch {
    return null;
  }
}
