#!/usr/bin/env node
// layr plugin "accounts": the PC's Claude logins. Every account's 5-hour and weekly usage, switching the login the
// PC's Claude Code uses (so new turns of Claude threads in layr run on the new account), logging in from the panel,
// switching by itself near the limit, and starting idle 5-hour windows. An MCP server on stdio (the core is its
// client); its tools are what the panel, other plugins and agents use (`accounts__<tool>` on the hub).
//
// Environment: LAYR_HUB_URL, LAYR_HUB_TOKEN, LAYR_DATA_DIR (docs/ARCHITECTURE.md > The MCP hub), and for tests or a
// second profile CLAUDE_CONFIG_DIR, LAYR_ACCOUNTS_HOME, LAYR_ACCOUNTS_VAULT (backend/files.js),
// LAYR_ACCOUNTS_API_ORIGIN (Anthropic's endpoints elsewhere: a local fake), LAYR_ACCOUNTS_CSWAP=off (don't look
// for a running cswap) and LAYR_ACCOUNTS_TICK_SEC (check more often than every minute).
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import os from "node:os";
import path from "node:path";
import { z } from "zod";
import { createActive } from "./active.js";
import { defaultPaths } from "./files.js";
import { Hub } from "./hub.js";
import { createNet } from "./oauth.js";
import { createService } from "./service.js";
import { statusBarItem } from "./statusbar.js";
import { createStore } from "./store.js";
import { errorMessage, log } from "./util.js";
import { createVault } from "./vault.js";

const env = process.env;
const dataDir = env.LAYR_DATA_DIR || path.join(os.homedir(), ".layr-accounts-dev");
const paths = defaultPaths(env);
const origin = env.LAYR_ACCOUNTS_API_ORIGIN;
const net = createNet(fetch, origin ? { api: origin, platform: origin } : undefined);
const hub = new Hub({ url: env.LAYR_HUB_URL, token: env.LAYR_HUB_TOKEN });
const active = createActive({ hub, net, paths, log });
const vault = createVault(paths);

let lastBar = "";
const service = createService({
  store: createStore(dataDir),
  paths,
  vault,
  net,
  log,
  limits: (options) => active.limits(options),
  pingActive: () => active.ping(),
  cswapCount: env.LAYR_ACCOUNTS_CSWAP === "off" ? async () => 0 : undefined,
  // The general settings are the core's plugin settings (manifest `settings`, the shell's Settings page shows them).
  coreSettings: hub.available
    ? {
        get: () => hub.call("layr__settings_get", {}),
        set: (id, value) => hub.call("layr__settings_set", { id, value }),
      }
    : undefined,
  tickMs: Number(env.LAYR_ACCOUNTS_TICK_SEC) > 0 ? Number(env.LAYR_ACCOUNTS_TICK_SEC) * 1000 : undefined,
  onChange: (state) => {
    hub.emit("accounts:state", state);
    // The status bar item (manifest `statusBar`, docs/ARCHITECTURE.md › Status bar items): set when it changed.
    const bar = statusBarItem(state);
    const key = JSON.stringify(bar);
    if (key !== lastBar) {
      lastBar = key;
      hub.quiet("layr__status_set", { id: "account", ...bar });
    }
  },
});
const ready = service.start();

const server = new McpServer({ name: "accounts", version: "0.1.0" }, { capabilities: { tools: {} } });

// Events meant for this plugin come as MCP notifications (docs/ARCHITECTURE.md › Backends hearing events): a change
// on the shell's Settings page reaches auto-switch at once.
server.server.fallbackNotificationHandler = async (notification) => {
  if (notification.method !== "notifications/layr/event") return;
  const { topic, data } = notification.params ?? {};
  if (topic === "accounts:settings") await service.settingsChanged(data?.values).catch(() => {});
};

/** Register a tool whose handler returns a value (sent as JSON text and as structured content). */
function tool(name, description, shape, handler) {
  server.registerTool(name, { description, inputSchema: shape }, async (args) => {
    try {
      await ready;
      const result = await handler(args ?? {});
      const structured = result && typeof result === "object" && !Array.isArray(result) ? result : { result };
      return { content: [{ type: "text", text: JSON.stringify(structured) }], structuredContent: structured };
    } catch (error) {
      return { content: [{ type: "text", text: errorMessage(error) }], isError: true };
    }
  });
}

const email = z.string().describe("The account's email (accounts__usage)");

// The tools today's layr gave agents (as accounts_usage, accounts_switch, ...), with the same names and behavior.

tool(
  "usage",
  "The PC's Claude accounts (the subscriptions the PC's Claude Code, and with it layr's Claude threads, run on): " +
    "for each, percent used of its 5-hour and weekly windows and when they reset, whether it is the active one, and " +
    "points left before auto-switch moves away from it. `weeklyPerDay`: weekly percent all accounts together can " +
    "spend per day and still last until each resets; `nextTwoHours`: 5-hour percent usable in the next two hours. " +
    "Readings can be some minutes old.",
  {},
  () => service.overview(),
);

tool(
  "switch",
  "Switch the PC's Claude Code to another account, as the Accounts panel does: the one with `email`, or without it " +
    "the one with the most room. New turns of Claude threads (and any Claude Code on the PC) run on it.",
  { email: email.optional() },
  async ({ email: wanted }) => {
    if (!wanted) return { switchedTo: await service.switchBest() };
    await service.switch(service.idOf(wanted));
    return { switchedTo: wanted };
  },
);

tool(
  "use",
  "Let auto-switch move to an account (`enabled: true`) or skip it (`false`), as its panel switch does.",
  { email, enabled: z.boolean() },
  async ({ email: wanted, enabled }) => {
    await service.setEnabled(service.idOf(wanted), enabled);
    return { email: wanted, enabled };
  },
);

tool(
  "start_windows",
  "Start every account's 5-hour window that isn't running now (a one-word message each), so its clock starts and " +
    "resets sooner. Returns the emails started.",
  {},
  async () => ({ started: await service.startWindows() }),
);

tool(
  "refresh",
  "Measure every account's usage again now, instead of waiting for the next reading. Returns what `usage` returns.",
  {},
  async () => {
    await service.refresh();
    return service.overview();
  },
);

tool(
  "settings",
  "Read the Accounts settings, or change them with `set` (autoSwitch, startWindows: true or false; fiveHourAt, " +
    "weeklyAt: switch points in percent, 10 to 100; cooldownMin: 1 to 120; idlePollMin: 5 to 240) and `limits` (an " +
    "account's own switch points by email: { fiveHour, weekly }, null for the general one). Say in your reply what " +
    "you changed.",
  {
    set: z.record(z.string(), z.any()).optional().describe("Setting name → new value"),
    limits: z
      .record(
        z.string(),
        z.object({ fiveHour: z.number().nullable().optional(), weekly: z.number().nullable().optional() }),
      )
      .optional()
      .describe("Email → { fiveHour, weekly }: that account's own switch points; null: the general one"),
  },
  ({ set, limits }) => service.configure({ set, limits }),
);

// What the panel needs besides (agents may use them too).

tool(
  "state",
  "Everything the Accounts panel shows: every account (id, number, email, plan, state, disabled, last reading with " +
    "its time and error, when layr started its window), the service's status (the active account, the live login's " +
    "email, what auto-switch is doing, the latest switches, a running cswap, the last problem, the last login from " +
    "the panel) and the settings. Never tokens.",
  {},
  () => service.state(),
);

tool(
  "next_room",
  "When auto-switch can next move the PC to an account with room below its switch points: `{at, email}` (`at` is " +
    "now or earlier when one has room already), or null when it won't (auto-switch off, no other account).",
  {},
  () => ({ next: service.nextRoom() }),
);

tool(
  "login_start",
  "Start logging in a Claude account (as Claude Code's /login): gives `{id, url, manualUrl}`. Open `url` in a " +
    "browser on this PC (it comes back to the PC by itself), or `manualUrl` anywhere else (it shows a code to pass " +
    "to login_code). The account is added once the login is through; `state` shows how it went. `email`: the " +
    "account to log in with (a hint for the login page).",
  { email: z.string().optional() },
  ({ email: hint }) => service.login(hint || undefined),
);

tool(
  "login_code",
  "Finish the login `id` (login_start) with the code Claude's login page showed (`code#state`, or the whole " +
    "address). Returns the account's email.",
  { id: z.string(), code: z.string() },
  async ({ id, code }) => ({ email: await service.loginCode(id, code) }),
);

tool(
  "login_cancel",
  "Cancel the login from login_start (all of them without `id`).",
  { id: z.string().optional() },
  ({ id }) => {
    service.loginCancel(id);
    return { cancelled: true };
  },
);

tool(
  "add_current",
  "Store the login the PC's Claude Code uses now as an account (after /login with another account in Claude Code).",
  {},
  () => service.addCurrent(),
);

tool(
  "import_cswap",
  "Copy the accounts claude-swap (cswap) keeps on the PC, once. Refused while `cswap auto` runs (the two would " +
    "break each other's logins). Returns `{added, problems}`.",
  {},
  () => service.importCswap(),
);

tool(
  "remove",
  "Forget an account: layr deletes its stored login; Claude Code stays signed in as it is. Only when the user asks.",
  { email },
  async ({ email: wanted }) => {
    await service.remove(service.idOf(wanted));
    return { removed: wanted };
  },
);

// ------------------------------------------------------------------ start

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  await ready;
  service.run();
  log(`accounts backend up (data ${dataDir}, vault ${paths.vault}, hub ${hub.available ? "on" : "off"})`);
}

let stopping = false;
async function stop(code = 0) {
  if (stopping) return;
  stopping = true;
  try {
    service.stop();
    await hub.close();
  } finally {
    process.exit(code);
  }
}
process.on("SIGINT", () => void stop(0));
process.on("SIGTERM", () => void stop(0));
process.stdin.on("end", () => void stop(0));
process.stdin.on("close", () => void stop(0));
process.on("uncaughtException", (error) => log("uncaught:", error));
process.on("unhandledRejection", (error) => log("unhandled rejection:", error));

main().catch((error) => {
  log("could not start:", error);
  process.exit(1);
});
