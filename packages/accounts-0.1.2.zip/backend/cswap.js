// Moving over from claude-swap (cswap): a one-time import of its stored logins, and finding a running `cswap auto`.
// The two must not run together: both refresh the idle account's token, and a refresh token works only once.

import { execFile } from "node:child_process";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { readJson } from "./files.js";
import { accountPart, isLogin } from "./vault.js";

/**
 * cswap's stored logins (Windows and Linux layout: base64 files under `credentials/`): `{logins: [{id, credentials,
 * oauthAccount}], problems: [text]}`.
 */
export async function readCswap(paths, live) {
  const sequence = await readJson(path.join(paths.cswap, "sequence.json"));
  if (!sequence) throw new Error(`No cswap data in ${paths.cswap}`);
  const logins = [];
  const problems = [];
  for (const [slot, { email }] of Object.entries(sequence.accounts ?? {})) {
    try {
      const config = await readJson(path.join(paths.cswap, "configs", `.claude-config-${slot}-${email}.json`));
      const oauthAccount = config?.oauthAccount;
      if (!oauthAccount?.accountUuid) throw new Error("no oauthAccount in its config copy");
      // The live login is newer than cswap's copy of it.
      const isLive = live.oauthAccount?.accountUuid === oauthAccount.accountUuid && live.credentials;
      const credentials = isLive
        ? live.credentials
        : JSON.parse(
            Buffer.from(
              (await readFile(path.join(paths.cswap, "credentials", `.creds-${slot}-${email}.enc`), "utf8")).trim(),
              "base64",
            ).toString("utf8"),
          );
      if (!isLogin(credentials.claudeAiOauth)) throw new Error("its stored login has no OAuth tokens");
      logins.push({ id: oauthAccount.accountUuid, credentials: accountPart(credentials), oauthAccount });
    } catch (error) {
      problems.push(`${email}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  return { logins, problems };
}

/** How many `cswap auto` processes run on the PC (Windows only; elsewhere 0). */
export function cswapAutoCount() {
  if (process.platform !== "win32") return Promise.resolve(0);
  const script =
    "@(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'cswap' -and " +
    "$_.CommandLine -match '\\sauto(\\s|$)' -and $_.Name -match '^python' }).Count";
  return new Promise((resolve) => {
    execFile(
      "powershell.exe",
      ["-NoProfile", "-NonInteractive", "-Command", script],
      { timeout: 20_000, windowsHide: true },
      (error, out) => resolve(error ? 0 : Number.parseInt(String(out).trim(), 10) || 0),
    );
  });
}
