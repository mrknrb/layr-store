// What the panel and the backend share: settings, switch points, and how full an account's windows are. Plain ES
// module without Node imports, so the panel loads it too (`../shared/types.js`). Tokens never get here: they stay in
// files on the PC (see backend/vault.js).
//
// Shapes (JSDoc, for readers):
//   UsageWindow  {pct: number|null, resetsAt: string|null}            percent used, and when it resets
//   Usage        {fiveHour: UsageWindow|null, sevenDay: UsageWindow|null, at: string}   `at`: when it was measured
//   Account      {email, organizationName?, subscription?, tier?, planAt?, state: "ok"|"needs-login", disabled?,
//                 usage?, usageError?, windowStartedAt?, addedAt}
//     `needs-login`: the server refused its refresh token; log in with it again (Log in on its card).
//     `tier`: the plan's rate limit tier, as the profile says it (e.g. `default_claude_max_5x`); `planAt`: when the
//     plan was last read from the profile. `disabled`: held out of auto-switch (you can still switch to it).
//     `usage`: the last good reading; `usageError`: why the last reading failed (e.g. `http-429`), until one
//     succeeds; `windowStartedAt`: when layr last started its 5-hour window with a message of its own.
//   SwitchEvent  {from: string|null, to: string, reason: "you"|"threshold"|"limit", at}   account ids; `from` is
//                null when the PC had no known login
//   LoginStatus  {id, state: "waiting"|"done"|"failed", email?, error?, at}   a login from the panel: `waiting`
//                until the browser comes back to the PC or a code is pasted, then `done` (with the account's email)
//                or `failed` (a code can be pasted again until the login times out)
//   AccountLimits {fiveHour?, weekly?}   an account's own switch points in percent; a missing one is the general one

export const DEFAULT_SETTINGS = Object.freeze({
  /** Switch to another account by itself at the switch points. */
  autoSwitch: true,
  /** Switch when the active account's 5-hour usage reaches this percent… */
  fiveHourAt: 97,
  /** …or its weekly (7-day) usage reaches this one. */
  weeklyAt: 97,
  /** Minutes between two switches. */
  cooldownMin: 5,
  /** How often the accounts not in use are measured, in minutes. */
  idlePollMin: 30,
  /** Send a one-word message to any account whose 5-hour window isn't running, so its clock starts. */
  startWindows: true,
  /** By account id. */
  accountLimits: Object.freeze({}),
});

/** The settings an agent or the panel may change, their ranges, and what each means. */
export const NUMBERS = {
  fiveHourAt: { min: 10, max: 100, about: "Switch when the active account's 5-hour usage reaches this percent" },
  weeklyAt: { min: 10, max: 100, about: "…or its weekly usage reaches this percent" },
  cooldownMin: { min: 1, max: 120, about: "Minutes between two switches" },
  idlePollMin: { min: 5, max: 240, about: "How often the accounts not in use are measured, in minutes" },
};
export const SWITCHES = {
  autoSwitch: "Switch to another account by itself at the switch points",
  startWindows: "Send a one-word message to any account whose 5-hour window isn't running, so its clock starts",
};

/**
 * The settings with defaults filled in. `threshold` is the one switch point for both windows from before they were
 * split: the default for both.
 */
export function settingsOf(stored) {
  const { threshold, ...rest } = stored ?? {};
  const set = Object.fromEntries(Object.entries(rest).filter(([, v]) => v !== undefined && v !== null));
  return {
    ...DEFAULT_SETTINGS,
    accountLimits: {},
    ...(threshold ? { fiveHourAt: threshold, weeklyAt: threshold } : {}),
    ...set,
  };
}

/** Where an account switches away: its own points, else the general ones. */
export function pointsOf(settings, accountId) {
  const own = accountId ? settings.accountLimits?.[accountId] : undefined;
  return { fiveHour: own?.fiveHour ?? settings.fiveHourAt, weekly: own?.weekly ?? settings.weeklyAt };
}

/** Percent used of a window; one that has reset counts as empty. */
export function windowPct(window, now = Date.now()) {
  if (!window || window.pct === null || window.pct === undefined) return null;
  return window.resetsAt && Date.parse(window.resetsAt) <= now ? 0 : window.pct;
}

/**
 * Points left before the account reaches a switch point: the smaller gap of its two windows (0 or less: it is at
 * one). `null` when neither window is known.
 */
export function roomLeft(usage, points, now = Date.now()) {
  const gaps = [
    [usage?.fiveHour, points.fiveHour],
    [usage?.sevenDay, points.weekly],
  ].flatMap(([window, at]) => {
    const pct = windowPct(window, now);
    return pct === null ? [] : [at - pct];
  });
  return gaps.length ? Math.min(...gaps) : null;
}

/**
 * When the account is below its switch points again: `now` when it already is, else when the last window holding it
 * back resets. `null` when nothing is known, or a window holding it back has no reset time.
 */
export function roomAt(usage, points, now = Date.now()) {
  const held = [
    [usage?.fiveHour, points.fiveHour],
    [usage?.sevenDay, points.weekly],
  ].filter(([window, at]) => (windowPct(window, now) ?? 0) >= at);
  if (!held.length) return roomLeft(usage, points, now) === null ? null : now;
  const resets = held.map(([window]) => (window?.resetsAt ? Date.parse(window.resetsAt) : NaN));
  return resets.some(Number.isNaN) ? null : Math.max(...resets);
}

/** A window is full: Claude refuses work until it resets. */
export const atLimit = (usage, now = Date.now()) =>
  [usage?.fiveHour, usage?.sevenDay].some((w) => (windowPct(w, now) ?? 0) >= 100);

/**
 * The 5-hour window isn't running: the reading has none, or the one it had has reset. A message starts it. `false`
 * when nothing is known (no reading, or one without either window unless `emptyIsIdle`), or when the weekly window
 * is full (the message would be refused). `emptyIsIdle`: the reading is the usage endpoint's, which leaves both
 * windows out for an account unused for a week, so neither runs.
 */
export function windowIdle(usage, now = Date.now(), emptyIsIdle = false) {
  if (!usage || (!emptyIsIdle && !usage.fiveHour && !usage.sevenDay)) return false;
  if ((windowPct(usage.sevenDay, now) ?? 0) >= 100) return false;
  const w = usage.fiveHour;
  return !w || !w.resetsAt || Date.parse(w.resetsAt) <= now;
}

/**
 * How many Pro 5-hour windows one of the account's windows is worth: Max 5x has five times a Pro's usage, Max 20x
 * twenty. Room is weighed by it, so a point on a Max account counts for more.
 */
export function planWeight(account) {
  const tier = account?.tier ?? "";
  if (/20x/.test(tier)) return 20;
  if (/5x/.test(tier) || account?.subscription === "max") return 5;
  return 1;
}

/** "Max 5x", "Pro", …: the plan as the panel shows it. */
export function planLabel(account) {
  const weight = planWeight(account);
  if (weight > 1) return `Max ${weight}x`;
  return account?.subscription ? account.subscription[0].toUpperCase() + account.subscription.slice(1) : null;
}

/** Account numbers by when they were added, so a switch doesn't renumber them. `entries`: [id, account] pairs. */
export function numbersOf(entries) {
  return new Map(
    [...entries]
      .sort(([, x], [, y]) => (x.addedAt ?? "").localeCompare(y.addedAt ?? "") || x.email.localeCompare(y.email))
      .map(([id], i) => [id, i + 1]),
  );
}

/** The part of an email before the @, for tight places (the status bar). */
export const shortName = (email) => String(email ?? "").split("@")[0] || String(email ?? "");
