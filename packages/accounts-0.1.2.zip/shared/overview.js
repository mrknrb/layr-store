// The numbers in the panel's top bar (how much room all accounts have together), and what agents see of the accounts.
import { planLabel, planWeight, pointsOf, roomLeft, windowPct } from "./types.js";

const HOUR = 3_600_000;
const DAY = 24 * HOUR;

/**
 * Weekly percent that can be spent per day, all accounts together, so each lasts until its weekly window resets:
 * every account's percent left divided by its days left (at least 1; 7 when the window isn't running), added up.
 * `null` when no account has a weekly reading.
 */
export function perDay(usages, now = Date.now()) {
  let sum = null;
  for (const usage of usages) {
    const pct = windowPct(usage?.sevenDay, now);
    if (pct === null) continue;
    const resetsAt = usage.sevenDay.resetsAt ? Date.parse(usage.sevenDay.resetsAt) : NaN;
    const days = resetsAt > now ? (resetsAt - now) / DAY : 7;
    sum = (sum ?? 0) + Math.max(0, 100 - pct) / Math.max(1, days);
  }
  return sum;
}

/**
 * 5-hour percent usable in the next `hours`, all accounts together: what is left of each 5-hour window, plus a fresh
 * 100 when it resets within that time. An account whose weekly window is full adds nothing. `null` when no account
 * has a reading.
 */
export function nextHours(usages, hours, now = Date.now()) {
  let sum = null;
  for (const usage of usages) {
    if (!usage || (!usage.fiveHour && !usage.sevenDay)) continue;
    sum ??= 0;
    if ((windowPct(usage.sevenDay, now) ?? 0) >= 100) continue;
    sum += Math.max(0, 100 - (windowPct(usage.fiveHour, now) ?? 0));
    const resetsAt = usage.fiveHour?.resetsAt ? Date.parse(usage.fiveHour.resetsAt) : NaN;
    if (resetsAt > now && resetsAt <= now + hours * HOUR) sum += 100;
  }
  return sum;
}

/**
 * What agents see of the accounts (`accounts__usage`): each account's windows, and the totals the panel's top bar
 * shows. `accounts`: [id, account] pairs.
 *
 * Per account: `email`; `active` (the PC's Claude Code is signed in with it now); `enabled` (auto-switch may move to
 * it); `state` (`needs-login`: it can't work until you log in with it again); `fiveHour` and `weekly` (percent used
 * and when it resets, null when not measured); `roomLeft` (points left before its switch points, 0 or less: it is at
 * one); `plan` ("Max 5x", "Pro", when known); `weight` (how many Pro windows one of its windows is worth);
 * `measuredAt`.
 */
export function usageOverview(accounts, activeId, settings, now = Date.now()) {
  // A window that has reset reads empty, without a reset time.
  const window = (w) => {
    if (!w || w.pct === null || w.pct === undefined) return null;
    const running = !!w.resetsAt && Date.parse(w.resetsAt) > now;
    return { pct: windowPct(w, now), resetsAt: running ? w.resetsAt : null };
  };
  const usable = accounts.filter(([, a]) => a.state === "ok").map(([, a]) => a.usage);
  return {
    accounts: accounts.map(([id, a]) => ({
      email: a.email,
      active: id === activeId,
      enabled: !a.disabled,
      state: a.state,
      fiveHour: window(a.usage?.fiveHour),
      weekly: window(a.usage?.sevenDay),
      roomLeft: roomLeft(a.usage, pointsOf(settings, id), now),
      plan: planLabel(a),
      weight: planWeight(a),
      measuredAt: a.usage?.at ?? null,
    })),
    /** Weekly percent all accounts together can spend per day and still last until each resets. */
    weeklyPerDay: perDay(usable, now),
    /** 5-hour percent usable in the next two hours, all accounts together. */
    nextTwoHours: nextHours(usable, 2, now),
    autoSwitch: settings.autoSwitch,
    switchPoints: { fiveHour: settings.fiveHourAt, weekly: settings.weeklyAt },
    startWindows: settings.startWindows,
  };
}
