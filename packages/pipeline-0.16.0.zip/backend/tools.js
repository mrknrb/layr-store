// The pipeline's tools (on the hub as pipeline__<name>), for its panels and for Claude threads that manage the
// board. Names and shapes follow layr_code's pipeline_* tools; the hub adds the `pipeline__` prefix.
import { z } from "zod";
import { notLanded } from "./branches.js";
import { COLUMNS, landQueued, placeTask } from "./columns.js";
import { changedFiles, currentBranch, isGitRepo } from "./git.js";
import { baseRef, taskLink } from "./prompts.js";
import { askPathHits, LAND_RISKS, wordsName } from "./report.js";
import { discardText as discardConfirm } from "./buttons.js";
import { mapSummary, sourceNodes } from "./concepts.js";
import { planImport, readLayrCode } from "./importer.js";
import { ROUNDS } from "./orchestrator.js";
import { checkValue, describe, GLOBAL, MODES, newTaskDefaults, PROJECT } from "./settings.js";
import { parseBackAt, SIZE_PCT_MAX } from "./pacing.js";
import { START_MODES, SIZES } from "./actions.js";
import { holdLane, laneOf, releaseLane, setWake, takeLane, WAKE_MAX_MIN } from "./lane.js";
import { SCOUT_KINDS } from "./scouts.js";
import { LOOKALIKE, similarity, snippet } from "./util.js";
import { byNumber } from "./store.js";

/** The Claude thread that called, from the hub's `_meta["layr/caller"]` (docs/ARCHITECTURE.md › The MCP hub). */
export function callerThread(caller) {
  if (caller?.kind !== "agent" || caller.plugin !== "claude") return null;
  const id = String(caller.label ?? "").trim();
  return /^t_[A-Za-z0-9_-]+$/.test(id) ? id : null;
}

/**
 * The user's own call (a panel, the shell, a device), not an agent's or another backend's; no caller: tests. The
 * claude plugin's thread panel is a panel too: its pipeline strip's buttons are the user's.
 */
export const callerIsUser = (caller) => !caller || ["panel", "shell", "device"].includes(caller.kind);

export const GUIDE = [
  "- One task is about one reviewable change. Put small ideas that touch the same area or files into one task, " +
    "with a checklist of them in its description, instead of a task each; keep large or unrelated ideas apart.",
  "- Small changes that aren't related (each size S) go into a batch: propose each with `batch: true` (or edit " +
    "`batch: true`), and it joins its project's open batch, made when there is none. A batch runs its tasks in one " +
    "worktree and one thread and lands them together, while each stays a task of its own (its worker may skip one, " +
    "which goes back to Proposed). Run it with run on the batch's number, not its tasks'.",
  "- Ideas that change the same code but must happen one after another: separate tasks, chained with `after`.",
  "- Before proposing, look at the proposals still waiting (tasks, column proposed): when a new idea fits one, add " +
    "it there with edit instead of a new task.",
  "- `noWorktree: true` makes a task's thread work in the project's own checkout on the PC instead of a new " +
    "worktree: for questions, and for changes meant for the PC itself. Nothing of it gets landed.",
  "- Who starts a task is its `start`: `either` (the user presses Run, or an agent runs it), `manual` (only the " +
    "user starts it: run refuses it) or `agents` (the user approved it in advance). propose, create and edit set " +
    "`either` or `manual`; `agents` is the user's, and so is turning `autoMerge` on.",
  "- Each task has two toggles; nothing runs by itself because of them. `plan` (📝 Plan): Run makes its worker only " +
    "plan and ask; it stays in Proposed until the user approves, then the work starts. `whenAway` (🌙 When away): " +
    "its work waits until the user is Away (a proposal without Plan waits in Ready; with Plan, Run still plans now " +
    "and the Approve waits), and the user's own messages to a started task wait too (yours don't).",
  "- create makes a task as the board does (with `run: true` it queues at once); from an agent it checks for " +
    "duplicates like propose (resend with confirm: true).",
  "- send with `whenAway: true` parks a message or answers until the user goes Away (the task waits in Ready). " +
    "Answers to a waiting question: `answers` {question text: label(s)} (requestId optional); images: `images`. " +
    "edit `whenAway` / `plan` flips the toggles (create takes them too).",
  "- A batch is one thread doing several small tasks of a project in one worktree; its tasks are numbered in it " +
    "(#84-1, #84-2…; give number \"84-1\"). A project may have several open batches: create with `tasks` makes one " +
    "with its tasks, `batch` (a number, \"new\", or true for the newest open one) makes a task in one. A task made " +
    "on its own doesn't go into a batch later; one taken out (or skipped) gets the project's next number.",
  "- Give each task you propose its size: `sizePct`, the exact percent of a Pro 5-hour window it " +
    "needs (the same on every account; a Max 5 window is 500%; pacing says what an S, M and L cost now, as anchors), or just `size` S, M or L. Pacing guesses what it " +
    "costs from it (a small model guesses the exact size of tasks without one). pacing says what Ready needs and whether it fits in the accounts' room before " +
    "the user is back; in Away, Ready goes in its order only as far as it fits.",
  "- A task with start `agents` is one the user has already approved for you to start: run it without asking.",
  "- Landing is the user's: land a task only with land, and only one the user named in their message (\"land #12\"), " +
    "quoting their words. Never land a task they didn't name. The tool refuses what the user must look at first " +
    "(database changes, risky reports, unfinished or unchecked work); don't work around it.",
  "- settings shows a project's pipeline settings (model, checks, landing…) and configure changes them; say in " +
    "your reply what you changed.",
  "- A worker waiting for something outside it (CI, a deploy) ends its turn and asks wake {number, inMinutes, note}; " +
    "one that needs the project's test lane takes it with lane {number} and gives it back with release: true.",
  "- scout {projectId, focus?, area?} sends a scout that looks for ideas and proposes them; scouts lists them.",
  "- branches {projectId} lists task branches whose work isn't on the base branch (stranded work); worktrees " +
    "{projectId} lists worktrees, what removing each loses and the free disk space; remove_worktree removes the safe " +
    "ones, only when the user asks; decide_round " +
    "starts a thread that answers what it can and gathers what waits for the user; round {kind: stuck, land_safe, " +
    "running or scout, focus?} starts the other ready-made rounds (What's stuck?, Land the safe ones, Brief me on " +
    "what's running, Send a scout). try and open_in open windows on the user's PC: only when they ask.",
  "- The concept map (when the concepts plugin is there): give propose `from` the nodes a task comes from " +
    "(layr://concepts/node/<id>): the task is linked to them, their Status follows it (In progress, To try, Done), " +
    "and without `after` it starts after the task of a node they need (\"needs\" edges). A project's node " +
    "(`projectNode` in settings, `map` in projects) and its rules go into every launch message.",
].join("\n");

export const INSTRUCTIONS =
  "layr pipeline: coding tasks run as Claude threads in their own worktrees and land on the base branch. Before " +
  "you propose, edit, run, message or land tasks, or change pipeline settings, read pipeline__guide once.";

const LIST_LIMIT = 30;

export function registerTools(server, p, actions) {
  const { store } = p;

  /** `handler(args, call)`: `call` = { caller, thread (the calling Claude thread's id), byYou }. */
  function tool(name, description, shape, handler) {
    server.registerTool(name, { description, inputSchema: shape }, async (args, extra) => {
      try {
        const caller = extra?._meta?.["layr/caller"] ?? null;
        const result = await handler(args ?? {}, { caller, thread: callerThread(caller), byYou: callerIsUser(caller) });
        const structured = result && typeof result === "object" && !Array.isArray(result) ? result : { result };
        return { content: [{ type: "text", text: JSON.stringify(structured) }], structuredContent: structured };
      } catch (error) {
        return { content: [{ type: "text", text: error instanceof Error ? error.message : String(error) }], isError: true };
      }
    });
  }

  /** The id of task `number` (84, or a batch's sub-task "84-1"). */
  const id = (number) => store.idOf(number);
  const taskNumber = z.union([z.number().int(), z.string().regex(/^#?\d+(-\d+)?$/)]);
  const number = taskNumber.describe("Task number: 84, or a batch's sub-task \"84-1\"");
  const files = z.array(z.string()).max(10).describe("Staged file ids (attach gives them)");
  const images = z
    .array(z.object({ mediaType: z.string().describe("image/png, image/jpeg, image/gif or image/webp"), data: z.string().describe("base64 (a data: URL is fine)") }))
    .max(10);
  /** The task `number` names, or the one whose thread is calling. */
  const taskFor = (n, call) => {
    if (n !== undefined && n !== null) return id(n);
    const found = call.thread && store.entries().find(([, t]) => t.threadId === call.thread);
    if (!found) throw new Error("Give number: the task (this thread isn't a pipeline task's)");
    return found[0];
  };
  const sizePct = z.number().min(1).max(SIZE_PCT_MAX).nullable().describe("Its exact size: percent of a Pro 5-hour window it needs, the same on every account (a Max 5 window is 500%; pacing says what S, M and L cost now). Replaces `size`; null takes it back");
  const size = z.enum(SIZES).describe("How big it is: S (a small fix, a few files), M (a feature; the default), L (many files or a large change)");
  const start = z.enum(START_MODES).describe("Who starts it: either (the user or an agent), manual (only the user), agents (the user approved it for agents; the user's to set). plan: the same as `plan: true` (either)");
  const plan = z.boolean().describe("📝 Plan: Run makes its worker plan and ask first; its work starts only with the user's Approve");
  const whenAway = z.boolean().describe("🌙 When away: its work, and the user's messages to it, wait until the user is Away (a proposal without Plan waits in Ready)");
  const startAt = z.string().nullable().describe("The time it starts: \"08:00\" (the next such time on the PC's clock) or a date and time like \"2026-12-01 08:00\"; null takes it back. At that time layr runs a proposal, or sends the go-ahead to a task waiting for it (Plan: the start of the work), as the Run / Approve button does");
  const batchRef = z.union([z.boolean(), z.literal("new"), z.literal("open"), z.number().int()]);

  /** One line of `tasks`, and what the other tools return about the task they changed. */
  function summary(tid) {
    const v = p.view(tid);
    return {
      number: v.number,
      title: v.title,
      link: `[#${v.number} ${v.title.replace(/[[\]\n]/g, " ")}](${taskLink(tid)})`,
      projectId: v.projectId,
      column: v.column,
      state: v.state,
      ...(v.waits ? { waits: v.waits } : {}),
      ...(v.after ? { startsAfter: store.get(v.after)?.number ?? Number(v.after) } : {}),
      ...(!v.threadId ? { start: v.start } : {}),
      ...(v.plan || v.planning ? { plan: true } : {}),
      ...(v.whenAway ? { whenAway: true } : {}),
      ...(v.parked?.length ? { waitsForAway: v.parked.map((m) => (m.start ? "start" : m.kind)) } : {}),
      ...(v.sizePct ? { sizePct: v.sizePct } : { size: v.size ?? "M" }),
      ...(v.verify ? { verifier: v.verify.state } : {}),
      ...(v.noWorktree ? { noWorktree: true } : {}),
      ...(v.batch ? { batch: { tasks: (v.members ?? []).map((m) => m.number) } } : {}),
      ...(v.inBatch ? { inBatch: store.get(v.inBatch)?.number ?? Number(v.inBatch) } : {}),
      ...(v.skipped ? { skipped: `by batch #${v.skipped.batch}: ${v.skipped.why}` } : {}),
      ...(v.thread?.replyStatus ? { reply: v.thread.replyStatus } : {}),
      ...(v.landed ? { landed: v.landed.commit.slice(0, 10) } : {}),
      ...(v.stakes ? { stakes: `${v.stakes.level} (${v.stakes.score})` } : {}),
      ...(v.source?.kind && v.source.kind !== "you" ? { from: v.source.kind } : {}),
      ...(v.wake ? { wakesAt: v.wake.at } : {}),
      ...(v.startAt ? { startsAt: v.startAt } : {}),
      ...(v.estimate ? { estimate: `~${v.estimate.pct}% of a 5-hour window still${v.estimate.spentPct ? `, ~${v.estimate.spentPct}% spent` : ""}` } : {}),
    };
  }

  /** Proposals and running tasks of the project that look like this one (for agents' propose and create). */
  function lookalikes(projectId, text) {
    return store
      .entries()
      .filter(([tid, t]) => t.projectId === projectId && p.placement(tid, t).column !== "settled")
      .map(([tid, t]) => ({ tid, t, score: similarity(text, `${t.title} ${t.prompt}`) }))
      .filter((m) => m.score >= LOOKALIKE)
      .sort((x, y) => y.score - x.score)
      .slice(0, 5)
      .map(({ tid, t }) => ({ number: t.number, title: t.title, column: p.placement(tid, t).column, about: snippet(t.prompt) }));
  }

  /** Who made a task an agent makes: a scout's thread, the orchestrator's, or any agent. */
  function agentSource(call, title) {
    const scout = call.thread ? p.scouts.filedBy(call.thread, title) : null;
    const byOrchestrator = call.thread && p.orchestrator.followed().some((f) => f.thread === call.thread);
    return scout ? { kind: "scout", scout } : byOrchestrator ? { kind: "orchestrator" } : { kind: "agent" };
  }

  /** What only the user may set on a task: `start: agents` (approval in advance), auto-merge and agent lands on. */
  function usersOnly(a, call) {
    if (call.byYou) return;
    if (a.start === "agents") throw new Error("start: agents is the user's approval in advance: leave it to them");
    if (a.autoMerge === true) throw new Error("Auto-merge lands work without review: only the user turns it on");
    if (a.agentLands === true) throw new Error("Agent lands lets the worker land its own work: only the user turns it on");
  }

  /** The task `number` or `thread` names, or the one whose thread is calling. */
  function taskOf(a, call) {
    if (a.number !== undefined && a.number !== null) return id(a.number);
    const thread = a.thread ?? call.thread;
    const found = thread && store.entries().find(([, t]) => t.threadId === thread);
    if (!found) throw new Error("Give number: the task (that thread isn't a pipeline task's)");
    return found[0];
  }

  /** `maps`: each project node's sections from the concepts plugin (`map`), when it is there. */
  async function projectsInfo({ maps = false } = {}) {
    await p.refreshProjects().catch(() => {});
    const out = [];
    for (const project of p.projectsCache) {
      const saved = store.projectSaved(project.id);
      if (!saved) continue;
      const settings = store.project(project.id);
      const map = maps && settings.projectNode ? await p.concepts.projectMap(settings.projectNode) : null;
      out.push({
        projectId: project.id,
        title: project.name,
        path: project.path,
        exists: project.exists !== false,
        ...settings,
        // How the task dialog starts a new task here: the project's values, else the global ones.
        newTask: newTaskDefaults(settings, store.global()),
        ...(settings.projectNode ? { map: map ? mapSummary(map) : { node: settings.projectNode } } : {}),
      });
    }
    return out;
  }

  /** Without `after`, what the task's nodes need on the map ("needs" edges) chains it to their tasks: {after?, notes}. */
  async function needsChain(projectId, links, after) {
    if (after !== undefined && after !== null) return { notes: [] };
    const nodes = sourceNodes({ from: links[0], alsoFrom: links.slice(1) });
    return p.concepts.needsChain(projectId, nodes).catch(() => ({ notes: [] }));
  }
  const linksOf = (from) => (Array.isArray(from) ? from : from ? [from] : []).filter((l) => typeof l === "string" && l.startsWith("layr://"));

  // ---------------------------------------------------------------- reading

  tool("guide", "How to cut work into pipeline tasks and manage them (batches, chains, start modes, sizes, running, landing). Read it once before you propose, edit, run, message or land tasks.", {}, () => ({ guide: GUIDE }));

  tool(
    "projects",
    "The projects (git repositories, claude plugin projects) tasks can be proposed in, with their ids for propose, base branch, checks, whether the pipeline is enabled there, and the project's node on the concept map (`map`: its sections' ids, when it has one).",
    {},
    async () => ({ projects: await projectsInfo({ maps: true }) }),
  );

  tool(
    "project_add",
    "Add a git repository folder to the pipeline (also as a claude project): its tasks then run there. Gives the project with its settings.",
    {
      path: z.string().describe("Absolute folder of a git repository"),
      name: z.string().optional(),
      baseBranch: z.string().optional().describe("Default: the branch the folder is on"),
      checks: z.string().optional().describe("Command run before landing, e.g. npm test"),
    },
    async (a) => {
      if (!(await isGitRepo(a.path))) throw new Error(`${a.path} is not a git repository`);
      const project = await p.claude.addProject(a.path, a.name);
      const baseBranch = a.baseBranch ?? (await currentBranch(a.path)) ?? "main";
      store.setProject(project.id, {
        ...(store.projectSaved(project.id) ?? {}),
        enabled: true,
        baseBranch: checkValue(PROJECT, "baseBranch", baseBranch),
        ...(a.checks !== undefined ? { checks: a.checks } : {}),
      });
      await p.refreshProjects();
      p.wake();
      return { project: (await projectsInfo()).find((x) => x.projectId === project.id) };
    },
  );

  tool("project_remove", "Take a project off the pipeline (its settings go; the folder, its claude project and threads stay). Refused while it has tasks that aren't settled.", { projectId: z.string() }, (a) => {
    const open = store.entries().filter(([, t]) => t.projectId === a.projectId && !t.settledAt);
    if (open.length) throw new Error(`It has ${open.length} task(s) not settled: ${open.map(([, t]) => `#${t.number}`).join(", ")}`);
    store.removeProject(a.projectId);
    return { removed: a.projectId };
  });

  tool(
    "tasks",
    "The pipeline's tasks, newest first, with their column (proposed: waits for someone to run it, or plans and asks the user; ready: waits for the user to go Away; running: runs or waits for a slot; stopped: finished, asks something or failed, waits for the user; settled: done) and state. Filter by project, column, or words in the title and description.",
    {
      projectId: z.string().optional(),
      column: z.enum(COLUMNS).optional(),
      query: z.string().optional().describe("Words in the title or description, or #number"),
      limit: z.number().int().min(1).max(500).optional(),
    },
    (a) => {
      let list = store.entries().filter(([, t]) => !a.projectId || t.projectId === a.projectId);
      if (a.column) list = list.filter(([tid, t]) => p.placement(tid, t).column === a.column);
      if (a.query) {
        const q = a.query.trim().toLowerCase();
        const n = /^#?(\d+(?:-\d+)?)$/.exec(q)?.[1];
        list = list.filter(([, t]) => (n ? String(t.number) === n : `${t.title}\n${t.prompt}`.toLowerCase().includes(q)));
      }
      list.sort(([, x], [, y]) => byNumber(y.number, x.number));
      const limit = a.limit ?? LIST_LIMIT;
      return { tasks: list.slice(0, limit).map(([tid]) => summary(tid)), more: Math.max(0, list.length - limit) };
    },
  );

  tool(
    "task",
    "One pipeline task: its description, state, and what its thread last said, failed with or asks (pending approvals and questions, with the requestId send answers with).",
    { number },
    (a) => {
      const v = p.view(id(a.number));
      const t = v.thread ?? {};
      return {
        ...summary(id(a.number)),
        description: v.prompt,
        threadId: v.threadId ?? null,
        branch: v.branch ?? null,
        worktree: v.worktreePath ?? null,
        ...(t.lastMessage ? { lastReply: t.lastMessage } : {}),
        ...(t.lastError ? { lastError: t.lastError } : {}),
        ...(t.pending?.length ? { pending: t.pending } : {}),
        ...(v.stopNote ? { stopNote: v.stopNote } : {}),
        ...(v.landing ? { landing: v.landing } : {}),
        ...(v.landedFor ? { landedFor: v.landedFor } : {}),
        ...(v.agentLands ? { agentLands: true, ...(v.landWanted ? { landWanted: v.landWanted } : {}) } : {}),
        ...(v.work ? { work: v.work } : {}),
        ...(v.ask ? { asksFirst: v.ask } : {}),
        ...(v.brief ? { brief: v.brief } : {}),
        ...(v.stakes ? { stakesWhy: v.stakes.reasons } : {}),
        ...(v.wake ? { wake: v.wake } : {}),
        ...(v.attachments?.length ? { attachments: v.attachments.map((a) => a.name) } : {}),
        approvable: v.approvable,
      };
    },
  );

  tool("board", "Everything the board shows at once (for the pipeline's panels): tasks with their column, projects, settings and the scheduler's state.", {}, async () => ({
    tasks: store.entries().map(([tid]) => p.view(tid)),
    projects: await projectsInfo(),
    global: store.global(),
    status: p.status(),
    views: store.views(),
  }));

  const tableView = z.object({
    id: z.string().min(1).max(40),
    name: z.string().trim().min(1).max(60),
    columns: z.array(z.string().max(30)).max(40).describe("The columns shown, in order"),
    widths: z.record(z.string().max(30), z.number().int().min(30).max(2000)).optional().describe("Column widths in pixels"),
    sorts: z.array(z.object({ by: z.string().max(30), desc: z.boolean() })).max(6).optional().describe("Sorted by each in turn"),
    group: z.enum(["none", "project", "stage"]).optional(),
    stages: z.array(z.enum(COLUMNS)).optional().describe("The board columns whose tasks are rows"),
    query: z.string().max(200).optional().describe("The search text"),
  });
  tool(
    "views",
    "The board table's saved views (each a named setup: its columns in order, their widths, sorts, grouping, stages and search text). Without arguments it gives them (null: none saved, the board shows its starting views); `views` replaces the whole list, `reset: true` goes back to the starting views. The board panel saves them; change them only when the user asks.",
    { views: z.array(tableView).max(30).optional(), reset: z.boolean().optional() },
    (a) => {
      if (a.reset) store.setViews(null);
      else if (a.views) {
        const ids = new Set(a.views.map((v) => v.id));
        if (ids.size !== a.views.length) throw new Error("Each view needs its own id");
        store.setViews(a.views);
      }
      return { views: store.views() };
    },
  );

  tool("state", "Why the pipeline's work runs or waits: the mode, running against the cap, a usage limit, what waits for the user, the last error.", {}, () => {
    const s = p.status();
    const waiting = store.entries().filter(([tid, t]) => ["question"].includes(p.placement(tid, t).why)).length;
    return { ...s, waitForUser: waiting, projects: p.projectsCache.filter((x) => store.projectSaved(x.id)).map((x) => ({ projectId: x.id, title: x.name, enabled: store.project(x.id).enabled })) };
  });

  tool(
    "pacing",
    "Pacing: what each size of task costs (learned from landed tasks' spend; percent of a Pro 5-hour window, a Max 5 account has 500%), what Ready and running work still need, the accounts' room now and until the user is back (`until`), how many of Ready fit, and the guess for each task not settled (a started task's includes re-reading its context when its prompt cache is cold: after its hour, or on another account; `plan`: its model runs only on that kind of account, the `modelPlans` setting). `refresh: true` reads the accounts again first.",
    { refresh: z.boolean().optional() },
    async (a) => {
      if (a.refresh) await p.pacing.read(true);
      const tasks = store
        .entries()
        .filter(([tid, t]) => !t.settledAt && !t.inBatch && p.placement(tid, t).column !== "settled")
        .map(([tid, t]) => ({ number: t.number, title: t.title, column: p.placement(tid, t).column, ...(p.pacing.estimate(t) ?? {}) }));
      return { ...p.pacing.summary(), tasks };
    },
  );

  // ---------------------------------------------------------------- proposing and editing

  tool(
    "propose",
    "Propose a new task (the projectId from projects). It waits in Proposed until the user runs it. The first call returns likely duplicates; resend with confirm: true if it is new. `after` makes it start only once that task has landed. `plan: true` makes its worker plan and ask first when it runs. `batch: true` makes a small task as a sub-task of its project's newest open batch (a number: that batch; \"new\": a new one), numbered in it (#84-1).",
    {
      title: z.string().describe("Short, imperative"),
      description: z.string().describe("What and why, with file pointers (Markdown)"),
      projectId: z.string(),
      reason: z.string().optional().describe("Why you noticed it"),
      from: z.union([z.string(), z.array(z.string())]).optional().describe("layr items it comes from (layr://...)"),
      after: taskNumber.optional(),
      noWorktree: z.boolean().optional(),
      size: size.optional(),
      sizePct: sizePct.optional(),
      start: z.enum(["either", "plan", "manual"]).optional(),
      plan: plan.optional(),
      batch: batchRef.optional(),
      confirm: z.boolean().optional(),
    },
    async (a, call) => {
      if (a.batch && (a.after !== undefined || a.noWorktree || a.start === "plan" || a.plan)) {
        throw new Error("A task in a batch has no `after`, `noWorktree` or Plan (the batch plans)");
      }
      if (!p.projectInfo(a.projectId) || !store.projectSaved(a.projectId)) throw new Error(`There is no pipeline project "${a.projectId}": see projects`);
      if (!a.confirm) {
        const duplicates = lookalikes(a.projectId, `${a.title} ${a.description}`);
        return {
          proposed: false,
          duplicates,
          next: duplicates.length
            ? "These existing tasks look similar. If yours fits one still proposed, add it there with edit; if it is really new, call again with confirm: true."
            : "No similar tasks found. Call again with confirm: true to propose it.",
        };
      }
      const links = linksOf(a.from);
      // A scout's or the orchestrator's thread: the task says so (and the scout counts it).
      const source = call.byYou ? { kind: "you" } : agentSource(call, a.title);
      const chain = await needsChain(a.projectId, links, a.after);
      const v = actions.create(
        {
          projectId: a.projectId,
          title: a.title,
          prompt: a.reason ? `${a.description}\n\n_Why: ${a.reason}_` : a.description,
          from: links[0],
          alsoFrom: links.length > 1 ? links.slice(1) : undefined,
          after: a.after ?? (chain.after ? store.get(chain.after)?.number : undefined),
          noWorktree: a.noWorktree,
          size: a.size,
          sizePct: a.sizePct,
          start: a.start,
          plan: a.plan,
        },
        // A "needs" chain keeps it out of the batch: it must wait for another task.
        { source, batch: a.batch && !chain.after, by: call.byYou ? "you" : "agent" },
      );
      return { proposed: true, ...summary(v.id), ...(chain.notes.length ? { needs: chain.notes } : {}) };
    },
  );

  tool(
    "create",
    "Make a task as the user does on the board: a proposal, `run: true` to queue it for a slot at once (with Plan: it plans now), `whenAway` / `plan` its two toggles (When away without Plan: it waits in Ready and launches when the user goes Away). `tasks` [{title, description}] makes it a batch with those tasks in it, numbered in it (#84-1, #84-2…); `batch` makes it a sub-task of a batch (true: the newest open one, \"new\", or a batch's number). From an agent it checks for duplicates first (resend with confirm: true); `start: agents`, `autoMerge: true` and `agentLands: true` are the user's.",
    {
      projectId: z.string(),
      title: z.string().optional().describe("Left out: a small model writes one from the prompt"),
      prompt: z.string().optional(),
      run: z.boolean().optional(),
      whenAway: whenAway.optional(),
      plan: plan.optional(),
      startAt: startAt.optional(),
      batch: batchRef.optional(),
      tasks: z.array(z.object({ title: z.string().optional(), description: z.string().optional() })).max(30).optional()
        .describe("A batch's tasks (one without a title takes its description's first line)"),
      start: start.optional(),
      autoMerge: z.boolean().optional(),
      agentLands: z.boolean().optional().describe("Its worker may start its own landing when it is done (the user's)"),
      noWorktree: z.boolean().optional(),
      after: taskNumber.nullable().optional(),
      model: z.string().nullable().optional(),
      effort: z.string().nullable().optional(),
      size: size.optional(),
      sizePct: sizePct.optional(),
      attachments: files.optional(),
      from: z.union([z.string(), z.array(z.string())]).optional().describe("layr items it comes from (layr://...), e.g. concept nodes"),
      confirm: z.boolean().optional().describe("An agent's second call: it is new, not one of the duplicates shown"),
    },
    async (a, call) => {
      const { run, whenAway, batch, confirm, from, tasks: subtasks, ...draft } = a;
      if (subtasks?.length) draft.tasks = subtasks.map((x) => ({ title: x.title ?? "", prompt: x.description ?? "" }));
      const links = linksOf(from);
      if (links.length) Object.assign(draft, { from: links[0], ...(links.length > 1 ? { alsoFrom: links.slice(1) } : {}) });
      usersOnly(draft, call);
      if (draft.startAt && !call.byYou && draft.start === "manual") throw new Error("Only the user starts this task: leave its start time to them");
      if (!call.byYou) {
        if (draft.projectId && (!p.projectInfo(draft.projectId) || !store.projectSaved(draft.projectId))) {
          throw new Error(`There is no pipeline project "${draft.projectId}": see projects`);
        }
        if (batch && (draft.after != null || draft.noWorktree || draft.start === "plan" || draft.plan)) throw new Error("A task in a batch has no `after`, `noWorktree` or Plan (the batch plans)");
        const duplicates = confirm ? [] : lookalikes(draft.projectId, `${draft.title ?? ""} ${draft.prompt ?? ""}`);
        if (duplicates.length) {
          return { created: false, duplicates, next: "These existing tasks look similar. If yours fits one still proposed, add it there with edit; if it is really new, call again with confirm: true." };
        }
      }
      const source = call.byYou ? { kind: "you" } : agentSource(call, draft.title || draft.prompt || "");
      const chain = draft.projectId ? await needsChain(draft.projectId, links, draft.after) : { notes: [] };
      if (chain.after) draft.after = store.get(chain.after)?.number;
      const task = actions.create(draft, { source, run, away: !!whenAway, batch: batch && !chain.after, by: call.byYou ? "you" : "agent" });
      return { task, ...(chain.notes.length ? { needs: chain.notes } : {}) };
    },
  );

  tool(
    "edit",
    "Change a task that hasn't started: title, description, project, after (null drops it), noWorktree, size, sizePct, start, autoMerge, agentLands, model, effort, its batch (false: out of it, a proposal with the next number; a task can't go into a batch, sub-tasks are made in theirs), more layr items (addFrom), sub-tasks (`tasks` [{title, description}]: a batch takes them as more tasks, a proposal becomes a batch with them, keeping its description as what the batch is about). Its toggles: `plan` (a proposal; off also on a planning thread) and `whenAway` (any task not settled). `startAt` (any task that can still start, a proposal or one waiting for its go-ahead): the time it starts, \"08:00\" (the next one) or a date and time; null takes it back. Any time: the title, `later` (put off in Decide), `hidden` (off the board), `tested` (the user tried its result), `controversial` (the user's mark), `retitle` (a small model writes a new title), autoMerge and agentLands (off or on). `start: agents`, autoMerge on and agentLands on are the user's.",
    {
      number,
      title: z.string().optional(),
      description: z.string().optional(),
      projectId: z.string().optional().describe("Another project (only a proposal)"),
      after: taskNumber.nullable().optional(),
      noWorktree: z.boolean().optional(),
      size: size.optional(),
      sizePct: sizePct.optional(),
      start: start.optional(),
      plan: plan.optional(),
      whenAway: whenAway.optional(),
      startAt: startAt.optional(),
      autoMerge: z.boolean().optional(),
      agentLands: z.boolean().optional().describe("Its worker may start its own landing when it is done (the user's)"),
      model: z.string().nullable().optional(),
      effort: z.string().nullable().optional(),
      batch: batchRef.optional(),
      tasks: z.array(z.object({ title: z.string().optional(), description: z.string().optional() })).max(30).optional()
        .describe("Sub-tasks to add: a batch takes them as more tasks, a proposal becomes a batch with them"),
      addFrom: z.array(z.string()).optional(),
      later: z.string().nullable().optional(),
      hidden: z.boolean().optional(),
      tested: z.boolean().optional(),
      controversial: z.boolean().optional().describe("The user's own mark: deciding about it is controversial"),
      retitle: z.boolean().optional().describe("A small model writes it a new short title from its description"),
      attachments: files.optional().describe("The files that go with its launch (staged ids; the full list)"),
    },
    (a, call) => {
      usersOnly(a, call);
      if (a.startAt && !call.byYou && store.get(id(a.number))?.start === "manual") throw new Error("Only the user starts this task: leave its start time to them");
      const { number: n, description, ...rest } = a;
      if (rest.tasks) rest.tasks = rest.tasks.map((x) => ({ title: x.title ?? "", prompt: x.description ?? "" }));
      return summary(actions.edit(id(n), { ...rest, ...(description !== undefined ? { prompt: description } : {}) }).id);
    },
  );

  tool("delete", "Delete a proposal that hasn't run (only when the user asks). Started tasks can't be deleted.", { number }, (a) => actions.remove(id(a.number)));

  // ---------------------------------------------------------------- running

  tool(
    "run",
    "Run a proposed task, as the user's Run button does: it queues for a running slot, then its thread starts in a new worktree (When away goes off: it runs now). With Plan on it only plans now, and its work waits for the user's Approve. `whenAway: true` turns its When away toggle on instead (it waits in Ready for Away). Only when the user asks, or their rules let you. Not a task with start manual.",
    { number, whenAway: z.boolean().optional() },
    (a, call) => summary(actions.run(id(a.number), { by: call.byYou ? "you" : "agent", away: !!a.whenAway }).id),
  );

  tool(
    "send",
    "Message a started task's thread (`text`, `images`, `attachments`), or answer what it waits for: `answers` {question text: label or labels} for a question (`requestId` optional: the question with those texts), or `decision` allow / allow_always / deny for a permission or a plan. Like the user's messages it waits for a running slot, unless the thread's turn runs: then it goes at once. `whenAway`: it waits until the user goes Away (the user's own messages also wait when the task's When away is on). `number`, or `thread` (the task's Claude thread).",
    {
      number: number.optional(),
      thread: z.string().optional().describe("The task's Claude thread, instead of number"),
      text: z.string().optional(),
      requestId: z.string().optional(),
      answers: z.record(z.string(), z.union([z.string(), z.array(z.string())])).optional(),
      decision: z.enum(["allow", "allow_always", "deny"]).optional(),
      message: z.string().optional().describe("With a deny: why, for Claude"),
      whenAway: z.boolean().optional(),
      attachments: files.optional(),
      images: images.optional().describe("Images to send with the text (as the claude plugin's thread_send takes them)"),
      box: z.boolean().optional().describe("The user's thread panel: if it waits for Away, the text stays in its text box (see thread_action box_text)"),
    },
    (a, call) => {
      const tid = taskOf(a, call);
      if (a.requestId || a.answers || a.decision) {
        const requestId = a.requestId ?? pendingFor(tid, a);
        return summary(actions.answer(tid, { requestId, answers: a.answers, decision: a.decision, message: a.message, away: a.whenAway, by: call.byYou ? "you" : "agent" }).id);
      }
      const ids = [...(a.attachments ?? []), ...stageImages(a.images ?? [])];
      const box = !!a.box && call.byYou;
      return boxed(actions.message(tid, a.text, { away: a.whenAway, attachments: ids.length ? ids : undefined, by: call.byYou ? "you" : "agent", box }).id, box);
    },
  );

  /** Stage images (as the claude plugin's thread_send takes them) as files; their ids. */
  function stageImages(list) {
    return list.map((img, i) => p.attachments.stage({ name: `image-${i + 1}.${(img.mediaType.split("/")[1] ?? "png").replace("jpeg", "jpg")}`, mediaType: img.mediaType, data: img.data }).id);
  }

  /** A summary, with `boxWaits` for the panel's text box (`box`): whether what it sent waits in the box for Away. */
  function boxed(tid, box) {
    return box ? { ...summary(tid), boxWaits: !!store.get(tid).parked?.some((m) => m.box) } : summary(tid);
  }

  /** The pending request `answers` / `decision` are for, when no requestId is given. */
  function pendingFor(tid, a) {
    const pending = p.need(tid).thread?.pending ?? [];
    if (a.answers) {
      const keys = Object.keys(a.answers);
      const q = pending.find((x) => x.kind === "question" && (x.questions ?? []).some((qq) => keys.includes(qq.question))) ?? pending.find((x) => x.kind === "question");
      if (!q) throw new Error(`#${p.need(tid).number} waits on no question`);
      return q.requestId;
    }
    const other = pending.find((x) => x.kind !== "question");
    if (!other) throw new Error(`#${p.need(tid).number} waits on no permission or plan`);
    return other.requestId;
  }

  tool(
    "stop",
    "Stop a task, as the user's Stop button does: interrupts its thread's turn (or its landing) and drops what waits to be sent to it, also for Away. Its worktree and work stay. `number`, or `thread` (the task's Claude thread).",
    { number: number.optional(), thread: z.string().optional() },
    async (a, call) => summary((await actions.stop(taskOf(a, call))).id),
  );

  tool(
    "land",
    "Land a finished task on the user's word: layr rebases it if needed, runs the project's checks, and moves the base branch onto it. Only a task the user named, with `words`: their own words asking for it. It refuses a task that isn't finished with a Status: done report, hasn't passed its verifier, asks a question, changes files the project always asks about, or reports Risk: database, data or breaking unless the user named that task itself. Without `confirm` it only says whether it may land. A task's own worker whose task has Agent lands on (the user's) calls it with just `number` when its work is done and everything went well: nothing lands at once, layr lands it after the turn ends (committed, clean, Status: done, no risky Risk), as the user's Land button does. With the task's When away on, landing waits in Ready until the user is Away.",
    {
      number,
      words: z.string().optional().describe("The user's own words asking to land it, quoted"),
      confirm: z.boolean().optional(),
      thread: z.string().optional().describe("Who asks: your thread's id"),
    },
    async (a, call) => {
      const tid = id(a.number);
      if (call.byYou) return summary(actions.land(tid).id);
      const own = call.thread && store.get(tid)?.threadId === call.thread;
      if (own && store.get(tid).agentLands) {
        await actions.wantLand(tid);
        return {
          landWanted: true,
          next: "Nothing lands yet. When this turn ends with your work committed, the worktree clean, Status: done and no database, data or breaking Risk, layr lands it (its checks run first). Don't merge or push it yourself.",
        };
      }
      if (!a.thread && call.thread) a.thread = call.thread;
      const refusal = await landRefusal(tid, a.words);
      if (refusal && own && !a.words) return { canLand: false, why: `${refusal} (Agent lands is off for this task: the user lands it)` };
      if (refusal) return { canLand: false, why: refusal };
      if (!a.confirm) return { canLand: true, steps: landSteps(tid) };
      return { landing: true, ...summary(actions.land(tid, { by: a.thread ?? null, words: a.words, at: new Date().toISOString() }).id) };
    },
  );

  tool("settle", "Settle a stopped task, as the user's Settle button does: it is done with (once its work is on the base branch its worktree goes; a message to its thread makes it again). Only when the user asks.", { number }, (a) => summary(actions.settle(id(a.number)).id));
  tool("unsettle", "Take a settled task back to Stopped.", { number }, (a) => summary(actions.unsettle(id(a.number)).id));

  tool(
    "act",
    "Board actions the other tools don't do: approve (a planning task's Start the work, or 'go ahead' to a task that stopped with its work not done; `text` goes with it; it waits for Away when the task's When away is on, or with `away`), start (send now what waits for Away), parked (`op`: send, drop or keep what waits for Away), unbox (the user's Unsend / Unapprove: what waits for Away from their thread's text box goes; theirs only), discard (remove a started task's worktree and branch and archive its thread), release (take it off the board, its thread stays), batch (`batch` null: out of its batch; sub-tasks are made in their batch, a task doesn't go into one), reorder (`order`: task numbers, the Running queue top first), adopt (`threadId`: a claude thread into the pipeline), drop (delete a proposal, with `reason`).",
    {
      action: z.enum(["approve", "start", "parked", "unbox", "discard", "release", "batch", "reorder", "adopt", "drop"]),
      number: taskNumber.optional(),
      thread: z.string().optional().describe("The task's Claude thread, instead of number"),
      text: z.string().optional(),
      away: z.boolean().optional(),
      op: z.enum(["send", "drop", "keep"]).optional(),
      batch: z.union([z.string(), z.number(), z.null()]).optional(),
      order: z.array(z.number().int()).optional(),
      threadId: z.string().optional(),
      reason: z.string().optional(),
    },
    async (a, call) => {
      const tid = a.number !== undefined || a.thread ? taskOf(a, call) : null;
      const needNumber = () => {
        if (!tid) throw new Error(`${a.action} needs number`);
        return tid;
      };
      switch (a.action) {
        case "approve":
          return summary(actions.approve(needNumber(), { text: a.text, away: a.away }).id);
        case "start":
          return summary(actions.parked(needNumber(), "send").id);
        case "parked":
          return summary(actions.parked(needNumber(), a.op).id);
        case "unbox":
          if (!call.byYou) throw new Error("unbox is the user's Unsend / Unapprove");
          return summary(actions.unbox(needNumber()).id);
        case "discard":
          return summary((await actions.discard(needNumber())).id);
        case "release":
          return actions.release(needNumber());
        case "batch":
          return summary(actions.toBatch(needNumber(), a.batch === null || a.batch === undefined ? null : ["open", "new"].includes(a.batch) ? a.batch : String(a.batch)).id);
        case "reorder":
          return actions.reorder((a.order ?? []).map(String));
        case "adopt":
          if (!a.threadId) throw new Error("adopt needs threadId");
          return summary((await actions.adopt(a.threadId)).id);
        case "drop":
          return { ...actions.remove(needNumber()), reason: a.reason ?? null };
      }
      throw new Error(`Unknown action ${a.action}`);
    },
  );

  // ---------------------------------------------------------------- the crew: files, wake-ups, the lane, scouts…

  tool(
    "attach",
    "Stage a file (an image, a log…) to send with a task's launch (create/edit `attachments`) or a message (send `attachments`). Images go to Claude as images; other files by their path on the PC. At most 5 MB. Gives its id.",
    { name: z.string(), mediaType: z.string().optional().describe("e.g. image/png, text/plain"), data: z.string().describe("base64 (a data: URL is fine)") },
    (a) => ({ file: p.attachments.stage(a) }),
  );

  tool(
    "wake",
    `For a task's worker: end your turn and have layr message you again in \`inMinutes\` (1 to ${WAKE_MAX_MIN}) with your \`note\`, for a wait outside you (CI, a deploy, a long build). One per task; it goes through the gate like any message. \`number\`: your task (default: the task of the calling thread).`,
    { number: number.optional(), inMinutes: z.number().int(), note: z.string() },
    (a, call) => setWake(p, taskFor(a.number, call), a.inMinutes, a.note),
  );

  tool(
    "lane",
    "For a task's worker: take the project's test lane (only one task uses it at a time) when your work needs it; busy: `wait: true` joins its queue (end your turn: layr messages you when it is yours). `release: true` gives it back or leaves the queue. `number`: your task (default: the calling thread's).",
    { number: number.optional(), wait: z.boolean().optional(), release: z.boolean().optional() },
    (a, call) => {
      const tid = taskFor(a.number, call);
      if (a.release) return { released: releaseLane(p, tid) };
      return takeLane(p, tid, !!a.wait);
    },
  );

  tool("hold_lane", "Hold a project's test lane yourself (workers wait) until `release: true` or its time runs out; the board's Hold lane.", { projectId: z.string(), release: z.boolean().optional() }, (a) => {
    const lane = holdLane(p, a.projectId, !!a.release);
    p.wake();
    return { lane };
  });

  tool(
    "scout",
    `Send a scout into a project: a read-only Claude thread that looks for ideas with evidence in one area and proposes them (or files them into the project's concept-map Features when it names one). Kinds: ${SCOUT_KINDS.join(", ")} (default: the one that ran longest ago). \`focus\`: what to look for; \`area\`: where. More than Scouts at once wait in a queue. Refused while Scouts are off.`,
    { projectId: z.string(), kind: z.enum(SCOUT_KINDS).optional(), focus: z.string().optional(), area: z.string().optional() },
    async (a, call) => ({ scout: await p.scouts.run(a.projectId, a, { byYou: call.byYou, caller: call.thread ?? undefined }) }),
  );

  tool(
    "scouts",
    "Scouts running and waiting, with what they filed, and the last runs; `stop`: a scout's id to stop (what it filed stays) or take out of the queue.",
    { stop: z.string().optional() },
    async (a) => {
      if (a.stop) await p.scouts.stop(a.stop);
      const s = p.scouts.state();
      return { active: s.active ?? [], runs: [...(s.runs ?? [])].reverse().slice(0, 20), lines: p.scouts.lines(), mode: store.global().scouts };
    },
  );

  tool("brief", "Write a task's brief now (what it is, what it asks you, what a wrong answer costs, stakes 1–10), with a small model.", { number }, async (a) => ({
    brief: await p.briefs.write(id(a.number)),
  }));

  tool(
    "orchestrator",
    "The orchestrator: `status` (its setup, last look, check-ins), `check` (look now and check in, even if nothing changed), `wake` (schedule a check-in for itself in `inMinutes` with a `note`), `cancel_wake`.",
    { action: z.enum(["status", "check", "wake", "cancel_wake"]), inMinutes: z.number().int().optional(), note: z.string().optional() },
    async (a) => {
      if (a.action === "check") return { ...(await p.orchestrator.lookNow(true)), status: p.orchestrator.status() };
      if (a.action === "wake") return { wake: p.orchestrator.scheduleWake(a.inMinutes, a.note) };
      if (a.action === "cancel_wake") p.orchestrator.cancelWake();
      return p.orchestrator.status();
    },
  );

  tool(
    "updates",
    "Keep up to date: each project's own folder against the base branch (with `updateMain` on), and the last update. `now` with `projectId`: Update now (what waited for it goes, or the whole update runs once the folder allows it).",
    { projectId: z.string().optional(), now: z.boolean().optional() },
    (a) => {
      if (a.now) {
        if (!a.projectId) throw new Error("Update now needs projectId");
        p.updater.now(a.projectId);
      }
      return { updates: p.updater.all() };
    },
  );

  tool("crew", "Everything the background jobs keep, for the Settings panel's Crew tab: scouts, the orchestrator, updates and test lanes.", {}, () => ({
    scouts: p.scouts.state(),
    orchestrator: p.orchestrator.status(),
    updates: p.updater.all(),
    lanes: Object.fromEntries(Object.keys(store.settings.projects).map((pid) => [pid, laneOf(p, pid)])),
  }));

  tool(
    "decide_round",
    "A Decide round: a Claude thread (in the orchestrator's folder, with the pipeline's tools) goes through what waits for the user, answers what it can judge, lists what is safe to land and merges the workers' open questions into one numbered list. Gives its thread (open it in the claude plugin's thread panel).",
    {},
    async (a, call) => {
      const round = await p.orchestrator.decideRound();
      // From a command (the shell): open its thread for the user.
      if (call.caller?.kind === "shell" && p.hub.available && p.hub.call) {
        p.hub.call("layr__panels_open", { plugin: "claude", panel: "thread", params: { thread: round.thread }, where: "tab", reuse: true }).catch(() => {});
      }
      return round;
    },
  );

  tool(
    "round",
    `A ready-made round like decide_round: a Claude thread (the orchestrator's folder, the pipeline's tools it needs) for ${Object.entries(ROUNDS).map(([k, r]) => `${k} (${r.label})`).join(", ")}. \`focus\`: the user's words (for scout: what to look for; for land_safe: their go-ahead, when they gave it). Its questions come in the user's question format. Gives its thread.`,
    {
      kind: z.enum(Object.keys(ROUNDS)),
      focus: z.string().optional(),
      projectId: z.string().optional().describe("scout: the project, when the user named one"),
    },
    async (a, call) => {
      const round = await p.orchestrator.round(a.kind, { focus: a.focus, projectId: a.projectId });
      if (call.caller?.kind === "shell" && p.hub.available && p.hub.call) {
        p.hub.call("layr__panels_open", { plugin: "claude", panel: "thread", params: { thread: round.thread }, where: "tab", reuse: true }).catch(() => {});
      }
      return round;
    },
  );

  // ---------------------------------------------------------------- the concept map (the concepts plugin)

  tool(
    "concepts",
    "For the pipeline's panels: whether the concepts plugin is there, and (with `query`) concept nodes for a picker [{id, label, in}]; `linked: true` adds the nodes linked to each task ({\"<number>\": [{id, text}]}).",
    { query: z.string().optional(), linked: z.boolean().optional() },
    async (a) => {
      const available = await p.concepts.available();
      if (!available) return { available: false };
      return {
        available: true,
        ...(a.query?.trim() ? { nodes: await p.concepts.nodes(a.query.trim()) } : {}),
        ...(a.linked ? { linked: await p.concepts.linkedNodes() } : {}),
      };
    },
  );

  tool(
    "setup_project_map",
    "Set up project map: give the project's node on the concept map (its `projectNode` setting) the standard sections it lacks (Rules, Brainstorm, Features with an Inbox, Plan), through the concepts plugin. Gives what it made.",
    { projectId: z.string() },
    async (a) => {
      if (!store.projectSaved(a.projectId)) throw new Error(`${a.projectId} isn't a pipeline project: see projects`);
      const node = store.project(a.projectId).projectNode;
      if (!node) throw new Error("Choose the project node first (Pipeline settings › the project › Project node)");
      if (!(await p.concepts.available())) throw new Error("The concepts plugin isn't there (or the pipeline may not call it)");
      const r = await p.concepts.setupProjectMap(node);
      if (!r) throw new Error("The concepts plugin didn't set it up (see the pipeline's log)");
      return { made: r.made ?? [], map: r.map ? mapSummary(r.map) : null };
    },
  );

  // ---------------------------------------------------------------- layr_code's settings (one-time import)

  tool(
    "import_layr_code",
    "Import layr_code's pipeline settings once: reads them (read-only) from layr_code's Supabase records with the signed-in account, and fills only the settings that are empty here, of the projects in the same folder (instructions, models, checks, landing, ▶ Try, icon, colour, project node…), and empty global ones. `dryRun: true` only says what it would fill. Never writes to layr_code's records.",
    { dryRun: z.boolean().optional() },
    async (a) => {
      let session;
      try {
        session = await p.hub.call("layr__supabase_session", {});
      } catch (error) {
        throw new Error(`No session to read layr_code's settings with: ${error.message ?? error}`);
      }
      const records = await readLayrCode(session);
      const projects = (await projectsInfo()).map((x) => ({ projectId: x.projectId, title: x.title, path: x.path, saved: store.projectSaved(x.projectId) }));
      const plan = planImport({ records, projects, global: store.settings.global });
      if (!plan.found && !Object.keys(plan.global.fill).length) {
        throw new Error(`Found no layr_code pipeline settings for ${session.email ?? "this account"}: none were saved, or the database's row level security hides them from this session`);
      }
      const filled = plan.projects.reduce((n, x) => n + Object.keys(x.fill).length, 0) + Object.keys(plan.global.fill).length;
      if (!a.dryRun) {
        for (const x of plan.projects) if (Object.keys(x.fill).length) store.setProject(x.projectId, x.fill);
        if (Object.keys(plan.global.fill).length) store.setGlobal(plan.global.fill);
        store.setState({ layrCodeImport: { at: new Date().toISOString(), filled } });
        p.wake();
      }
      return { dryRun: !!a.dryRun, filled, ...plan };
    },
  );

  // ---------------------------------------------------------------- windows on the PC, branches

  tool(
    "try",
    "▶ Try a task: the project's Try command runs from the task's worktree in a PowerShell window on the PC, on a free port ($env:LAYR_TRY_PORT); the project's previous try stops first.",
    { number },
    async (a) => p.windows.tryTask(id(a.number)),
  );

  tool(
    "open_in",
    "Open a task's worktree (without one: the project's folder) in VS Code or File Explorer on the PC.",
    { number, app: z.enum(["vscode", "explorer"]) },
    (a) => p.windows.openIn(id(a.number), a.app),
  );

  tool(
    "branches",
    "Not landed: a project's task branches whose work isn't on its base branch (stranded work), with their task and its state, commits ahead of and behind the base, and their worktree.",
    { projectId: z.string() },
    async (a) => {
      if (!store.projectSaved(a.projectId)) throw new Error(`${a.projectId} isn't a pipeline project: see projects`);
      return { projectId: a.projectId, branches: await notLanded(p, a.projectId) };
    },
  );

  tool(
    "worktrees",
    "Branches & worktrees: a project's worktrees (not its own checkout) and its task branches that aren't landed, each with its task, commits ahead of and behind the base, whether removing it loses nothing (removable, else why), its size in bytes (measured in the background; measure: true measures again) and the drive's free space.",
    { projectId: z.string(), measure: z.boolean().optional() },
    async (a) => {
      if (!store.projectSaved(a.projectId)) throw new Error(`${a.projectId} isn't a pipeline project: see projects`);
      return p.worktrees.list(a.projectId, { measure: !!a.measure });
    },
  );

  tool(
    "remove_worktree",
    "Remove a project's worktree (path) or every one that loses nothing (all: true), with its local branch: only worktrees whose commits are on the base branch and that have no uncommitted or untracked files (build output goes). A task keeps its card and thread; a message to the thread makes the worktree again. Only when the user asks.",
    { projectId: z.string(), path: z.string().optional(), all: z.boolean().optional() },
    async (a) => {
      if (!store.projectSaved(a.projectId)) throw new Error(`${a.projectId} isn't a pipeline project: see projects`);
      return p.worktrees.remove(a.projectId, { dir: a.path, all: !!a.all });
    },
  );

  // ---------------------------------------------------------------- a task's Claude thread (the claude plugin's panel)

  tool(
    "thread_task",
    "The pipeline task a Claude thread is (for the claude plugin's thread panel): its number, column, why, a note, its link, brief, stakes (high, medium or low), landing, the buttons it offers now ({id, label, kind?, confirm?, pc?}), its toggles ({plan, whenAway}: {on, can, why?}; thread_action toggle_plan / toggle_away flips them) and `unsent` (text of messages that waited for Away, given back when When away went off: put it in the text box, then thread_action unsent_taken), `box` ({start, text}: what waits for Away from the panel's text box; the text is still in the box) and `boxSent` (the text Away sent from the box: empty the box if it still holds that, then thread_action box_sent_taken); null when the thread is no task's.",
    { thread: z.string() },
    (a) => {
      const found = store.entries().find(([, t]) => t.threadId === a.thread);
      if (!found) return null;
      const v = p.view(found[0]);
      const buttons = [...v.buttons];
      if (v.column !== "running") buttons.push({ id: "brief", label: v.brief ? "Write the brief again" : "Write brief" });
      if (v.column === "settled" && !v.discarded && !v.landed) buttons.push({ id: "discard", label: "Discard", kind: "danger", confirm: discardConfirm(v) });
      const box = v.parked?.find((m) => m.box);
      return {
        number: v.number,
        title: v.title,
        column: v.column,
        why: v.why,
        state: v.state,
        note: v.note,
        link: taskLink(v.id),
        ...(v.brief ? { brief: { what: v.brief.what, asks: v.brief.ask, ifWrong: v.brief.cost } } : {}),
        ...(v.stakes ? { stakes: v.stakes.level, stakesScore: v.stakes.score } : {}),
        ...(v.landing ? { landing: { state: v.state, ...(v.landing.problem ? { problem: v.landing.problem } : {}) } } : {}),
        ...(v.planning ? { planning: true } : {}),
        buttons,
        toggles: v.toggles,
        ...(v.unsent ? { unsent: v.unsent.text } : {}),
        ...(box ? { box: { start: !!box.start, text: box.said ?? "" } } : {}),
        ...(v.boxSent ? { boxSent: v.boxSent.text } : {}),
      };
    },
  );

  tool(
    "thread_action",
    "Press one of the buttons thread_task gave for a Claude thread's task (the user's own press, in the claude plugin's thread panel): approve (with `text`: the user's answers; it waits for Away when When away is on), start, unpark (drop what waits for Away), stop, land, try, settle, unsettle, brief, discard; toggle_plan and toggle_away flip its toggles (`on`: the new value, else the other one); unsent_taken: the unsent text is in the text box now. approve_away (older panels): approve, waiting for Away. `box` with approve: the panel keeps the text in its box; if it waits for Away (the answer's `boxWaits`), it is the box's waiting item: box_text (`text`, `images` when they changed) keeps it up to date, unbox takes it back (Unapprove / Unsend), box_sent_taken: the panel handled `boxSent`.",
    {
      thread: z.string(),
      action: z.enum(["approve", "approve_away", "start", "unpark", "stop", "land", "try", "settle", "unsettle", "brief", "discard", "toggle_plan", "toggle_away", "unsent_taken", "box_text", "unbox", "box_sent_taken"]),
      text: z.string().optional(),
      on: z.boolean().optional(),
      box: z.boolean().optional(),
      images: images.optional(),
    },
    async (a, call) => {
      if (!call.byYou) throw new Error("thread_action is the user's buttons: agents use send, stop, land and act");
      const tid = taskOf({ thread: a.thread }, call);
      switch (a.action) {
        case "approve":
          return boxed(actions.approve(tid, { text: a.text, box: !!a.box }).id, a.box);
        case "approve_away":
          return summary(actions.approve(tid, { text: a.text, away: true }).id);
        case "start":
          return summary(actions.parked(tid, "send").id);
        case "unpark":
          return summary(actions.parked(tid, "drop").id);
        case "stop":
          return summary((await actions.stop(tid)).id);
        case "land":
          return summary(actions.land(tid).id);
        case "try":
          return p.windows.tryTask(tid);
        case "settle":
          return summary(actions.settle(tid).id);
        case "unsettle":
          return summary(actions.unsettle(tid).id);
        case "brief":
          return { brief: await p.briefs.write(tid) };
        case "discard":
          return summary((await actions.discard(tid)).id);
        case "toggle_plan": {
          const t = store.get(tid);
          return summary(actions.setPlan(tid, a.on ?? !(t.plan || t.planning)).id);
        }
        case "toggle_away":
          return summary(actions.setAway(tid, a.on ?? !store.get(tid).whenAway).id);
        case "unsent_taken":
          return summary(actions.unsentTaken(tid).id);
        case "box_text": {
          const ids = a.images ? stageImages(a.images) : undefined;
          const r = actions.boxText(tid, { text: a.text, attachments: ids });
          return { ...summary(r.task.id), boxWaits: r.waiting };
        }
        case "unbox":
          return summary(actions.unbox(tid).id);
        case "box_sent_taken":
          return summary(actions.boxSentTaken(tid).id);
      }
      throw new Error(`Unknown action ${a.action}`);
    },
  );

  // ---------------------------------------------------------------- mode and settings

  const setMode = (mode, backAt) => {
    let until;
    if (backAt !== undefined && backAt !== null && String(backAt).trim()) {
      until = parseBackAt(backAt);
      if (!until) throw new Error(`backAt: give a time like 08:00, or an ISO time later than now (not "${backAt}")`);
    }
    p.setMode(mode, { backAt: until });
    return { mode, status: p.status() };
  };
  tool(
    "mode",
    "Switch the mode, as the board's button does: stop (Soft stop: nothing new starts, what runs goes on to its end), here (the user is at the PC: tasks marked Plan plan and ask now), away (planned and approved work goes; nobody answers until the user is back). `backAt` with away: when the user is back (\"08:00\" or an ISO time; default: awayHours from now), the time pacing fits Ready into. Say why you switched.",
    { mode: z.enum(MODES), backAt: z.string().optional() },
    (a) => setMode(a.mode, a.backAt),
  );

  tool(
    "settings",
    "The pipeline's settings: with `projectId`, that project's (values, which differ from the defaults, what each means); without, the global ones and each project's.",
    { projectId: z.string().optional() },
    (a) => {
      if (a.projectId) {
        if (!store.projectSaved(a.projectId)) throw new Error(`${a.projectId} isn't a pipeline project: see projects`);
        return { projectId: a.projectId, settings: describe(PROJECT, store.settings.projects[a.projectId]) };
      }
      return {
        ...(store.state().layrCodeImport ? { layrCodeImport: store.state().layrCodeImport } : {}),
        global: describe(GLOBAL, store.settings.global),
        projects: Object.keys(store.settings.projects).map((pid) => ({ projectId: pid, title: p.projectInfo(pid)?.name ?? pid, settings: describe(PROJECT, store.settings.projects[pid]) })),
      };
    },
  );

  tool(
    "configure",
    "Change pipeline settings, as the Settings panel does: a project's (`projectId`) or the global ones (`global: true`). `set` gives new values by name (see settings), `reset` puts settings back to their defaults. Say in your reply what you changed.",
    {
      projectId: z.string().optional(),
      global: z.boolean().optional(),
      set: z.record(z.string(), z.any()).optional(),
      reset: z.array(z.string()).optional(),
    },
    (a) => {
      const defs = a.global ? GLOBAL : PROJECT;
      if (!a.global && (!a.projectId || !store.projectSaved(a.projectId))) throw new Error("Give projectId (a pipeline project) or global: true");
      const patch = {};
      for (const [k, v] of Object.entries(a.set ?? {})) patch[k] = checkValue(defs, k, v);
      for (const k of a.reset ?? []) checkValue(defs, k, defs[k]?.[0]);
      if (a.global) {
        if ("mode" in patch) p.setMode(patch.mode);
        store.setGlobal(patch);
        for (const k of a.reset ?? []) delete store.settings.global[k];
      } else {
        store.setProject(a.projectId, patch);
        if (a.reset?.length) store.resetProject(a.projectId, a.reset);
      }
      store.changed();
      p.wake();
      return a.global ? { global: store.global() } : { projectId: a.projectId, settings: store.project(a.projectId) };
    },
  );

  // ---------------------------------------------------------------- the land guard

  /** Why an agent may not land this task now, or null. */
  async function landRefusal(tid, words) {
    const task = p.need(tid);
    if (!String(words ?? "").trim()) return "Give `words`: the user's own words asking to land this task";
    if (task.noWorktree) return "It works in the project's checkout: nothing to land";
    if (store.project(task.projectId).landing === "pr") return "Its project lands through pull requests: the user's Land button opens and merges those";
    if (task.landed) return "It has landed already";
    if (task.landing || landQueued(task)) return "It is landing already";
    if (!task.worktreePath) return "Its worktree isn't known";
    if (task.thread?.pending?.length) return "Its thread asks a question: answer it first";
    const { why } = placeTask(task);
    if (why !== "finished") return `It isn't finished (${why})`;
    const status = task.thread?.replyStatus;
    if (!status) return "Its last reply has no status line";
    if (status.status !== "done") return `Its last reply says Status: ${status.status}`;
    if (p.verifies(task) && task.verify?.state !== "passed") return "Its verifier hasn't passed it";
    const settings = store.project(task.projectId);
    const files = await changedFiles(task.worktreePath, baseRef(settings)).catch(() => task.ask?.paths ?? []);
    const hits = askPathHits(files, settings.askPaths);
    if (hits.length) return `It changes files the user always looks at first (${hits.slice(0, 5).join(", ")}): the user lands it`;
    const risks = [...new Set([...(status.risks ?? []), ...(task.ask?.risks ?? [])])].filter((r) => LAND_RISKS.includes(r));
    if (risks.length && !wordsName(words, task.number)) {
      return `Its report names Risk: ${risks.join(", ")}: land it only when the user names #${task.number} itself`;
    }
    return null;
  }

  function landSteps(tid) {
    const task = p.need(tid);
    const s = store.project(task.projectId);
    return [
      `The thread rebases onto ${baseRef(s)}${s.squash ? " and squashes into one commit" : ""} if needed`,
      s.checks.trim() ? `layr runs \`${s.checks.trim()}\` in the worktree` : "no checks command is set",
      s.landing === "pr"
        ? `layr pushes it to its branch, opens a pull request into ${s.baseBranch} and merges it once CI is green`
        : s.landing === "push"
          ? `layr pushes it to ${s.remote}/${s.baseBranch} and moves the local ${s.baseBranch}`
          : `layr moves ${s.baseBranch} onto it`,
    ];
  }
}
