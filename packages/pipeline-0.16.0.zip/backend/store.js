// The board, all in the plugin's own folder (LAYR_DATA_DIR), never in layr_code's Supabase tables:
//   tasks.json      { counter, tasks: { "<number>": Task } }
//   settings.json   { global: {...}, projects: { "<claude project id>": {...} }, state, views }
//   crew.json       what the background jobs keep: scouts, the orchestrator, lanes, updates, the last usage read
//   attachments/    files staged for a task's launch or a message (attachments.js)
// One writer (this backend); panels and agents change it through the tools. Writes are atomic and soon after a
// change; `onChange` tells the panels (event pipeline:changed).
import path from "node:path";
import { globalDefaults, projectDefaults } from "./settings.js";
import { ensureDir, nowIso, readJson, writeFileAtomic } from "./util.js";

const SAVE_MS = 150;

export class Store {
  constructor(dataDir) {
    this.dir = ensureDir(dataDir);
    this.tasksFile = path.join(this.dir, "tasks.json");
    this.settingsFile = path.join(this.dir, "settings.json");
    const data = readJson(this.tasksFile, { counter: 0, tasks: {} });
    this.counter = data.counter ?? 0;
    /** @type {Record<string, any>} */
    this.tasks = data.tasks ?? {};
    // 0.7: Plan is a toggle of its own (`plan`), no longer a "who starts it" value.
    for (const t of Object.values(this.tasks)) {
      if (t.start === "plan") Object.assign(t, { start: "either", plan: true });
    }
    const settings = readJson(this.settingsFile, {});
    this.settings = { global: settings.global ?? {}, projects: settings.projects ?? {}, state: settings.state ?? {} };
    if (Array.isArray(settings.views)) this.settings.views = settings.views;
    this.crewFile = path.join(this.dir, "crew.json");
    /** @type {Record<string, any>} */
    this.crewData = readJson(this.crewFile, {});
    this.timer = null;
    this.onChange = null;
    /** `(id, before, after)` after a task is made (before undefined), changed, or forgotten (after undefined). */
    this.onTaskChange = null;
    /** Tasks changed since the last `takeChanged()` (the event pipeline:changed names them). */
    this.changedIds = new Set();
  }

  // ---------------------------------------------------------------- tasks

  get(id) {
    return this.tasks[String(id)] ?? null;
  }

  entries() {
    return Object.entries(this.tasks);
  }

  /**
   * A new task with the next number; `draft` holds its fields. With `inBatch` (a batch's id) it is that batch's
   * sub-task: its number is the batch's with its place in it (`"84-1"`, a string), and no number of the project's
   * goes to it. Its id is its first number for good (links name it), even once it leaves the batch (`leaveBatch`).
   */
  create(draft, source = { kind: "you" }, { inBatch } = {}) {
    const batch = inBatch !== undefined ? this.get(inBatch) : null;
    if (inBatch !== undefined && !batch) throw new Error(`There is no batch #${inBatch}`);
    let number;
    if (batch) {
      batch.subs = (batch.subs ?? 0) + 1;
      number = `${batch.number}-${batch.subs}`;
      this.changed(String(inBatch));
    } else number = this.counter += 1;
    const id = String(number);
    const at = nowIso();
    // New tasks go to the end of the Running order: the top gets the next free slot.
    const highest = Math.max(0, ...Object.values(this.tasks).map((t) => t.order ?? 0));
    const task = {
      number,
      projectId: draft.projectId,
      title: String(draft.title ?? "").trim() || `Task ${number}`,
      prompt: String(draft.prompt ?? ""),
      source,
      start: draft.start === "plan" ? "either" : (draft.start ?? "either"),
      order: highest + 1,
      createdAt: at,
      updatedAt: at,
    };
    for (const key of DRAFT_FIELDS) if (draft[key] !== undefined && draft[key] !== null) task[key] = draft[key];
    if (batch) task.inBatch = String(inBatch);
    this.tasks[id] = task;
    this.changed(id);
    this.told(id, undefined, task);
    return [id, task];
  }

  /** The id of the task numbered `n` (`84`, `"84-1"`, `"#84-1"`): its id, or the one that took that number later. */
  idOf(n) {
    const want = String(n).trim().replace(/^#/, "");
    const own = this.tasks[want];
    if (own && String(own.number) === want) return want;
    const found = Object.entries(this.tasks).find(([, t]) => String(t.number) === want);
    return found ? found[0] : want;
  }

  /**
   * The patch that takes a task out of its batch: a sub-task numbered in it (`"84-1"`) gets the project's next
   * number, as a proposal of its own. Its id stays, so links to it go on working.
   */
  leaveBatch(task) {
    return { inBatch: undefined, ...(typeof task?.number === "string" ? { number: (this.counter += 1) } : {}) };
  }

  /** Change a task: `fn(task)` gives a patch (undefined values remove the field) or null for no change. */
  mutate(id, fn) {
    const task = this.get(id);
    if (!task) return null;
    const patch = fn(task);
    if (!patch) return task;
    const before = this.onTaskChange ? { ...task } : undefined;
    for (const [k, v] of Object.entries(patch)) {
      if (v === undefined) delete task[k];
      else task[k] = v;
    }
    task.updatedAt = nowIso();
    this.changed(String(id));
    this.told(String(id), before, task);
    return task;
  }

  remove(id) {
    const task = this.tasks[String(id)];
    if (!task) return false;
    delete this.tasks[String(id)];
    this.changed(String(id));
    this.told(String(id), task, undefined);
    return true;
  }

  /** Tell `onTaskChange`; its failures are its own. */
  told(id, before, after) {
    try {
      this.onTaskChange?.(id, before, after);
    } catch {
      // a listener's mistake doesn't stop the change
    }
  }

  // ---------------------------------------------------------------- settings

  global() {
    return { ...globalDefaults(), ...this.settings.global };
  }

  setGlobal(patch) {
    this.settings.global = clean({ ...this.settings.global, ...patch });
    this.changed();
  }

  project(projectId) {
    return { ...projectDefaults(), ...(this.settings.projects[projectId] ?? {}) };
  }

  /** Settings saved for this project (without defaults): whether the pipeline knows it at all. */
  projectSaved(projectId) {
    return this.settings.projects[projectId] ?? null;
  }

  setProject(projectId, patch) {
    this.settings.projects[projectId] = clean({ ...(this.settings.projects[projectId] ?? {}), ...patch });
    this.changed();
  }

  resetProject(projectId, keys) {
    const saved = { ...(this.settings.projects[projectId] ?? {}) };
    for (const key of keys) delete saved[key];
    this.settings.projects[projectId] = saved;
    this.changed();
  }

  removeProject(projectId) {
    delete this.settings.projects[projectId];
    this.changed();
  }

  /** Backend-only state that must survive a restart (the usage limit, the last error). */
  state() {
    return this.settings.state;
  }

  setState(patch) {
    this.settings.state = clean({ ...this.settings.state, ...patch });
    this.changed();
  }

  /** The board table's saved views (the board panel's own shape); null: none saved yet (the panel's starting views). */
  views() {
    return this.settings.views ?? null;
  }

  /** Replace the saved views; null: back to the starting views. */
  setViews(list) {
    if (list === null) delete this.settings.views;
    else this.settings.views = list;
    this.changed();
  }

  // ---------------------------------------------------------------- crew (background jobs)

  /** What a background job keeps under `key` (scouts, orchestrator, lanes, updates, usage). */
  crew(key, fallback = null) {
    return this.crewData[key] ?? fallback;
  }

  setCrew(key, value) {
    if (value === undefined) delete this.crewData[key];
    else this.crewData[key] = value;
    this.changed();
  }

  // ---------------------------------------------------------------- saving

  /** Something changed (`id`: that task): save soon and tell the panels. */
  changed(id) {
    if (id !== undefined) this.changedIds.add(String(id));
    this.onChange?.();
    if (this.timer) return;
    this.timer = setTimeout(() => this.saveNow(), SAVE_MS);
    this.timer.unref?.();
  }

  /** The tasks changed since the last call (numbers). */
  takeChanged() {
    const ids = [...this.changedIds].map(Number);
    this.changedIds.clear();
    return ids;
  }

  saveNow() {
    clearTimeout(this.timer);
    this.timer = null;
    writeFileAtomic(this.tasksFile, JSON.stringify({ counter: this.counter, tasks: this.tasks }, null, 1));
    writeFileAtomic(this.settingsFile, JSON.stringify(this.settings, null, 1));
    writeFileAtomic(this.crewFile, JSON.stringify(this.crewData));
  }
}

/** Task fields a draft may give. */
export const DRAFT_FIELDS = [
  "plan",
  "from",
  "alsoFrom",
  "model",
  "effort",
  "permissionMode",
  "autoMerge",
  "agentLands",
  "size",
  "sizePct",
  "noWorktree",
  "after",
  "attachments",
];

function clean(object) {
  return Object.fromEntries(Object.entries(object).filter(([, v]) => v !== undefined));
}

/** Orders task numbers: 83, 84, "84-1", "84-2", 85 (a batch's sub-tasks right after it). */
export function byNumber(a, b) {
  const [a1, a2 = 0] = String(a).split("-").map(Number);
  const [b1, b2 = 0] = String(b).split("-").map(Number);
  return a1 - b1 || a2 - b2;
}
