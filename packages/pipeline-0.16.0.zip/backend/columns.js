// Which column a task is in, from the task and what layr last saw of its Claude thread (`task.thread`). Pure: the
// board, Decide, the tools and the scheduler all use it.
//
// Columns: proposed (no thread yet, Run not pressed; or a Plan task still planning), ready (what you sent for Away
// waits for it: a message, answers, an approval, or a proposal's launch), running (its turn runs, or something waits for a slot, or it is landing), stopped (finished, asks,
// failed, interrupted: yours to look at), settled (you're done with it).
//
// `task.thread` (written by the scheduler): { status: starting|running|waiting|done|failed|interrupted, pending:
// [approval], lastMessage, replyStatus, lastError, turnStatus, turnEndedAt, archived, missing, branch, worktreePath,
// limitPause: ISO (claude 0.9.0: the turn stopped at the usage limit; the thread, still running, goes on then),
// background: [{ id, type, agent?, description, startedAt }] (Claude Code's background tasks still running: subagents,
// background shells, Monitor watches; the turn's end counts only once they are done) }.

export const COLUMNS = ["proposed", "ready", "running", "stopped", "settled"];

/** Claude thread statuses whose turn runs (or is about to). `waiting` is a turn that waits for the user. */
const ACTIVE = new Set(["starting", "running"]);
export const isActive = (thread) => !!thread && !thread.missing && ACTIVE.has(thread.status);

/** After layr sends a thread something, it counts as running this long, until the thread shows the turn. */
export const STARTING_GRACE_MS = 30_000;

/** claude 0.9.0: its turn stopped at the usage limit and the thread waits to go on by itself (`thread.limitPause`). */
export const limitPaused = (thread) => !!thread && !thread.missing && !!thread.limitPause;

/** Its turn is over, but background tasks it started (subagents, background shells, watches) still run. */
export const inBackground = (thread) => !!thread && !thread.missing && (thread.background?.length ?? 0) > 0;

export const waitsForAnswer = (thread) =>
  !!thread && !thread.missing && (thread.status === "waiting" || (thread.pending?.length ?? 0) > 0);

/**
 * Held messages that still go once a slot is free: the ones before a message whose sending failed. A failed message
 * blocks the later ones (they'd reach the thread out of order) until the user sends again, which retries it first.
 */
export function heldWaiting(task) {
  const held = task.held ?? [];
  const failed = held.findIndex((m) => m.kind === "message" && m.failed);
  return failed < 0 ? held : held.slice(0, failed);
}

/** Held messages with their failed marks taken off: a new message from the user sends them again, in order. */
/** A land is on its way: held for the gate, or waiting for Away (When away on). */
export const landQueued = (task) => [...(task.held ?? []), ...(task.parked ?? [])].some((m) => m.kind === "land");

/** All that waits for Away is a land. */
export const parksOnlyLand = (task) => !!task.parked?.length && task.parked.every((m) => m.kind === "land");

export const retryFailed = (held) => (held ?? []).map((m) => (m.failed ? { ...m, failed: undefined } : m));

/** Layr sent it something recently, and the thread doesn't show a turn since. */
export function isStarting(task, thread, now = Date.now()) {
  if (!task.sentAt || now - Date.parse(task.sentAt) > STARTING_GRACE_MS) return false;
  const started = thread?.turnStartedAt;
  return !started || Date.parse(started) < Date.parse(task.sentAt) - 2_000;
}

/** Its worktree has something to land (Land shows): commits or uncommitted changes, or not looked at yet. */
export const hasWork = (task) => !task.work || task.work.ahead > 0 || task.work.dirty > 0;

/** A planning task stays in Proposed until you approve its plan. */
const PLANNING = new Set(["queued", "limit", "starting", "running", "question"]);

/** `batch`: the task's batch (`task.inBatch`), whose column it shares. */
export function placeTask(task, now = Date.now(), batch = null) {
  if (task.inBatch) return { column: batch ? placeTask(batch, now).column : "proposed", why: "batched" };
  const placed = place(task, now);
  return task.planning && PLANNING.has(placed.why) ? { column: "proposed", why: placed.why } : placed;
}

function place(task, now) {
  const thread = task.thread;
  const held = heldWaiting(task);
  const waiting = () => (task.resumeAt && Date.parse(task.resumeAt) > now ? "limit" : "queued");
  if (task.settledAt) return { column: "settled", why: "settled" };
  if (!task.threadId) {
    if (held.some((m) => m.kind === "launch")) {
      return { column: "running", why: isStarting(task, thread, now) ? "starting" : waiting() };
    }
    if (task.parked?.some((m) => m.kind === "launch")) return { column: "ready", why: "ready" };
    return { column: "proposed", why: "proposal" };
  }
  if (!thread) return held.length || isStarting(task, thread, now) ? { column: "running", why: "starting" } : { column: "stopped", why: "idle" };
  if (thread.missing) return { column: "stopped", why: "missing" };
  if (waitsForAnswer(thread) && !held.some((m) => m.kind === "answer")) {
    if (parked(task) === "ready" && task.parked.some((m) => m.kind === "answer")) return { column: "ready", why: "ready" };
    return { column: "stopped", why: "question" };
  }
  if (isActive(thread) && limitPaused(thread)) return { column: "running", why: "limit" };
  if (isActive(thread) || thread.reacting) return { column: "running", why: task.landing ? "landing" : "running" };
  if (task.landing) return { column: "running", why: "landing" };
  if (inBackground(thread)) return { column: "running", why: "background" };
  if (task.verify?.state === "running" || task.verify?.state === "queued") return { column: "running", why: "verifying" };
  if (held.length) return { column: "running", why: waiting() };
  if (isStarting(task, thread, now)) return { column: "running", why: "starting" };
  const waits = parked(task);
  if (waits) return waits === "ready" ? { column: "ready", why: "ready" } : { column: "stopped", why: "question" };
  if (task.stopNote) return { column: "stopped", why: "note" };
  if (task.landed) return { column: "stopped", why: "landed" };
  if (thread.status === "failed") return { column: "stopped", why: "failed" };
  if (thread.status === "interrupted") return { column: "stopped", why: "interrupted" };
  if (task.planning) return { column: "stopped", why: "question" };
  if (thread.status === "done") return { column: "stopped", why: "finished" };
  return { column: "stopped", why: "idle" };
}

/** What you sent for Away still waits for it (`ready`), or a turn since asked again (`stale`): it waits for you. */
function parked(task) {
  if (!task.parked?.length) return null;
  return parkedStale(task) ? "stale" : "ready";
}

export function parkedStale(task) {
  const first = Math.min(...(task.parked ?? []).map((m) => Date.parse(m.at)));
  const turn = task.thread?.turnStartedAt;
  return !!turn && Date.parse(turn) > first && !planSettled(task);
}

/** A planning worker's reply says nothing is left to ask. */
export const planSettled = (task) => task.thread?.replyStatus?.status === "done";

/**
 * Approve fits: a planning task once its worker replied; any other task whose worker stopped with its work not done
 * (Approve says "go ahead with your recommendations"). Not while it runs, asks through a question, landed, or gone.
 */
export function approvable(task, now = Date.now()) {
  const thread = task.thread;
  if (!task.threadId || !thread || task.landed || task.landing || task.settledAt) return false;
  const { why } = placeTask(task, now);
  if (task.planning) return why === "question";
  if (thread.pending?.length || planSettled(task)) return false;
  return ["question", "finished", "idle", "interrupted", "failed", "note"].includes(why) && thread.replyStatus?.status !== "done";
}

/**
 * The task's thread uses a running slot now: its turn runs (not waiting for you), or is about to, or its background
 * work runs (subagents spend usage too).
 */
export function usesSlot(task, now = Date.now()) {
  if (task.verify?.state === "running") return true;
  if (task.settledAt) return false;
  if (isActive(task.thread)) return true;
  if (inBackground(task.thread) && !waitsForAnswer(task.thread)) return true;
  return isStarting(task, task.thread, now);
}

/** Why-words for people: the card's state. */
export const WHY_LABEL = {
  proposal: "proposed",
  queued: "waits for a slot",
  limit: "usage limit",
  starting: "starting",
  running: "running",
  background: "background work",
  landing: "landing",
  verifying: "verifying",
  ready: "waits for Away",
  question: "asks you",
  finished: "finished",
  landed: "landed",
  failed: "failed",
  interrupted: "stopped",
  note: "stopped by layr",
  missing: "thread gone",
  idle: "idle",
  settled: "settled",
  batched: "in a batch",
};

/** The colour tone of a why, for the panels. */
export const WHY_TONE = {
  proposal: "neutral",
  idle: "neutral",
  batched: "neutral",
  queued: "info",
  limit: "warning",
  interrupted: "warning",
  starting: "progress",
  running: "progress",
  background: "progress",
  landing: "accent",
  verifying: "accent",
  ready: "accent",
  question: "danger",
  failed: "danger",
  note: "danger",
  missing: "danger",
  finished: "success",
  landed: "landed",
  settled: "muted",
};
