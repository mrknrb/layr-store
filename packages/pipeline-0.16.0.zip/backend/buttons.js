// What a started task offers the user right now, in one place: the board's cards, Decide and the claude plugin's
// thread panel (its pipeline strip, through `thread_task` / `thread_action`) all show these buttons with the same
// labels and the same confirm texts, which say what pressing it really does (what Land does per landing mode, Settle
// on a checkout with changes, Discard losing the work). Pure: a task as `p.view` gives it, and its project's settings.

import { parksOnlyLand } from "./columns.js";

/** The checks line of a confirm text. */
const checksText = (s) => (s.checks.trim() ? `runs \`${s.checks.trim()}\`` : "runs no checks (none are set)");

/** What Land does, per landing mode. */
export function landText(t, s) {
  const how =
    s.landing === "pr"
      ? `layr ${checksText(s)}, pushes its branch, opens a pull request into ${s.baseBranch} and merges it once CI is green`
      : s.landing === "push"
        ? `layr ${checksText(s)}, pushes it to ${s.remote}/${s.baseBranch} (never forced) and moves the local ${s.baseBranch}`
        : `layr ${checksText(s)} and moves ${s.baseBranch} in the project's folder onto it`;
  const asks = [...(t.ask?.paths ?? []), ...(t.ask?.risks ?? [])];
  const look = asks.length ? ` It changes what you always look at first (${asks.slice(0, 4).join(", ")}): landing applies it.` : "";
  const auto = t.thread?.replyStatus?.status && t.thread.replyStatus.status !== "done" ? ` Its last reply says Status: ${t.thread.replyStatus.status}.` : "";
  const away = t.whenAway ? " When away is on: it waits in Ready and lands once you're Away." : "";
  return `Land #${t.number} on ${s.baseBranch}? Its thread rebases${s.squash ? " and squashes" : ""} if needed, ${how}.${look}${auto}${away}`;
}

/** Settle: only asks when something would be left behind. */
export function settleText(t) {
  if (t.noWorktree && (t.checkout?.files?.length || t.checkout?.branch)) {
    const parts = [
      t.checkout.files?.length ? `has ${t.checkout.files.length} uncommitted file(s)` : "",
      t.checkout.branch ? `is on ${t.checkout.branch}, not the base branch` : "",
    ].filter(Boolean);
    return `Settle #${t.number}? The project's checkout ${parts.join(" and ")}: commit or revert it there.`;
  }
  if (!t.noWorktree && t.threadId && !t.landed && t.work && (t.work.ahead > 0 || t.work.dirty > 0)) {
    return `Settle #${t.number} without landing? Its work (${t.work.ahead} commit(s), ${t.work.dirty} uncommitted) stays in its worktree (only work that is on the base branch is removed); Unsettle brings it back.`;
  }
  return undefined;
}

export function discardText(t) {
  if (t.noWorktree) return `Discard #${t.number}? Its thread is archived; the project's checkout stays as it is.`;
  return `Discard #${t.number}? Its worktree and branch are removed and its thread archived.${t.landed ? "" : " Its work isn't on the base branch: it's lost."}`;
}

export function stopText(t) {
  if (t.landing) return `Stop landing #${t.number}? Its thread's turn is interrupted; the work stays in its worktree.`;
  if (["running", "starting"].includes(t.why)) return `Stop #${t.number}? Its turn is interrupted and what waits for it (also for Away) is dropped.`;
  return undefined;
}

/**
 * The buttons of a task for its state: [{id, label, kind?, confirm?, pc?}]. `pc`: it opens a window on the PC (the
 * panels hide it on a phone). Proposals' own buttons (Run, Plan, Edit) are the board's, not these.
 */
export function taskButtons(t, s) {
  const out = [];
  const add = (id, label, extra = {}) => out.push({ id, label, ...Object.fromEntries(Object.entries(extra).filter(([, v]) => v !== undefined && v !== false)) });
  // The one Approve: with When away on, it waits in Ready for Away (the label says so).
  if (t.approvable && !t.parked?.some((m) => m.start)) {
    add("approve", `${t.planning ? "Approve" : "Go ahead"}${t.whenAway ? " · 🌙" : ""}`, { kind: "primary" });
  }
  // Ready: Run / Send now turns When away off (you're here after all); a proposal goes back with the toggle. A Land
  // that waits for Away: Land now, or Don't land (the Land button is back).
  if (t.column === "ready") {
    const lands = parksOnlyLand(t);
    add("start", lands ? "Land now" : t.threadId ? "Send now" : "Run now", { kind: "primary" });
    if (lands) add("unpark", "Don't land", { confirm: `Don't land #${t.number} when you're Away? It stays as it is: Land is back.` });
    else if (t.threadId) add("unpark", "Don't send", { confirm: `Drop what waits for Away for #${t.number}? It isn't sent.` });
  }
  // What waits from the thread's text box (its text is still there): take it back, no question asked.
  const box = t.parked?.find((m) => m.box);
  if (box) add("unbox", box.start ? "Unapprove" : "Unsend");
  if (t.column === "running" && !t.inBatch) add("stop", "Stop", { confirm: stopText(t) });
  if (t.canLand && !t.inBatch) add("land", `Land${t.whenAway ? " · 🌙" : ""}`, { kind: t.thread?.replyStatus?.status === "done" ? "primary" : undefined, confirm: landText(t, s) });
  if (canTry(t, s)) add("try", "▶ Try", { kind: t.thread?.replyStatus?.try === "ready" && t.column === "stopped" ? "primary" : undefined, pc: true });
  if (t.column === "stopped" && !t.inBatch) add("settle", "Settle", { confirm: settleText(t) });
  if (t.column === "settled" && !t.discarded) add("unsettle", "Unsettle");
  return out;
}

/**
 * The task's two toggles, as every panel shows them: `plan` (📝 Plan: Run plans first, the work starts with Approve)
 * and `whenAway` (🌙 When away: the work, and what you send it, waits for Away). {on, can, why?}: `can` false when it
 * can't change now (`why` says why).
 */
export function taskToggles(t) {
  const off = (why) => ({ can: false, why });
  const started = !!t.threadId;
  const plan = t.inBatch ? off("it runs with its batch")
    : t.settledAt ? off("it is settled")
      : t.planning ? { can: true }
        : started ? off("it has started")
          : t.held?.some((m) => m.kind === "launch") ? off("it is starting")
            : { can: true };
  const away = t.inBatch ? off("it runs with its batch") : t.settledAt ? off("it is settled") : t.landed ? off("it has landed") : { can: true };
  return { plan: { on: !!(t.plan || t.planning), ...plan }, whenAway: { on: !!t.whenAway, ...away } };
}

/** ▶ Try fits: a started task with a worktree of its own, in a project with a Try command. */
export const canTry = (t, s) => !!(t.threadId && !t.noWorktree && t.worktreePath && !t.discarded && s.tryCommand?.trim());

/** It stopped with a reply that asks the user (Status: asks). */
export const replyAsks = (t) => t.column === "stopped" && t.thread?.replyStatus?.status === "asks" && !t.landed;

/** What a card says under its title. */
export function noteOf(t) {
  if (t.landing) return `${t.state}${t.landing.pr ? ` · PR #${t.landing.pr.number}` : ""}${t.landing.waits ? ` · ${t.landing.waits}` : ""}`;
  if (t.landed && t.why === "landed") return `Landed as ${t.landed.commit.slice(0, 8)}`;
  if (t.stopNote && (t.why === "note" || !t.threadId)) return t.stopNote;
  if (replyAsks(t) && !t.thread?.pending?.length) return "Its reply asks you: answer its questions";
  if (t.why === "question" && t.thread?.pending?.length) {
    return t.thread.pending.map((a) => (a.kind === "question" ? (a.questions ?? []).map((q) => q.question).join(" · ") : `${a.kind}: ${a.tool ?? ""}`)).join(" · ");
  }
  if (t.unsent) return "Your unsent message is back in its thread's text box";
  if (t.planning) return t.why === "question" ? "your turn: answer or approve" : "planning";
  if (t.parked?.length) return t.waits ? `🌙 ${t.waits}` : parksOnlyLand(t) ? "🌙 Lands when you're Away" : "🌙 Waits for Away";
  if (t.waits && t.column === "running") return t.waits;
  if (t.why === "failed" && t.thread?.lastError) return t.thread.lastError;
  if (t.thread?.lastMessage && t.column === "stopped") return t.thread.lastMessage.split("\n").find((l) => l.trim() && !/^#/.test(l)) ?? "";
  return t.column === "proposed" ? (t.prompt ?? "").split("\n")[0] : "";
}
