// The prompt cache of a task's thread between turns, for the cards, the table and Decide. Pure (no DOM), so the
// table's code and test/table.test.js use it too.

/** How long Claude keeps a thread's prompt cache after its last turn (Claude Code on a subscription: an hour). */
export const CACHE_TTL_MS = 60 * 60_000;

/**
 * The prompt cache of a task's thread between turns: { warm, leftMin } or { warm: false, switched? } once it is cold;
 * null while a turn runs, and for tasks without a turn to go by. A message while warm re-reads the context from the
 * cache; after it the whole context is processed again (much more of the plan's usage). Each Claude account has its
 * own cache: since the active account changed (`t.cacheSwitched`, from the backend) it is cold too.
 */
export function cacheOf(t, now = Date.now()) {
  const th = t.thread;
  if (!t.threadId || !th || th.missing || th.archived || t.settledAt || ["starting", "running"].includes(th.status)) return null;
  const ended = Date.parse(th.turnEndedAt ?? "");
  if (Number.isNaN(ended)) return null;
  if (t.cacheSwitched) return { warm: false, switched: true };
  const left = CACHE_TTL_MS - Math.max(0, now - ended);
  return left > 0 ? { warm: true, leftMin: Math.ceil(left / 60_000) } : { warm: false };
}

/** Why it is cold, for a tooltip. */
export const coldWhy = (c) => (c?.switched ? "another Claude account is active now (each account has its own cache)" : "its hour is over");
