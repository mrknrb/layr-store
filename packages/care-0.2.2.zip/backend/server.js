#!/usr/bin/env node
// layr plugin "care" (Plugin care, built into layr since 0.2.0: its page is the Problems tab of every plugin's page,
// drawn by the app from these tools): every plugin's problems (the core's list, docs/ARCHITECTURE.md › Problems), one
// notification per problem that opens, a status bar count, going back to what worked, fixes with Claude that are
// proven or undone, and updates that keep your changes. An MCP server on stdio (the core is its client); its tools
// are what the plugin page and agents use (`care__<tool>` on the hub). The decisions live in care.js, updates.js and
// logic.js; this file is only the glue.
//
// Environment: LAYR_HUB_URL, LAYR_HUB_TOKEN (docs/ARCHITECTURE.md › The MCP hub).
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { Care } from "./care.js";
import { Hub } from "./hub.js";
import { hubStore, memoryStore } from "./store.js";
import { errorMessage, log, readManifest } from "./util.js";

const hub = new Hub({ url: process.env.LAYR_HUB_URL, token: process.env.LAYR_HUB_TOKEN });
const care = new Care({ hub, store: hub.available ? hubStore(hub) : memoryStore(), readManifest, log });
// Started before the MCP handshake (subscribing may come first); tools and events wait for it.
const ready = hub.available ? care.start().catch((error) => log("starting:", error)) : Promise.resolve();

const server = new McpServer(
  { name: "care", version: "0.2.0" },
  {
    capabilities: { tools: {} },
    instructions:
      "Plugin care looks after layr's plugins: `overview` lists every plugin's problems (what broke, when, its " +
      "state) and how care handles each plugin. `fix` starts a Claude thread fixing one problem (proven or undone " +
      "afterwards), `go_back` returns to the version or commit that worked. Ask the user before fixing, going back " +
      "or changing modes.",
  },
);

// Events (docs/ARCHITECTURE.md › Backends hearing events): problems, packages, the claude plugin's threads, and its
// own settings.
server.server.fallbackNotificationHandler = async (notification) => {
  if (notification.method !== "notifications/layr/event") return;
  const { topic, data } = notification.params ?? {};
  await ready;
  await care.heard(topic, data).catch((error) => log(`handling ${topic}:`, error));
};

/** Register a tool whose handler returns a value (sent as JSON text and as structured content). */
function tool(name, description, shape, handler) {
  server.registerTool(name, { description, inputSchema: shape }, async (args) => {
    try {
      await ready;
      const result = await handler(args ?? {});
      const structured = result && typeof result === "object" && !Array.isArray(result) ? result : { result };
      return { content: [{ type: "text", text: JSON.stringify(structured) }], structuredContent: structured };
    } catch (error) {
      return { content: [{ type: "text", text: errorMessage(error) }], isError: true };
    }
  });
}

const key = z.string().describe("The problem's key, <plugin>/<source>/<id> (overview)");
const plugin = z.string().describe("An installed plugin's id");

tool(
  "overview",
  "Every plugin with how Plugin care looks after it: `place` (made, changed, store, inside: inside a bigger " +
    "repository, reported only), `mode` (report, ask, auto), `autoUpdate` (its own choice: true, false, or null: " +
    "the setting changedUpdates) and `autoUpdateOn` (the result), `health`, the fix running, a recent update, " +
    "`merge` (an update being combined with your changes: resolving, ready, failed), `autoUpdated` (applied by " +
    "itself, with undo_update), and its problems (title, source, details, url, state: watching, open, fixing, " +
    "fixed, ignored; count, note, `fix` with its thread, `fixState`, `goBack` when going back without AI is " +
    "possible). Plugins with problems first; `budget`: today's fixes by itself. `plugin`: only that one.",
  { plugin: plugin.optional() },
  ({ plugin: only }) => care.overview({ plugin: only }),
);

tool(
  "fix",
  "Fix a problem with Claude: a thread on the plugin (a store plugin gets your own copy first) told the problem, the " +
    "page's outline and the extension's logs. When its turn ends the change is saved as a version and proven (the " +
    "backend restarted, the self-test run, or the next pass); if the problem comes back it is undone. One fix per " +
    "plugin at a time; plugins inside a bigger repository are only reported. Gives {key, thread, link}.",
  { key },
  ({ key: k }) => care.fix(k),
);

tool(
  "go_back",
  "Go back to what worked, without AI: the version or commit the problem last passed at (when a change broke it), " +
    "or the version a plugin had before an update in the day before it broke.",
  { key },
  ({ key: k }) => care.goBack(k),
);

tool("ignore", "Ignore a problem: it is still counted, but needs no care.", { key }, ({ key: k }) => care.ignore(k));

tool(
  "reopen",
  "Open an ignored or fixed problem again (and let it be fixed by itself again after a fix that didn't work).",
  { key },
  ({ key: k }) => care.reopen(k),
);

tool(
  "set_mode",
  "How Plugin care handles a plugin's problems: report (only tell), ask (offer Fix with Claude), auto (fix by " +
    "itself, at most dailyFixes a day); null: the default mode (setting defaultMode).",
  { plugin, mode: z.enum(["report", "ask", "auto"]).nullable() },
  ({ plugin: id, mode }) => care.setMode(id, mode),
);

tool(
  "set_auto_update",
  "Update by itself, keep my changes: a store plugin takes new versions by itself (shortly after the start and every " +
    "6 hours); your changes are merged and its self-test run first; when they conflict Claude combines them and the " +
    "update waits as ready to apply. `on`: true, false, or null to follow the settings (autoUpdate, on by default, " +
    "for plugins as they came; changedUpdates for plugins with your changes). Gives {plugin, autoUpdate, autoUpdateOn}.",
  { plugin, on: z.boolean().nullable() },
  ({ plugin: id, on }) => care.setAutoUpdate(id, on),
);

tool(
  "undo_update",
  "Undo an update that was applied by itself (overview's `autoUpdated`): back to the version before, with your " +
    "changes as they stood there when it had them; that version isn't taken by itself again. Gives the PluginInfo.",
  { plugin },
  ({ plugin: id }) => care.undoUpdate(id),
);

tool(
  "apply_update",
  "Apply an update that is ready (overview's `merge.state` ready: Claude combined it with your changes in " +
    "packages/<id>/merge and its self-test passed there). Gives {state: updated, from, to, mine}.",
  { plugin },
  ({ plugin: id }) => care.updater.apply(id),
);

tool(
  "update_now",
  "Look for a newer version of a store plugin now and take it as Update by itself would (your changes merged and " +
    "checked first). Gives {state: current | updated | merging | fixing-merge | ready | permissions | failed, from, " +
    "to}.",
  { plugin },
  ({ plugin: id }) => care.updater.update(id, { manual: true }),
);

tool(
  "check_updates",
  "Look for updates now for every plugin that updates by itself. Gives what happened to each.",
  {},
  async () => ({ results: await care.updater.tick() }),
);

tool(
  "add_checks",
  "A Claude thread that adds self-checks to a plugin (layr.expect where its code relies on a page or an API, and a " +
    "`check` script), so Plugin care notices when it breaks. Gives {thread, link}.",
  { plugin },
  ({ plugin: id }) => care.addChecks(id),
);

// ------------------------------------------------------------------ start

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  if (!hub.available) {
    log("care backend up without a hub (LAYR_HUB_URL not set): nothing to look after");
    return;
  }
  await ready;
  care.run();
  log("care backend up");
}

let stopping = false;
async function stop(code = 0) {
  if (stopping) return;
  stopping = true;
  try {
    care.stop();
    await hub.close();
  } finally {
    process.exit(code);
  }
}
process.on("SIGINT", () => void stop(0));
process.on("SIGTERM", () => void stop(0));
process.stdin.on("end", () => void stop(0));
process.stdin.on("close", () => void stop(0));
process.on("uncaughtException", (error) => log("uncaught:", error));
process.on("unhandledRejection", (error) => log("unhandled rejection:", error));

main().catch((error) => {
  log("could not start:", error);
  process.exit(1);
});
