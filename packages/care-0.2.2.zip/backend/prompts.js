// What Plugin care tells Claude: a fix of one problem, adding self-checks, combining an update with your changes and
// fixing a check that fails in that merge. The claude plugin's own system prompt for threads on a plugin says how
// layr plugins work and where the thread is; these say what to do.
import { SOURCE_LABELS } from "./logic.js";

const cut = (text, max) => {
  const s = String(text ?? "");
  return s.length > max ? `${s.slice(0, max)}\n… (cut, ${s.length - max} more characters)` : s;
};
const fence = (text) => `\`\`\`\n${String(text).replace(/```/g, "ˋˋˋ")}\n\`\`\``;
const when = (ms) => (ms ? new Date(ms).toISOString().replace("T", " ").slice(0, 16) + " UTC" : "unknown");
const short = (sha) => (sha ? String(sha).slice(0, 7) : null);

const NO_GIT =
  "- Don't run git (no commit, reset, checkout, stash or merge): layr saves your work as a version by itself when " +
  "your turn ends, and undoes it if the problem comes back.";

const CHECKS_RULE =
  "- Keep the plugin's checks meaningful: never loosen, delete, skip or catch a `layr.expect` / `layr.problem` call " +
  "or its `check` script to make it pass. If the site, API or plugin it relies on changed, change the code (the " +
  "selector, the request) so the check tests the same thing it did before. If a check itself was wrong, fix it and " +
  "say why in your reply.";

/**
 * The first message of a fix thread. `problem`: the core's Problem with `outline` (layr__problem_get); `logs`:
 * layr__extension_logs' answer for extension plugins; `manifest`: its layr.json; `update`: an update just before it
 * broke (logic.relatedUpdate), or null.
 */
export function fixPrompt({ problem: p, name, place, manifest, logs, update, names = {} }) {
  const lines = [];
  lines.push(`Plugin care: ${name} (${p.plugin}) has a problem. Please find its cause and fix it.`, "");
  lines.push(`Problem: ${p.title || p.id}`);
  lines.push(
    `Seen by: ${SOURCE_LABELS[p.source] ?? p.source} (source \`${p.source}\`, id \`${p.id}\`, key \`${p.key}\`)`,
  );
  lines.push(`Failed ${p.count ?? 1} time(s), first ${when(p.firstAt)}, last ${when(p.lastAt)}`);
  if (p.url) lines.push(`Page: ${p.url}`);
  const running = [p.version && `version ${p.version}`, short(p.commit) && `commit ${short(p.commit)}`, p.running]
    .filter(Boolean)
    .join(", ");
  if (running) lines.push(`Running when it failed: ${running}`);
  if (p.okAt) {
    const ok = [short(p.okCommit) && `commit ${short(p.okCommit)}`, p.okVersion && `version ${p.okVersion}`];
    lines.push(`Last worked: ${when(p.okAt)}${ok.some(Boolean) ? ` (${ok.filter(Boolean).join(", ")})` : ""}`);
  } else {
    lines.push("It hasn't been seen working yet.");
  }
  if (p.changed && p.okCommit && p.commit && p.okCommit !== p.commit) {
    lines.push(
      `It worked at ${short(p.okCommit)} and fails at ${short(p.commit)}, so a change in between probably broke it: ` +
        `\`git diff ${short(p.okCommit)} ${short(p.commit)}\` shows it (reading is fine).`,
    );
  } else if (p.changed) {
    lines.push("It worked at another version than the one that fails now: a change between them probably broke it.");
  }
  if (update) {
    const who = names[update.plugin] ?? update.plugin;
    lines.push(`It started after ${who} was updated from ${update.from} to ${update.to} (${when(update.at)}).`);
  }
  if (p.recurred) lines.push("It was fixed before and came back.");
  if (p.details) lines.push("", "Details:", fence(cut(p.details, 8000)));
  if (p.stack) lines.push("", "Where it was reported (stack):", fence(cut(p.stack, 4000)));
  if (p.outline) lines.push("", "Outline of the page when it failed (trimmed):", fence(cut(p.outline, 12000)));
  const entries = logs?.entries ?? [];
  if (entries.length) {
    const text = entries
      .slice(-40)
      .map(
        (e) =>
          `[${e.level}${e.source ? ` ${e.source}` : ""}] ${cut(String(e.text).split("\n").slice(0, 3).join(" "), 300)}`,
      )
      .join("\n");
    lines.push("", `Recent lines from its extension's log${logs.connected === false ? " (not connected now)" : ""}:`);
    lines.push(fence(text));
  }
  lines.push("", "How:");
  lines.push("- Fix the cause in this plugin's code, not the symptom. Read the code that reported it first.");
  lines.push(CHECKS_RULE);
  lines.push(
    "- If there is no `layr.expect` check around the part that broke, add one, so the next break is noticed " +
      "(`await layr.expect(id, found, {min, label})`; `layr.problem(id, details)` for other failures).",
  );
  if (manifest?.extension) {
    lines.push(
      "- It is a Chrome extension: layr reloads it when your turn ends. To try a change during the turn, reload it " +
        `with \`mcp__layr__layr__extension_reload\` {"plugin": "${p.plugin}"} and read its errors with ` +
        "`mcp__layr__layr__extension_logs`. Web tools (`scraper__*`, if installed) can open the page to try selectors " +
        "live.",
    );
  }
  if (p.source === "backend") lines.push("- layr restarts its backend when your turn ends; it must start and stay up.");
  if (p.source === "check" && manifest?.check) {
    lines.push(
      `- When your turn ends layr runs its self-test (\`${manifest.check}\`, with LAYR_CHECK=1 in the plugin's ` +
        "folder; exit code 0 passes). Run it yourself before you finish.",
    );
  }
  if (place === "changed") {
    lines.push("- This is your copy of a store plugin: keep the change small and focused on this problem.");
  }
  lines.push(NO_GIT);
  lines.push(
    "- If it can't be fixed here (it needs a login, a key, a decision, or the site is down), change nothing and say " +
      "what is needed.",
  );
  lines.push("- End with a short summary: the cause, and what you changed.");
  return lines.join("\n");
}

/** A thread that adds self-checks to a plugin that has few or none (the contract's SDK block). */
export function checksPrompt({ name, plugin, manifest }) {
  const backend = manifest?.backend?.kind === "process";
  const lines = [
    `Plugin care: please add self-checks to ${name} (${plugin}), so layr notices when it stops working (a site, an ` +
      "API, another plugin or layr changed under it) and Plugin care can have it fixed.",
    "",
    "What to add (docs/ARCHITECTURE.md › Problems (plugins that broke) › SDK):",
    "- Next to the code's own queries of what it relies on, `await layr.expect(id, found, {min, max, label, waitMs, " +
      "text})`: found is a CSS selector (counted in the page), a function (called again until it passes or waitMs " +
      "runs out), a list or NodeList, a number or a value. Use short stable ids (`videos`, `title`). It reports a " +
      "pass, or a failure with the page's url, the stack and an outline of the page.",
    "- For other failures (data that doesn't parse, a click that did nothing, an answer missing a field): " +
      "`await layr.problem(id, details, {title})`, and `await layr.ok(id)` once it works again.",
    "- Panels use `layr.js`; an extension's service worker and pages `layr-ext.js`; its content scripts " +
      "`layr-page.js` (`/_layr/layr-page.js`, a classic script listed before the plugin's own in " +
      "`content_scripts[].js`). Uncaught errors are reported by themselves.",
  ];
  if (backend) {
    lines.push(
      "- Its backend reports with the hub tool `layr__problem_report {id, ok?, title?, details?}` (a failure, or " +
        "`ok: true` once it works).",
    );
  }
  const selfTest = manifest?.check
    ? `Improve its self-test (\`${manifest.check}\`)`
    : 'Add a self-test: manifest field `"check": "test/check.mjs"`';
  lines.push(
    `- ${selfTest}: a script run with node (\`.py\`: \`uv run --no-project\`) in the plugin's folder with ` +
      "LAYR_CHECK=1, exit code 0 passes, at most 120 s. It tests the plugin's own logic without layr running and " +
      "without installing anything (an update is checked with it before it is used).",
    "- Check what people rely on, at the places where the code already looks for it. A check must not fail on a slow " +
      "page or a fluke (layr opens a problem only after two failing visits).",
    "- Don't change what the plugin does.",
    NO_GIT,
    "- End with a short list of the checks you added.",
  );
  return lines.join("\n");
}

/** The first message of a thread combining an update with your changes (`base`: merge_help's own prompt). */
export function mergePrompt({ base, name, from, to, manifest }) {
  const lines = [
    base || `Combine ${name}'s update from ${from} to ${to} with the changes made to it here: resolve every conflict.`,
    "",
    `Plugin care (updating ${name} from ${from} to ${to} by itself, keeping the user's changes):`,
    "- Keep what both sides meant: the update's fixes and the user's changes.",
    "- Leave no conflict markers. layr commits the merge by itself when your turn ends.",
  ];
  if (manifest?.check) {
    lines.push(`- Then layr runs its self-test here (\`${manifest.check}\`, LAYR_CHECK=1): run it before you finish.`);
  }
  lines.push(CHECKS_RULE);
  return lines.join("\n");
}

/** A thread fixing the self-test that fails in the merged update. */
export function mergeCheckPrompt({ name, to, output, file }) {
  return [
    `Plugin care: ${name} ${to}, merged with the user's changes in this folder, fails its self-test` +
      `${file ? ` (\`${file}\`)` : ""}. Please fix the merged code so it passes.`,
    "",
    "Its output (the end):",
    fence(cut(output || "(no output)", 6000)),
    "",
    "- Keep what both the update and the user's changes meant.",
    CHECKS_RULE,
    "- layr commits your work by itself when your turn ends, then runs the self-test again.",
    "- End with a short summary of what was wrong.",
  ].join("\n");
}
