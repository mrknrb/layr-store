// Plugin care's decisions, pure (no hub, no files, no clock of their own): what a plugin's place and mode allow,
// whether a problem that opened is fixed by itself, what going back means, which update a problem may come from,
// and the status bar item. docs/ARCHITECTURE.md › Problems (plugins that broke) › Plugin care.

export const MODES = ["report", "ask", "auto"];
export const MODE_LABELS = { report: "Report only", ask: "Ask", auto: "Automatic" };
export const HOUR = 3_600_000;
/** Problems that open this long after an update of their plugin (or one it connects to) name it. */
export const UPDATE_NOTE_MS = 24 * HOUR;
/** Updates are remembered this long (the plugin page lists them; older ones are dropped). */
export const UPDATE_KEEP_MS = 7 * 24 * HOUR;
/** States that need someone: the status bar counts plugins with one of these. */
export const NEEDS_CARE = new Set(["open", "fixing"]);
/** Where a problem's plugin is no longer failing: what Plugin care told about it is forgotten. */
export const SETTLED = new Set(["ok", "fixed", "ignored", "watching"]);

export const SOURCE_LABELS = {
  self: "its own check",
  panel: "an error in its page",
  extension: "an error in its extension",
  backend: "its backend",
  tool: "a tool call",
  install: "its install",
  check: "its self-test",
};

/**
 * Where a plugin lives, from `layr__plugin_repos`: `made` (yours, its own repository), `changed` (a store plugin with
 * your changes), `store` (as it came), `inside` (linked from a bigger repository: reported only). As the claude
 * plugin's targets_list says it.
 */
export function placeOf(repo) {
  if (!repo) return null;
  if (repo.insideRepo) return "inside";
  return repo.kind === "made" || repo.kind === "changed" ? repo.kind : "store";
}

/** The plugin's mode: its own, else the `defaultMode` setting; plugins inside a bigger repository only report. */
export function modeOf({ prefs, plugin, defaultMode, place }) {
  if (place === "inside") return "report";
  const own = prefs?.[plugin]?.mode;
  if (MODES.includes(own)) return own;
  return MODES.includes(defaultMode) ? defaultMode : "ask";
}

/** The setting "When a new version of a plugin you changed arrives" (`changedUpdates`). */
export const CHANGED_UPDATES = ["ask", "auto"];

/**
 * A plugin's own "Update by itself" choice, tri-state: true, false, or null (follow the setting). Stored booleans
 * from 0.1 are kept as they are (each was a choice of the user's).
 */
export function ownAutoUpdate(prefs, plugin) {
  const v = prefs?.[plugin]?.autoUpdate;
  return typeof v === "boolean" ? v : null;
}

/**
 * Does the plugin take new versions by itself? Its own choice wins; else a store plugin with your changes follows
 * `changedUpdates` (auto: yes), and one as it came follows `autoUpdate` (on unless it is false). Plugins that don't
 * come from a store never do.
 */
export function autoUpdateOf({ prefs, plugin, place, changedUpdates, autoUpdate = true }) {
  if (place !== "store" && place !== "changed") return false;
  const own = ownAutoUpdate(prefs, plugin);
  if (own !== null) return own;
  if (place === "changed") return changedUpdates === "auto";
  return autoUpdate !== false;
}

/**
 * Where an update being combined with your changes is (a job of `runtime.updateJobs`), for the plugin page:
 * `{version, from, state: resolving | ready | failed, thread, link, error, at}` or null.
 */
export function mergeStateOf(job) {
  if (!job) return null;
  const state = job.stage === "ready" ? "ready" : job.stage === "failed" ? "failed" : "resolving";
  return {
    version: job.to,
    from: job.from ?? null,
    state,
    thread: job.thread ?? null,
    link: threadLink(job.thread),
    error: job.error ?? null,
    at: job.at ?? null,
  };
}

/**
 * Where a fix of a problem stands, in one word: `fixing` (Claude's thread runs), `proving` (fixed, waiting for it to
 * work again), `works` (fixed and proven), `undone` (Claude's fix came back and was taken back), `failed` (it
 * changed nothing, or its thread failed), `wentBack` (went back without AI), or null (no fix tried).
 */
export function fixStateOf(p) {
  if (!p) return null;
  if (p.state === "fixing") return "fixing";
  const fix = p.fix;
  if (!fix) return null;
  if (fix.undone || fix.undoFailed) return "undone";
  if (fix.wentBack && p.state === "fixed") return "wentBack";
  if (p.state === "fixed") return p.verified ? "works" : "proving";
  if (p.state === "open" && fix.thread) return "failed";
  return null;
}

/** The local day of `ms` (`YYYY-MM-DD`): the daily cap of automatic fixes counts per day. */
export function dayOf(ms) {
  const d = new Date(ms);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** The automatic fixes already started today (`runtime.fixDay`, `runtime.fixCount`). */
export function fixesToday(runtime, now) {
  return runtime?.fixDay === dayOf(now) ? (runtime.fixCount ?? 0) : 0;
}

/** Is a fix running for the plugin (`jobs`: key → job)? Gives the job. */
export function jobOfPlugin(jobs, plugin) {
  return Object.values(jobs ?? {}).find((j) => j.plugin === plugin) ?? null;
}

/**
 * Why a problem that just opened is not fixed by itself, or null when it is: the plugin's mode must be `auto`, it
 * must not live inside a bigger repository, a fix of this key must not have failed before, no fix of the plugin may
 * be running, and today's automatic fixes must stay under `dailyFixes`.
 */
export function autoFixBlock({ problem, mode, place, jobs, noAuto, today, dailyFixes, claude = true }) {
  if (!problem || problem.state !== "open") return "not open";
  if (place === "inside") return "inside a bigger repository: reported only";
  if (!place) return "not installed";
  if (mode !== "auto") return `mode ${mode}`;
  if ((noAuto ?? []).includes(problem.key)) return "a fix of it didn't work before";
  if (jobOfPlugin(jobs, problem.plugin)) return "a fix of this plugin is running";
  if (today >= (Number(dailyFixes) || 0)) return "today's automatic fixes are used up";
  if (!claude) return "Claude can't be used";
  return null;
}

/** The newest update (of `plugin`, or of a plugin it connects to) in the 24 hours before `at`, or null. */
export function relatedUpdate({ plugin, updates, at, connectsTo = [] }) {
  const near = new Set([plugin, ...connectsTo]);
  let best = null;
  for (const u of updates ?? []) {
    if (!near.has(u.plugin) || u.wentBack) continue;
    if (u.at > at || at - u.at > UPDATE_NOTE_MS) continue;
    if (!best || u.at > best.at) best = u;
  }
  return best;
}

const short = (sha) => String(sha ?? "").slice(0, 7);

/**
 * What going back means for a problem, without AI: `{tool, args, label, note, update?}` or null.
 * - `changed` (it failed at another commit or version than it last passed at): the version that worked
 *   (`layr__plugin_switch {version: okVersion, mine}`, mine when it runs your changes) when the version differs,
 *   else the commit that worked (`layr__plugin_restore {commit: okCommit}`).
 * - Else an update in the 24 hours before it opened, of its plugin or of one it connects to: that plugin back to
 *   the version it had (`layr__plugin_switch {version: from, mine}`).
 */
export function goBackPlan(problem, { updates = [], connectsTo = [], names = {} } = {}) {
  if (!problem) return null;
  const plugin = problem.plugin;
  if (problem.changed) {
    if (problem.okVersion && problem.version && problem.okVersion !== problem.version) {
      const mine = problem.running === "mine";
      return {
        tool: "layr__plugin_switch",
        args: { plugin, version: problem.okVersion, mine },
        label: `Go back to ${problem.okVersion}${mine ? " with your changes" : ""}`,
        note: `Went back to ${problem.okVersion}, where it worked`,
      };
    }
    if (problem.okCommit && problem.okCommit !== problem.commit) {
      if (problem.commit) {
        return {
          tool: "layr__plugin_restore",
          args: { plugin, commit: problem.okCommit },
          label: "Go back to when it worked",
          note: `Went back to how it was at ${short(problem.okCommit)}, where it worked`,
        };
      }
      // It runs a version as it came now, and worked with your changes on it.
      const version = problem.okVersion ?? problem.version;
      if (version) {
        return {
          tool: "layr__plugin_switch",
          args: { plugin, version, mine: true },
          label: "Go back to your changes",
          note: `Went back to your changes on ${version}, where it worked`,
        };
      }
    }
  }
  const update = relatedUpdate({ plugin, updates, at: problem.firstAt ?? problem.lastAt ?? 0, connectsTo });
  if (update) {
    const name = names[update.plugin] ?? update.plugin;
    return {
      tool: "layr__plugin_switch",
      args: { plugin: update.plugin, version: update.from, mine: Boolean(update.mine) },
      label: update.plugin === plugin ? `Go back to ${update.from}` : `Put ${name} back to ${update.from}`,
      note: `Went back to ${name} ${update.from} (the update to ${update.to} came just before it broke)`,
      update,
    };
  }
  return null;
}

/** The note a problem gets when it opens within a day of an update. */
export function updateNote(update, names = {}) {
  const name = names[update.plugin] ?? update.plugin;
  return `Started after ${name} was updated from ${update.from} to ${update.to}: going back may fix it`;
}

/** One plugin's health from its problems: `open`, `fixing`, `watching`, `fixed` or `ok` (worst first). */
export function healthOf(problems) {
  const states = new Set((problems ?? []).map((p) => p.state));
  for (const s of ["open", "fixing", "watching", "fixed"]) if (states.has(s)) return s;
  return "ok";
}

/** The status bar item from every problem: `{text, tooltip, visible}`. */
export function statusItem(problems, names = {}) {
  const open = new Map();
  let fixing = 0;
  for (const p of problems ?? []) {
    if (!NEEDS_CARE.has(p.state)) continue;
    if (p.state === "fixing") fixing += 1;
    open.set(p.plugin, (open.get(p.plugin) ?? 0) + 1);
  }
  if (!open.size) return { text: "", tooltip: "Plugin care: every plugin works", visible: false };
  const n = open.size;
  const text = `${n} plugin${n === 1 ? " needs" : "s need"} care${fixing ? ` · ${fixing} fixing` : ""}`;
  const lines = [...open].map(([id, count]) => `${names[id] ?? id}: ${count} problem${count === 1 ? "" : "s"}`);
  return { text, tooltip: ["Plugin care", ...lines].join("\n"), visible: true };
}

/** `a` compared with `b` as versions (1.10.0 > 1.9.2; a pre-release before its release): -1, 0 or 1. */
export function compareVersions(a, b) {
  const parse = (v) => {
    const [main, pre] = String(v ?? "")
      .replace(/^v/, "")
      .split("-", 2);
    return { nums: main.split(".").map((n) => Number.parseInt(n, 10) || 0), pre: pre ?? null };
  };
  const x = parse(a);
  const y = parse(b);
  for (let i = 0; i < Math.max(x.nums.length, y.nums.length); i++) {
    const d = (x.nums[i] ?? 0) - (y.nums[i] ?? 0);
    if (d) return d > 0 ? 1 : -1;
  }
  if (x.pre === y.pre) return 0;
  if (x.pre === null) return 1;
  if (y.pre === null) return -1;
  return x.pre > y.pre ? 1 : -1;
}

/** The plugins a manifest connects to (`connections`, and `dependencies` as the old form of them). */
export function connectsOf(manifest) {
  const ids = new Set();
  for (const c of manifest?.connections ?? []) if (c?.plugin) ids.add(c.plugin);
  const deps = manifest?.dependencies;
  if (Array.isArray(deps)) for (const d of deps) ids.add(typeof d === "string" ? d : (d?.id ?? d?.plugin));
  else if (deps && typeof deps === "object") for (const id of Object.keys(deps)) ids.add(id);
  ids.delete(undefined);
  return [...ids];
}

/** A thread's id from what claude__thread_start answers (`{thread: summary}` or `{thread: id}`). */
export function threadIdOf(started) {
  const t = started?.thread;
  if (typeof t === "string") return t;
  return t?.id ?? started?.id ?? null;
}

/** The claude plugin's link to a thread (its manifest `links`: path `thread`). */
export const threadLink = (thread) => (thread ? `layr://claude/thread/${thread}` : null);

/** A thread summary's status that means its turn is over (not running, starting, waiting or being picked up). */
export function turnOver(summary) {
  if (!summary || summary.resuming) return false;
  return ["done", "failed", "interrupted"].includes(summary.status);
}
