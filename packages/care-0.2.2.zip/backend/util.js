// Small helpers shared by the backend modules.
import { readFileSync } from "node:fs";
import path from "node:path";

/** Log to stderr: the core keeps it in logs/care.log (stdout is MCP). */
export function log(...args) {
  const text = args.map((a) => (typeof a === "string" ? a : a instanceof Error ? a.stack || a.message : safeJson(a)));
  process.stderr.write(`[care ${new Date().toISOString()}] ${text.join(" ")}\n`);
}

export function safeJson(value) {
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

export function errorMessage(error) {
  if (error instanceof Error) return error.message;
  return typeof error === "string" ? error : safeJson(error);
}

/** A plugin folder's layr.json, or null (missing, unreadable). */
export function readManifest(folder) {
  if (!folder) return null;
  try {
    return JSON.parse(readFileSync(path.join(folder, "layr.json"), "utf8"));
  } catch {
    return null;
  }
}

export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
