// Updates that keep your changes (docs/ARCHITECTURE.md › Problems › Plugin care, and › One place for each plugin ›
// The lifecycle): for plugins that update by themselves (their own choice, else the setting `autoUpdate`, on by
// default, for plugins as they came, and `changedUpdates` for plugins with your changes), 20 seconds after the start
// and every 6 hours `layr__plugin_update {apply: false}` says whether a store version is newer.
// - New permissions: wait for the user (told once per version).
// - With your changes (`mine`): merged in packages/<id>/merge (`layr__plugin_merge_help`), then
//   `layr__plugin_check {where: "merge"}`. A clean merge whose check passes is used (`layr__plugin_update
//   {version}`). Conflicts go to one Claude thread there, a failing check to one thread fixing it (checked again);
//   what Claude changed is never used by itself: it waits as "Ready to apply" (`apply_update`, or the plugin page's
//   Apply = layr__plugin_update) while the old version keeps running.
// - Without: `layr__plugin_update {apply: true}`, then its self-test and its backend; failing: back to the old
//   version (`layr__plugin_switch`).
// Each update is remembered (plugin, from, to, at): problems in the next day name it (care.js). One applied by
// itself (not asked for with update_now) is also `autoUpdated` with Undo (care.undoUpdate).
import { compareVersions, threadIdOf, threadLink } from "./logic.js";
import { mergeCheckPrompt, mergePrompt } from "./prompts.js";

const LONG = { timeout: 10 * 60_000 };

export function createUpdater(care) {
  const running = new Set();
  const { hub } = care;
  const rt = () => care.rt;
  const name = (plugin) => care.name(plugin);

  async function saveJob(plugin, job) {
    if (job) rt().updateJobs[plugin] = job;
    else delete rt().updateJobs[plugin];
    await care.save("runtime");
    care.changed();
  }

  /** A version not to take by itself again; told once. A merge's job stays as `failed` for the plugin page. */
  async function giveUp(plugin, to, text, job = null) {
    rt().skip[plugin] = to;
    await saveJob(plugin, job ? { ...job, stage: "failed", error: text, at: care.now() } : null);
    care.notify(text, "error");
    return { plugin, state: "failed", version: to, error: text };
  }

  /** Used: remembered; applied by itself (`auto`), also `autoUpdated` with Undo on its page. */
  async function done(plugin, from, to, mine, { auto = false } = {}) {
    care.recordUpdate({ plugin, from, to, mine, by: "care" });
    delete rt().skip[plugin];
    delete rt().waiting[plugin];
    await saveJob(plugin, null);
    if (auto) {
      await care.recordAutoUpdated(plugin, { from, to, at: care.now(), mine: Boolean(mine) });
      care.notify(
        `${name(plugin)} updated to ${to} by itself${mine ? ", your changes kept" : ""}. Undo on its page.`,
        "success",
      );
    } else {
      await care.clearAutoUpdated(plugin);
      care.notify(`${name(plugin)} updated to ${to}${mine ? ", with your changes" : ""}`, "success");
    }
    return { plugin, state: "updated", from, to, mine };
  }

  /** Claude changed the merge and its self-test passes there: it waits for the user (Apply). */
  async function ready(job) {
    const { plugin, from, to } = job;
    await saveJob(plugin, { ...job, stage: "ready", error: null, at: care.now() });
    care.notify(`${name(plugin)} ${to} is ready to apply, with your changes: see its page`);
    return { plugin, state: "ready", from, to, thread: job.thread ?? null };
  }

  /** Its backend's status after a while (layr__plugins_list), or null without one. */
  async function backendStatus(plugin) {
    const manifest = care.manifestOf(plugin);
    if (manifest?.backend?.kind !== "process") return null;
    await care.sleep(care.timing.backendSettleMs);
    const list = await hub.call("layr__plugins_list", {}).catch(() => null);
    return (list?.plugins ?? []).find((p) => p.id === plugin)?.status ?? null;
  }

  /** Without your changes: install it, check it, go back when it fails. */
  async function plain(plugin, plan, manual) {
    const { from, to } = plan;
    care.busy.add(`version:${plugin}`);
    try {
      await hub.call("layr__plugin_update", { plugin, version: to, apply: true }, LONG);
      await care.refreshRepos(true);
      let why = null;
      const check = await hub.call("layr__plugin_check", { plugin }, LONG).catch(() => null);
      if (check?.ran && !check.ok) why = "its self-test fails";
      if (!why) {
        const status = await backendStatus(plugin);
        if (status === "failed" || status === "blocked")
          why = `its backend ${status === "failed" ? "doesn't start" : "is blocked"}`;
      }
      if (why) {
        await hub
          .call("layr__plugin_switch", { plugin, version: from }, LONG)
          .catch((e) => care.log("switching back:", e));
        await care.refreshRepos(true);
        return giveUp(plugin, to, `${name(plugin)} ${to} didn't work (${why}): went back to ${from}`);
      }
    } finally {
      care.busy.delete(`version:${plugin}`);
    }
    return done(plugin, from, to, false, { auto: !manual });
  }

  /** With your changes: merged in packages/<id>/merge first. */
  async function merge(plugin, plan, manual) {
    const { from, to } = plan;
    const help = await hub.call("layr__plugin_merge_help", { plugin, version: to }, LONG);
    const job = {
      plugin,
      from,
      to,
      path: help?.path ?? null,
      project: null,
      thread: null,
      tries: 0,
      manual: Boolean(manual),
      at: care.now(),
    };
    if (help?.conflicts?.length) {
      const started = await thread(
        job,
        mergePrompt({ base: help.prompt, name: name(plugin), from, to, manifest: care.manifestOf(plugin) }),
        "merge",
      );
      care.notify(`Updating ${name(plugin)} to ${to}: Claude combines it with your changes`);
      return { plugin, state: "merging", from, to, thread: started.thread, link: threadLink(started.thread) };
    }
    return checkMerge(job);
  }

  /** A Claude thread in the merge folder (a project of the claude plugin). */
  async function thread(job, prompt, stage) {
    if (!job.project) {
      const added = await hub.call("claude__project_add", {
        path: job.path,
        name: `${name(job.plugin)} ${job.to} (update)`,
      });
      job.project = added?.project?.id ?? added?.id ?? job.path;
    }
    const started = await hub.call(
      "claude__thread_start",
      {
        project: job.project,
        prompt,
        title: `${stage === "merge" ? "Update" : "Fix the update of"} ${name(job.plugin)} to ${job.to}`.slice(0, 100),
        permissionMode: "acceptEdits",
      },
      LONG,
    );
    const id = threadIdOf(started);
    if (!id) throw new Error("The claude plugin didn't say which thread it started");
    Object.assign(job, { thread: id, stage, at: care.now() });
    await saveJob(job.plugin, job);
    return { thread: id };
  }

  /** The merged update's self-test: passing → used; failing → one Claude thread fixes it, then checked again. */
  async function checkMerge(job) {
    const { plugin, from, to } = job;
    const check = await hub.call("layr__plugin_check", { plugin, where: "merge" }, LONG).catch((e) => ({ error: e }));
    if (check?.error)
      return giveUp(
        plugin,
        to,
        `${name(plugin)} ${to} wasn't used: its check couldn't run (${check.error.message ?? check.error})`,
        job,
      );
    if (!check?.ran || check.ok) {
      // What Claude changed (conflicts, a failing check) waits for the user; a clean merge is used now.
      if (job.thread) return ready(job);
      return apply(job, { auto: !job.manual });
    }
    if ((job.tries ?? 0) >= 1 || !job.path) {
      return giveUp(
        plugin,
        to,
        `${name(plugin)} ${to} wasn't used: its self-test fails with your changes merged in`,
        job,
      );
    }
    job.tries = (job.tries ?? 0) + 1;
    const prompt = mergeCheckPrompt({
      name: name(plugin),
      to,
      output: check.output,
      file: care.manifestOf(plugin)?.check,
    });
    const started = await thread(job, prompt, "fix");
    return { plugin, state: "fixing-merge", from, to, thread: started.thread, link: threadLink(started.thread) };
  }

  /** The merged update is used (layr__plugin_update {version} takes packages/<id>/merge's branch). */
  async function apply(job, { auto = false } = {}) {
    const { plugin, from, to } = job;
    care.busy.add(`version:${plugin}`);
    try {
      await hub.call("layr__plugin_update", { plugin, version: to }, LONG);
      await care.refreshRepos(true);
    } catch (e) {
      return giveUp(plugin, to, `${name(plugin)} ${to} wasn't used: ${e.message ?? e}`, job);
    } finally {
      care.busy.delete(`version:${plugin}`);
    }
    return done(plugin, from, to, true, { auto });
  }

  return {
    isUp: (from, to) => compareVersions(to, from) > 0,

    /** Apply an update that is ready (Claude combined it with your changes and its self-test passed there). */
    async apply(plugin) {
      const job = rt().updateJobs[plugin];
      if (job?.stage !== "ready") throw new Error(`No update of ${name(plugin)} is ready to apply`);
      if (running.has(plugin)) throw new Error(`${name(plugin)} is being updated already`);
      running.add(plugin);
      try {
        return await apply(job, { auto: false });
      } finally {
        running.delete(plugin);
      }
    },

    /** The look after the start and every 6 hours: every plugin that updates by itself, one after another (Plugin
     * care itself last: updating it restarts this backend). Gives what each did. */
    async tick() {
      rt().lastUpdateCheck = care.now();
      await care.save("runtime");
      await care.refreshRepos(true);
      const results = [];
      const last = (id) => (id === "care" ? 1 : 0);
      const plugins = [...care.repos.keys()].sort((a, b) => last(a) - last(b) || a.localeCompare(b));
      for (const plugin of plugins) {
        if (!care.autoUpdateOf(plugin)) continue;
        const r = await this.update(plugin).catch((e) => ({ plugin, state: "error", error: e.message ?? String(e) }));
        if (r?.state === "error") care.log(`updating ${plugin}:`, r.error);
        results.push(r);
      }
      care.changed();
      return results;
    },

    /** Look for and take a newer version of `plugin` (`manual`: asked for now, so skipped versions count too). */
    async update(plugin, { manual = false } = {}) {
      if (running.has(plugin)) return { plugin, state: "busy" };
      const job = rt().updateJobs[plugin];
      if (job && (job.stage === "merge" || job.stage === "fix"))
        return { plugin, state: job.stage === "merge" ? "merging" : "fixing-merge", to: job.to, thread: job.thread };
      const place = care.placeOf(plugin);
      if (!place) throw new Error(`${plugin} isn't installed`);
      if (place === "made" || place === "inside") throw new Error(`${name(plugin)} doesn't come from a store`);
      running.add(plugin);
      try {
        const plan = await hub.call("layr__plugin_update", { plugin, apply: false }, LONG);
        const { from, to } = plan ?? {};
        if (!to || to === from || !this.isUp(from, to)) return { plugin, state: "current", version: from ?? null };
        // Ready to apply: waits for the user until a newer version comes. A failed one is tried again when asked.
        if (job?.stage === "ready" && job.to === to) return { plugin, state: "ready", from, to, thread: job.thread };
        if (!manual && rt().skip[plugin] === to) return { plugin, state: "skipped", version: to };
        if (job) await saveJob(plugin, null);
        if (plan.newPermissions?.length) {
          if (manual || rt().waiting[plugin] !== to) {
            rt().waiting[plugin] = to;
            await care.save("runtime");
            care.changed();
            care.notify(
              `${name(plugin)} ${to} asks for more (${plan.newPermissions.join(", ")}): update it on its page`,
            );
          }
          return { plugin, state: "permissions", from, to, newPermissions: plan.newPermissions };
        }
        return plan.mine ? await merge(plugin, plan, manual) : await plain(plugin, plan, manual);
      } catch (error) {
        if (manual) throw error;
        care.log(`updating ${plugin} failed:`, error);
        return { plugin, state: "error", error: error.message ?? String(error) };
      } finally {
        running.delete(plugin);
      }
    },

    /** A merge or merge-fix thread's turn ended: its work is committed by the claude plugin, then checked. */
    async turnEnded(job, summary) {
      const guard = `update:${job.plugin}`;
      if (care.busy.has(guard)) return;
      care.busy.add(guard);
      try {
        if (summary.status !== "done") {
          return await giveUp(
            job.plugin,
            job.to,
            `${name(job.plugin)} ${job.to} wasn't used: Claude's thread ` +
              (summary.status === "failed" || summary.gone ? "failed" : "was stopped"),
            job,
          );
        }
        await care.sleep(care.timing.mergeSettleMs);
        return await checkMerge({ ...job });
      } finally {
        care.busy.delete(guard);
      }
    },
  };
}
