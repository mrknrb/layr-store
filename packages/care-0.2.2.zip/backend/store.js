// Plugin care's own records, in its plugin data (layr__data_get / layr__data_set; not synced: problems are about
// this PC's copy of each plugin). Two keys: `prefs` (per plugin: mode, autoUpdate: true | false, left out to follow
// the setting) and `runtime` (fixes running, today's count, keys not to fix by itself again, updates done, what was
// notified). 0.2.0: an update applied by itself is also written as `autoUpdated/<id>` {from, to, at, mine}, which
// the plugin page (the core's layr__plugin_overview) reads. Tests give a memory store.

export const emptyRuntime = () => ({
  fixDay: null,
  fixCount: 0,
  /** Fix threads running: problem key → {key, plugin, thread, base, at, auto, source}. */
  jobs: {},
  /** Keys whose fix didn't work: not fixed by itself again (until it works, or the user reopens it). */
  noAuto: [],
  /** Keys told about while open: key → time (forgotten once it works, is fixed or ignored). */
  notified: {},
  /** Updates: [{plugin, from, to, at, mine, by: "care" | "you", wentBack?}], newest last. */
  updates: [],
  /** Updates being combined with your changes in packages/<id>/merge: plugin → {plugin, from, to, stage, thread}.
   * `stage`: merge | fix (Claude resolves it), ready (its self-test passed there: waits for Apply), failed. */
  updateJobs: {},
  /** Updates applied by itself, with Undo on the plugin's page: plugin → {from, to, at, mine}. */
  autoUpdated: {},
  /** Versions not to update to by itself again (they failed, or you went back from them): plugin → version. */
  skip: {},
  /** Versions waiting for the user (new permissions), told once: plugin → version. */
  waiting: {},
  lastUpdateCheck: 0,
});

/** The store over the hub's plugin data. */
export function hubStore(hub) {
  return {
    async load() {
      const [prefs, runtime] = await Promise.all([
        hub.call("layr__data_get", { key: "prefs" }).catch(() => null),
        hub.call("layr__data_get", { key: "runtime" }).catch(() => null),
      ]);
      return { prefs, runtime };
    },
    async save(key, value) {
      await hub.call("layr__data_set", { key, value });
    },
  };
}

/** A store in memory (tests, and a backend started without the hub). */
export function memoryStore(initial = {}) {
  const data = structuredClone(initial);
  return {
    data,
    async load() {
      return { prefs: data.prefs ?? null, runtime: data.runtime ?? null };
    },
    async save(key, value) {
      data[key] = structuredClone(value);
    },
  };
}
