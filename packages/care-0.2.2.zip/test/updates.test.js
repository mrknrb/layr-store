// Updates that keep your changes, against the fake core: nothing new, new permissions, a plain update that works or
// goes back, and with your changes the merge folder, Claude for conflicts and for a failing self-test there.
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { repo, startedWorld } from "./fakes.js";

const store = (patch = {}) => repo("notes", { kind: "store", running: "version", ...patch });
const manifests = { "/plugins/notes": { id: "notes", backend: { kind: "process" }, check: "test/check.mjs" } };
const on = { prefs: { notes: { autoUpdate: true } } };

/** layr__plugin_update's answer for apply: false. */
function offers(w, plan) {
  w.on("layr__plugin_update", (args) => {
    if (args.apply === false)
      return { from: "1.0.0", newPermissions: [], mine: false, merges: false, conflicts: [], applied: false, ...plan };
    const r = w.repos.find((x) => x.id === args.plugin);
    if (args.version) r.version = args.version;
    return { from: "1.0.0", to: args.version, applied: true };
  });
}

describe("updating by itself", () => {
  it("does nothing when there is nothing new, and only for plugins with it on", async () => {
    const data = { prefs: { notes: { autoUpdate: true }, pdf: { autoUpdate: false } } };
    const w = await startedWorld({ repos: [store(), repo("pdf", { kind: "store" })], manifests, data });
    offers(w, { to: "1.0.0" });
    const results = await w.care.updater.tick();
    assert.deepEqual(results, [{ plugin: "notes", state: "current", version: "1.0.0" }]);
    assert.deepEqual(w.callsOf("layr__plugin_update"), [{ plugin: "notes", apply: false }]);
  });

  it("is on by default for store plugins, never for folders you made, and Plugin care goes last", async () => {
    const repos = [repo("care", { kind: "store" }), store(), repo("mine", { kind: "made" })];
    const w = await startedWorld({ repos, manifests });
    offers(w, { to: "1.0.0" });
    await w.care.updater.tick();
    assert.deepEqual(
      w.callsOf("layr__plugin_update").map((c) => c.plugin),
      ["notes", "care"],
    );
    const o = await w.care.overview();
    assert.equal(o.plugins.find((p) => p.id === "notes").autoUpdateOn, true);
    assert.equal(o.plugins.find((p) => p.id === "notes").autoUpdate, null, "not its own choice: the setting's");
    assert.equal(o.plugins.find((p) => p.id === "mine").autoUpdateOn, false);
  });

  it("the autoUpdate setting turns it off for every plugin without its own choice", async () => {
    const data = { prefs: { pdf: { autoUpdate: true } } };
    const w = await startedWorld({
      repos: [store(), repo("pdf", { kind: "store" })],
      manifests,
      data,
      settings: { autoUpdate: false },
    });
    offers(w, { to: "1.0.0" });
    await w.care.updater.tick();
    assert.deepEqual(w.callsOf("layr__plugin_update").map((c) => c.plugin), ["pdf"]);
    await w.care.setAutoUpdate("pdf", null);
    assert.equal(w.care.autoUpdateOf("pdf"), false);
    assert.deepEqual(w.store.data.prefs.pdf, {});
  });

  it("waits for the user when the version asks for new permissions, and tells once", async () => {
    const w = await startedWorld({ repos: [store()], manifests, data: on });
    offers(w, { to: "1.1.0", newPermissions: ["pc"] });
    await w.care.updater.tick();
    await w.care.updater.tick();
    assert.equal(w.callsOf("layr__plugin_update").length, 2, "only looked");
    assert.equal(w.notes.filter((n) => /asks for more \(pc\)/.test(n.text)).length, 1);
    assert.equal((await w.care.overview()).plugins[0].waiting, "1.1.0");
  });

  it("without your changes: takes it, checks it, remembers it", async () => {
    const w = await startedWorld({ repos: [store()], manifests, data: on });
    offers(w, { to: "1.1.0" });
    w.on("layr__plugin_check", () => ({ ran: true, ok: true, code: 0, output: "" }));
    const [r] = await w.care.updater.tick();
    assert.equal(r.state, "updated");
    assert.deepEqual(w.callsOf("layr__plugin_update")[1], { plugin: "notes", version: "1.1.0", apply: true });
    assert.deepEqual(w.callsOf("layr__plugin_check"), [{ plugin: "notes" }]);
    assert.deepEqual(
      w.care.rt.updates.map(({ plugin, from, to, by }) => ({ plugin, from, to, by })),
      [{ plugin: "notes", from: "1.0.0", to: "1.1.0", by: "care" }],
      "remembered once (not again as an update by hand)",
    );
    assert.match(w.notes.at(-1).text, /Notes updated to 1.1.0/);
  });

  it("without your changes: goes back when its self-test fails, and doesn't take that version again", async () => {
    const w = await startedWorld({ repos: [store()], manifests, data: on });
    offers(w, { to: "1.1.0" });
    w.on("layr__plugin_check", () => ({ ran: true, ok: false, code: 1, output: "fail" }));
    const [r] = await w.care.updater.tick();
    assert.equal(r.state, "failed");
    assert.deepEqual(w.callsOf("layr__plugin_switch"), [{ plugin: "notes", version: "1.0.0" }]);
    assert.match(w.notes.at(-1).text, /didn't work \(its self-test fails\): went back to 1.0.0/);
    const [again] = await w.care.updater.tick();
    assert.equal(again.state, "skipped");
    // Asked for by hand, it is tried again.
    const manual = await w.care.updater.update("notes", { manual: true });
    assert.equal(manual.state, "failed");
  });

  it("without your changes: goes back when its backend doesn't start", async () => {
    const w = await startedWorld({ repos: [store()], manifests, data: on });
    offers(w, { to: "1.1.0" });
    w.on("layr__plugins_list", () => ({ plugins: [{ id: "notes", status: "failed" }] }));
    const [r] = await w.care.updater.tick();
    assert.equal(r.state, "failed");
    assert.match(r.error, /backend doesn't start/);
    assert.deepEqual(w.callsOf("layr__plugin_switch"), [{ plugin: "notes", version: "1.0.0" }]);
  });

  it("with your changes and no conflicts: merged, checked in the merge folder, then used", async () => {
    const w = await startedWorld({ repos: [store({ kind: "changed", running: "mine" })], manifests, data: on });
    offers(w, { to: "1.1.0", mine: true });
    w.on("layr__plugin_check", () => ({ ran: true, ok: true, code: 0, output: "" }));
    const [r] = await w.care.updater.tick();
    assert.equal(r.state, "updated");
    assert.equal(r.mine, true);
    assert.deepEqual(w.callsOf("layr__plugin_merge_help"), [{ plugin: "notes", version: "1.1.0" }]);
    assert.deepEqual(w.callsOf("layr__plugin_check"), [{ plugin: "notes", where: "merge" }]);
    assert.deepEqual(w.callsOf("layr__plugin_update").at(-1), { plugin: "notes", version: "1.1.0" });
    assert.equal(w.callsOf("claude__thread_start").length, 0);
  });

  it("with conflicts: a Claude thread in the merge folder, the check, a thread fixing it, then ready", async () => {
    const w = await startedWorld({ repos: [store({ kind: "changed", running: "mine" })], manifests, data: on });
    offers(w, { to: "1.1.0", mine: true, conflicts: ["panel.js"] });
    w.on("layr__plugin_merge_help", () => ({
      path: "/packages/notes/merge",
      branch: "merge/v1.1.0",
      conflicts: ["panel.js"],
      prompt: "Resolve panel.js.",
    }));
    const [r] = await w.care.updater.tick();
    assert.equal(r.state, "merging");
    assert.deepEqual(w.callsOf("claude__project_add")[0].path, "/packages/notes/merge");
    const [start] = w.callsOf("claude__thread_start");
    assert.equal(start.project, "proj-/packages/notes/merge");
    assert.ok(start.prompt.startsWith("Resolve panel.js."));
    assert.equal(start.target, undefined);
    assert.equal(w.care.rt.updateJobs.notes.stage, "merge");
    // Claude's turn ends; the check fails in the merge folder: a thread to fix it.
    let checks = 0;
    w.on("layr__plugin_check", () =>
      ++checks === 1
        ? { ran: true, ok: false, code: 1, output: "TypeError in merged code" }
        : { ran: true, ok: true, code: 0, output: "" },
    );
    w.endTurn(r.thread);
    await w.settle();
    assert.equal(w.care.rt.updateJobs.notes.stage, "fix");
    const fixStart = w.callsOf("claude__thread_start")[1];
    assert.equal(fixStart.project, "proj-/packages/notes/merge");
    assert.match(fixStart.prompt, /TypeError in merged code/);
    assert.equal(w.callsOf("claude__project_add").length, 1, "the same project");
    // Its turn ends; the check passes: what Claude changed waits for the user (Ready to apply), the old one runs.
    w.endTurn(w.care.rt.updateJobs.notes.thread);
    await w.settle();
    assert.equal(w.care.rt.updateJobs.notes.stage, "ready");
    assert.equal(w.callsOf("layr__plugin_update").filter((a) => a.apply !== false).length, 0, "not used by itself");
    const [p] = (await w.care.overview()).plugins;
    assert.equal(p.merge.state, "ready");
    assert.equal(p.merge.version, "1.1.0");
    assert.match(w.notes.at(-1).text, /ready to apply/);
    // Looked for again: still ready, nothing merged again.
    const [again] = await w.care.updater.tick();
    assert.equal(again.state, "ready");
    assert.equal(w.callsOf("layr__plugin_merge_help").length, 1);
    // Apply: used, and not an update by itself (no Undo).
    const applied = await w.care.updater.apply("notes");
    assert.equal(applied.state, "updated");
    assert.deepEqual(w.callsOf("layr__plugin_update").at(-1), { plugin: "notes", version: "1.1.0" });
    assert.deepEqual(w.care.rt.updateJobs, {});
    assert.equal(w.care.rt.updates.at(-1).mine, true);
    assert.equal(w.care.rt.autoUpdated.notes, undefined);
    await assert.rejects(w.care.updater.apply("notes"), /No update of Notes is ready/);
  });

  it("with your changes: gives up when the check still fails after Claude's fix", async () => {
    const w = await startedWorld({ repos: [store({ kind: "changed", running: "mine" })], manifests, data: on });
    offers(w, { to: "1.1.0", mine: true });
    w.on("layr__plugin_check", () => ({ ran: true, ok: false, code: 1, output: "still failing" }));
    const [r] = await w.care.updater.tick();
    assert.equal(r.state, "fixing-merge");
    w.endTurn(r.thread);
    await w.settle();
    assert.equal(w.care.rt.updateJobs.notes.stage, "failed", "kept as failed for the plugin page");
    assert.equal((await w.care.overview()).plugins[0].merge.state, "failed");
    assert.equal(w.care.rt.skip.notes, "1.1.0");
    assert.equal(w.callsOf("layr__plugin_update").filter((a) => a.apply !== false).length, 0, "never used");
    assert.match(w.notes.at(-1).text, /wasn't used: its self-test fails/);
  });

  it("doesn't touch plugins that don't come from a store", async () => {
    const w = await startedWorld({ repos: [repo("mine-made")], manifests });
    await assert.rejects(w.care.updater.update("mine-made", { manual: true }), /doesn't come from a store/);
  });
});
