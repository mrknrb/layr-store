// Plugin care against a fake core and claude plugin: notifications, modes, the daily cap, one fix per plugin, a fix's
// turn, its proof or undo, report-only plugins, going back, ignore and reopen, the overview.
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { fakeWorld, HOUR, problem, repo, startedWorld, T0 } from "./fakes.js";

const yt = () =>
  repo("youtube", {
    path: "/plugins/youtube",
    kind: "made",
    running: "folder",
  });
const manifests = {
  "/plugins/youtube": { id: "youtube", extension: "extension" },
  "/plugins/notes": { id: "notes", backend: { kind: "process" }, check: "test/check.mjs" },
};
const auto = (...ids) => ({ prefs: Object.fromEntries(ids.map((id) => [id, { mode: "auto" }])) });

describe("a problem that opens", () => {
  it("is told once, counted in the status bar, and in Ask mode not fixed by itself", async () => {
    const w = await startedWorld({ repos: [yt()], manifests });
    w.report({ key: "youtube/self/videos", title: "No videos found" });
    await w.settle();
    assert.equal(w.notes.length, 1);
    assert.match(w.notes[0].text, /Youtube needs care: No videos found/);
    assert.equal(w.notes[0].kind, "error");
    assert.deepEqual(w.status.at(-1), {
      id: "health",
      text: "1 plugin needs care",
      tooltip: "Plugin care\nYoutube: 1 problem",
      visible: true,
    });
    assert.equal(w.callsOf("claude__thread_start").length, 0);
    // It fails again (count changes): no second notification.
    w.report({ key: "youtube/self/videos", count: 3 });
    await w.settle();
    assert.equal(w.notes.length, 1);
  });

  it("problems open before care started are told in one notification, once", async () => {
    const w = fakeWorld({ repos: [yt(), repo("notes")], manifests });
    w.problems.set("youtube/self/a", problem({ key: "youtube/self/a" }));
    w.problems.set("notes/panel/error-1", problem({ key: "notes/panel/error-1" }));
    await w.care.start();
    assert.equal(w.notes.length, 1);
    assert.match(w.notes[0].text, /2 plugins need care \(2 problems\)/);
    // Started again: told already.
    const again = fakeWorld({ repos: [yt()], manifests, data: w.store.data });
    again.problems.set("youtube/self/a", problem({ key: "youtube/self/a" }));
    await again.care.start();
    assert.equal(again.notes.length, 0);
  });

  it("in Automatic mode starts a fix: an extension thread told the problem, its outline and logs", async () => {
    const w = await startedWorld({ repos: [yt()], manifests, data: auto("youtube") });
    w.report(
      {
        key: "youtube/self/videos",
        title: "No videos found",
        details: "0 of 3 ytd-rich-item-renderer",
        url: "https://www.youtube.com/feed/subscriptions",
        stack: "at group (content.js:12)",
      },
      { outline: "<ytd-app><ytd-browse page-subtype=subscriptions>…" },
    );
    await w.settle();
    const [start] = w.callsOf("claude__thread_start");
    assert.deepEqual(start.target, { kind: "extension", plugin: "youtube" });
    assert.equal(start.permissionMode, "acceptEdits");
    for (const part of [
      "No videos found",
      "0 of 3 ytd-rich-item-renderer",
      "content.js:12",
      "<ytd-app>",
      "TypeError: x is null",
      "Don't run git",
      "never loosen, delete",
    ]) {
      assert.ok(start.prompt.includes(part), `prompt has ${part}`);
    }
    const p = w.problems.get("youtube/self/videos");
    assert.equal(p.state, "fixing");
    assert.deepEqual(p.fix, { thread: "t1", at: T0, by: "care" });
    assert.equal(w.care.rt.fixCount, 1);
    assert.equal(w.status.at(-1).text, "1 plugin needs care · 1 fixing");
  });

  it("fixes one problem per plugin at a time, and at most dailyFixes a day", async () => {
    const w = await startedWorld({
      repos: [yt(), repo("notes"), repo("pdf")],
      manifests,
      settings: { dailyFixes: 2 },
      data: auto("youtube", "notes", "pdf"),
    });
    w.report({ key: "youtube/self/a" });
    await w.settle();
    w.report({ key: "youtube/self/b" });
    await w.settle();
    assert.equal(w.callsOf("claude__thread_start").length, 1, "one fix per plugin");
    w.report({ key: "notes/panel/error-1" });
    await w.settle();
    w.report({ key: "pdf/panel/error-2" });
    await w.settle();
    assert.equal(w.callsOf("claude__thread_start").length, 2, "the daily cap");
    assert.equal(w.problems.get("pdf/panel/error-2").state, "open");
    await assert.rejects(w.care.fix("youtube/self/b"), /fixing Youtube already/);
    // The next day counts again.
    w.clock.t += 24 * HOUR;
    w.report({ key: "pdf/panel/error-3" });
    await w.settle();
    assert.equal(w.callsOf("claude__thread_start").length, 3);
  });
});

describe("a fix's turn", () => {
  it("records the commit, sets fixed, and a pass verifies it", async () => {
    const w = await startedWorld({ repos: [yt()], manifests });
    w.report({ key: "youtube/self/videos" });
    await w.settle();
    const r = await w.care.fix("youtube/self/videos");
    assert.equal(r.link, "layr://claude/thread/t1");
    w.endTurn("t1", { commit: "c1" });
    await w.settle();
    const p = w.problems.get("youtube/self/videos");
    assert.equal(p.state, "fixed");
    assert.equal(p.fix.commit, "c1");
    assert.equal(p.fix.by, "care");
    assert.deepEqual(w.care.rt.jobs, {});
    // The core sees it pass.
    w.report({ key: "youtube/self/videos", verified: true });
    await w.settle();
    assert.match(w.notes.at(-1).text, /Claude's fix works/);
    assert.equal(w.status.at(-1).visible, false);
  });

  it("is noticed by looking at the thread when the event was missed", async () => {
    const w = await startedWorld({ repos: [yt()], manifests });
    w.report({ key: "youtube/self/videos" });
    await w.settle();
    await w.care.fix("youtube/self/videos");
    w.threads.get("t1").status = "done";
    w.history.get("youtube").unshift({ sha: "c9" });
    await w.care.pollThreads();
    await w.settle();
    assert.equal(w.problems.get("youtube/self/videos").fix.commit, "c9");
  });

  it("restarts the backend for backend problems, runs the self-test for check problems", async () => {
    const w = await startedWorld({ repos: [repo("notes")], manifests });
    w.report({ key: "notes/backend/start", title: "It didn't start" });
    w.report({ key: "notes/check/check", title: "Its self-test fails" });
    await w.settle();
    await w.care.fix("notes/backend/start");
    w.endTurn("t1", { commit: "c1" });
    await w.settle();
    assert.deepEqual(w.callsOf("layr__plugin_restart"), [{ plugin: "notes" }]);
    assert.equal(w.problems.get("notes/backend/start").verified, true, "it started: proof");
    await w.care.fix("notes/check/check");
    w.on("layr__plugin_check", () => ({ ran: true, ok: true, code: 0, output: "ok" }));
    w.endTurn("t2", { commit: "c2" });
    await w.settle();
    assert.equal(w.problems.get("notes/check/check").verified, true);
  });

  it("is undone when the self-test still fails", async () => {
    const w = await startedWorld({ repos: [repo("notes")], manifests });
    w.report({ key: "notes/check/check" });
    await w.settle();
    await w.care.fix("notes/check/check");
    w.on("layr__plugin_check", () => ({ ran: true, ok: false, code: 1, output: "1 failing" }));
    w.endTurn("t1", { commit: "c1" });
    await w.settle();
    assert.deepEqual(w.callsOf("layr__plugin_undo"), [{ plugin: "notes", commit: "c1" }]);
    const p = w.problems.get("notes/check/check");
    assert.equal(p.state, "open");
    assert.equal(p.fix.undone, true);
    assert.equal(p.note, "Claude's fix didn't work and was undone");
    assert.ok(w.care.rt.noAuto.includes("notes/check/check"));
  });

  it("that changed nothing leaves the problem open, and it isn't fixed by itself again", async () => {
    const w = await startedWorld({ repos: [yt()], manifests, data: auto("youtube") });
    w.report({ key: "youtube/self/videos" });
    await w.settle();
    w.endTurn("t1", {});
    await w.settle();
    const p = w.problems.get("youtube/self/videos");
    assert.equal(p.state, "open");
    assert.match(p.note, /without changing the plugin/);
    assert.equal(w.callsOf("claude__thread_start").length, 1, "no loop of fixes");
    assert.ok(w.care.rt.noAuto.includes("youtube/self/videos"));
  });

  it("whose thread failed reopens the problem", async () => {
    const w = await startedWorld({ repos: [yt()], manifests });
    w.report({ key: "youtube/self/videos" });
    await w.settle();
    await w.care.fix("youtube/self/videos");
    w.endTurn("t1", { status: "failed" });
    await w.settle();
    assert.equal(w.problems.get("youtube/self/videos").state, "open");
    assert.match(w.problems.get("youtube/self/videos").note, /failed/);
  });
});

describe("a fixed problem that comes back", () => {
  it("undoes Claude's commit, says so, and isn't fixed by itself again", async () => {
    const w = await startedWorld({ repos: [yt()], manifests, data: auto("youtube") });
    w.report({ key: "youtube/self/videos" });
    await w.settle();
    w.endTurn("t1", { commit: "c1" });
    await w.settle();
    assert.equal(w.problems.get("youtube/self/videos").state, "fixed");
    w.report({ key: "youtube/self/videos", state: "open", recurred: true });
    await w.settle();
    assert.deepEqual(w.callsOf("layr__plugin_undo"), [{ plugin: "youtube", commit: "c1" }]);
    assert.deepEqual(
      w.callsOf("layr__extension_reload"),
      [{ plugin: "youtube" }],
      "the extension runs the undone code",
    );
    const p = w.problems.get("youtube/self/videos");
    assert.equal(p.state, "open");
    assert.equal(p.fix.undone, true);
    assert.equal(p.note, "Claude's fix didn't work and was undone");
    assert.match(w.notes.at(-1).text, /didn't work and was undone/);
    assert.equal(w.callsOf("claude__thread_start").length, 1, "not fixed by itself again");
    // More failures of it: undone once only.
    w.report({ key: "youtube/self/videos", count: 5 });
    await w.settle();
    assert.equal(w.callsOf("layr__plugin_undo").length, 1);
  });

  it("says so when undoing fails, and doesn't try again on every failure", async () => {
    const w = await startedWorld({ repos: [yt()], manifests });
    w.report({ key: "youtube/self/videos" });
    await w.settle();
    await w.care.fix("youtube/self/videos");
    w.endTurn("t1", { commit: "c1" });
    await w.settle();
    w.on("layr__plugin_undo", () => {
      throw new Error("conflicts");
    });
    w.report({ key: "youtube/self/videos", state: "open", recurred: true });
    await w.settle();
    w.report({ key: "youtube/self/videos", count: 9 });
    await w.settle();
    assert.equal(w.callsOf("layr__plugin_undo").length, 1);
    assert.match(w.problems.get("youtube/self/videos").note, /undoing it failed: conflicts/);
  });
});

describe("plugins inside a bigger repository", () => {
  it("are only reported", async () => {
    const inside = repo("mono", { insideRepo: "C:/work/big", kind: "made" });
    const w = await startedWorld({ repos: [inside], manifests, settings: { defaultMode: "auto" } });
    w.report({ key: "mono/panel/error-1" });
    await w.settle();
    assert.equal(w.notes.length, 1);
    assert.equal(w.callsOf("claude__thread_start").length, 0);
    await assert.rejects(w.care.fix("mono/panel/error-1"), /inside a bigger repository/);
    await assert.rejects(w.care.setMode("mono", "auto"), /only reported/);
    const o = await w.care.overview();
    assert.equal(o.plugins[0].mode, "report");
    assert.equal(o.plugins[0].reportOnly, true);
    assert.equal(o.plugins[0].problems[0].canFix, false);
  });
});

describe("layr's own crashes", () => {
  it("are told and shown as the app's, never fixed here", async () => {
    const w = await startedWorld({ repos: [yt()], manifests, settings: { defaultMode: "auto" } });
    w.report({ key: "layr/crash/crash-1a2b3c4d", title: "layr crashed: an access violation in x.dll",
      running: "app", count: 1, streak: 1 });
    await w.settle();
    assert.equal(w.notes.length, 1);
    assert.match(w.notes[0].text ?? JSON.stringify(w.notes[0]), /layr \(the app\) needs care/);
    assert.equal(w.callsOf("claude__thread_start").length, 0);
    const o = await w.care.overview();
    const app = o.plugins.find((p) => p.id === "layr");
    assert.equal(app.name, "layr (the app)");
    assert.equal(app.app, true);
    assert.equal(app.reportOnly, true);
    assert.equal(app.installed, false);
    assert.equal(app.problems[0].canFix, false);
  });
});

describe("going back", () => {
  it("switches to the version that worked when the version changed", async () => {
    const w = await startedWorld({
      repos: [repo("notes", { kind: "changed", running: "mine", version: "1.1.0" })],
      manifests,
    });
    w.report({ key: "notes/self/list", changed: true, version: "1.1.0", okVersion: "1.0.0", running: "mine" });
    await w.settle();
    const r = await w.care.goBack("notes/self/list");
    assert.deepEqual(w.callsOf("layr__plugin_switch"), [{ plugin: "notes", version: "1.0.0", mine: true }]);
    assert.match(r.done, /Went back to 1.0.0/);
    const p = w.problems.get("notes/self/list");
    assert.equal(p.state, "fixed");
    assert.equal(p.fix.commit, undefined, "nothing to undo if it comes back");
  });

  it("restores the commit that worked when only the commit changed", async () => {
    const w = await startedWorld({ repos: [yt()], manifests });
    w.report({ key: "youtube/self/videos", changed: true, commit: "bad", okCommit: "good", okVersion: "1.0.0" });
    await w.settle();
    await w.care.goBack("youtube/self/videos");
    assert.deepEqual(w.callsOf("layr__plugin_restore"), [{ plugin: "youtube", commit: "good" }]);
    assert.deepEqual(w.callsOf("layr__extension_reload"), [{ plugin: "youtube" }]);
  });

  it("after an update of a plugin it connects to: notes the update, and puts that plugin back", async () => {
    const w = await startedWorld({
      repos: [repo("claude", { kind: "store", version: "0.3.2" }), repo("pipeline", { kind: "store" })],
      manifests: { "/plugins/pipeline": { id: "pipeline", connections: [{ plugin: "claude", groups: ["run"] }] } },
    });
    w.care.recordUpdate({ plugin: "claude", from: "0.3.1", to: "0.3.2", mine: false, by: "care" });
    w.clock.t += HOUR;
    w.report({ key: "pipeline/tool/run", firstAt: w.clock.t, lastAt: w.clock.t });
    await w.settle();
    assert.match(w.problems.get("pipeline/tool/run").note, /Started after Claude was updated from 0.3.1 to 0.3.2/);
    const o = await w.care.overview({ plugin: "pipeline" });
    assert.equal(o.plugins[0].problems[0].goBack.label, "Put Claude back to 0.3.1");
    await w.care.goBack("pipeline/tool/run");
    assert.deepEqual(w.callsOf("layr__plugin_switch"), [{ plugin: "claude", version: "0.3.1", mine: false }]);
    assert.equal(w.care.rt.skip.claude, "0.3.2", "not updated to it again by itself");
    // A day later an update no longer explains a new problem.
    w.clock.t += 25 * HOUR;
    w.report({ key: "pipeline/tool/other", firstAt: w.clock.t });
    await w.settle();
    assert.equal(w.problems.get("pipeline/tool/other").note, null);
  });

  it("refuses when there is nothing to go back to", async () => {
    const w = await startedWorld({ repos: [yt()], manifests });
    w.report({ key: "youtube/self/videos" });
    await w.settle();
    await assert.rejects(w.care.goBack("youtube/self/videos"), /Nothing to go back to/);
  });

  it("counts updates made by hand (a version that moved up)", async () => {
    const repos = [repo("notes", { kind: "store", version: "1.0.0" })];
    const w = await startedWorld({ repos, manifests });
    repos[0].version = "1.2.0";
    w.emit("layr:packages", { op: "install", phase: "done" });
    await w.settle();
    assert.deepEqual(
      w.care.rt.updates.map(({ plugin, from, to, by }) => ({ plugin, from, to, by })),
      [{ plugin: "notes", from: "1.0.0", to: "1.2.0", by: "you" }],
    );
  });
});

describe("the panel's tools", () => {
  it("ignore and reopen", async () => {
    const w = await startedWorld({ repos: [yt()], manifests, data: auto("youtube") });
    w.care.rt.noAuto.push("youtube/self/videos");
    w.report({ key: "youtube/self/videos" });
    await w.settle();
    await w.care.ignore("youtube/self/videos");
    await w.settle();
    assert.equal(w.problems.get("youtube/self/videos").state, "ignored");
    assert.equal(w.status.at(-1).visible, false);
    await w.care.reopen("youtube/self/videos");
    await w.settle();
    assert.equal(w.problems.get("youtube/self/videos").state, "open");
    assert.equal(w.care.rt.noAuto.length, 0);
    assert.equal(w.notes.length, 1, "reopening by hand isn't news");
  });

  it("modes and auto update are kept per plugin", async () => {
    const w = await startedWorld({ repos: [yt(), repo("notes", { kind: "store" })], manifests });
    await w.care.setMode("youtube", "report");
    await w.care.setAutoUpdate("notes", true);
    assert.deepEqual(w.store.data.prefs, { youtube: { mode: "report" }, notes: { autoUpdate: true } });
    await assert.rejects(w.care.setAutoUpdate("youtube", true), /doesn't come from a store/);
    await w.care.setMode("youtube", null);
    assert.equal(w.care.modeOf("youtube"), "ask");
    await assert.rejects(w.care.setMode("youtube", "sometimes"), /mode/);
  });

  it("add_checks starts a thread asking for layr.expect and a check script", async () => {
    const w = await startedWorld({ repos: [yt()], manifests });
    const r = await w.care.addChecks("youtube");
    assert.equal(r.thread, "t1");
    const [start] = w.callsOf("claude__thread_start");
    assert.deepEqual(start.target, { kind: "extension", plugin: "youtube" });
    for (const part of ["layr.expect", "layr.problem", "layr-page.js", '"check"', "LAYR_CHECK=1"])
      assert.ok(start.prompt.includes(part), part);
  });

  it("overview groups problems by plugin, worst first, with the fix's thread", async () => {
    const w = await startedWorld({ repos: [yt(), repo("notes"), repo("hello")], manifests });
    w.report({ key: "notes/self/list", state: "watching" });
    w.report({ key: "youtube/self/videos" });
    await w.settle();
    await w.care.fix("youtube/self/videos");
    await w.settle();
    const o = await w.care.overview();
    assert.deepEqual(
      o.plugins.map((p) => [p.id, p.health]),
      [
        ["youtube", "fixing"],
        ["notes", "watching"],
        ["hello", "ok"],
      ],
    );
    const y = o.plugins[0];
    assert.equal(y.extension, true);
    assert.equal(y.fixing.link, "layr://claude/thread/t1");
    assert.equal(y.problems[0].link, "layr://claude/thread/t1");
    assert.equal(y.problems[0].canFix, false, "one fix per plugin");
    assert.equal(o.settings.dailyFixes, 5);
  });
});
