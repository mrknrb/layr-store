// Plugin care's pure decisions (backend/logic.js) and prompts (backend/prompts.js).
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  autoFixBlock,
  compareVersions,
  connectsOf,
  goBackPlan,
  healthOf,
  modeOf,
  placeOf,
  relatedUpdate,
  statusItem,
  threadIdOf,
  turnOver,
} from "../backend/logic.js";
import { fixPrompt, mergeCheckPrompt } from "../backend/prompts.js";
import { HOUR, problem, T0 } from "./fakes.js";

describe("place and mode", () => {
  it("reads the place as the claude plugin's targets do", () => {
    assert.equal(placeOf({ kind: "made" }), "made");
    assert.equal(placeOf({ kind: "changed" }), "changed");
    assert.equal(placeOf({ kind: "store" }), "store");
    assert.equal(placeOf({ kind: "made", insideRepo: "C:/big" }), "inside");
    assert.equal(placeOf(null), null);
  });

  it("a plugin's own mode, else the default; inside: report", () => {
    assert.equal(modeOf({ prefs: { a: { mode: "auto" } }, plugin: "a", defaultMode: "ask", place: "made" }), "auto");
    assert.equal(modeOf({ prefs: {}, plugin: "a", defaultMode: "report", place: "made" }), "report");
    assert.equal(modeOf({ prefs: {}, plugin: "a", defaultMode: "nonsense", place: "made" }), "ask");
    assert.equal(
      modeOf({ prefs: { a: { mode: "auto" } }, plugin: "a", defaultMode: "auto", place: "inside" }),
      "report",
    );
  });
});

describe("fixing by itself", () => {
  const base = {
    problem: problem({ key: "a/self/x" }),
    mode: "auto",
    place: "made",
    jobs: {},
    noAuto: [],
    today: 0,
    dailyFixes: 5,
  };
  it("goes when everything allows it", () => assert.equal(autoFixBlock(base), null));
  it("not in report or ask mode", () => {
    assert.equal(autoFixBlock({ ...base, mode: "ask" }), "mode ask");
    assert.equal(autoFixBlock({ ...base, mode: "report" }), "mode report");
  });
  it("not inside a bigger repository", () => assert.match(autoFixBlock({ ...base, place: "inside" }), /reported only/));
  it("not twice for a key whose fix failed", () =>
    assert.match(autoFixBlock({ ...base, noAuto: ["a/self/x"] }), /didn't work/));
  it("one per plugin", () => {
    assert.match(autoFixBlock({ ...base, jobs: { "a/self/y": { plugin: "a" } } }), /running/);
    assert.equal(autoFixBlock({ ...base, jobs: { "b/self/y": { plugin: "b" } } }), null);
  });
  it("within the daily cap", () => {
    assert.match(autoFixBlock({ ...base, today: 5 }), /used up/);
    assert.match(autoFixBlock({ ...base, dailyFixes: 0 }), /used up/);
  });
  it("only open problems", () =>
    assert.equal(autoFixBlock({ ...base, problem: problem({ key: "a/self/x", state: "watching" }) }), "not open"));
});

describe("going back", () => {
  it("to the version that worked (with your changes when they ran)", () => {
    const p = problem({ key: "a/self/x", changed: true, version: "2.0.0", okVersion: "1.0.0", running: "mine" });
    assert.deepEqual(goBackPlan(p).args, { plugin: "a", version: "1.0.0", mine: true });
    assert.equal(goBackPlan(p).tool, "layr__plugin_switch");
  });
  it("to the commit that worked when the version is the same", () => {
    const p = problem({ key: "a/self/x", changed: true, commit: "bbb", okCommit: "aaa", okVersion: "1.0.0" });
    assert.deepEqual(goBackPlan(p), {
      tool: "layr__plugin_restore",
      args: { plugin: "a", commit: "aaa" },
      label: "Go back to when it worked",
      note: "Went back to how it was at aaa, where it worked",
    });
  });
  it("to your changes when it now runs the version as it came", () => {
    const p = problem({
      key: "a/self/x",
      changed: true,
      commit: null,
      okCommit: "aaa",
      okVersion: "1.0.0",
      running: "version",
    });
    assert.deepEqual(goBackPlan(p).args, { plugin: "a", version: "1.0.0", mine: true });
  });
  it("to the version before an update in the day before it broke", () => {
    const p = problem({ key: "a/self/x", firstAt: T0 });
    const updates = [{ plugin: "b", from: "0.1.0", to: "0.2.0", at: T0 - HOUR, mine: true }];
    assert.equal(goBackPlan(p, { updates }), null, "a plugin it doesn't connect to");
    const plan = goBackPlan(p, { updates, connectsTo: ["b"], names: { b: "Bee" } });
    assert.deepEqual(plan.args, { plugin: "b", version: "0.1.0", mine: true });
    assert.equal(plan.label, "Put Bee back to 0.1.0");
    assert.equal(goBackPlan({ ...p, firstAt: T0 + 24 * HOUR }, { updates, connectsTo: ["b"] }), null, "too long after");
    assert.equal(goBackPlan(p, { updates: [{ ...updates[0], wentBack: true }], connectsTo: ["b"] }), null);
  });
  it("nothing when it never worked elsewhere", () => {
    assert.equal(goBackPlan(problem({ key: "a/self/x", changed: false })), null);
    assert.equal(goBackPlan(problem({ key: "a/self/x", changed: true })), null);
  });
  it("the newest related update wins", () => {
    const updates = [
      { plugin: "a", from: "1", to: "2", at: T0 - 3 * HOUR },
      { plugin: "a", from: "2", to: "3", at: T0 - HOUR },
      { plugin: "a", from: "3", to: "4", at: T0 + HOUR },
    ];
    assert.equal(relatedUpdate({ plugin: "a", updates, at: T0 }).to, "3");
  });
});

describe("status and health", () => {
  it("counts plugins that need care", () => {
    const ps = [
      problem({ key: "a/self/x" }),
      problem({ key: "a/self/y", state: "fixing" }),
      problem({ key: "b/self/x", state: "watching" }),
      problem({ key: "c/self/x", state: "ignored" }),
    ];
    assert.deepEqual(statusItem(ps, { a: "Alpha" }), {
      text: "1 plugin needs care · 1 fixing",
      tooltip: "Plugin care\nAlpha: 2 problems",
      visible: true,
    });
    assert.equal(statusItem([]).visible, false);
    assert.equal(statusItem([problem({ key: "a/x/1" }), problem({ key: "b/x/1" })]).text, "2 plugins need care");
  });
  it("health is the worst state", () => {
    assert.equal(healthOf([{ state: "fixed" }, { state: "open" }]), "open");
    assert.equal(healthOf([{ state: "ignored" }]), "ok");
    assert.equal(healthOf([]), "ok");
  });
});

describe("helpers", () => {
  it("compares versions", () => {
    assert.equal(compareVersions("1.10.0", "1.9.2"), 1);
    assert.equal(compareVersions("1.0.0", "1.0.0"), 0);
    assert.equal(compareVersions("1.0.0-beta", "1.0.0"), -1);
    assert.equal(compareVersions("0.3.1", "0.3.2"), -1);
  });
  it("reads connections and dependencies", () => {
    assert.deepEqual(connectsOf({ connections: [{ plugin: "claude" }], dependencies: { notes: "^1" } }), [
      "claude",
      "notes",
    ]);
    assert.deepEqual(connectsOf(null), []);
  });
  it("thread ids and turn ends", () => {
    assert.equal(threadIdOf({ thread: { id: "t1" } }), "t1");
    assert.equal(threadIdOf({ thread: "t2" }), "t2");
    assert.equal(turnOver({ status: "done" }), true);
    assert.equal(turnOver({ status: "waiting" }), false);
    assert.equal(turnOver({ status: "interrupted", resuming: true }), false);
  });
});

describe("prompts", () => {
  it("a fix prompt says what changed, where, and what not to do", () => {
    const text = fixPrompt({
      problem: problem({
        key: "a/check/check",
        title: "Self-test fails",
        changed: true,
        commit: "bbbbbbbbb",
        okCommit: "aaaaaaaaa",
        okAt: T0 - HOUR,
        details: "x".repeat(9000),
      }),
      name: "Alpha",
      place: "changed",
      manifest: { check: "test/check.mjs", backend: { kind: "process" } },
      update: { plugin: "claude", from: "0.3.1", to: "0.3.2", at: T0 - HOUR },
      names: { claude: "Claude" },
    });
    assert.match(text, /git diff aaaaaaa bbbbbbb/);
    assert.match(text, /test\/check\.mjs/);
    assert.match(text, /updated from 0.3.1 to 0.3.2/);
    assert.match(text, /your copy of a store plugin/);
    assert.match(text, /\(cut, 1000 more characters\)/);
    assert.match(text, /Don't run git/);
  });
  it("a merge check prompt carries the output", () => {
    assert.match(
      mergeCheckPrompt({ name: "A", to: "2", output: "boom", file: "c.mjs" }),
      /boom[\s\S]*c\.mjs|c\.mjs[\s\S]*boom/,
    );
  });
});
