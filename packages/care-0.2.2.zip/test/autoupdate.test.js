// 0.2.0, against the fake core: the setting changedUpdates as every changed plugin's default, the per-plugin choice
// as true / false / null (follow the setting), updates applied by itself remembered as `autoUpdated/<id>` with a
// notification, and undo_update going back.
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { autoUpdateOf, ownAutoUpdate } from "../backend/logic.js";
import { repo, startedWorld } from "./fakes.js";

const changed = (patch = {}) => repo("notes", { kind: "changed", running: "mine", ...patch });
const plain = (patch = {}) => repo("pdf", { kind: "store", running: "version", ...patch });
const manifests = { "/plugins/notes": { id: "notes" }, "/plugins/pdf": { id: "pdf" } };

/** layr__plugin_update offers 1.1.0 (mine when the plugin runs your changes); using it moves the version. */
function offers(w, to = "1.1.0") {
  w.on("layr__plugin_update", (args) => {
    const r = w.repos.find((x) => x.id === args.plugin);
    if (args.apply === false)
      return { from: r.version, to, newPermissions: [], mine: r.running === "mine", conflicts: [], applied: false };
    const from = r.version;
    if (args.version) r.version = args.version;
    return { from, to: args.version, applied: true };
  });
}

describe("the choice of updating by itself", () => {
  it("is true, false, or null (follows the setting); stored booleans stay choices", () => {
    assert.equal(ownAutoUpdate({ a: { autoUpdate: true } }, "a"), true);
    assert.equal(ownAutoUpdate({ a: { autoUpdate: false } }, "a"), false);
    assert.equal(ownAutoUpdate({ a: { mode: "ask" } }, "a"), null);
    assert.equal(ownAutoUpdate({}, "a"), null);
    const of = (prefs, place, changedUpdates) => autoUpdateOf({ prefs, plugin: "a", place, changedUpdates });
    assert.equal(of({}, "changed", "auto"), true, "a changed plugin follows the setting");
    assert.equal(of({}, "changed", "ask"), false);
    assert.equal(of({}, "store", "ask"), true, "a plugin as it came follows autoUpdate (on by default)");
    const off = autoUpdateOf({ prefs: {}, plugin: "a", place: "store", changedUpdates: "auto", autoUpdate: false });
    assert.equal(off, false, "autoUpdate off: plugins as they came wait");
    assert.equal(of({ a: { autoUpdate: false } }, "changed", "auto"), false, "its own choice wins");
    assert.equal(of({ a: { autoUpdate: true } }, "store", "ask"), true);
    assert.equal(of({ a: { autoUpdate: true } }, "made", "auto"), false, "not from a store: never");
  });

  it("changedUpdates auto: a changed plugin updates by itself; ask: it doesn't", async () => {
    // autoUpdate off, so only the changed plugin's setting counts here.
    const settings = (changedUpdates) => ({ changedUpdates, autoUpdate: false });
    const auto = await startedWorld({ repos: [changed(), plain()], manifests, settings: settings("auto") });
    offers(auto);
    const results = await auto.care.updater.tick();
    assert.deepEqual(results.map((r) => [r.plugin, r.state]), [["notes", "updated"]]);
    const ask = await startedWorld({ repos: [changed(), plain()], manifests, settings: settings("ask") });
    offers(ask);
    assert.deepEqual(await ask.care.updater.tick(), []);
  });

  it("the setting is heard when it changes", async () => {
    const w = await startedWorld({ repos: [changed()], manifests });
    assert.equal((await w.care.overview()).plugins[0].autoUpdateOn, false);
    await w.care.heard("care:settings", { values: { changedUpdates: "auto" } });
    const [p] = (await w.care.overview()).plugins;
    assert.equal(p.autoUpdate, null);
    assert.equal(p.autoUpdateOn, true);
    assert.equal((await w.care.overview()).settings.changedUpdates, "auto");
  });

  it("set_auto_update takes true, false and null; its own choice wins over the setting", async () => {
    const w = await startedWorld({
      repos: [changed()],
      manifests,
      settings: { changedUpdates: "auto" },
      timing: { autoUpdateFirstMs: 60_000 },
    });
    assert.deepEqual(await w.care.setAutoUpdate("notes", false), {
      plugin: "notes",
      autoUpdate: false,
      autoUpdateOn: false,
    });
    offers(w);
    assert.deepEqual(await w.care.updater.tick(), [], "off by its own choice");
    assert.deepEqual(await w.care.setAutoUpdate("notes", null), {
      plugin: "notes",
      autoUpdate: null,
      autoUpdateOn: true,
    });
    assert.equal("autoUpdate" in w.store.data.prefs.notes, false, "null forgets the choice");
    w.care.stop();
  });
});

describe("updates applied by itself", () => {
  it("are remembered as autoUpdated/<id> and told, with your changes kept", async () => {
    const w = await startedWorld({ repos: [changed()], manifests, settings: { changedUpdates: "auto" } });
    offers(w);
    const [r] = await w.care.updater.tick();
    assert.equal(r.state, "updated");
    const record = w.store.data["autoUpdated/notes"];
    assert.deepEqual(record, { from: "1.0.0", to: "1.1.0", at: w.clock.t, mine: true });
    assert.equal(w.notes.at(-1).text, "Notes updated to 1.1.0 by itself, your changes kept. Undo on its page.");
    assert.deepEqual((await w.care.overview()).plugins[0].autoUpdated, record);
  });

  it("without your changes too (mine: false)", async () => {
    const w = await startedWorld({ repos: [plain()], manifests, data: { prefs: { pdf: { autoUpdate: true } } } });
    offers(w);
    await w.care.updater.tick();
    assert.equal(w.store.data["autoUpdated/pdf"].mine, false);
    assert.equal(w.notes.at(-1).text, "Pdf updated to 1.1.0 by itself. Undo on its page.");
  });

  it("not when asked for (Update now)", async () => {
    const w = await startedWorld({ repos: [changed()], manifests });
    offers(w);
    const r = await w.care.updater.update("notes", { manual: true });
    assert.equal(r.state, "updated");
    assert.equal(w.store.data["autoUpdated/notes"], undefined);
    assert.equal((await w.care.overview()).plugins[0].autoUpdated, null);
  });

  it("undo_update goes back to the version before with your changes, and not to that version again", async () => {
    const w = await startedWorld({ repos: [changed()], manifests, settings: { changedUpdates: "auto" } });
    offers(w);
    await w.care.updater.tick();
    const info = await w.care.undoUpdate("notes");
    assert.deepEqual(w.callsOf("layr__plugin_switch").at(-1), { plugin: "notes", version: "1.0.0", mine: true });
    assert.deepEqual(info, { id: "notes", version: "1.0.0" }, "the PluginInfo");
    assert.equal(w.store.data["autoUpdated/notes"], undefined);
    assert.equal(w.care.rt.autoUpdated.notes, undefined);
    assert.equal(w.care.rt.skip.notes, "1.1.0");
    assert.equal(w.care.rt.updates.at(-1).wentBack, true);
    const [again] = await w.care.updater.tick();
    assert.equal(again.state, "skipped");
    await assert.rejects(w.care.undoUpdate("notes"), /wasn't updated by itself/);
  });

  it("undo without your changes switches to the plain version", async () => {
    const w = await startedWorld({ repos: [plain()], manifests, data: { prefs: { pdf: { autoUpdate: true } } } });
    offers(w);
    await w.care.updater.tick();
    await w.care.undoUpdate("pdf");
    assert.deepEqual(w.callsOf("layr__plugin_switch").at(-1), { plugin: "pdf", version: "1.0.0" });
  });

  it("is forgotten when the version is changed by hand", async () => {
    const w = await startedWorld({ repos: [changed()], manifests, settings: { changedUpdates: "auto" } });
    offers(w);
    await w.care.updater.tick();
    w.repos[0].version = "1.2.0";
    await w.care.refreshRepos(true);
    await w.settle();
    assert.equal(w.care.rt.autoUpdated.notes, undefined);
    assert.equal(w.store.data["autoUpdated/notes"], undefined);
  });
});

describe("the overview for the plugin page", () => {
  it("has the budget, the merge state, the fix state and the go-back offer", async () => {
    const w = await startedWorld({ repos: [changed()], manifests, settings: { dailyFixes: 3 } });
    w.report({ key: "notes/self/list", changed: true, version: "1.1.0", okVersion: "1.0.0", running: "mine" });
    await w.settle();
    const d = await w.care.overview({ plugin: "notes" });
    assert.deepEqual(d.budget, { dailyFixes: 3, today: 0, left: 3 });
    const [p] = d.plugins;
    assert.equal(p.merge, null);
    assert.equal(p.changed, true);
    const [x] = p.problems;
    assert.equal(x.fixState, null);
    assert.equal(x.okVersion, "1.0.0");
    assert.equal(x.goBack.tool, "layr__plugin_switch");
    assert.deepEqual(x.goBack.args, { plugin: "notes", version: "1.0.0", mine: true });
    await w.care.fix("notes/self/list");
    await w.settle();
    assert.equal((await w.care.overview()).plugins[0].problems[0].fixState, "fixing");
  });
});
