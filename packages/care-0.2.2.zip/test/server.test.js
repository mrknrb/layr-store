// The backend as the core runs it: `node backend/server.js` over stdio (this test is its MCP client, as the core
// is), with a fake hub on a local port answering the core's and the claude plugin's tools from test/fakes.js. Checks
// the glue: its tools, events arriving as `notifications/layr/event`, and what it calls back. Needs `npm install`.
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { CallToolRequestSchema, isInitializeRequest, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import http from "node:http";
import path from "node:path";
import { after, before, describe, it } from "node:test";
import { fileURLToPath } from "node:url";
import { fakeWorld, repo } from "./fakes.js";

const pluginDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

/** The fake core's /mcp: every tool of the fake world, results as the core gives them. */
async function startHub(world) {
  const makeServer = () => {
    const server = new Server({ name: "layr-fake-hub", version: "0.0.1" }, { capabilities: { tools: {} } });
    server.setRequestHandler(ListToolsRequestSchema, async () => ({
      tools: world.toolNames().map((name) => ({ name, inputSchema: { type: "object" } })),
    }));
    server.setRequestHandler(CallToolRequestSchema, async (req) => {
      try {
        const value = await world.tool(req.params.name, req.params.arguments ?? {});
        const structured =
          value && typeof value === "object" && !Array.isArray(value) ? value : { result: value ?? null };
        return { content: [{ type: "text", text: JSON.stringify(value ?? null) }], structuredContent: structured };
      } catch (error) {
        return { content: [{ type: "text", text: error.message }], isError: true };
      }
    });
    return server;
  };
  const sessions = new Map();
  const httpServer = http.createServer(async (req, res) => {
    let body = "";
    for await (const chunk of req) body += chunk;
    const parsed = body ? JSON.parse(body) : undefined;
    const sid = req.headers["mcp-session-id"];
    let transport = sid ? sessions.get(sid) : undefined;
    if (!transport && req.method === "POST" && isInitializeRequest(parsed)) {
      transport = new StreamableHTTPServerTransport({
        sessionIdGenerator: () => randomUUID(),
        onsessioninitialized: (id) => sessions.set(id, transport),
      });
      await makeServer().connect(transport);
    }
    if (!transport) {
      res.writeHead(400).end();
      return;
    }
    await transport.handleRequest(req, res, parsed);
  });
  await new Promise((resolve) => httpServer.listen(0, "127.0.0.1", resolve));
  return {
    url: `http://127.0.0.1:${httpServer.address().port}/mcp`,
    close: () => {
      httpServer.closeAllConnections?.();
      return new Promise((resolve) => httpServer.close(resolve));
    },
  };
}

const waitFor = async (fn, ms = 10_000) => {
  const end = Date.now() + ms;
  for (;;) {
    const value = await fn();
    if (value) return value;
    if (Date.now() > end) throw new Error("timed out");
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
};

describe("the backend over stdio", () => {
  let world;
  let hub;
  let client;
  const logs = [];
  const call = async (name, args = {}) => {
    const r = await client.callTool({ name, arguments: args });
    if (r.isError) throw new Error(`${name}: ${r.content?.[0]?.text}`);
    return r.structuredContent ?? JSON.parse(r.content[0].text);
  };

  before(async () => {
    world = fakeWorld({
      repos: [repo("youtube")],
      manifests: {},
      // The core sends events to the backend: here this test's client does.
      deliver: (topic, data) => client.notification({ method: "notifications/layr/event", params: { topic, data } }),
    });
    hub = await startHub(world);
    const transport = new StdioClientTransport({
      command: process.execPath,
      args: [path.join(pluginDir, "backend", "server.js")],
      cwd: pluginDir,
      env: { ...process.env, LAYR_HUB_URL: hub.url, LAYR_HUB_TOKEN: "fake", LAYR_PLUGIN_ID: "care" },
      stderr: "pipe",
    });
    transport.stderr?.on("data", (d) => logs.push(String(d)));
    client = new Client({ name: "test", version: "1" });
    await client.connect(transport);
  });

  after(async () => {
    await client?.close();
    await hub?.close();
  });

  it("lists its tools and subscribes to the topics it needs", async () => {
    const { tools } = await client.listTools();
    assert.deepEqual(tools.map((t) => t.name).sort(), [
      "add_checks",
      "apply_update",
      "check_updates",
      "fix",
      "go_back",
      "ignore",
      "overview",
      "reopen",
      "set_auto_update",
      "set_mode",
      "undo_update",
      "update_now",
    ]);
    await call("overview");
    assert.deepEqual(
      world.callsOf("layr__events_subscribe").map((a) => a.topic),
      ["layr:problems", "layr:packages", "claude:threads"],
    );
  });

  it("hears a problem open, tells about it, and the panel's tools work on it", async () => {
    world.report({ key: "youtube/self/videos", title: "No videos found" });
    await waitFor(() => world.notes.length);
    assert.match(world.notes[0].text, /Youtube needs care: No videos found/);
    await waitFor(() => world.status.some((s) => s.text === "1 plugin needs care"));
    const o = await call("overview");
    assert.equal(o.plugins[0].problems[0].key, "youtube/self/videos");
    const fix = await call("fix", { key: "youtube/self/videos" });
    assert.equal(fix.link, "layr://claude/thread/t1");
    await waitFor(() => world.problems.get("youtube/self/videos").state === "fixing");
    // The turn ends (the event from the claude plugin): the commit is recorded.
    world.endTurn("t1", { commit: "c1" });
    await waitFor(() => world.problems.get("youtube/self/videos").fix?.commit === "c1");
    assert.equal(world.problems.get("youtube/self/videos").state, "fixed");
    await call("set_mode", { plugin: "youtube", mode: "auto" });
    assert.deepEqual(world.store.data.prefs, { youtube: { mode: "auto" } });
  });

  it("answers errors as tool errors", async () => {
    const r = await client.callTool({ name: "go_back", arguments: { key: "youtube/self/nothing" } });
    assert.equal(r.isError, true);
    assert.match(r.content[0].text, /No problem|no problem/);
    assert.ok(!logs.join("").includes("uncaught"), logs.join(""));
  });
});
