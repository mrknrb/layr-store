// A fake core and claude plugin for the tests: the hub tools Plugin care calls (layr__problems, layr__problem_get,
// layr__problem_set, the git tools, plugin_check, plugin_restart, extension logs, notify, status, data, settings,
// claude__thread_start / thread_status / project_add), the events the core would send back (`layr:problems` after
// every change, `claude:threads` when a turn ends), and a clock that `sleep` moves on. Not loaded in production.
import { Care } from "../backend/care.js";
import { memoryStore } from "../backend/store.js";

export const T0 = Date.parse("2026-11-17T10:00:00Z");
export const HOUR = 3_600_000;

export function problem(patch) {
  const [plugin, source, id] = patch.key.split("/");
  return {
    plugin,
    source,
    id,
    title: `${id} failed`,
    details: null,
    url: null,
    stack: null,
    version: "1.0.0",
    commit: null,
    running: "version",
    state: "open",
    verified: false,
    count: 2,
    streak: 2,
    firstAt: T0,
    lastAt: T0,
    okAt: null,
    okCommit: null,
    okVersion: null,
    changed: false,
    recurred: false,
    fixedAt: null,
    note: null,
    fix: null,
    ...patch,
  };
}

/**
 * `repos`: layr__plugin_repos' plugins (`{id, name, version, kind, path, running, insideRepo?}`); `manifests`: path →
 * layr.json; `settings`: the plugin's settings; `data`: its stored records.
 */
export function fakeWorld({ repos = [], manifests = {}, settings = {}, data = {}, timing = {}, deliver } = {}) {
  const clock = { t: T0 };
  const calls = [];
  const notes = [];
  const status = [];
  const problems = new Map();
  const outlines = new Map();
  const history = new Map(repos.map((r) => [r.id, [{ sha: `${r.id}-base`, subject: "v1" }]]));
  const threads = new Map();
  const handlers = {};
  const pending = new Set();
  let seq = 0;
  const store = memoryStore(data);

  const world = {
    clock,
    calls,
    notes,
    status,
    problems,
    threads,
    history,
    repos,
    manifests,
    store,
    settings: { dailyFixes: 5, defaultMode: "ask", ...settings },
    /** Replace a tool's fake (gets args, gives a result or throws). */
    on(name, fn) {
      handlers[name] = fn;
    },
    callsOf(name) {
      return calls.filter((c) => c.name === name).map((c) => c.args);
    },
    /** An event the core would send the backend. */
    emit(topic, payload) {
      const hear = deliver ?? ((t, d) => world.care.heard(t, d));
      const p = new Promise((resolve) => setImmediate(resolve)).then(() => hear(topic, payload));
      pending.add(p);
      p.finally(() => pending.delete(p));
    },
    /** Wait until every event and what it started is through. */
    async settle() {
      for (let i = 0; i < 50; i++) {
        await new Promise((resolve) => setImmediate(resolve));
        if (!pending.size) {
          await new Promise((resolve) => setImmediate(resolve));
          if (!pending.size) return;
        }
        await Promise.allSettled([...pending]);
      }
    },
    /** The core noticed a problem (a report): kept and told. */
    report(patch, { outline } = {}) {
      const prev = problems.get(patch.key);
      const p = prev ? { ...prev, ...patch } : problem(patch);
      problems.set(p.key, p);
      if (outline) outlines.set(p.key, outline);
      world.emit("layr:problems", { op: "changed", problem: p });
      return p;
    },
    /** A thread's turn ends: the claude plugin commits (`commit`), then the thread's status is told. */
    endTurn(thread, { status: st = "done", commit } = {}) {
      const t = threads.get(thread);
      t.status = st;
      if (commit && t.plugin) history.get(t.plugin).unshift({ sha: commit, subject: "Claude" });
      world.emit("claude:threads", { kind: "thread", thread: { id: thread, status: st } });
    },
  };

  const fakes = {
    layr__events_subscribe: ({ topic }) => ({ topics: [topic] }),
    layr__events_emit: () => null,
    layr__settings_get: () => world.settings,
    layr__data_get: ({ key }) => store.data[key] ?? null,
    layr__data_set: ({ key, value }) => ((store.data[key] = value), null),
    layr__data_delete: ({ key }) => (delete store.data[key], null),
    layr__notify: ({ text, kind }) => (notes.push({ text, kind }), null),
    layr__status_set: (item) => (status.push(item), null),
    layr__connections: () => ({ connections: [{ plugin: "claude", installed: true, state: "ok", usable: true }] }),
    layr__plugin_repos: () => ({ git: true, plugins: repos }),
    layr__problems: () => ({ problems: [...problems.values()].filter((p) => p.state !== "ok"), open: {} }),
    layr__problem_get: ({ key }) => {
      const p = problems.get(key);
      if (!p) throw new Error(`no problem ${key}`);
      return { ...p, outline: outlines.get(key) ?? null };
    },
    layr__problem_set: ({ key, ...patch }) => {
      const p = problems.get(key);
      if (!p) throw new Error(`no problem ${key}`);
      const next = { ...p };
      if ("state" in patch) {
        next.state = patch.state;
        if (patch.state === "fixed") {
          next.fixedAt = clock.t;
          next.verified = patch.verified ?? false;
          next.streak = 0;
        }
      }
      if ("verified" in patch) next.verified = patch.verified;
      if ("note" in patch) next.note = patch.note;
      if ("fix" in patch) next.fix = patch.fix;
      problems.set(key, next);
      world.emit("layr:problems", { op: "changed", problem: next });
      return next;
    },
    layr__plugin_history: ({ plugin }) => ({ commits: history.get(plugin) ?? [], more: false }),
    layr__plugin_undo: ({ plugin, commit }) => {
      const sha = `undo-${commit}`;
      history.get(plugin).unshift({ sha, subject: `Undo ${commit}` });
      return { commit: sha };
    },
    layr__plugin_restore: ({ plugin, commit }) => {
      const sha = `restore-${commit}`;
      history.get(plugin).unshift({ sha });
      return { commit: sha };
    },
    layr__plugin_switch: ({ plugin, version }) => {
      const r = repos.find((x) => x.id === plugin);
      if (r) r.version = version;
      return { id: plugin, version };
    },
    layr__plugin_update: ({ plugin, apply = true, version }) => {
      const r = repos.find((x) => x.id === plugin);
      if (apply === false)
        return {
          from: r.version,
          to: r.version,
          newPermissions: [],
          mine: false,
          merges: false,
          conflicts: [],
          applied: false,
        };
      if (r && version) r.version = version;
      return { from: r?.version, to: version, applied: true };
    },
    layr__plugin_check: () => ({ ran: false, ok: true, code: null, output: "", ms: 0 }),
    layr__plugin_restart: () => ({ status: "running" }),
    layr__plugins_list: () => ({ plugins: repos.map((r) => ({ id: r.id, status: "running" })) }),
    layr__extension_logs: () => ({
      entries: [{ seq: 1, level: "error", text: "TypeError: x is null", source: "content" }],
      connected: true,
    }),
    layr__extension_reload: () => null,
    layr__plugin_merge_help: ({ plugin, version }) => ({
      path: `/packages/${plugin}/merge`,
      branch: `merge/v${version}`,
      conflicts: [],
      prompt: "Resolve the conflicts.",
    }),
    claude__project_add: ({ path }) => ({ project: { id: `proj-${path}` } }),
    claude__thread_start: (args) => {
      const id = `t${++seq}`;
      threads.set(id, { id, args, plugin: args.target?.plugin ?? null, status: "running" });
      return { thread: { id, status: "starting" }, folder: "/f", pluginId: args.target?.plugin, place: "made" };
    },
    claude__thread_status: ({ thread }) => {
      const t = threads.get(thread);
      if (!t) throw new Error(`No thread ${thread}`);
      return { thread: { id: thread, status: t.status }, approvals: [] };
    },
  };

  /** A hub tool's fake answer (or its error). */
  world.tool = async (name, args = {}) => {
    calls.push({ name, args });
    const fn = handlers[name] ?? fakes[name];
    if (!fn) throw new Error(`fake hub: no tool ${name}`);
    return structuredClone(await fn(args));
  };
  world.toolNames = () => [...new Set([...Object.keys(fakes), ...Object.keys(handlers)])];

  const hub = {
    available: true,
    call: (name, args) => world.tool(name, args),
    quiet(name, args) {
      this.call(name, args).catch(() => {});
    },
  };

  world.hub = hub;
  world.care = new Care({
    hub,
    store,
    readManifest: (folder) => manifests[folder] ?? null,
    now: () => clock.t,
    sleep: async (ms) => {
      clock.t += ms;
    },
    timing,
  });
  return world;
}

/** A started world: care has read everything. */
export async function startedWorld(options) {
  const world = fakeWorld(options);
  await world.care.start();
  await world.settle();
  return world;
}

export const repo = (id, patch = {}) => ({
  id,
  name: id.charAt(0).toUpperCase() + id.slice(1),
  version: "1.0.0",
  kind: "made",
  path: `/plugins/${id}`,
  linked: true,
  running: "folder",
  ...patch,
});
