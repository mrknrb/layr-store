// The backend's link to the core's MCP hub (docs/ARCHITECTURE.md › The MCP hub): the core's web view tools
// (layr__webview_*) and notifications.
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

export class Hub {
  constructor({ url, token }) {
    this.url = url;
    this.token = token;
    this.client = null;
    this.connecting = null;
  }

  get available() {
    return Boolean(this.url && this.token);
  }

  async connect() {
    if (this.client) return this.client;
    if (!this.available) throw new Error("No hub: LAYR_HUB_URL and LAYR_HUB_TOKEN are not set");
    this.connecting ??= (async () => {
      const client = new Client({ name: "layr-plugin-scraper", version: "0.1.0" });
      const transport = new StreamableHTTPClientTransport(new URL(this.url), {
        requestInit: { headers: { Authorization: `Bearer ${this.token}` } },
      });
      client.onclose = () => {
        if (this.client === client) this.client = null;
      };
      await client.connect(transport);
      this.client = client;
      return client;
    })().finally(() => (this.connecting = null));
    return this.connecting;
  }

  /** Calls a hub tool; gives its structured content (a plain value comes as `{result}` there). Throws its error. */
  async call(name, args = {}, { timeoutMs = 130_000 } = {}) {
    const options = { timeout: timeoutMs };
    let client = await this.connect();
    let result;
    try {
      result = await client.callTool({ name, arguments: args }, undefined, options);
    } catch (error) {
      if (/timed out|timeout/i.test(String(error?.message ?? error))) throw error;
      // The core may have restarted its HTTP session: connect once more.
      this.client = null;
      client = await this.connect();
      result = await client.callTool({ name, arguments: args }, undefined, options);
    }
    if (result.isError) {
      const text = (result.content ?? []).map((c) => c.text ?? "").join("\n");
      throw new Error(text || `${name} failed`);
    }
    const s = result.structuredContent;
    if (s && typeof s === "object" && Object.keys(s).length === 1 && "result" in s) return s.result;
    if (s !== undefined) return s;
    const text = (result.content ?? []).filter((c) => c.type === "text").map((c) => c.text).join("\n");
    try {
      return JSON.parse(text);
    } catch {
      return text;
    }
  }

  async close() {
    try {
      await this.client?.close();
    } catch {
      // closing anyway
    }
  }
}
