// What runs inside a scraped page: `window.__layrScrape`, installed once per document by the backend (through
// layr__webview_eval) and called with one expression per tool. It reads the page (text, Markdown through Mozilla's
// Readability and Turndown when they were added, links, fields by CSS selector) and finds, clicks and types into
// elements. It never leaves the page: the core and the shell decide which pages a web view may be on.
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";

/** Bumped when the kit changes, so a page holding an older one gets the new one. */
export const KIT_VERSION = 6;

/** Installs `window.__layrScrape` (a function stringified into the page: no closures over this module). */
function pageKit(version) {
  if (window.__layrScrape && window.__layrScrape.v === version) return true;
  const els = new Map();
  let nextRef = 1;
  const clean = (t) => String(t ?? "").replace(/\s+/g, " ").trim();
  const lines = (t) => String(t ?? "").replace(/[ \t ]+/g, " ").replace(/ *\n */g, "\n").replace(/\n{3,}/g, "\n\n")
    .trim();
  const abs = (u) => {
    try {
      return new URL(u, location.href).href;
    } catch {
      return u;
    }
  };
  const cut = (s, max) => {
    const n = Math.max(1, max || 20000);
    return s.length > n ? { content: s.slice(0, n), chars: s.length, truncated: true }
      : { content: s, chars: s.length, truncated: false };
  };
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    const s = getComputedStyle(el);
    return s.visibility !== "hidden" && s.display !== "none" && Number(s.opacity) > 0;
  };
  const root = (selector) => {
    if (!selector) return document.body || document.documentElement;
    const el = document.querySelector(selector);
    if (!el) throw new Error(`nothing on the page matches ${selector}`);
    return el;
  };
  const ref = (el) => {
    for (const [k, w] of els) if (w.deref() === el) return k;
    const k = String(nextRef++);
    els.set(k, new WeakRef(el));
    return k;
  };
  const label = (el) => clean(el.innerText || el.value || el.getAttribute("aria-label") || el.getAttribute("placeholder")
    || el.getAttribute("title") || el.getAttribute("alt") || "");
  const describe = (el) => {
    const d = { ref: ref(el), tag: el.tagName.toLowerCase(), text: label(el).slice(0, 160), visible: visible(el) };
    const role = el.getAttribute("role");
    if (role) d.role = role;
    if (el.tagName === "A" && el.getAttribute("href")) d.url = abs(el.getAttribute("href"));
    if (el.tagName === "INPUT") d.type = el.type;
    if (el.name) d.name = el.name;
    return d;
  };
  const CLICKABLE = "a[href],button,input:not([type=hidden]),select,textarea,summary,label,[role=button],[role=link]," +
    "[role=tab],[role=menuitem],[role=option],[role=checkbox],[role=switch],[onclick],[contenteditable=true]";
  const textMatch = (el, text) => {
    const want = clean(text).toLowerCase();
    const have = label(el).toLowerCase();
    return have === want ? 2 : have.includes(want) ? 1 : 0;
  };
  const pick = (t) => {
    if (t && t.ref != null) {
      const el = els.get(String(t.ref))?.deref();
      if (el && el.isConnected) return el;
      throw new Error(`element ${t.ref} is gone (the page changed): find it again`);
    }
    if (t && t.selector) return root(t.selector);
    if (t && t.text) {
      let best = null;
      let score = 0;
      for (const el of document.querySelectorAll(CLICKABLE)) {
        const m = textMatch(el, t.text);
        if (!m) continue;
        const s = m * 2 + (visible(el) ? 1 : 0);
        if (s > score) {
          best = el;
          score = s;
        }
      }
      if (best) return best;
      throw new Error(`nothing clickable says “${t.text}”`);
    }
    throw new Error("give ref (from find), selector or text");
  };
  /** A field spec: "selector", "selector@attr", "@attr" or "" (the item's own text). */
  const field = (el, spec) => {
    const all = Array.isArray(spec);
    const s = String(all ? spec[0] ?? "" : spec ?? "");
    const m = /^(.*?)(?:@([a-zA-Z_:][\w:.-]*))?$/.exec(s.trim());
    const sel = (m?.[1] ?? "").trim();
    const attr = m?.[2] ?? "text";
    const value = (t) => {
      if (attr === "text") return clean(t.innerText ?? t.textContent);
      if (attr === "html") return t.innerHTML;
      if (attr === "href" || attr === "src") return t.getAttribute(attr) == null ? null : abs(t.getAttribute(attr));
      if (attr === "value") return t.value ?? t.getAttribute("value");
      return t.getAttribute(attr);
    };
    if (all) return [...(sel ? el.querySelectorAll(sel) : [el])].map(value);
    const t = sel ? el.querySelector(sel) : el;
    return t ? value(t) : null;
  };
  /** The element that scrolls the page: the document, else the biggest scrolling box (apps that scroll a pane). */
  const scroller = () => {
    const doc = document.scrollingElement || document.documentElement;
    if (doc.scrollHeight > innerHeight + 4) return doc;
    let best = doc;
    let size = 0;
    for (const el of document.querySelectorAll("body *")) {
      if (el.scrollHeight <= el.clientHeight + 4) continue;
      const o = getComputedStyle(el).overflowY;
      if (o !== "auto" && o !== "scroll") continue;
      const a = el.clientWidth * el.clientHeight;
      if (a > size) {
        best = el;
        size = a;
      }
    }
    return best;
  };
  const api = {
    v: version,
    /** What the user selected in the page (in their own tabs), cut short; undefined when nothing is. */
    selected() {
      const sel = clean(String(window.getSelection?.() ?? ""));
      return sel ? sel.slice(0, 5000) : undefined;
    },
    info() {
      const s = scroller();
      return { url: location.href, title: document.title, ready: document.readyState, height: s.scrollHeight,
        y: Math.round(s.scrollTop), size: document.body ? document.body.innerText.length : 0 };
    },
    exists(selector, text, gone) {
      let found;
      if (selector) {
        const el = document.querySelector(selector);
        found = !!el && (!text || clean(el.innerText).toLowerCase().includes(clean(text).toLowerCase()));
      } else if (text) {
        found = clean(document.body?.innerText).toLowerCase().includes(clean(text).toLowerCase());
      } else {
        found = document.readyState === "complete";
      }
      return gone ? !found : found;
    },
    text(selector, max) {
      return { ...cut(lines(root(selector).innerText), max), url: location.href, title: document.title,
        selected: api.selected() };
    },
    html(selector, max) {
      return { ...cut(root(selector).outerHTML, max), url: location.href, title: document.title };
    },
    markdown(selector, main, max) {
      let html = null;
      let title = document.title;
      let byline = null;
      let excerpt = null;
      if (main && !selector && window.__layrReadability) {
        try {
          const article = new window.__layrReadability(document.cloneNode(true), { charThreshold: 200 }).parse();
          if (article && article.content) {
            html = article.content;
            title = article.title || title;
            byline = article.byline || null;
            excerpt = article.excerpt || null;
          }
        } catch {
          // Not an article: the whole page below.
        }
      }
      let md = null;
      if (window.__layrTurndown) {
        try {
          const td = new window.__layrTurndown({ headingStyle: "atx", codeBlockStyle: "fenced", bulletListMarker: "-" });
          td.remove(["script", "style", "noscript", "iframe", "svg", "canvas", "template"]);
          md = td.turndown(html ?? root(selector).cloneNode(true));
        } catch {
          md = null; // A page that forbids building HTML from text (Trusted Types): plain text below.
        }
      }
      if (md == null) md = lines(root(selector).innerText);
      // Readability keeps the article's heading apart: it leads the Markdown again.
      if (html != null && title && !md.trimStart().startsWith("#")) md = `# ${clean(title)}

${md}`;
      return { ...cut(md.replace(/\n{3,}/g, "\n\n").trim(), max), url: location.href, title, byline, excerpt,
        main: html != null, selected: api.selected() };
    },
    links(selector, match, limit) {
      const seen = new Set();
      const out = [];
      let re = null;
      // "/…/flags" with regex characters inside is a regex; "/p/" is just a piece of address.
      if (match && /^\/.+\/[a-z]*$/.test(match) && /[\^$.*+?()[\]{}|]/.test(match.slice(1, match.lastIndexOf("/")))) {
        const i = match.lastIndexOf("/");
        re = new RegExp(match.slice(1, i), match.slice(i + 1));
      }
      for (const a of root(selector).querySelectorAll("a[href]")) {
        const url = abs(a.getAttribute("href"));
        if (!/^https?:/.test(url) || seen.has(url)) continue;
        const text = label(a).slice(0, 200);
        if (match && !(re ? re.test(url) || re.test(text)
          : (url + " " + text).toLowerCase().includes(String(match).toLowerCase()))) continue;
        seen.add(url);
        out.push({ text, url });
        if (out.length >= (limit || 200)) break;
      }
      return { links: out, url: location.href, title: document.title };
    },
    extract(items, fields, limit) {
      const roots = items ? [...document.querySelectorAll(items)] : [document.documentElement];
      const rows = roots.slice(0, limit || 100).map((el) => {
        const row = {};
        for (const [name, spec] of Object.entries(fields || {})) row[name] = field(el, spec);
        return row;
      });
      return { rows, count: roots.length, url: location.href, title: document.title };
    },
    find(text, selector, limit) {
      const out = [];
      const pool = document.querySelectorAll(selector || CLICKABLE + ",h1,h2,h3");
      const hits = [];
      for (const el of pool) {
        const m = text ? textMatch(el, text) : 1;
        if (m) hits.push([m * 2 + (visible(el) ? 1 : 0), el]);
      }
      hits.sort((a, b) => b[0] - a[0]);
      for (const [, el] of hits.slice(0, limit || 20)) out.push(describe(el));
      return { elements: out, count: hits.length };
    },
    /** Scrolls the element into view and gives its middle, for a real click. */
    point(t) {
      const el = pick(t);
      el.scrollIntoView({ block: "center", inline: "center" });
      const r = el.getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + r.height / 2, ...describe(el) };
    },
    click(t) {
      const el = pick(t);
      el.scrollIntoView({ block: "center", inline: "center" });
      el.click();
      return describe(el);
    },
    focus(t, clear) {
      const el = pick(t);
      if (el.type === "password") throw new Error("password fields aren't typed into");
      el.scrollIntoView({ block: "center" });
      el.focus();
      if (clear && "value" in el) {
        const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        Object.getOwnPropertyDescriptor(proto, "value")?.set?.call(el, "");
        el.dispatchEvent(new Event("input", { bubbles: true }));
      } else if (clear && el.isContentEditable) {
        el.textContent = "";
      }
      return describe(el);
    },
    type(t, value, clear) {
      const el = pick(t);
      if (el.type === "password") throw new Error("password fields aren't typed into");
      el.focus();
      if ("value" in el && !el.isContentEditable) {
        const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype
          : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
        const next = clear === false ? String(el.value) + value : value;
        Object.getOwnPropertyDescriptor(proto, "value")?.set?.call(el, next);
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } else {
        if (clear !== false) el.textContent = "";
        document.execCommand("insertText", false, value);
      }
      return describe(el);
    },
    submit(t) {
      const el = pick(t);
      const form = el.form || el.closest("form");
      if (form) {
        if (form.requestSubmit) form.requestSubmit();
        else form.submit();
        return true;
      }
      for (const type of ["keydown", "keypress", "keyup"]) {
        el.dispatchEvent(new KeyboardEvent(type, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
      }
      return false;
    },
    /** Scrolls an element into the middle of the view. */
    reveal(t) {
      pick(t).scrollIntoView({ block: "center", inline: "center" });
      return api.info();
    },
    scroll(to) {
      const s = scroller();
      const top = to === "top" ? 0 : to === "bottom" ? s.scrollHeight : typeof to === "number" ? to
        : to === "up" ? s.scrollTop - innerHeight * 0.9 : s.scrollTop + innerHeight * 0.9;
      s.scrollTo({ top, behavior: "instant" });
      if (s !== document.scrollingElement && (to === "top" || to === "bottom")) {
        window.scrollTo({ top: to === "top" ? 0 : document.body.scrollHeight });
      }
      return api.info();
    },
  };
  window.__layrScrape = api;
  return true;
}

/** The script that installs the kit. */
export const KIT_SOURCE = `(${pageKit.toString()})(${KIT_VERSION})`;

const require = createRequire(import.meta.url);

/**
 * The script that adds Readability (Apache-2.0) and Turndown (MIT) to the page as `__layrReadability` and
 * `__layrTurndown`, each in its own scope (the page's own globals stay as they were).
 */
export function readerSource() {
  const wrap = (file, name) =>
    `(function(){var module={exports:{}},exports=module.exports,define=undefined;\n${readFileSync(file, "utf8")}\n` +
    `;window.${name}=module.exports;})();`;
  return [
    wrap(require.resolve("@mozilla/readability/Readability.js"), "__layrReadability"),
    wrap(require.resolve("turndown/lib/turndown.browser.umd.js"), "__layrTurndown"),
    "true",
  ].join("\n");
}
