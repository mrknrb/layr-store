// The Web tools panel: try the plugin's tools by hand. Open a page (hidden or beside your tabs), pick one of its web
// views or one of the pages open in your tabs, and read it, list its links, extract fields or take a picture.
// Everything goes through the plugin's own tools (scraper__*), the same ones agents and other plugins call.
import "/_layr/layr.js";
const layr = window.layr;

const $ = (id) => document.getElementById(id);
let views = [];
let pages = [];
let selected = null;
let lastText = "";

const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

/** Calls one of the scraper's tools; gives its structured result, or `{image, mimeType}` for a picture. */
async function tool(name, args) {
  const r = await layr.tools.call(name, args);
  if (r?.isError) throw new Error((r.content ?? []).map((c) => c.text ?? "").join("\n") || `${name} failed`);
  const img = (r?.content ?? []).find((c) => c.type === "image");
  if (img) return { image: img.data, mimeType: img.mimeType };
  return r?.structuredContent ?? r;
}

function show(text, { error = false } = {}) {
  const out = $("out");
  out.className = `out${error ? " error" : ""}`;
  out.textContent = text;
  lastText = error ? "" : text;
  $("copy").hidden = !lastText;
}

function busy(on, what) {
  for (const b of document.querySelectorAll("button")) b.disabled = on;
  if (on) show(`${what}…`);
}

async function run(what, fn) {
  busy(true, what);
  try {
    await fn();
  } catch (e) {
    show(String(e?.message ?? e), { error: true });
  } finally {
    busy(false);
  }
}

async function refresh() {
  const [v, p] = await Promise.allSettled([tool("views", {}), tool("pages", {})]);
  views = v.status === "fulfilled" ? (v.value.views ?? []) : [];
  // Its own web views in tabs are listed above already.
  pages = p.status === "fulfilled" ? (p.value.pages ?? []).filter((x) => !x.mine) : [];
  const failed = [v, p].find((r) => r.status === "rejected");
  if (failed) show(String(failed.reason?.message ?? failed.reason), { error: true });
  if (selected && !views.some((x) => x.view === selected) && !pages.some((x) => x.view === selected)) selected = null;
  render();
}

const item = (v, badge, cls = "") => `<li data-view="${esc(v.view)}" class="${v.view === selected ? "sel" : ""}">
  <span class="t"><b>${esc(v.title || "Web page")}</b><small>${esc(v.url)}</small></span>
  <span class="badge ${cls}">${esc(badge)}</span></li>`;

function render() {
  $("views").innerHTML = views.map((v) => item(v, v.hidden ? "hidden" : "in a tab", v.hidden ? "hidden" : "")).join("");
  $("noViews").hidden = views.length > 0;
  $("pages").innerHTML = pages.map((p) => item(p, p.visible ? "showing" : "your tab")).join("");
  $("noPages").hidden = pages.length > 0;
  const own = views.find((x) => x.view === selected);
  const v = own ?? pages.find((x) => x.view === selected);
  $("actions").hidden = !v;
  for (const b of document.querySelectorAll("#actions .own")) b.hidden = !own;
  if (v) $("selTitle").textContent = v.title || v.url;
}

for (const list of ["views", "pages"]) {
  $(list).addEventListener("click", (e) => {
    const li = e.target.closest("li[data-view]");
    if (!li) return;
    selected = li.dataset.view;
    render();
  });
}

$("openForm").addEventListener("submit", (e) => {
  e.preventDefault();
  let url = $("url").value.trim();
  if (!url) return;
  if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
  void run("Opening", async () => {
    const r = await tool("open", { url, show: $("show").value });
    selected = r.view;
    show(JSON.stringify(r, null, 2));
    await refresh();
  });
});

$("refresh").addEventListener("click", () => void refresh());
// Your tabs change while you are elsewhere: the lists follow when you come back.
window.addEventListener("focus", () => void refresh());

$("copy").addEventListener("click", () => {
  if (lastText) void navigator.clipboard?.writeText(lastText);
});

document.querySelector("#actions").addEventListener("click", (e) => {
  const b = e.target.closest("button[data-act]");
  if (!b || !selected) return;
  const view = selected;
  const act = b.dataset.act;
  void run(b.textContent, async () => {
    switch (act) {
      case "markdown":
      case "text": {
        const r = await tool("read", { view, format: act });
        const cut = r.truncated ? `(first ${r.content.length} of ${r.chars} characters)\n` : "";
        show(`# ${r.title ?? ""}\n${r.url ?? ""}\n${cut}\n${r.content}`);
        break;
      }
      case "links": {
        const r = await tool("links", { view });
        show(r.links.map((l) => `${l.text || "(no text)"}\n  ${l.url}`).join("\n") || "No links.");
        break;
      }
      case "extract": {
        let fields;
        try {
          fields = JSON.parse($("fields").value);
        } catch {
          throw new Error('Fields are JSON: {"name": "css selector", "link": "a@href"}');
        }
        const items = $("items").value.trim() || undefined;
        const r = await tool("extract", { view, items, fields });
        show(`${r.count} item(s), ${r.rows.length} shown\n\n${JSON.stringify(r.rows, null, 2)}`);
        break;
      }
      case "screenshot": {
        const r = await tool("screenshot", { view });
        const out = $("out");
        out.className = "out";
        out.innerHTML = `<img alt="The page" src="data:${esc(r.mimeType)};base64,${esc(r.image)}">`;
        lastText = "";
        $("copy").hidden = true;
        break;
      }
      case "show":
      case "hide":
        show(JSON.stringify(await tool(act, { view }), null, 2));
        await refresh();
        break;
      case "close":
        await tool("close", { view });
        selected = null;
        show("Closed.");
        await refresh();
        break;
    }
  });
});

await layr.ready;
// Its web views opened, hidden, shown or closed (by anyone): the lists follow.
layr.events.on("layr:webviews", () => void refresh());
const s = await layr.settings.get().catch(() => null);
if (s?.show) $("show").value = s.show;
await refresh();
