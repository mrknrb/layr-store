// The scraper end to end, without the Flutter app: `layr serve` with the plugin linked, a stand-in for the shell that
// hosts the web views (`webviews.host`) in Chromium through Playwright, answering the core's `webviews.run` requests
// the way the app does with WebView2 (scripts through the DevTools protocol's Runtime.evaluate, other DevTools calls
// passed on), a local test site, and the scraper's tools called through the core as agents and plugins call them.
//   PLAYWRIGHT_DIR=plugins/dev node plugins/scraper/test/scraper.e2e.mjs
// LAYR_EXE: the layr binary (default core/target/debug/layr[.exe]); CHROMIUM_PATH: a Chrome or Edge to use.
import { spawn } from "node:child_process";
import { mkdtempSync } from "node:fs";
import http from "node:http";
import { createRequire } from "node:module";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const pluginDir = path.resolve(here, "..");
const repo = path.resolve(pluginDir, "..", "..");
const exe = process.env.LAYR_EXE || path.join(repo, "core", "target", "debug", process.platform === "win32" ? "layr.exe" : "layr");
const require = createRequire(path.resolve(process.env.PLAYWRIGHT_DIR || path.join(repo, "plugins", "dev"), "package.json"));
const { chromium } = require("playwright");

let failures = 0;
const check = (ok, what, detail) => {
  const d = detail === undefined ? "" : ` — ${typeof detail === "string" ? detail : JSON.stringify(detail).slice(0, 400)}`;
  console.log(`${ok ? "PASS" : "FAIL"} ${what}${d}`);
  if (!ok) failures++;
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- a test site ----------
const page = (title, body, script = "") =>
  `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title></head><body>${body}` +
  `${script ? `<script>${script}</script>` : ""}</body></html>`;
const para = (n) => Array.from({ length: n }, (_, i) =>
  `<p>Apples stay crisp because their cells hold water under pressure; paragraph ${i + 1} explains how cold storage ` +
  "slows the softening of the cell walls, why some kinds keep for months, and what a grower can do about it.</p>").join("");
const site = http.createServer((req, res) => {
  const u = new URL(req.url, "http://x");
  res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
  switch (u.pathname) {
    case "/article":
      return res.end(page("Why apples are crisp", `<nav><a href="/">Home</a> <a href="/about">About</a></nav>
        <article><h1>Why apples are crisp</h1>${para(6)}<p>More in <a href="/products">our products</a>.</p></article>
        <footer>Copyright 2026, the orchard</footer>`));
    case "/products":
      return res.end(page("Products", `<h1>Products</h1>
        ${["Gala", "Fuji", "Jonagold"].map((n, i) => `<div class="product"><h2>${n}</h2><span class="price">€${i + 2}.50</span>
          <a href="/p/${i + 1}">Details</a><img src="/img/${i + 1}.png" alt="${n}"></div>`).join("")}
        <a href="https://elsewhere.example/">Elsewhere</a>`));
    case "/form":
      return res.end(page("Form", `<form action="/search"><input name="q" id="q" placeholder="Search apples">
        <button type="submit">Search</button></form>
        <button id="press" onclick="this.textContent = 'Clicked ' + (event.isTrusted ? 'by a mouse' : 'by a script')">Press me</button>
        <input type="password" id="pw">`));
    case "/search":
      return res.end(page(`Results for ${u.searchParams.get("q")}`, `<h1>Results for ${u.searchParams.get("q")}</h1>`));
    case "/late":
      return res.end(page("Late", "<h1>Waiting</h1>",
        "setTimeout(() => { const d = document.createElement('div'); d.id = 'late'; d.textContent = 'Here now'; " +
        "document.body.append(d); }, 900);"));
    case "/feed":
      return res.end(page("Feed", '<ul id="feed"></ul>', `
        let n = 0; const feed = document.getElementById('feed');
        function more() { for (let i = 0; i < 20 && n < 100; i++) { const li = document.createElement('li');
          li.style.height = '60px'; li.textContent = 'Item ' + (++n); feed.append(li); } }
        more(); addEventListener('scroll', () => { if (innerHeight + scrollY > document.body.scrollHeight - 200)
          setTimeout(more, 100); });`));
    default:
      return res.end(page("Home", "<h1>Home</h1>"));
  }
});
await new Promise((r) => site.listen(0, "127.0.0.1", r));
const base = `http://127.0.0.1:${site.address().port}`;

// ---------- the core ----------
const tmp = mkdtempSync(path.join(os.tmpdir(), "layr-scraper-"));
const port = 4300 + Math.floor(Math.random() * 500) + 300;
const core = spawn(exe, ["serve", "--port", String(port), "--token", "shell", "--home", path.join(tmp, "home"),
  "--link", pluginDir, "--link", path.join(repo, "plugins", "browser")], { stdio: ["ignore", "pipe", "pipe"] });
let coreLog = "";
core.stdout.on("data", (d) => (coreLog += d));
core.stderr.on("data", (d) => (coreLog += d));

// ---------- the stand-in shell: hosts web views in Chromium ----------
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const views = new Map(); // view → {page, cdp}
const tabs = new Map(); // the user's web pages in tabs: instance → {page, cdp, focusedAt}
const events = [];
let ws;
let nextId = 1;
const waiting = new Map();

async function connect() {
  for (let i = 0; i < 100; i++) {
    try {
      ws = await new Promise((resolve, reject) => {
        const s = new WebSocket(`ws://127.0.0.1:${port}/_layr/ws?token=shell`);
        s.onopen = () => resolve(s);
        s.onerror = () => reject(new Error("no core yet"));
      });
      break;
    } catch {
      await sleep(150);
    }
  }
  if (!ws) throw new Error(`the core didn't start:\n${coreLog}`);
  ws.onmessage = (m) => {
    const msg = JSON.parse(m.data);
    if (msg.method === "event") {
      events.push(msg.params);
      const d = msg.params.data ?? {};
      if ((msg.params.topic === "layr:webviews" && d.op === "closed") || msg.params.topic === "shell:close") {
        const v = views.get(d.view ?? d.instance);
        views.delete(d.view ?? d.instance);
        void v?.page.close().catch(() => {});
      }
    } else if (msg.method) {
      void answer(msg);
    } else if (waiting.has(msg.id)) {
      const w = waiting.get(msg.id);
      waiting.delete(msg.id);
      msg.error ? w.reject(Object.assign(new Error(msg.error.message), { code: msg.error.code })) : w.resolve(msg.result);
    }
  };
}

/** A second connection with another token (a plugin's panel): `{call, close}`. */
async function connectAs(token) {
  const s = await new Promise((resolve, reject) => {
    const c = new WebSocket(`ws://127.0.0.1:${port}/_layr/ws?token=${token}`);
    c.onopen = () => resolve(c);
    c.onerror = () => reject(new Error("couldn't connect as a panel"));
  });
  const pending = new Map();
  let n = 1;
  s.onmessage = (m) => {
    const msg = JSON.parse(m.data);
    const w = msg.id != null && !msg.method ? pending.get(msg.id) : null;
    if (!w) return;
    pending.delete(msg.id);
    msg.error ? w.reject(new Error(msg.error.message)) : w.resolve(msg.result);
  };
  return {
    call(method, params = {}) {
      const id = n++;
      s.send(JSON.stringify({ jsonrpc: "2.0", id, method, params }));
      return new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
    },
    close: () => s.close(),
  };
}

function call(method, params = {}) {
  const id = nextId++;
  ws.send(JSON.stringify({ jsonrpc: "2.0", id, method, params }));
  return new Promise((resolve, reject) => waiting.set(id, { resolve, reject }));
}

const guarded = (url, ports) => {
  try {
    const u = new URL(url);
    if (u.hostname.endsWith(".localhost")) return true;
    const loop = u.hostname === "localhost" || u.hostname.startsWith("127.") || u.hostname === "[::1]";
    return loop && ports.includes(Number(u.port || (u.protocol === "https:" ? 443 : 80)));
  } catch {
    return false;
  }
};

async function answer(msg) {
  try {
    if (msg.method !== "webviews.run") throw Object.assign(new Error(`no ${msg.method}`), { code: -32601 });
    const p = msg.params;
    if (p.op === "pages") {
      const pages = [];
      for (const [view, t] of tabs) {
        pages.push({ view, url: t.page.url(), title: await t.page.title(), visible: true, focusedAt: t.focusedAt });
      }
      ws.send(JSON.stringify({ jsonrpc: "2.0", id: msg.id, result: { pages } }));
      return;
    }
    // One of the user's pages: only while it is open here, never made.
    let v = p.page ? tabs.get(p.view) : views.get(p.view);
    if (!v && p.page) throw Object.assign(new Error("that page isn't open in a tab here"), { code: -32002 });
    if (!v) {
      const pg = await context.newPage();
      v = { page: pg, cdp: await context.newCDPSession(pg) };
      views.set(p.view, v);
      if (p.op !== "open" && p.at) await pg.goto(p.at, { waitUntil: "load" });
    }
    const info = (loaded = true) => ({ url: v.page.url(), loaded, error: null });
    const withTitle = async (o) => ({ ...o, title: await v.page.title() });
    let result;
    switch (p.op) {
      case "open":
      case "navigate":
        await v.page.goto(p.url, { waitUntil: "load", timeout: p.timeout });
        result = await withTitle(info());
        break;
      case "back":
        await v.page.goBack({ waitUntil: "load" });
        result = await withTitle(info());
        break;
      case "reload":
        await v.page.reload({ waitUntil: "load" });
        result = await withTitle(info());
        break;
      case "info":
        result = await withTitle(info());
        break;
      case "eval": {
        if (guarded(v.page.url(), p.guard)) throw Object.assign(new Error("layr's own page"), { code: -32001 });
        const r = await v.cdp.send("Runtime.evaluate", { expression: p.script, awaitPromise: true, returnByValue: true,
          userGesture: true, replMode: true });
        if (r.exceptionDetails) {
          const e = r.exceptionDetails.exception;
          throw new Error(String(e?.description ?? e?.value ?? r.exceptionDetails.text).split("\n")[0]);
        }
        result = { value: r.result?.value ?? null };
        break;
      }
      case "cdp":
        if (guarded(v.page.url(), p.guard)) throw Object.assign(new Error("layr's own page"), { code: -32001 });
        result = await v.cdp.send(p.method, p.params ?? {});
        break;
      default:
        throw Object.assign(new Error(`unknown op ${p.op}`), { code: -32601 });
    }
    ws.send(JSON.stringify({ jsonrpc: "2.0", id: msg.id, result }));
  } catch (e) {
    ws.send(JSON.stringify({ jsonrpc: "2.0", id: msg.id, error: { code: e.code ?? -32000, message: String(e.message) } }));
  }
}

/** A scraper tool through the core (the shell's tools.call); gives its structured result or its image. */
async function tool(name, args = {}) {
  const r = await call("tools.call", { plugin: "scraper", tool: name, args });
  if (r?.isError) throw new Error(r.content?.map((c) => c.text).join("\n"));
  const img = r?.content?.find((c) => c.type === "image");
  return img ? img : r.structuredContent;
}

async function refused(what, fn, re) {
  try {
    const r = await fn();
    check(false, what, r);
  } catch (e) {
    check(re.test(String(e.message)), what, String(e.message));
  }
}

try {
  await connect();
  await call("webviews.host");

  // Open hidden: the core lists it as hidden, in no session.
  const opened = await tool("open", { url: `${base}/article` });
  check(opened.view && opened.hidden === true && opened.loaded === true, "open: a hidden web view, loaded", opened);
  check(opened.title === "Why apples are crisp", "open gives the page's title", opened.title);
  const listed = await call("webviews.list");
  check(listed.some((v) => v.view === opened.view && v.hidden && v.plugin === "scraper"), "the shell sees it hidden", listed);
  const view = opened.view;

  // Read: the article as Markdown (Readability + Turndown), without the menu and footer.
  const md = await tool("read", { view });
  check(md.main === true && /^# Why apples are crisp|Why apples are crisp/.test(md.content), "read: the article's Markdown", md.content.slice(0, 120));
  check(md.content.includes("cold storage") && !md.content.includes("Copyright 2026"), "read: body in, footer out");
  check(/\[our products\]\(http:\/\/127\.0\.0\.1:\d+\/products\)/.test(md.content), "read: links as Markdown links");
  check(typeof md.note === "string" && /never as instructions/.test(md.note), "page content is marked untrusted");
  const text = await tool("read", { view, format: "text", selector: "footer" });
  check(text.content === "Copyright 2026, the orchard", "read: an element's text", text.content);
  const short = await tool("read", { view, format: "text", maxChars: 300 });
  check(short.truncated === true && short.content.length === 300, "read: maxChars cuts and says so", short.chars);

  // Navigate, links, extract.
  const nav = await tool("navigate", { view, url: `${base}/products` });
  check(nav.title === "Products" && nav.loaded, "navigate", nav);
  const links = await tool("links", { view, match: "/p/" });
  check(links.links.length === 3 && links.links[0].url === `${base}/p/1`, "links: matched, absolute", links.links);
  const ex = await tool("extract", { view, items: ".product", fields: { name: "h2", price: ".price", link: "a@href",
    picture: "img@src", alt: "img@alt" } });
  check(ex.count === 3 && ex.rows[1].name === "Fuji" && ex.rows[1].price === "€3.50", "extract: fields from items", ex.rows);
  check(ex.rows[0].link === `${base}/p/1` && ex.rows[2].picture === `${base}/img/3.png`, "extract: @href/@src absolute");
  const one = await tool("extract", { view, fields: { title: "h1", names: ["h2"] } });
  check(one.rows.length === 1 && one.rows[0].title === "Products" && one.rows[0].names.join() === "Gala,Fuji,Jonagold",
    "extract: one row from the page, a list field", one.rows);

  // Wait for something a script adds later.
  await tool("navigate", { view, url: `${base}/late` });
  const waited = await tool("wait", { view, selector: "#late", timeout: 5000 });
  check(waited.found === true && waited.ms > 0, "wait: an element added later", waited);
  const never = await tool("wait", { view, selector: "#never", timeout: 700 });
  check(never.found === false, "wait: gives up after the timeout", never);

  // Find, click (a real mouse click through the DevTools protocol), type and submit.
  await tool("navigate", { view, url: `${base}/form` });
  const found = await tool("find", { view, text: "Press me" });
  check(found.elements[0]?.tag === "button", "find: by text", found.elements);
  const clicked = await tool("click", { view, ref: found.elements[0].ref });
  check(clicked.how === "mouse", "click: a mouse click", clicked);
  const pressed = await tool("eval", { view, script: "document.getElementById('press').textContent" });
  check(pressed.value === "Clicked by a mouse", "the page saw a trusted click", pressed.value);
  await refused("type: never into password fields", () => tool("type", { view, selector: "#pw", value: "x" }), /password/);
  const typed = await tool("type", { view, selector: "#q", value: "honeycrisp", submit: true });
  check(typed.how === "keyboard" && typed.submitted, "type: keys and Enter", typed);
  const results = await tool("read", { view, format: "text" });
  check(results.title === "Results for honeycrisp", "submit led to the results page", results.title);
  const async = await tool("eval", { view, script: "await new Promise((r) => setTimeout(() => r(6 * 7), 50))" });
  check(async.value === 42, "eval: promises are awaited", async.value);
  await refused("eval: a thrown error fails the call", () => tool("eval", { view, script: "throw new Error('nope')" }), /nope/);

  // Scroll a list that loads more.
  await tool("navigate", { view, url: `${base}/feed` });
  const before = await tool("eval", { view, script: "document.querySelectorAll('#feed li').length" });
  const scrolled = await tool("scroll", { view, times: 4, pause: 300 });
  const after = await tool("eval", { view, script: "document.querySelectorAll('#feed li').length" });
  check(before.value === 20 && after.value > 40 && scrolled.y > 0, "scroll: loads more", { before: before.value, after: after.value });

  // A picture of the page.
  const shot = await tool("screenshot", { view });
  check(shot.type === "image" && shot.mimeType === "image/jpeg" && shot.data.length > 1000, "screenshot: a JPEG", shot.mimeType);

  // Show it in a tab, hide it again: the shell is told.
  await tool("show", { view, where: "right" });
  await sleep(200);
  check(events.some((e) => e.topic === "shell:open" && e.data.instance === view && e.data.where === "right"),
    "show: the shell opens it as a tab");
  check((await call("webviews.list")).find((v) => v.view === view)?.hidden === false, "show: no longer hidden");
  await tool("hide", { view });
  await sleep(200);
  check(events.some((e) => e.topic === "layr:webviews" && e.data.op === "hidden" && e.data.view === view), "hide: the shell is told");
  const views1 = await tool("views");
  check(views1.views.find((v) => v.view === view)?.openedBy === "you", "views: who opened it", views1.views);

  // The core keeps web views off layr's own pages and the profile's cookies.
  await refused("open: not layr's own pages", () => tool("open", { url: `http://scraper.localhost:${port}/panels/main.html` }),
    /own pages/);
  await refused("open: http and https only", () => tool("open", { url: "file:///C:/Windows/win.ini" }), /http and https/);
  const cookies = await call("tools.call", { plugin: "layr", tool: "webview_cdp", args: { view, method: "Network.getAllCookies" } })
    .then((r) => r, (e) => e);
  check(cookies instanceof Error || cookies?.isError, "layr's own web view tools are for plugins, not the shell", String(cookies?.message ?? ""));

  // Close; scrape in one go (closed afterwards).
  await tool("close", { view });
  await sleep(150);
  check(!(await call("webviews.list")).some((v) => v.view === view), "close: gone");
  const scraped = await tool("scrape", { url: `${base}/products`, items: ".product", fields: { name: "h2" } });
  check(scraped.rows?.map((r) => r.name).join() === "Gala,Fuji,Jonagold" && scraped.view === null, "scrape: extract in one go", scraped);
  const art = await tool("scrape", { url: `${base}/article`, wait: "article" });
  check(art.main === true && art.content.includes("cold storage") && art.waited?.found, "scrape: Markdown in one go");
  check((await call("webviews.list")).length === 0, "scrape closes what it opened");

  // The user's own tab: the Browser plugin's web page, open in this window.
  const { instance: mine } = await call("panels.open", { plugin: "browser", panel: "page", params: { url: `${base}/form` } });
  const tabPage = await context.newPage();
  await tabPage.goto(`${base}/form`, { waitUntil: "load" });
  tabs.set(mine, { page: tabPage, cdp: await context.newCDPSession(tabPage), focusedAt: Date.now() });
  const pages = await tool("pages");
  check(pages.pages.length === 1 && pages.pages[0].view === mine && pages.pages[0].mine === false,
    "pages: the user's tab", pages.pages);
  const tabText = await tool("read", { format: "text" });
  check(tabText.title === "Form" && tabText.url === `${base}/form`, "read: without a view, the page focused last",
    tabText);
  await tabPage.evaluate(() => {
    const r = document.createRange();
    r.selectNodeContents(document.getElementById("press"));
    getSelection().addRange(r);
  });
  check((await tool("read", { view: mine, format: "text" })).selected === "Press me", "read: what the user selected");
  const tabClick = await tool("click", { text: "Press me" });
  const tabPressed = await tabPage.evaluate(() => document.getElementById("press").textContent);
  check(tabClick.how === "mouse" && tabPressed === "Clicked by a mouse", "click: a mouse click in the user's tab",
    tabPressed);
  const tabShot = await tool("screenshot", { view: mine });
  check(tabShot.type === "image" && tabShot.data.length > 1000, "screenshot: the user's tab");
  await refused("close: never the user's tabs", () => tool("close", { view: mine }), /yours to show, hide or close/);
  await refused("navigate: the user's tab never to layr's own pages",
    () => tool("navigate", { view: mine, url: `http://scraper.localhost:${port}/` }), /own pages/);
  check(tabs.has(mine) && !tabPage.isClosed(), "the user's tab is still there");

  // Another plugin calling: its "read" group allowed, the "pages" group asked (no window to ask: refused), then
  // allowed by the user.
  const { instance: start } = await call("panels.open", { plugin: "browser", panel: "start" });
  const startUrl = (await call("panels.get", { instance: start })).url;
  const other = await connectAs(new URL(startUrl).searchParams.get("layr"));
  const otherTool = async (name, args) => {
    const r = await other.call("tools.call", { plugin: "scraper", tool: name, args });
    if (r?.isError) throw new Error(r.content?.map((c) => c.text).join("\n"));
    return r.structuredContent;
  };
  for (const [group, value] of [["read", "allow"], ["act", "allow"]]) {
    await call("access.set", { plugin: "scraper", audience: "plugin:browser", group, value });
  }
  const own = await otherTool("open", { url: `${base}/products` });
  check(own.view && own.loaded, "another plugin: its own hidden page, no further question", own);
  check((await otherTool("read", { view: own.view, format: "text" })).title === "Products",
    "another plugin: reads its own page");
  await refused("another plugin: the user's tab is asked first", () => otherTool("read", { view: mine }),
    /needs your permission|may not use/);
  await refused("another plugin: no page without a view either", () => otherTool("read", {}), /pass a view/);
  await refused("another plugin: the list of the user's tabs is asked first", () => otherTool("pages", {}),
    /needs your permission|may not use/);
  await call("access.set", { plugin: "scraper", audience: "plugin:browser", group: "pages", value: "allow" });
  const allowed = await otherTool("read", { view: mine, format: "text" });
  check(allowed.title === "Form", "another plugin: the user's tab once the user allowed it", allowed.title);
  await call("access.set", { plugin: "scraper", audience: "plugin:browser", group: "pages", value: "deny" });
  await refused("another plugin: refused again once the user said no", () => otherTool("click", { view: mine,
    text: "Press me" }), /may not use/);
  await otherTool("close", { view: own.view });
  other.close();
} catch (e) {
  check(false, "the test ran through", String(e?.stack ?? e));
} finally {
  await browser.close().catch(() => {});
  core.kill();
  site.close();
}
if (failures) {
  console.log(`\n${failures} failed. Core log:\n${coreLog.slice(-4000)}`);
  process.exit(1);
}
console.log("\nall passed");
process.exit(0);
