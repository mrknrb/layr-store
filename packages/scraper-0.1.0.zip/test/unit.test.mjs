// The scraper's parts that need no browser: the scripts it sends parse, the libraries are wrapped in their own
// scope, and its helpers. `node test/unit.test.mjs`
import assert from "node:assert/strict";
import { test } from "node:test";
import { KIT_SOURCE, KIT_VERSION, readerSource } from "../backend/pagekit.js";
import { Scraper, callerName, errorText } from "../backend/scraper.js";

test("the page kit and the reader are valid scripts", () => {
  assert.doesNotThrow(() => new Function(KIT_SOURCE));
  const reader = readerSource();
  assert.doesNotThrow(() => new Function(reader));
  assert.match(reader, /window\.__layrReadability=module\.exports/);
  assert.match(reader, /window\.__layrTurndown=module\.exports/);
  assert.match(KIT_SOURCE, new RegExp(`\\(${KIT_VERSION}\\)$`));
});

test("the reader defines its libraries without touching the page's globals", () => {
  const window = {};
  const run = new Function("window", "self", "globalThis", readerSource());
  run(window, window, window);
  assert.equal(typeof window.__layrReadability, "function");
  assert.equal(typeof window.__layrTurndown, "function");
  assert.equal(window.Readability, undefined);
  assert.equal(window.TurndownService, undefined);
});

test("errors lose the page's stack", () => {
  assert.equal(errorText(new Error("Error: nothing on the page matches .x\n    at <anonymous>:1:2")),
    "Error: nothing on the page matches .x");
  assert.equal(errorText("Uncaught boom"), "boom");
});

test("callers in words", () => {
  assert.equal(callerName({ kind: "agent", plugin: "claude", label: "t_1" }), "agent t_1 (claude)");
  assert.equal(callerName({ kind: "panel", plugin: "scraper", instance: "p" }), "you (Web tools panel)");
  assert.equal(callerName({ kind: "backend", plugin: "research" }), "plugin research");
  assert.equal(callerName({ kind: "shell" }), "you");
  assert.equal(callerName(null), null);
});

/** A hub whose web view runs scripts against a tiny fake page state. */
function fakeHub() {
  const calls = [];
  let hasKit = false;
  const hub = {
    calls,
    async call(name, args) {
      calls.push([name, args]);
      if (name === "layr__webview_open") return { view: "p_1", url: args.url, title: "T", loaded: true, hidden: true };
      if (name === "layr__webview_close") return null;
      if (name === "layr__webview_cdp") throw new Error("the DevTools protocol works on Windows only");
      if (name === "layr__webview_eval") {
        if (args.script === KIT_SOURCE) {
          hasKit = true;
          return { value: true };
        }
        if (args.script.includes("__layr_kit_missing__")) {
          if (!hasKit) return { value: "__layr_kit_missing__" };
          if (args.script.includes("info()")) return { value: { ready: "complete", size: 10, url: "u", title: "T" } };
          if (args.script.includes("click(")) return { value: { ref: "1", tag: "button", text: "Go" } };
          if (args.script.includes("point(")) return { value: { x: 1, y: 2, ref: "1", tag: "button", text: "Go" } };
          if (args.script.includes("extract(")) return { value: { rows: [{ a: 1 }], count: 1 } };
        }
        return { value: null };
      }
      throw new Error(`unexpected ${name}`);
    },
  };
  return hub;
}

test("the kit is added once a page lacks it, then used", async () => {
  const hub = fakeHub();
  const s = new Scraper({ hub });
  const r = await s.extract({ view: "p_1", items: ".x", fields: { a: "b" } });
  assert.deepEqual(r.rows, [{ a: 1 }]);
  const evals = hub.calls.filter(([n]) => n === "layr__webview_eval").map(([, a]) => a.script);
  assert.equal(evals.filter((x) => x === KIT_SOURCE).length, 1);
  assert.equal(evals.length, 3, "asked, added, asked again");
});

test("without the DevTools protocol a click is a script click", async () => {
  const s = new Scraper({ hub: fakeHub() });
  const r = await s.click({ view: "p_1", text: "Go" });
  assert.equal(r.how, "script");
  assert.equal(r.clicked.tag, "button");
});

test("scrape closes what it opened, also when reading fails", async () => {
  const hub = fakeHub();
  const s = new Scraper({ hub });
  await assert.rejects(s.scrape({ url: "https://a.b/", fields: {} }), /fields names what to take/);
  assert.ok(hub.calls.some(([n, a]) => n === "layr__webview_close" && a.view === "p_1"));
  await assert.rejects(s.extract({ view: "p_1", fields: null }), /fields/);
});

test("open uses the setting when the caller doesn't say where", async () => {
  const hub = fakeHub();
  const s = new Scraper({ hub, settings: async () => ({ show: "right" }) });
  await s.open({ url: "https://a.b/" }, { kind: "agent", plugin: "claude", label: "t" });
  const open = hub.calls.find(([n]) => n === "layr__webview_open")[1];
  assert.equal(open.show, "right");
  assert.equal(s.opened.get("p_1").openedBy, "agent t (claude)");
});

/** A hub with own views, the user's pages, and an access check that allows `allowed` callers. */
function pagesHub({ allowed = () => true, pages = [] } = {}) {
  const calls = [];
  return {
    calls,
    async call(name, args) {
      calls.push([name, args]);
      if (name === "layr__webview_list") return [{ view: "p_own", url: "https://own/", hidden: true }];
      if (name === "layr__webview_pages") return pages;
      if (name === "layr__access_check") {
        if (allowed(args.caller)) return { allowed: true };
        throw new Error(`not allowed to call scraper's tools: ${args.caller?.kind} may not use scraper__${args.tool}`);
      }
      if (name === "layr__webview_show" || name === "layr__webview_close") return null;
      throw new Error(`unexpected ${name}`);
    },
  };
}

const AGENT = { kind: "agent", plugin: "claude", label: "t" };
const TABS = [
  { view: "p_mail", url: "https://mail/", title: "Mail", focusedAt: 20, visible: true },
  { view: "p_bank", url: "https://bank/", title: "Bank", focusedAt: 10, visible: false },
];

test("its own web views need no further question", async () => {
  const hub = pagesHub({ allowed: () => false });
  const s = new Scraper({ hub });
  assert.equal(await s.target("p_own", AGENT, "read"), "p_own");
  assert.ok(!hub.calls.some(([n]) => n === "layr__access_check"));
});

test("the user's pages: asked per caller; without a view, the page focused last", async () => {
  const hub = pagesHub({ pages: TABS });
  const s = new Scraper({ hub });
  assert.equal(await s.target("p_bank", AGENT, "read"), "p_bank");
  assert.equal(await s.target(undefined, AGENT, "click"), "p_mail");
  const checks = hub.calls.filter(([n]) => n === "layr__access_check").map(([, a]) => a);
  assert.deepEqual(checks.map((a) => [a.group, a.tool, a.caller.kind]), [["pages", "read", "agent"],
    ["pages", "click", "agent"]]);
});

test("refused callers don't reach the user's pages; unknown views aren't asked about", async () => {
  const hub = pagesHub({ pages: TABS, allowed: () => false });
  const s = new Scraper({ hub });
  await assert.rejects(s.target("p_mail", AGENT, "read"), /may not use scraper__read/);
  await assert.rejects(s.target(undefined, AGENT, "read"), /pass a view/);
  const before = hub.calls.filter(([n]) => n === "layr__access_check").length;
  await assert.rejects(s.target("p_nope", AGENT, "read"), /No web view p_nope/);
  assert.equal(hub.calls.filter(([n]) => n === "layr__access_check").length, before);
  await assert.rejects(new Scraper({ hub: pagesHub() }).target(undefined, AGENT, "read"), /No web pages are open/);
});

test("show, hide and close take the scraper's own views only", async () => {
  const hub = pagesHub({ pages: TABS });
  const s = new Scraper({ hub });
  await assert.rejects(s.close({ view: "p_mail" }), /yours to show, hide or close/);
  await assert.rejects(s.show({ view: "p_mail" }), /yours to show, hide or close/);
  await s.close({ view: "p_own" });
  assert.ok(hub.calls.some(([n, a]) => n === "layr__webview_close" && a.view === "p_own"));
  assert.ok(!hub.calls.some(([n, a]) => n === "layr__webview_close" && a.view === "p_mail"));
});

test("pages lists the user's tabs with readable times", async () => {
  const r = await new Scraper({ hub: pagesHub({ pages: TABS }) }).pages();
  assert.deepEqual(r.pages.map((p) => p.view), ["p_mail", "p_bank"]);
  assert.equal(r.pages[0].focusedAt, new Date(20).toISOString());
});
