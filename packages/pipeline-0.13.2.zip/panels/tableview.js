// The board's table (task #50): its columns, and its views. A view is a named setup of the whole table: the columns
// shown in their order, their widths, the sorts, the grouping, the stages whose tasks are rows, and the search text.
// The views are saved in the backend (the `views` tool: the same on every board and device); none saved: the starting
// views here. Pure (no DOM), so test/table.test.js tests it; table.js draws it.

/** Orders task numbers: 83, 84, "84-1", "84-2", 85 (as common.js's byNumber; this file stays without the DOM). */
const byNumber = (a, b) => {
  const [a1, a2 = 0] = String(a).split("-").map(Number);
  const [b1, b2 = 0] = String(b).split("-").map(Number);
  return a1 - b1 || a2 - b2;
};

export const STAGES = ["proposed", "ready", "running", "stopped", "settled"];
export const STAGE_TITLE = { proposed: "Proposed", ready: "Ready", running: "Running", stopped: "Stopped", settled: "Settled" };
export const GROUPS = { none: "No grouping", project: "Project", stage: "Stage" };

/**
 * Every column: its heading, what it shows (the heading's tooltip and the Columns menu), its width when new (none:
 * it takes the room left), whether it sorts most first, and whether it sorts at all.
 */
export const COLUMNS = {
  number: { label: "#", about: "The task's number", width: 58, desc: true },
  title: { label: "Title", about: "Click the row to open its thread, or a proposal's edit form (⋯ › See it: it in a window)" },
  project: { label: "Project", about: "The project it works in", width: 130 },
  stage: { label: "Stage", about: "The board's column it is in: Proposed, Ready, Running, Stopped or Settled", width: 92 },
  status: { label: "Status", about: "Where it stands: queued, running, question, finished, landed…", width: 130 },
  note: { label: "Note", about: "What it asks, waits for or failed with (the line under a card's title)", width: 260 },
  stakes: { label: "Stakes", about: "How much deciding about it matters, from its brief and risks (1–10)", width: 70, desc: true },
  size: { label: "Size", about: "S, M, L or an exact percent of a Pro 5-hour window, and pacing's guess of what it still needs (click to change the size)", width: 84 },
  needs: { label: "Needs", about: "Pacing's guess of what it still needs: percent of a Pro 5-hour window", width: 66, desc: true },
  spent: { label: "Spent", about: "What it spent so far: percent of a Pro 5-hour window", width: 64, desc: true },
  model: { label: "Model", about: "Its own model and effort, when it has any (else the project's)", width: 100 },
  start: { label: "Starts", about: "Who starts it: you or agents, plan first, only you, agents", width: 92 },
  branch: { label: "Branch", about: "Its worktree's branch (⌀: its worktree was removed, its work is on the base branch)", width: 180 },
  prompt: { label: "Description", about: "What the task asks for, a batch's sub-tasks after it (hover for more; ▸ shows all of it)", width: 260 },
  reply: { label: "Last reply", about: "The start of its thread's last reply (hover for more; ▸ shows all of it)", width: 260 },
  tested: { label: "Tested", about: "✓: you tested its result (click to mark or unmark it)", width: 66, desc: true },
  controversial: { label: "🚩", about: "🚩: you marked it controversial (click to mark or unmark it)", width: 46, desc: true },
  chips: { label: "Chips", about: "What its card shows as chips: ◆ nodes, tested, batch, auto-merge, verifier, PR, warnings…", width: 200, noSort: true },
  changed: { label: "Changed", about: "When it last changed", width: 82, desc: true },
  created: { label: "Created", about: "When it was made", width: 82, desc: true },
  actions: { label: "Actions", about: "Its next step as a button (Run, Answer, Land…), everything else under ⋯", width: 170, noSort: true },
};
export const ALL_COLUMNS = Object.keys(COLUMNS);
export const MIN_WIDTH = 40;
export const MAX_WIDTH = 900;
/** The title column's least width while it takes the room left. */
export const TITLE_MIN = 220;

const view = (id, name, stages, columns, sorts, extra = {}) => ({ id, name, columns, widths: {}, sorts, group: "none", stages, query: "", ...extra });

/** The views a board starts with (until views are saved). */
export function startingViews() {
  return [
    view("open", "Open", ["proposed", "ready", "running", "stopped"],
      ["number", "title", "project", "stage", "status", "note", "size", "changed", "actions"],
      [{ by: "stage", desc: false }, { by: "changed", desc: true }]),
    view("waits", "Waits for me", ["stopped"],
      ["number", "title", "project", "status", "note", "stakes", "changed", "actions"],
      [{ by: "stakes", desc: true }, { by: "changed", desc: true }]),
    view("running", "Running", ["ready", "running"],
      ["number", "title", "project", "stage", "status", "note", "needs", "model", "changed", "actions"],
      [{ by: "stage", desc: true }, { by: "changed", desc: true }]),
    view("settled", "Settled", ["settled"],
      ["number", "title", "project", "status", "branch", "spent", "changed", "actions"],
      [{ by: "changed", desc: true }]),
  ];
}

/** A view with every field, unknown columns and stages left out. */
export function normalize(v) {
  const columns = [...new Set((v?.columns ?? []).filter((c) => c in COLUMNS))];
  const widths = Object.fromEntries(Object.entries(v?.widths ?? {}).filter(([c, w]) => c in COLUMNS && Number.isFinite(w)).map(([c, w]) => [c, clampWidth(w)]));
  const sorts = (v?.sorts ?? []).filter((s) => s?.by in COLUMNS && !COLUMNS[s.by].noSort).map((s) => ({ by: s.by, desc: !!s.desc }));
  const stages = STAGES.filter((s) => (v?.stages ?? STAGES).includes(s));
  return {
    id: String(v?.id ?? "view"),
    name: String(v?.name ?? "View"),
    columns: columns.length ? columns : ["number", "title"],
    widths,
    sorts: sorts.length ? sorts : [{ by: "number", desc: true }],
    group: v?.group in GROUPS ? v.group : "none",
    stages,
    query: String(v?.query ?? ""),
  };
}

export const clampWidth = (w) => Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, Math.round(w)));

/** The saved views (the backend's; null or none: the starting ones), normalized. */
export const savedViews = (list) => (Array.isArray(list) && list.length ? list : startingViews()).map(normalize);

/** Whether two views show the same (the name and id aside): a changed view offers Save. */
export function sameView(a, b) {
  const key = (v) => {
    const n = normalize(v);
    const widths = Object.fromEntries(Object.entries(n.widths).sort(([x], [y]) => x.localeCompare(y)));
    return JSON.stringify([n.columns, widths, n.sorts, n.group, n.stages, n.query.trim()]);
  };
  return key(a) === key(b);
}

/** A fresh id for a new view. */
export const newViewId = (list) => {
  for (let i = list.length + 1; ; i++) if (!list.some((v) => v.id === `v${i}`)) return `v${i}`;
};

/**
 * The sort after a click on a heading: a plain click sorts by that column alone (again: the other way round).
 * Shift+click adds it after the sorts there, then turns it round, then takes it out, so several columns sort together.
 */
export function clickSort(sorts, by, shift, descFirst = !!COLUMNS[by]?.desc) {
  const index = sorts.findIndex((s) => s.by === by);
  const found = sorts[index];
  if (!shift) {
    if (found && sorts.length === 1) return [{ by, desc: !found.desc }];
    return [{ by, desc: found ? found.desc : descFirst }];
  }
  if (!found) return [...sorts, { by, desc: descFirst }];
  if (found.desc !== descFirst) return sorts.length > 1 ? sorts.filter((_, i) => i !== index) : sorts;
  return sorts.map((s, i) => (i === index ? { by, desc: !s.desc } : s));
}

/** `column` moved to just before `before` (the end without it). */
export function moveColumn(columns, column, before) {
  if (column === before) return columns;
  const rest = columns.filter((c) => c !== column);
  const at = before === null || before === undefined ? -1 : rest.indexOf(before);
  return at < 0 ? [...rest, column] : [...rest.slice(0, at), column, ...rest.slice(at)];
}

/** `list` with the item at `index` moved one place left (-1) or right (1), in a new array. */
export function moveBy(list, index, by) {
  const to = index + by;
  if (index < 0 || index >= list.length || to < 0 || to >= list.length) return list;
  const next = [...list];
  next.splice(to, 0, ...next.splice(index, 1));
  return next;
}

/** Show or hide a column; one shown again goes back after the shown columns that come before it in ALL_COLUMNS. */
export function toggleColumn(columns, column) {
  if (columns.includes(column)) return columns.length > 1 ? columns.filter((c) => c !== column) : columns;
  const rank = ALL_COLUMNS.indexOf(column);
  let at = columns.length;
  for (let i = columns.length - 1; i >= 0; i--) {
    if (ALL_COLUMNS.indexOf(columns[i]) < rank) break;
    at = i;
  }
  return [...columns.slice(0, at), column, ...columns.slice(at)];
}

// ---------------------------------------------------------------- values

const collator = new Intl.Collator(undefined, { sensitivity: "base", numeric: true });
/** What a size letter counts as when sorting against exact sizes (percent of a Pro 5-hour window). */
const SIZE_RANK = { S: 10, M: 30, L: 60 };
export const START_LABEL = { either: "you or agents", plan: "plan first", manual: "only you", agents: "agents" };

/** A task's model and effort as one text. */
export const modelText = (t) => [t.model, t.effort].filter(Boolean).join(" · ");

/** The first lines of a text, without Markdown headings and the status line. */
/**
 * A batch's sub-tasks one after the other (`#84-1 Title · #84-2 Title`): its description cell shows them after its
 * own description. `byId`: the board's tasks by id (each member's newest title); "": not a batch.
 */
export function subTasksText(t, byId = {}) {
  return (t.members ?? []).map((m) => `#${byId[m.id]?.number ?? m.number} ${byId[m.id]?.title ?? m.title}`).join(" · ");
}

export function firstLines(text, max = 240) {
  const lines = String(text ?? "").split("\n").map((l) => l.trim()).filter((l) => l && !/^#{1,6}\s/.test(l) && !/^status\s*:/i.test(l));
  const joined = lines.join(" ");
  return joined.length > max ? `${joined.slice(0, max - 1)}…` : joined;
}

/**
 * A cell's value for sorting (and its text when no drawing is given): numbers or text; empty values are null and
 * sort last either way round. `projects`: by id.
 */
export function cellValue(t, column, projects = {}) {
  switch (column) {
    case "number":
      return t.number;
    case "title":
      return t.title ?? "";
    case "project":
      return projects[t.projectId]?.title ?? t.projectId ?? "";
    case "stage":
      return STAGES.indexOf(t.column);
    case "status":
      return t.state ?? "";
    case "note":
      return t.note || null;
    case "stakes":
      return t.stakes?.score ?? null;
    case "size":
      return t.estimate?.exact ?? t.sizePct ?? SIZE_RANK[t.estimate?.size ?? t.size ?? "M"];
    case "needs":
      return t.estimate && !t.settledAt ? t.estimate.pct : null;
    case "spent":
      return t.estimate?.spentPct ?? null;
    case "model":
      return modelText(t) || null;
    case "start":
      return START_LABEL[t.start ?? "either"] ?? t.start;
    case "branch":
      return t.branch || null;
    case "prompt":
      return [t.prompt, subTasksText(t)].filter(Boolean).join(" ") || null;
    case "tested":
      return t.tested ?? null;
    case "controversial":
      return t.controversial ?? null;
    case "reply":
      return t.thread?.lastMessage ? firstLines(t.thread.lastMessage) : null;
    case "changed":
      return t.updatedAt ?? null;
    case "created":
      return t.createdAt ?? null;
  }
  return null;
}

/** Rows sorted by each sort in turn; ties: newest number first. Empty values go last. */
export function sortTasks(tasks, sorts, projects = {}) {
  const compare = (a, b) => {
    for (const { by, desc } of sorts) {
      const x = cellValue(a, by, projects);
      const y = cellValue(b, by, projects);
      const ex = x === null || x === "" || x === undefined;
      const ey = y === null || y === "" || y === undefined;
      if (ex || ey) {
        if (ex !== ey) return ex ? 1 : -1;
        continue;
      }
      const order = typeof x === "number" && typeof y === "number" ? x - y : collator.compare(String(x), String(y));
      if (order) return desc ? -order : order;
    }
    return byNumber(b.number, a.number);
  };
  return [...tasks].sort(compare);
}

/**
 * The rows in groups: [{key, label, rows}], projects by title, stages left to right. `group` none: one group
 * without a key.
 */
export function groupTasks(rows, group, projects = {}) {
  if (group !== "project" && group !== "stage") return [{ key: "", label: "", rows }];
  const keyOf = (t) => (group === "project" ? `project:${t.projectId}` : `stage:${t.column}`);
  const map = new Map();
  for (const t of rows) {
    const k = keyOf(t);
    if (!map.has(k)) map.set(k, { key: k, label: group === "project" ? (projects[t.projectId]?.title ?? t.projectId) : STAGE_TITLE[t.column] ?? t.column, rows: [] });
    map.get(k).rows.push(t);
  }
  const list = [...map.values()];
  if (group === "stage") return list.sort((a, b) => STAGES.indexOf(a.key.slice(6)) - STAGES.indexOf(b.key.slice(6)));
  return list.sort((a, b) => collator.compare(a.label, b.label));
}

// ---------------------------------------------------------------- acting on several rows

/** The backend's buttons that may be pressed for several tasks at once (not ▶ Try, Discard or Brief). */
const BULK_BUTTONS = ["approve", "start", "unpark", "stop", "land", "settle", "unsettle"];
const BULK_LABEL = {
  run: "Run",
  approve: "Go ahead",
  away_on: "🌙 When away on",
  away_off: "🌙 When away off",
  start: "Run / send now",
  unpark: "Don't send",
  stop: "Stop",
  land: "Land",
  settle: "Settle",
  unsettle: "Unsettle",
};
/** What a bulk action does, for its confirm. */
const BULK_ABOUT = {
  run: "They queue for a free slot.",
  approve: "Their threads go ahead with the work.",
  away_on: "Their work, and what you send them, waits until you're Away (proposals without Plan wait in Ready).",
  away_off: "Proposals go back to Proposed; messages that waited go back, unsent, into their threads' text boxes.",
  start: "What waits in Ready for them is sent now.",
  unpark: "What waits in Ready for them is dropped.",
  stop: "Their turns are interrupted.",
  land: "Each runs its project's checks and lands on the base branch, one after another.",
  settle: "They move to Settled; work that isn't landed stays in its worktree; landed work's worktree goes (Unsettle brings it back).",
  unsettle: "They come back to Stopped.",
};

/** A proposal that Run starts (the board's own Run button). */
export const canRun = (t) => t.column === "proposed" && !t.threadId && !t.inBatch && !t.held?.some((m) => m.kind === "launch");

/**
 * What can be done to the picked tasks together: [{id, label, about, tasks, danger}], each with the tasks it fits,
 * in a fixed order. Hide / Unhide are the panel's own.
 */
export function bulkActions(tasks) {
  const out = [];
  const add = (id, list) => list.length && out.push({ id, label: BULK_LABEL[id], about: BULK_ABOUT[id], tasks: list, danger: id === "stop" });
  add("run", tasks.filter(canRun));
  for (const id of BULK_BUTTONS) add(id, tasks.filter((t) => (t.buttons ?? []).some((b) => b.id === id)));
  add("away_on", tasks.filter((t) => t.toggles?.whenAway.can && !t.toggles.whenAway.on));
  add("away_off", tasks.filter((t) => t.toggles?.whenAway.can && t.toggles.whenAway.on));
  return out;
}
