// Pure parts: reply status lines, batch reports, verdicts, error kinds, globs, columns.
// Run: node test/unit.test.js
import { approvable, placeTask, usesSlot } from "../backend/columns.js";
import { askPathHits, batchReport, classifyError, replySections, replyStatus, verdictOf, wordsName } from "../backend/report.js";
import { checkValue, describe, GLOBAL, globalDefaults, PROJECT, workerSettings } from "../backend/settings.js";
import { byNumber } from "../backend/store.js";
import { taskPlugins, withPlugins } from "../backend/pipeline.js";
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";

let failures = 0;
let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`ok   ${name}`);
  } catch (error) {
    failures++;
    console.log(`FAIL ${name}: ${error.message}`);
  }
}
const eq = (a, b, msg = "values differ") => {
  if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${msg}: ${JSON.stringify(a)} != ${JSON.stringify(b)}`);
};

test("status line", () => {
  eq(replyStatus("Done.\n\nStatus: done · Risk: none · Try: ready"), { status: "done", risks: [], try: "ready" });
  eq(replyStatus("x\n**Status: asks | Risk: Database, UI | Try: none**"), { status: "asks", risks: ["database", "ui"], try: "none" });
  eq(replyStatus("Status: partial • Risk: data and breaking"), { status: "partial", risks: ["data", "breaking"] });
  eq(replyStatus("No status here"), null);
  eq(replyStatus(""), null);
});

test("reply sections", () => {
  const s = replySections("intro\n## Summary\nAll good\n## ✅ Checks\n- tests pass");
  eq(s.map((x) => x.heading), ["", "Summary", "Checks"]);
  eq(s[2].body, "- tests pass");
});

test("batch report", () => {
  const text = "Done.\n- #12 done\n`#14 skipped: needs a decision`\n#99 done\n#12 — done";
  eq(batchReport(text, [12, 14]), [
    { number: 12, done: true },
    { number: 14, done: false, why: "needs a decision" },
  ]);
  eq(batchReport("#3 skipped", [3]), [{ number: 3, done: false, why: "no reason given" }]);
  // Task #88: sub-tasks numbered in their batch; #84-11 is not #84-1.
  eq(batchReport("#84-1 done\n- `#84-2 skipped: too big`\n#84-11 done\n#84 done", ["84-1", "84-2"]), [
    { number: "84-1", done: true },
    { number: "84-2", done: false, why: "too big" },
  ]);
});

test("task numbers in order, sub-tasks after their batch", () => {
  eq([85, "84-2", 83, "84-1", 84, "84-10"].sort(byNumber), [83, 84, "84-1", "84-2", "84-10", 85]);
});

test("verdict", () => {
  eq(verdictOf("Looks fine.\n\nVerdict: pass"), "pass");
  eq(verdictOf("Verdict: fix\n...\n**Verdict:** you"), "you");
  eq(verdictOf("no verdict"), null);
});

test("error kinds", () => {
  eq(classifyError("Claude AI usage limit reached|1700000000"), "limit");
  eq(classifyError("API Error: 529 overloaded"), "network");
  eq(classifyError("fetch failed"), "network");
  eq(classifyError("TypeError: x is undefined"), null);
});

test("always-ask globs and naming", () => {
  eq(askPathHits(["supabase/migrations/001.sql", "src/a.ts", "db\\migrations\\x.ts", "q.SQL"], "supabase/migrations/**\n**/migrations/**\n**/*.sql"), [
    "supabase/migrations/001.sql",
    "db\\migrations\\x.ts",
    "q.SQL",
  ]);
  eq(wordsName("please land #12 and #3", 12), true);
  eq(wordsName("land 120", 12), false);
  eq(wordsName("land 1.2", 2), false);
});

test("settings checks", () => {
  eq(checkValue(PROJECT, "checksTimeoutMin", "20"), 20);
  eq(checkValue(PROJECT, "maxRunning", ""), null);
  let threw = false;
  try {
    checkValue(PROJECT, "landing", "merge-queue");
  } catch {
    threw = true;
  }
  eq(threw, true, "unknown landing refused");
});

test("worker model and effort: task > project > global > default", () => {
  const g = globalDefaults();
  eq([g.workerModel, g.workerEffort], [null, null], "global defaults: the claude plugin decides");
  eq(workerSettings({}, { workerModel: null, workerEffort: null }, g), { model: null, effort: null }, "nothing set");
  const global = { ...g, workerModel: "opus", workerEffort: "high" };
  eq(workerSettings({}, { workerModel: null, workerEffort: null }, global), { model: "opus", effort: "high" }, "the global values");
  eq(workerSettings({}, { workerModel: "sonnet", workerEffort: null }, global), { model: "sonnet", effort: "high" }, "the project's");
  eq(workerSettings({ model: "claude-x-1", effort: "low" }, { workerModel: "sonnet", workerEffort: "max" }, global), { model: "claude-x-1", effort: "low" }, "the task's");
  // A project saved before the global settings existed keeps its value; an empty one falls through.
  eq(workerSettings({ model: null }, { workerModel: "haiku" }, g), { model: "haiku", effort: null }, "old project values");
  eq(workerSettings({ model: "" }, { workerModel: "" }, global).model, "opus", "empty text is empty");
});

test("model settings: Task threads first, empty values", () => {
  const keys = Object.keys(GLOBAL);
  eq(keys.slice(0, 4), ["mode", "maxRunning", "workerModel", "workerEffort"], "Model and Effort near the top of Global");
  eq(checkValue(GLOBAL, "workerModel", "  "), null, "blank model is empty");
  eq(checkValue(GLOBAL, "workerModel", " opus[1m] "), "opus[1m]", "a model id, trimmed");
  eq(checkValue(PROJECT, "workerEffort", ""), null, "empty effort");
  const row = (list, key) => list.find((s) => s.key === key);
  const project = describe(PROJECT, { workerModel: "sonnet" });
  eq([row(project, "workerModel").value, row(project, "workerModel").nullable, row(project, "workerModel").changed], ["sonnet", true, true], "project model row");
  eq(row(project, "workerEffort").value, null, "project effort: empty (the global value)");
  const global = describe(GLOBAL, { orchestratorEffort: null });
  eq([row(global, "orchestratorEffort").value, row(global, "orchestratorEffort").changed], [null, true], "a saved null stays null");
  eq(row(global, "verifierModel").nullable, undefined, "verifier model can't be empty");
});

test("columns", () => {
  const now = Date.now();
  const iso = (ms) => new Date(now + ms).toISOString();
  eq(placeTask({ number: 1 }), { column: "proposed", why: "proposal" });
  eq(placeTask({ number: 1, held: [{ kind: "launch", at: iso(0) }] }).why, "queued");
  eq(placeTask({ number: 1, held: [{ kind: "launch", at: iso(0) }], resumeAt: iso(60000) }).why, "limit");
  const thread = (status, extra = {}) => ({ status, pending: [], turnStartedAt: iso(-5000), ...extra });
  eq(placeTask({ threadId: "t", thread: thread("running") }), { column: "running", why: "running" });
  const paused = thread("running", { limitPause: iso(60000) });
  eq(placeTask({ threadId: "t", thread: paused }), { column: "running", why: "limit" }, "paused for the usage limit");
  eq(placeTask({ threadId: "t", planning: true, thread: paused }).column, "proposed");
  eq(placeTask({ threadId: "t", thread: thread("waiting", { pending: [{ requestId: "r" }] }) }), { column: "stopped", why: "question" });
  eq(placeTask({ threadId: "t", thread: thread("waiting"), held: [{ kind: "answer", at: iso(0) }] }).column, "running");
  eq(placeTask({ threadId: "t", thread: thread("done") }), { column: "stopped", why: "finished" });
  eq(placeTask({ threadId: "t", thread: thread("done"), landed: { commit: "c" } }).why, "landed");
  eq(placeTask({ threadId: "t", thread: thread("done"), landing: { phase: "checks" } }).why, "landing");
  eq(placeTask({ threadId: "t", thread: thread("failed") }).why, "failed");
  eq(placeTask({ threadId: "t", thread: thread("done"), settledAt: iso(0) }).column, "settled");
  eq(placeTask({ threadId: "t", thread: { missing: true } }).why, "missing");
  // A turn that ended with background work (subagents, background shells, watches) still running stays running.
  const bg = [{ id: "b1", type: "local_bash", description: "cargo test" }];
  eq(placeTask({ threadId: "t", thread: thread("done", { background: bg }) }), { column: "running", why: "background" });
  eq(placeTask({ threadId: "t", thread: thread("waiting", { background: bg, pending: [{ requestId: "r" }] }) }).why, "question");
  eq(usesSlot({ threadId: "t", thread: thread("done", { background: bg }) }), true, "background work holds a slot");
  eq(usesSlot({ threadId: "t", thread: thread("waiting", { background: bg }) }), false, "not while it asks you");
  eq(usesSlot({ threadId: "t", thread: thread("done", { background: [] }) }), false);
  eq(approvable({ threadId: "t", thread: thread("done", { background: bg }) }), false, "not approvable while it works");
  // Planning stays in Proposed while it plans or asks.
  eq(placeTask({ threadId: "t", planning: true, thread: thread("done") }), { column: "proposed", why: "question" });
  // Parked for Away: Ready; a turn after it that doesn't end done: back to the user.
  const parked = [{ kind: "message", text: "go", at: iso(-1000) }];
  eq(placeTask({ threadId: "t", parked, thread: thread("done", { turnStartedAt: iso(-9000) }) }).column, "ready");
  eq(placeTask({ threadId: "t", parked, thread: thread("done", { turnStartedAt: iso(0) }) }).why, "question");
  // Batch members follow their batch.
  eq(placeTask({ inBatch: "9" }, now, { threadId: "t", thread: thread("running") }), { column: "running", why: "batched" });
  // Approve fits a task that stopped without Status: done.
  eq(approvable({ threadId: "t", thread: thread("done", { replyStatus: { status: "asks", risks: [] } }) }), true);
  eq(approvable({ threadId: "t", thread: thread("done", { replyStatus: { status: "done", risks: [] } }) }), false);
});

test("installed plugins beside the worktree (0.17.0)", () => {
  const dir = mkdtempSync(path.join(os.tmpdir(), "pl-plugins-"));
  try {
    eq(withPlugins({ plugins: null }, dir), false, "another project: off");
    mkdirSync(path.join(dir, "core", "layr_core"), { recursive: true });
    writeFileSync(path.join(dir, "core", "layr_core", "Cargo.toml"), "");
    eq(withPlugins({ plugins: null }, dir), true, "layr's own source: on");
    eq(withPlugins({ plugins: false }, dir), false, "the setting wins");
    eq(withPlugins({ plugins: true }, null), true, "the setting wins");
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
  eq(taskPlugins(null), undefined);
  eq(taskPlugins([{ id: "wiki", name: "Wiki", mode: "read" }]), undefined, "read only: not changed by it");
  eq(taskPlugins([{ id: "wiki", name: "Wiki", mode: "change", held: { version: "0.3.0" } }, { id: "pdf", mode: "change" }]),
    [{ id: "wiki", name: "Wiki", held: "0.3.0" }, { id: "pdf", name: "pdf" }]);
  eq(checkValue(PROJECT, "plugins", true), true);
});

console.log(`${passed} passed, ${failures} failed`);
process.exit(failures ? 1 : 0);
