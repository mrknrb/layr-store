// The pipeline's panels in headless Chromium against an in-process backend (the real Pipeline and tools, the fake
// claude plugin, real git in a temp folder) behind a stub layr.js: no core, no Claude. It renders the board (cards
// opening threads, the card menu, hide / unhide, the table, task links revealing a card, the phone), Decide and
// Settings › Crew with the crew's state in them, and saves screenshots to plugins/pipeline/screenshots.
//   node test/panels.smoke.js     (Playwright from plugins/dev/node_modules, or PLAYWRIGHT_DIR)
import { execFileSync } from "node:child_process";
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import http from "node:http";
import { createRequire } from "node:module";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createActions } from "../backend/actions.js";
import { Pipeline } from "../backend/pipeline.js";
import { Store } from "../backend/store.js";
import { registerTools } from "../backend/tools.js";
import { FakeClaude } from "./fakeClaude.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..");
const pwDir = process.env.PLAYWRIGHT_DIR || path.resolve(root, "..", "dev");
const { chromium } = createRequire(path.join(pwDir, "package.json"))("playwright");
const out = path.join(root, "screenshots");
mkdirSync(out, { recursive: true });
let failures = 0;
const check = (ok, what, detail) => {
  console.log(`${ok ? "PASS" : "FAIL"} ${what}${detail ? ` — ${detail}` : ""}`);
  if (!ok) failures++;
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- a backend with some state ----------
const tmp = mkdtempSync(path.join(os.tmpdir(), "layr-pipeline-panels-"));
const repo = path.join(tmp, "demo");
const git = (...a) => execFileSync("git", ["-C", repo, ...a], { stdio: ["ignore", "pipe", "pipe"] }).toString().trim();
execFileSync("git", ["init", "-q", "-b", "main", repo]);
git("config", "user.name", "Test");
git("config", "user.email", "test@example.com");
writeFileSync(path.join(repo, "README.md"), "# Demo\n");
git("add", ".");
git("commit", "-q", "-m", "init");
const store = new Store(path.join(tmp, "data"));
const claude = new FakeClaude();
const project = await claude.addProject(repo, "Demo");
// A hub with the concepts plugin (0.4.0: node picker, ◆ chips, Set up project map) and a Supabase session (Import from
// layr_code, whose GETs a stubbed fetch answers from test/fixtures).
const NODE = "aaaaaaaa-1111-4111-8111-111111111111";
const hubCalls = [];
const hub = {
  available: true,
  emit() {},
  notify() {},
  async call(name, args) {
    hubCalls.push([name, args]);
    if (name === "layr__plugins_list") {
      const tools = ["nodes", "link", "relink", "advance_status", "needs", "linked_nodes", "project_map", "setup_project_map"];
      return { plugins: [{ id: "concepts", status: "running", tools: tools.map((n) => ({ name: n })) }] };
    }
    if (name === "concepts__nodes") return [{ id: NODE, label: "Demo app", in: ["Projects"] }];
    if (name === "concepts__linked_nodes") return { [`layr://pipeline/task/${asks.id}`]: [{ id: NODE, text: "Greeting feature" }] };
    if (name === "concepts__project_map") return { node: NODE, title: "Demo app", sections: { features: NODE }, rules: {}, workerRules: {}, missing: [] };
    if (name === "concepts__setup_project_map") return { made: ["Rules", "Plan"], map: { node: NODE, title: "Demo app", sections: {}, missing: [] } };
    if (name === "layr__supabase_session") return { url: "https://fake.supabase.test", key: "anon", accessToken: "tok", email: "me@example.com" };
    if (name.startsWith("concepts__") || name.startsWith("layr__")) return {};
    throw new Error(`unknown tool ${name}`);
  },
};
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, init) => {
  if (!String(url).startsWith("https://fake.supabase.test")) return realFetch(url, init);
  const fixture = JSON.parse(readFileSync(path.join(here, "fixtures", "layr_code-records.json"), "utf8"));
  const rows = fixture.map((r) => (r.id === "catalog" ? { ...r, data: { projects: [{ id: "t3-demo", title: "Demo (T3)", workspaceRoot: repo }] } } : r));
  const q = new URL(url).searchParams;
  const list = rows.filter((r) => `eq.${r.collection}` === q.get("collection") && (!q.get("id") || `eq.${r.id}` === q.get("id")));
  return { ok: true, status: 200, text: async () => JSON.stringify(list) };
};
const p = new Pipeline({ store, claude, hub, logger: () => {} });
const actions = createActions(p);
store.setGlobal({ pollSec: 1, briefs: true, scouts: "ask" });
store.setProject(project.id, { enabled: true, baseBranch: "main", laneRun: "npm run dev", updateMain: true });
await p.refreshProjects();
const handlers = new Map();
registerTools({ registerTool: (name, def, fn) => handlers.set(name, fn) }, p, actions);
claude.asker = async () => ({ text: '{"what":"Adds a greeting file.","ask":"Answer which colour.","cost":"A wrong colour is easy to change.","stakes":3}' });
claude.usageValue = { account: { email: "me@example.com" }, limits: { fiveHour: { utilization: 42, resetsAt: new Date(Date.now() + 2 * 3600e3).toISOString() }, sevenDay: { utilization: 61, resetsAt: new Date(Date.now() + 3 * 86400e3).toISOString() } }, updatedAt: new Date().toISOString() };
claude.worker = async (t, text) => {
  if (/Code scout/.test(t.title)) return { reply: 'Looked.\n\n```json\n{"area":"src","summary":"nothing serious","filed":0}\n```' };
  if (/Check-in/.test(t.title)) return { reply: "Nothing to run.\n\nLog: Nothing to do" };
  return { reply: "Which colour?\n\n## Questions\n1. 3 ⚪ Which colour?\n   - A. ⭐ Blue (80%) **calm**\n   - B. Red (40%) **loud**\n\nStatus: asks · Risk: none · Try: none" };
};
p.start();
const asks = actions.create({ projectId: project.id, title: "Add a greeting", prompt: "add greeting.txt", run: true });
const proposal = actions.create({ projectId: project.id, title: "Dark theme switch", prompt: "a theme switch" });
const member = actions.create({ projectId: project.id, title: "Fix a typo", prompt: "in the readme", batch: true });
await p.limits.read(true);
await handlers.get("scout")({ projectId: project.id, kind: "code" }, {});
await p.orchestrator.lookNow(true);
for (let i = 0; i < 100 && !(store.get(asks.id).brief && (p.scouts.state().runs ?? []).length); i++) {
  p.wake();
  await sleep(100);
}
await handlers.get("wake")({ number: Number(asks.id), inMinutes: 30, note: "look again" }, {});

// ---------- a stub layr.js and the panels over HTTP ----------
const STUB = `
(() => {
  const params = JSON.parse(new URLSearchParams(location.search).get("params") || "{}");
  const listeners = new Map();
  window.__opened = [];
  window.__notes = [];
  window.layr = {
    ready: Promise.resolve(),
    info: { params, state: {}, device: { id: "d_test", kind: new URLSearchParams(location.search).get("device") || "pc", name: "Test" } },
    tools: {
      run: async (tool, args = {}) => {
        const r = await fetch("/tool/" + tool, { method: "POST", body: JSON.stringify(args) });
        const body = await r.json();
        if (body.error) throw new Error(body.error);
        // The backend tells panels of changes with pipeline:changed; here every call does.
        setTimeout(() => listeners.get("pipeline:changed")?.({}), 50);
        return body.result;
      },
    },
    data: {
      get: async (key) => (await (await fetch("/data/" + encodeURIComponent(key))).json()).value,
      set: async (key, value) => void (await fetch("/data/" + encodeURIComponent(key), { method: "PUT", body: JSON.stringify({ value }) })),
      delete: async (key) => void (await fetch("/data/" + encodeURIComponent(key), { method: "DELETE" })),
    },
    events: { on: (topic, fn) => (listeners.set(topic, fn), () => {}) },
    panel: { setState: async () => {}, setTitle: async (t) => (document.title = t), onParams: (fn) => (window.__onParams = fn) },
    panels: { open: async (panel, params, opts) => window.__opened.push({ panel, params, opts }) },
    links: { open: async (url) => window.__opened.push({ link: url }) },
    ui: { notify: (text, kind) => window.__notes.push({ text, kind }) },
  };
})();`;
const css = readFileSync(path.resolve(root, "..", "..", "core", "layr_core", "assets", "layr.css"), "utf8");
const data = new Map();
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://x");
  if (url.pathname.startsWith("/data/")) {
    const key = decodeURIComponent(url.pathname.slice(6));
    let body = "";
    for await (const chunk of req) body += chunk;
    if (req.method === "PUT") data.set(key, JSON.parse(body).value);
    if (req.method === "DELETE") data.delete(key);
    res.setHeader("content-type", "application/json");
    return res.end(JSON.stringify({ value: data.get(key) ?? null }));
  }
  if (url.pathname.startsWith("/tool/")) {
    let body = "";
    for await (const chunk of req) body += chunk;
    const fn = handlers.get(url.pathname.slice(6));
    const r = fn ? await fn(JSON.parse(body || "{}"), { _meta: { "layr/caller": { kind: "panel", plugin: "pipeline" } } }) : { isError: true, content: [{ text: "no tool" }] };
    res.setHeader("content-type", "application/json");
    return res.end(JSON.stringify(r.isError ? { error: r.content[0].text } : { result: r.structuredContent }));
  }
  if (url.pathname === "/_layr/layr.js") return res.end(STUB);
  if (url.pathname === "/_layr/layr.css") return res.end(css);
  const file = path.join(root, url.pathname);
  try {
    const type = file.endsWith(".js") || file.endsWith(".mjs") ? "text/javascript" : file.endsWith(".css") ? "text/css" : "text/html";
    res.setHeader("content-type", type);
    res.end(readFileSync(file));
  } catch {
    res.statusCode = 404;
    res.end("not found");
  }
});
await new Promise((r) => server.listen(0, "127.0.0.1", r));
const base = `http://127.0.0.1:${server.address().port}`;

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 860 }, colorScheme: "dark" });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => m.type() === "error" && errors.push(m.text()));
const open = async (panel, params = {}, device = "pc") => {
  await page.goto(`${base}/panels/${panel}.html?device=${device}&params=${encodeURIComponent(JSON.stringify(params))}`);
  await sleep(700);
};
const cardOf = (n) => page.locator(`.card[data-number="${n}"]`);
const menuItems = async () => (await page.locator(".own-menu .item").allTextContents()).map((x) => x.replace(/^✓ /, ""));
const opened = () => page.evaluate(() => window.__opened);
try {
  await open("board");
  const info = await page.textContent(".infobar");
  check(!/usage guard|5h \d+%/i.test(info), "no usage guard chip on the board", info);
  check((await page.textContent("body")).includes("⏰"), "a wake-up chip on its card");
  check((await page.locator("button", { hasText: "Crew" }).count()) === 1, "a Crew button");
  await page.screenshot({ path: path.join(out, "board-crew.png") });

  // No task page: a started task's card opens its Claude thread; a proposal's opens Edit.
  check((await fetch(`${base}/panels/task.html`)).status === 404, "the task page is gone");
  await cardOf(asks.number).locator(".top .num").click();
  await sleep(200);
  const thread = (await opened()).at(-1);
  check(thread?.panel === "thread" && thread.params?.thread === store.get(asks.id).threadId && thread.opts?.plugin === "claude" && thread.opts?.reuse === true,
    "a started task's card opens its thread in the claude plugin (reuse)", JSON.stringify(thread));
  check(await cardOf(asks.number).evaluate((el) => el.classList.contains("selected-task")) && (await page.locator(".card.selected-task").count()) === 1,
    "the task whose thread opened is the selected one, marked on its card");
  // A click on a started task's text opens it in a floating window, not its thread.
  const openedBefore = (await opened()).length;
  await cardOf(asks.number).locator(".t").click();
  await sleep(200);
  check(await page.locator(".dialog.member-view").isVisible() && new RegExp(`#${asks.number}`).test(await page.textContent(".dialog.member-view h2")),
    "a started task's text opens it in a floating window");
  check((await opened()).length === openedBefore, "and not its thread");
  await page.keyboard.press("Escape");
  await sleep(100);
  check((await page.locator(".dialog.member-view").count()) === 0, "Esc closes the window");
  await cardOf(proposal.number).locator(".t").click();
  await sleep(300);
  check(new RegExp(`Task #${proposal.number}`).test(await page.textContent(".dialog h2")) && !/Pre-flight|Refine/.test(await page.textContent(".dialog")), "a proposal's card opens Edit, without a refiner");
  check(await page.locator(".dialog .prop.plan .mini-switch").count() === 1 && await page.locator(".dialog .prop.away .mini-switch").count() === 1, "the dialog has the two toggles, as small switches");
  check(await page.locator(".dialog .subtask-section button", { hasText: "Add sub-task" }).isVisible(), "a single proposal's Edit can add sub-tasks");
  check(await page.locator(".dialog .props .prop").filter({ hasText: "Model" }).isVisible(), "the options show without a More options fold");
  await page.locator(".dialog .dialog-foot .menu-btn").click();
  await sleep(200);
  check(!(await menuItems()).some((x) => /Add to/.test(x)), "a proposal's Edit has no Add to batch (⋯): sub-tasks are made in it", (await menuItems()).join(" | "));
  await page.keyboard.press("Escape");
  await sleep(150);
  // 📝 Plan is a toggle: nothing starts.
  await page.locator(".dialog .prop.plan .mini-switch").click();
  await sleep(1200);
  check(store.get(proposal.id).plan === true && !store.get(proposal.id).held && !store.get(proposal.id).threadId, "Plan in the dialog is a toggle: nothing starts");
  check(/Run plan/.test(await page.textContent(".dialog .dialog-foot")), "Run says it plans");
  await page.locator(".dialog .prop.plan .mini-switch").click();
  await sleep(1200);
  check(!store.get(proposal.id).plan, "and off again");
  // Edits are saved as you type, without Save; Close keeps them.
  await page.fill(".dialog textarea.layr-textarea >> nth=0", "Typed, never saved by hand");
  await sleep(1200);
  check(store.get(proposal.id).prompt === "Typed, never saved by hand", "a proposal's description saves itself", store.get(proposal.id).prompt);
  await page.fill(".dialog input.layr-input >> nth=0", `${proposal.title} (edited)`);
  await page.locator(".dialog .icon-close").click();
  await sleep(500);
  check(store.get(proposal.id).title === `${proposal.title} (edited)`, "Close keeps the last edit", store.get(proposal.id).title);
  // 0.5.2: a task waiting for one settled without landing shows that link, and "nothing" drops it.
  const gone = actions.create({ projectId: project.id, title: "Never landed", prompt: "x" });
  const child = actions.create({ projectId: project.id, title: "Waits for it", prompt: "y", after: Number(gone.id) });
  actions.settle(gone.id);
  await open("board");
  await cardOf(child.number).locator(".t").click();
  await sleep(300);
  const afterSelect = page.locator(".dialog select", { has: page.locator("option", { hasText: "nothing: when a slot is free" }) });
  check(/settled without landing: it never starts/.test((await afterSelect.locator("option:checked").textContent()) ?? ""), "Starts after shows the dead link",
    await afterSelect.locator("option:checked").textContent());
  await afterSelect.selectOption("");
  await sleep(1200);
  check(store.get(child.id).after === undefined, "and nothing drops it", store.get(child.id).after);
  await page.locator(".dialog .icon-close").click();
  await sleep(300);
  actions.remove(child.id);

  // The card menu (the panel's own here: the stub has no shell menu): windows, Hide, Copy link; Hide and ⊘ unhide.
  await cardOf(asks.number).click({ button: "right" });
  await sleep(200);
  const items = await menuItems();
  for (const want of ["Open its thread", "Open in VS Code", "Open in File Explorer", "Message…", "Tested ✓", "Hide", "Copy link"]) {
    check(items.includes(want), `the card menu has ${want}`, items.join(" | "));
  }
  await page.screenshot({ path: path.join(out, "board-menu.png") });
  await page.locator(".own-menu .item", { hasText: "Hide" }).click();
  await sleep(500);
  check(store.get(asks.id).hidden === true && (await cardOf(asks.number).count()) === 0, "Hide takes the card off the board");
  await page.locator(".header button", { hasText: "hidden" }).click();
  await sleep(200);
  check((await menuItems()).some((x) => x.startsWith(`Unhide #${asks.number}`)), "⊘ hidden lists it");
  await page.locator(".own-menu .item", { hasText: `Unhide #${asks.number}` }).click();
  await sleep(500);
  check(!store.get(asks.id).hidden && (await cardOf(asks.number).count()) === 1, "and unhides it");

  // Settled hidden takes no room; ✓ Settled shows it and hides it again.
  check((await page.locator('.column[data-column="settled"]').count()) === 0, "Settled is hidden: no column, no pill");
  await page.locator(".header button", { hasText: "Settled" }).click();
  await sleep(200);
  check((await page.locator('.column[data-column="settled"]').count()) === 1, "✓ Settled shows the column");
  await page.locator(".header button", { hasText: "Settled" }).click();
  await sleep(200);
  check((await page.locator('.column[data-column="settled"]').count()) === 0, "and hides it again");

  // A redraw (a change on the board) keeps where a column was scrolled to.
  const scrolledTo = await page.evaluate(() => {
    document.head.append(Object.assign(document.createElement("style"), { id: "short-columns", textContent: ".column-body { max-height: 60px; }" }));
    const b = document.querySelector('.column-body[data-column="proposed"]');
    b.scrollTop = 30;
    return b.scrollTop;
  });
  await page.locator(".header button", { hasText: "Settled" }).click();
  await page.locator(".header button", { hasText: "Settled" }).click();
  await sleep(200);
  const after = await page.evaluate(() => document.querySelector('.column-body[data-column="proposed"]').scrollTop);
  check(scrolledTo > 0 && after === scrolledTo, "a redraw keeps a column's scroll", `${scrolledTo} → ${after}`);
  await page.evaluate(() => document.getElementById("short-columns").remove());

  // A proposal's menu: Only you / Agents, batch, Delete asks in the panel's own confirm.
  await cardOf(proposal.number).locator(".more").click();
  await sleep(200);
  const pitems = await menuItems();
  for (const want of ["Edit", "📝 Plan", "🌙 When away", "🔒 Only you start it", "⚡ Agents may start it", "Delete"]) check(pitems.includes(want), `a proposal's menu has ${want}`, pitems.join(" | "));
  check(!pitems.some((x) => /Add to/.test(x)), "a proposal's menu has no Add to batch (task #88)", pitems.join(" | "));
  await page.locator(".own-menu .item", { hasText: "Delete" }).click();
  await sleep(200);
  check(/Delete proposal #/.test(await page.textContent(".ask-dialog")), "Delete asks in the panel's own confirm");
  await page.locator(".ask-dialog button", { hasText: "Cancel" }).click();
  await sleep(200);
  check(!!store.get(proposal.id), "Cancel keeps it");
  await page.keyboard.press("Escape");

  // Task #66: a task planning in Proposed has a thread, so no Delete: its menu offers Discard instead.
  const planner = actions.create({ projectId: project.id, title: "Plans in Proposed", prompt: "x", plan: true });
  store.mutate(planner.id, () => ({ threadId: "t_planner", planning: true, thread: { status: "done", turns: 1, pending: [] } }));
  await open("board");
  await sleep(500);
  await cardOf(planner.number).locator(".more").click();
  await sleep(200);
  const planItems = await menuItems();
  check(store.get(planner.id) && planItems.includes("Discard…") && !planItems.includes("Delete"), "a planning task in Proposed can be discarded", planItems.join(" | "));
  await page.keyboard.press("Escape");
  store.remove(planner.id);
  await open("board");
  await sleep(300);

  // A batch's tasks are edited in the batch's Edit (task #113): a click on one opens it at that one's line; its ×
  // deletes it on close, the card's × after asking; a right-click on its line takes it out of the batch.
  const second = actions.create({ projectId: project.id, title: "Fix a link", batch: true });
  const third = actions.create({ projectId: project.id, title: "Fix a colour", batch: true });
  await open("board");
  await sleep(500);
  const batchNo = store.get(store.get(member.id).inBatch).number;
  const memberOf = (title) => cardOf(batchNo).locator(".members .member", { hasText: title });
  await memberOf("Fix a typo").click();
  await sleep(300);
  check(new RegExp(`Batch #${batchNo}`).test(await page.textContent(".dialog h2")),
    "a batch's task opens the batch's Edit");
  const line = page.locator(`.dialog .subtask[data-member="${member.id}"] textarea`);
  const focused = await line.evaluate((e) => e === document.activeElement);
  check(focused && (await line.inputValue()) === "Fix a typo\nin the readme",
    "at its line, to edit right there", await line.inputValue());
  await line.fill("Fix two typos\nin the readme and the guide");
  await page.locator(`.dialog .subtask[data-member="${second.id}"] .sub-remove`).click();
  check((await page.locator(`.dialog .subtask[data-member="${second.id}"]`).count()) === 0 && !!store.get(second.id),
    "its × takes the line away, deleting it only on close");
  await page.locator(".dialog .icon-close").click();
  await sleep(800);
  check(store.get(member.id).title === "Fix two typos" && store.get(member.id).prompt === "in the readme and the guide",
    "the line edited is saved", JSON.stringify([store.get(member.id).title, store.get(member.id).prompt]));
  check(!store.get(second.id), "the one whose × was pressed is deleted on close");
  await open("board");
  await sleep(500);
  await memberOf("Fix a colour").hover();
  await memberOf("Fix a colour").locator(".member-remove").click();
  await sleep(200);
  await page.locator(".ask-dialog button", { hasText: "Delete" }).click();
  await sleep(500);
  check(!store.get(third.id), "the card's × deletes a sub-task after asking");
  await memberOf("Fix two typos").click();
  await sleep(300);
  await page.locator(`.dialog .subtask[data-member="${member.id}"]`).click({ button: "right" });
  await sleep(200);
  await page.locator(".own-menu .item", { hasText: "Take out of the batch" }).click();
  await sleep(500);
  const lineLeft = (await page.locator(`.dialog .subtask[data-member="${member.id}"]`).count()) === 0;
  check(!store.get(member.id).inBatch && lineLeft,
    "Take out of the batch");
  await page.locator(".dialog .icon-close").click();
  await sleep(300);

  // New task with sub-tasks: a batch whose tasks each get their own number; a second open batch of the project.
  await page.locator(".header button", { hasText: "New task" }).first().click();
  await sleep(300);
  await page.fill(".dialog input.title-input", "Pipeline polish");
  for (const [i, t] of ["Sub one", "Sub two"].entries()) {
    await page.locator(".dialog button", { hasText: "Add sub-task" }).click();
    await page.fill(`.dialog .subtask >> nth=${i} >> textarea`, t);
  }
  // One with only details below its first line still counts: nothing is dropped for want of a title.
  await page.locator(".dialog button", { hasText: "Add sub-task" }).click();
  await page.fill(".dialog .subtask >> nth=2 >> textarea", "Sub three\nits details");
  check(/New batch/.test(await page.textContent(".dialog h2")), "sub-tasks make it a New batch");
  await page.screenshot({ path: path.join(out, "new-batch-dialog.png") });
  await page.locator(".dialog .dialog-foot button", { hasText: "Save as proposal" }).click();
  await sleep(500);
  const made = store.entries().map(([, t]) => t).find((t) => t.title === "Pipeline polish");
  const subs = store.entries().map(([, t]) => t).filter((t) => t.inBatch === String(made?.number));
  check(made?.batch && subs.length === 3 && subs.map((t) => t.number).sort().join() === [1, 2, 3].map((k) => `${made.number}-${k}`).join(), "the batch and its three tasks, numbered in it", JSON.stringify(subs.map((t) => t.number)));
  check(subs.some((t) => t.title === "Sub three" && t.prompt === "its details"), "a sub-task's first line is its title, the rest its details", JSON.stringify(subs.map((t) => [t.title, t.prompt])));
  for (const t of [...subs, made].filter(Boolean)) actions.remove(String(t.number));

  // A proposal's Edit adds sub-tasks: on close it becomes a batch with them, keeping its own description.
  const single = actions.create({ projectId: project.id, title: "Thread polish", prompt: "All about threads" });
  await open("board");
  await sleep(500);
  await cardOf(single.number).locator(".t").click();
  await sleep(300);
  await page.locator(".dialog button", { hasText: "Add sub-task" }).click();
  await page.fill(".dialog .subtask >> nth=0 >> textarea", "Scroll keeps its place");
  check(/Batch #/.test(await page.textContent(".dialog h2")), "with a sub-task, the Edit says Batch");
  await page.screenshot({ path: path.join(out, "edit-dialog-subtasks.png") });
  await page.locator(".dialog .icon-close").click();
  await sleep(800);
  const grown = store.get(single.id);
  const its = store.entries().map(([, t]) => t).filter((t) => t.inBatch === single.id);
  check(grown.batch && grown.prompt === "All about threads" && its.length === 1 && its[0].title === "Scroll keeps its place", "the proposal became a batch with its sub-task", JSON.stringify({ batch: grown.batch, its: its.map((t) => t.title) }));
  for (const t of its) actions.remove(String(t.number));
  actions.remove(single.id);
  // Let the board redraw for it now, not in the middle of the table's drags below.
  await open("board");
  await sleep(800);

  // The table (task #50): views as tabs, headings that sort, Save into the backend, the search, the Columns picker,
  // resizing and moving columns, grouping, ▸ previews, the keys, ticked rows, a row's menu, Save as new.
  await page.locator(".header button", { hasText: "Table" }).click();
  await sleep(300);
  const tabs = await page.locator(".view-tab").allTextContents();
  check(["Open", "Waits for me", "Running", "Settled"].every((x) => tabs.some((y) => y.startsWith(x))), "the starting views as tabs", tabs.join(", "));
  const heads = await page.locator("table.grid th[data-col]").allTextContents();
  check(["#", "Title", "Stage", "Status", "Note", "Actions"].every((x) => heads.some((y) => y.startsWith(x))) && !heads.some((y) => y.startsWith("Project")),
    "Open's columns (no Project with one project)", heads.join(", "));
  const rowCount = await page.locator("table.grid tr.task-row").count();
  const onBoard = store.entries().filter(([id, t]) => !t.inBatch && !t.hidden && p.view(id).column !== "settled").length;
  check(rowCount === onBoard && rowCount >= 2, "every open task is a row", `${rowCount} of ${onBoard}`);
  check((await page.locator(`tr.task-row[data-number="${proposal.number}"] td.actions-cell button`, { hasText: "Run" }).count()) === 1, "a proposal's next step is Run");
  await page.locator("table.grid th[data-col=title]").click();
  await sleep(200);
  const titles = await page.locator("table.grid td.title-cell").allTextContents();
  check(titles.length === rowCount && titles.every((x, i) => !i || titles[i - 1].localeCompare(x) <= 0), "sorted by title", titles.join(" | "));
  check((await page.locator(".save-bar").count()) === 1, "a changed view offers Save");
  await page.locator(".save-bar button", { hasText: /^Save$/ }).click();
  await sleep(400);
  check(store.views()?.find((v) => v.id === "open")?.sorts?.[0]?.by === "title" && (await page.locator(".save-bar").count()) === 0, "Save puts the view in the backend", JSON.stringify(store.views()?.[0]?.sorts));
  await page.fill(".header .search", "greeting");
  await sleep(200);
  check((await page.locator("table.grid tr.task-row").count()) === 1, "the search narrows the rows");
  await page.locator(".save-bar button", { hasText: "Reset" }).click();
  await sleep(300);
  check((await page.locator("table.grid tr.task-row").count()) === rowCount && (await page.inputValue(".header .search")) === "", "Reset takes the search back");

  // Columns: tick Branch in the picker; resize Title by its edge; drag Status before #.
  await page.locator(".columns-btn").click();
  await sleep(200);
  await page.screenshot({ path: path.join(out, "board-table-columns.png") });
  await page.locator(".col-item", { hasText: "Branch" }).locator("input").check();
  await sleep(200);
  await page.keyboard.press("Escape");
  check((await page.locator("table.grid th[data-col=branch]").count()) === 1, "the Columns picker shows a column");
  const grip = page.locator("table.grid th[data-col=note] .resize");
  const gb = await grip.boundingBox();
  const noteBefore = (await page.locator("table.grid th[data-col=note]").boundingBox()).width;
  await page.mouse.move(gb.x + 3, gb.y + gb.height / 2);
  await page.mouse.down();
  await page.mouse.move(gb.x + 83, gb.y + gb.height / 2, { steps: 5 });
  await page.mouse.up();
  await sleep(300);
  const noteAfter = (await page.locator("table.grid th[data-col=note]").boundingBox()).width;
  check(Math.abs(noteAfter - noteBefore - 80) <= 3, "dragging a heading's edge resizes it", `${noteBefore} → ${noteAfter}`);
  await page.dragAndDrop("table.grid th[data-col=status]", "table.grid th[data-col=number]", { targetPosition: { x: 4, y: 10 } });
  await sleep(300);
  const order = await page.locator("table.grid th[data-col]").evaluateAll((ths) => ths.map((th) => th.dataset.col));
  check(order[0] === "status", "dragging a heading moves its column", order.join(", "));

  // Group by stage; ▸ opens a row's description and buttons.
  await page.locator(".group-btn").click();
  await sleep(150);
  await page.locator(".own-menu .item", { hasText: "Stage" }).click();
  await sleep(300);
  const groupsShown = await page.locator("tr.group-row").allTextContents();
  check(groupsShown.length === 2 && /Proposed/.test(groupsShown[0]) && /Stopped/.test(groupsShown[1]), "grouped by stage, left to right", groupsShown.join(" | "));
  await page.locator(`tr.task-row[data-number="${proposal.number}"] button.expand`).click();
  await sleep(300);
  const preview = await page.textContent("tr.preview-row");
  check(/Description/.test(preview) && /Plan/.test(preview), "▸ shows its description and every button", preview.slice(0, 120));
  await page.screenshot({ path: path.join(out, "board-table.png") });
  await page.locator("tr.group-row").first().click();
  await sleep(200);
  check((await page.locator(`tr.task-row[data-number="${proposal.number}"]`).count()) === 0, "a group folds");
  await page.locator("tr.group-row").first().click();
  await sleep(200);

  // Save as new: a view of its own, in the backend.
  await page.locator(".save-bar button", { hasText: "Save as new" }).click();
  await sleep(200);
  await page.fill(".ask-dialog input", "By stage");
  await page.locator(".ask-dialog button", { hasText: "OK" }).click();
  await sleep(500);
  const saved = store.views() ?? [];
  check(saved.length === 5 && saved.at(-1).name === "By stage" && saved.at(-1).group === "stage" && saved.at(-1).widths.note > 0, "Save as new keeps a view of its own", saved.map((v) => v.name).join(", "));
  check((await page.locator(".view-tab.on").textContent()).startsWith("By stage"), "and shows it");
  await page.screenshot({ path: path.join(out, "board-table-grouped.png") });

  // The keys: ↓ picks a row, Space ticks it, Enter opens it.
  await page.locator(".view-tab", { hasText: "Open" }).click();
  await sleep(300);
  await page.mouse.click(5, 850);
  await page.keyboard.press("ArrowDown");
  await page.keyboard.press("ArrowDown");
  await sleep(100);
  check((await page.locator("tr.task-row.selected").count()) === 1, "↓ picks a row");
  await page.keyboard.press("Space");
  await sleep(200);
  check((await page.locator("tr.task-row.picked").count()) === 1 && /1 ticked/.test(await page.textContent(".table-tools.bulk")), "Space ticks it");
  await page.keyboard.press("Escape");
  await sleep(200);
  check((await page.locator("tr.task-row.picked").count()) === 0, "Esc unticks");

  // Ticked rows: Hide them all, after the confirm.
  await page.locator("thead input.pick").check();
  await sleep(200);
  const bulk = await page.textContent(".table-tools.bulk");
  check(new RegExp(`${rowCount} ticked`).test(bulk) && /Run · \d/.test(bulk) && /Settle · 1/.test(bulk) && /Hide/.test(bulk), "ticking every row offers what fits them", bulk);
  await page.screenshot({ path: path.join(out, "board-table-ticked.png") });
  await page.locator(".table-tools.bulk button", { hasText: "Hide" }).click();
  await sleep(200);
  check(new RegExp(`Hide: ${rowCount} tasks`).test(await page.textContent(".ask-dialog")), "acting on ticked rows asks first");
  await page.locator(".ask-dialog button", { hasText: "Hide" }).click();
  await sleep(600);
  const hiddenNow = store.entries().filter(([, t]) => t.hidden);
  check(hiddenNow.length === rowCount, "and hides them all", `${hiddenNow.length}`);
  for (const [id] of hiddenNow) actions.edit(id, { hidden: false });
  await sleep(400);

  const askRow = page.locator(`tr.task-row[data-number="${asks.number}"]`);
  await askRow.locator("td.title-cell").click({ button: "right" });
  await sleep(200);
  check((await menuItems()).includes("Copy link"), "a row has the card's menu");
  await page.keyboard.press("Escape");
  await askRow.locator("td.title-cell").click();
  await sleep(200);
  check((await opened()).at(-1)?.panel === "thread", "a row opens its thread");
  await page.locator(".header button", { hasText: "Columns" }).click();
  await sleep(200);

  // Task links: {task: N} reveals the card (unhidden, flashed); {link} too, also through onParams.
  actions.edit(proposal.id, { hidden: true });
  await open("board", { task: proposal.number });
  check(!store.get(proposal.id).hidden && (await cardOf(proposal.number).count()) === 1, "a task link unhides its card");
  check(/flash/.test((await cardOf(proposal.number).getAttribute("class")) ?? ""), "and flashes it");
  await page.screenshot({ path: path.join(out, "board-reveal.png") });
  await sleep(2800);
  await page.evaluate((n) => window.__onParams({ link: `layr://pipeline/task/${n}` }), asks.number);
  await sleep(400);
  check(/flash/.test((await cardOf(asks.number).getAttribute("class")) ?? ""), "a link given later (onParams) reveals its card");

  // Decide round: a thread opens with reuse.
  await page.locator(".header button", { hasText: "Decide round" }).click();
  await sleep(600);
  const round = (await opened()).at(-1);
  check(round?.panel === "thread" && round.opts?.reuse === true && /^t_|./.test(round.params?.thread ?? ""), "Decide round opens its thread", JSON.stringify(round));

  // 0.4.0: ◆ linked nodes open their node; ⚠ checkout drift with its files; the Rounds menu; Send a scout asks first.
  store.mutate(asks.id, () => ({ checkout: { files: [" M src/app.js"], more: 2, branch: "side", at: new Date().toISOString() } }));
  await open("board");
  await sleep(500);
  const nodesChip = cardOf(asks.number).locator("button.chip.nodes");
  check((await nodesChip.textContent()) === "◆ 1", "a ◆ chip with the linked node", await nodesChip.textContent());
  const drift = cardOf(asks.number).locator(".chip.checkout");
  check(/⚠ checkout on side · 3 uncommitted/.test((await drift.textContent()) ?? "") && /src\/app\.js[\s\S]*2 more/.test((await drift.getAttribute("title")) ?? ""),
    "⚠ checkout with the files in its tooltip", await drift.textContent());
  await page.screenshot({ path: path.join(out, "board-nodes.png") });
  const before = (await opened()).length;
  await nodesChip.click();
  await sleep(200);
  check((await opened()).at(-1)?.link === `layr://concepts/node/${NODE}`, "◆ opens the node's link", JSON.stringify((await opened()).at(-1)));
  check((await opened()).length === before + 1, "and not the card's thread");
  store.mutate(asks.id, () => ({ checkout: undefined }));
  await page.locator(".header button.rounds").click();
  await sleep(200);
  const rounds = await menuItems();
  check(["What's stuck?", "Land the safe ones", "Brief me on what's running", "Send a scout…"].every((x) => rounds.includes(x)), "the Rounds menu", rounds.join(" | "));
  await page.screenshot({ path: path.join(out, "board-rounds.png") });
  await page.locator(".own-menu .item", { hasText: "What's stuck?" }).click();
  await sleep(600);
  check((await opened()).at(-1)?.panel === "thread" && /What's stuck/.test(claude.calls.filter((c) => c[0] === "start").at(-1)[1].title), "What's stuck? opens its thread");
  await open("board", { round: "scout" });
  await page.fill(".ask-dialog textarea", "slow queries in sync");
  await page.locator(".ask-dialog button", { hasText: "Send" }).click();
  await sleep(600);
  const scoutRound = claude.calls.filter((c) => c[0] === "start").at(-1)[1];
  check(/Send a scout/.test(scoutRound.title) && /slow queries in sync/.test(scoutRound.prompt), "Send a scout asks what to look for", scoutRound.title);

  // 0.5.0: 🌙 When Away on a proposal, Ready's pacing line, the size chip, Away asking when you're back.
  await open("board");
  const night = actions.create({ projectId: project.id, title: "Night proposal", prompt: "for tonight", size: "S" });
  await open("board");
  await cardOf(night.number).locator("button", { hasText: "🌙" }).click();
  await sleep(500);
  check(p.view(night.id).column === "ready", "🌙 puts a proposal in Ready", p.view(night.id).column);
  const readyCol = page.locator('.column[data-column="ready"]');
  check(/Ready 1 ≈ \d+%/.test((await readyCol.locator(".pace-line").textContent()) ?? ""), "Ready's pacing line", await readyCol.locator(".pace-line").textContent().catch(() => ""));
  check((await readyCol.locator("button.toggle-pill.on", { hasText: "When away" }).count()) === 1, "its card shows 🌙 When away on (the way back to Proposed)");
  await page.screenshot({ path: path.join(out, "board-ready-pacing.png") });
  await cardOf(night.number).locator("button.size-chip").click();
  await sleep(200);
  await page.locator(".own-menu .item", { hasText: "L: large change" }).click();
  await sleep(400);
  check(store.get(night.id).size === "L", "the size chip changes the size", store.get(night.id).size);
  // Out of Ready first, or Away would launch it.
  actions.parked(night.id, "drop");
  actions.remove(night.id);
  await page.locator('.modes button[data-mode="away"]').click();
  await sleep(300);
  check(/When are you back/.test((await page.textContent(".ask-dialog")) ?? ""), "Away asks when you're back");
  await page.fill(".ask-dialog input", "07:30");
  await page.locator(".ask-dialog button", { hasText: "Away" }).click();
  await sleep(600);
  const backAt = new Date(store.state().awayUntil ?? 0);
  check(store.global().mode === "away" && backAt.getHours() === 7 && backAt.getMinutes() === 30, "and keeps it", store.state().awayUntil);
  check(/back at 07:30/.test(await page.textContent(".infobar")), "the info bar says when you're back");
  p.setMode("here");

  // On a phone: no VS Code, File Explorer or ▶ Try.
  await open("board", {}, "phone");
  await cardOf(asks.number).click({ button: "right" });
  await sleep(200);
  const phone = await menuItems();
  check(!phone.includes("Open in VS Code") && !phone.includes("Open in File Explorer") && !phone.some((x) => x.includes("▶ Try")), "a phone's menu has no PC windows", phone.join(" | "));
  await page.keyboard.press("Escape");
  check((await page.locator(".header button", { hasText: "Table" }).count()) === 0, "no table on a phone");

  await open("decide");
  const decide = await page.textContent("body");
  check(/It asks you/.test(decide) && /Questions/.test(decide), "Decide shows the brief with the question");
  await page.screenshot({ path: path.join(out, "decide-brief.png"), fullPage: true });

  await open("settings", { tab: "crew" });
  const crew = await page.textContent("body");
  for (const part of ["Orchestrator", "Scouts", "Keep up to date", "Test lanes", "Nothing to do", "nothing serious"]) {
    check(crew.includes(part), `Crew shows ${part}`);
  }
  check(!/Retro|Usage guard/.test(crew), "Crew has no retro or usage guard");
  await page.screenshot({ path: path.join(out, "settings-crew.png"), fullPage: true });

  await open("settings", { tab: "global" });
  const global = await page.textContent("body");
  check(!/Usage guard|Retro/.test(global) && /Orchestrator/.test(global) && /Scouts at once/.test(global), "Global has the crew's settings");
  await page.screenshot({ path: path.join(out, "settings-global-crew.png"), fullPage: true });

  // Task threads: Model and Effort under Global's first heading; every model setting is a drop-down.
  const groups = await page.locator("h3.group").allTextContents();
  check(groups[0] === "Task threads", "Task threads is Global's first heading", groups.join(", "));
  const row = (key) => page.locator(`[data-key="${key}"]`);
  const opts = await row("workerModel").locator("option").allTextContents();
  check(JSON.stringify(opts) === JSON.stringify(["the claude project's default", "opus", "sonnet", "haiku", "Other…"]), "Model: default, the aliases, Other…", opts.join(", "));
  for (const key of ["verifierModel", "briefModel", "scoutModel", "orchestratorModel"]) {
    const o = await row(key).locator("option").allTextContents();
    check(JSON.stringify(o) === JSON.stringify(["opus", "sonnet", "haiku", "Other…"]), `${key} is a drop-down without an empty choice`, o.join(", "));
  }
  check((await row("briefModel").locator("select").inputValue()) === "haiku", "the briefs show haiku");
  check(!(await row("workerModel").locator("input").isVisible()), "no model id field until Other…");
  await row("workerModel").locator("select").selectOption("__other__");
  check(await row("workerModel").locator("input").isVisible(), "Other… shows the model id field");
  await row("workerModel").locator("input").fill("claude-opus-4-1");
  await row("workerModel").locator("input").press("Tab");
  await sleep(600);
  check(store.global().workerModel === "claude-opus-4-1", "the id is saved as the global model", store.global().workerModel);
  check((await row("workerModel").locator("select").inputValue()) === "__other__" && (await row("workerModel").locator("input").inputValue()) === "claude-opus-4-1", "a saved id shows as Other… with the id");
  await row("workerEffort").locator("select").selectOption("high");
  await sleep(600);
  check(store.global().workerEffort === "high", "the global effort is saved", store.global().workerEffort);
  await row("orchestratorEffort").locator("select").selectOption("");
  await sleep(600);
  check(store.global().orchestratorEffort === null && (await row("orchestratorEffort").locator("select").inputValue()) === "", "an effort can go back to the model's default");
  await page.screenshot({ path: path.join(out, "settings-global-models.png"), fullPage: true });

  await open("settings", { tab: project.id });
  const first = async (key) => (await row(key).locator("option").first().textContent()) ?? "";
  check((await first("workerModel")) === "the global value: claude-opus-4-1", "a project's empty model names the global one", await first("workerModel"));
  check((await first("workerEffort")) === "the global value: high", "and its empty effort", await first("workerEffort"));
  check((await first("verifierModel")) === "the global value: sonnet", "and its empty verifier model", await first("verifierModel"));
  check((await row("maxRunning").locator("input").getAttribute("placeholder")) === "the global value: 2", "and its empty running cap");
  await row("workerModel").locator("select").selectOption("haiku");
  await sleep(600);
  check(store.project(project.id).workerModel === "haiku", "a project picks its own model");
  await row("workerModel").locator("select").selectOption("");
  await sleep(600);
  check(store.project(project.id).workerModel === null, "and back to the global value");
  await page.screenshot({ path: path.join(out, "settings-project-models.png"), fullPage: true });
  const projectTab = await page.textContent("body");
  check(/Icon/.test(projectTab) && /Colour/.test(projectTab) && /▶ Try command/.test(projectTab), "a project has Icon, Colour and ▶ Try command");
  await row("color").locator(`.swatch[title="#0090ff"]`).click();
  await sleep(600);
  check(store.project(project.id).color === "#0090ff", "a colour swatch saves", store.project(project.id).color);
  await page.screenshot({ path: path.join(out, "settings-project-look.png"), fullPage: true });

  // 0.4.0: the project node: search, pick, Open, Set up project map.
  await row("projectNode").locator("input[type=search]").fill("Demo");
  await sleep(700);
  await row("projectNode").locator(".node-hit").first().click();
  await sleep(700);
  check(store.project(project.id).projectNode === NODE, "a picked node is the project node", store.project(project.id).projectNode);
  await row("projectNode").scrollIntoViewIfNeeded();
  await page.screenshot({ path: path.join(out, "settings-project-node.png") });
  await row("projectNode").locator("button", { hasText: "Open" }).click();
  await sleep(200);
  check((await opened()).at(-1)?.link === `layr://concepts/node/${NODE}`, "Open opens the node");
  await row("projectNode").locator("button", { hasText: "Set up project map" }).click();
  await sleep(400);
  check(hubCalls.some(([n, a]) => n === "concepts__setup_project_map" && a.node === NODE), "Set up project map asks the concepts plugin");
  check((await page.evaluate(() => window.__notes.at(-1)?.text)) === "Made: Rules, Plan", "and says what it made");

  // 0.4.0: Import from layr_code (Global): what it would fill, a confirm, then filled.
  await open("settings", { tab: "global" });
  await page.locator("button", { hasText: "Import from layr_code" }).click();
  await sleep(600);
  check(/Fill \d+ empty setting/.test(await page.textContent(".ask-dialog")), "the import asks first, with a count");
  check(/▶ Try command/.test(await page.textContent(".import-result")), "and lists what it would fill");
  await page.locator(".ask-dialog button", { hasText: "Fill them" }).click();
  await sleep(900);
  check(store.project(project.id).tryCommand === "pnpm dev" && store.project(project.id).landing === "push", "filled the empty settings", store.project(project.id).tryCommand);
  check(store.project(project.id).baseBranch === "main" && store.project(project.id).laneRun === "npm run dev", "kept the ones set here", store.project(project.id).baseBranch);
  check(/Imported on/.test(await page.textContent(".import")), "says when it imported");
  await page.screenshot({ path: path.join(out, "settings-import.png") });

  await open("board", { new: true });
  check((await page.locator(".dialog .attach-btn").count()) === 1, "the new-task dialog can attach files");

  // The new-task dialog keeps what you wrote, and only a click on the backdrop itself closes it.
  await page.fill(".dialog input.layr-input", "Kept title");
  await page.fill(".dialog textarea", "kept details");
  const box = await page.locator(".dialog textarea").boundingBox();
  await page.mouse.move(box.x + 10, box.y + 10);
  await page.mouse.down();
  await page.mouse.move(5, 5, { steps: 5 });
  await page.mouse.up();
  check((await page.locator(".dialog").count()) === 1, "a drag that ends on the backdrop leaves the dialog open");
  await page.mouse.click(5, 5);
  await sleep(300);
  check((await page.locator(".dialog").count()) === 0, "a click on the backdrop closes it");
  check(data.get("draft:new-task")?.title === "Kept title", "what you wrote is kept as a draft", JSON.stringify(data.get("draft:new-task")));
  await open("board", { new: true });
  check((await page.inputValue(".dialog input.layr-input")) === "Kept title" && (await page.inputValue(".dialog textarea")) === "kept details", "reopened, the dialog shows it again");
  await page.locator(".dialog button", { hasText: "Clear" }).click();
  await sleep(300);
  check((await page.inputValue(".dialog input.layr-input")) === "" && !data.has("draft:new-task"), "Clear empties it and forgets the draft");
  await page.fill(".dialog input.layr-input", "Made from a draft");
  await page.locator(".dialog button", { hasText: "Save as proposal" }).click();
  await sleep(600);
  check(store.entries().some(([, t]) => t.title === "Made from a draft") && !data.has("draft:new-task"), "making the task forgets the draft");
  check(errors.length === 0, "no page errors", errors.join(" | "));
} finally {
  await browser.close();
  server.close();
  p.stop();
  try {
    rmSync(tmp, { recursive: true, force: true, maxRetries: 3 });
  } catch {
    // Windows may hold a file a moment longer
  }
}
console.log(failures ? `${failures} failed` : "all passed");
process.exit(failures ? 1 : 0);
