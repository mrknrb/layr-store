// A task's card (the board, Decide), its toggles, its buttons and its ⋯ / right-click menu. The two toggles (📝 Plan,
// 🌙 When away) and the buttons of a started task come from the backend (`t.toggles`, `t.buttons`, backend/buttons.js:
// the claude plugin's thread panel shows the same); a proposal's own (Run, Edit) are drawn here. A click opens a started task's Claude thread, or a
// proposal's Edit dialog; a click on a started task's text opens it read-only in a floating window (taskView); a click
// on a task listed in a batch's card opens the batch's Edit at that task (or taskView once the batch has started), its
// × deletes it. The task whose thread was opened last is the selected one (common.js selectedThread), marked on its
// card.
import {
  act,
  ago,
  api,
  button,
  cacheBadge,
  chip,
  clock,
  confirmMenu,
  contextMenu,
  copyText,
  h,
  icon,
  layr,
  LETTER,
  markdown,
  onPhone,
  openThread,
  projectLabel,
  promptMenu,
  selectedThread,
  taskLink,
  TONE,
} from "./common.js";

export const STAKES_TONE = { high: "danger", medium: "warning", low: "neutral" };

/** It stopped with a reply that asks the user (Status: asks), and nothing else runs for it. */
export const asks = (t) => t.column === "stopped" && t.thread?.replyStatus?.status === "asks" && !t.landed;

/**
 * A started task's text (its title, or `text`: its description's start): a click on it opens the task in a floating
 * window (taskView), not its thread.
 */
export function taskText(t, tag = "div.t", text = t.title) {
  if (!t.threadId) return h(tag, {}, text);
  return h(`${tag}.task-text`, { title: "See it (its description, files, sub-tasks)", onclick: (e) => (e.stopPropagation(), taskView(t)) }, text);
}

/** What a click on a task does: a started one's thread; a proposal's Edit dialog. */
export function openTask(t, ctx) {
  if (t.threadId) return openThread(t.threadId);
  return ctx.onEdit?.(t);
}

/** The call behind one of the backend's buttons (`b.id`) for task number `n`, without asking first. */
export function buttonCall(id, n) {
  const calls = {
    run: () => api("run", { number: n }),
    approve: () => api("act", { action: "approve", number: n }),
    start: () => api("act", { action: "start", number: n }),
    stop: () => api("stop", { number: n }),
    land: () => api("land", { number: n }),
    try: () => api("try", { number: n }),
    settle: () => api("settle", { number: n }),
    unsettle: () => api("unsettle", { number: n }),
    discard: () => api("act", { action: "discard", number: n }),
    brief: () => api("brief", { number: n }),
    unpark: () => api("act", { action: "parked", op: "drop", number: n }),
    away_on: () => api("edit", { number: n, whenAway: true }),
    away_off: () => api("edit", { number: n, whenAway: false }),
  };
  return calls[id]();
}

/** Press one of the backend's buttons (`t.buttons`): asks first when it has a confirm text. */
export async function press(t, b) {
  if (b.confirm && !(await confirmMenu(b.confirm, { ok: b.label.replace(/^▶ /, ""), danger: b.kind === "danger" || b.id === "discard" }))) return;
  const done = { try: "▶ Trying it in a window on the PC", brief: "Brief written" };
  return act(() => buttonCall(b.id, t.number), done[b.id]);
}

/** The backend's buttons a device shows: on a phone, none that open windows on the PC. */
export const shownButtons = (t) => (t.buttons ?? []).filter((b) => !(b.pc && onPhone()));

/**
 * A task's card. `ctx`: { projects (by id), multi (show the project), byId, lanes, onEdit(t), folded (Set of ids),
 * onFold(t), onHide(t) }.
 */
export function card(t, ctx) {
  const tone = asks(t) ? "danger" : (TONE[t.why] ?? "neutral");
  const folded = ctx.folded?.has(t.id);
  const selected = !!t.threadId && t.threadId === selectedThread();
  const el = h(`article.card.tone-${tone}${t.why === "landed" ? ".landed" : ""}${folded ? ".folded" : ""}${t.hidden ? ".hidden-card" : ""}${selected ? ".selected-task" : ""}`, {
    "data-id": t.id,
    "data-number": t.number,
    "data-thread": t.threadId ?? undefined,
    title: [t.threadId ? "Open its Claude thread" : "Edit the proposal", t.branch && `branch ${t.branch}`, t.worktreePath && `worktree ${t.worktreePath}`, t.model && `model ${t.model}`].filter(Boolean).join("\n"),
    onclick: () => openTask(t, ctx),
    oncontextmenu: (e) => cardMenu(t, ctx, e),
  });
  const project = ctx.projects?.[t.projectId];
  if (project?.color) el.style.setProperty("--project", project.color);
  const showLetter = !["proposal", "ready", "running", "settled"].includes(t.why);
  const more = h("button.more", { title: "More", onclick: (e) => (e.stopPropagation(), cardMenu(t, ctx, e)) }, "⋯");
  el.append(
    h(
      "div.top",
      {},
      h("span.num", {}, `#${t.number}`),
      showLetter ? h(`span.letter.tone-${tone}`, { title: asks(t) ? "its reply asks you" : t.state }, asks(t) ? "?" : (LETTER[t.why] ?? "·")) : null,
      ctx.multi || project?.icon ? projectLabel(project, { title: !!ctx.multi }) : null,
      t.source?.kind && !["you", "batch"].includes(t.source.kind) ? h("span", {}, { agent: "agent", adopted: "added", scout: "scout", orchestrator: "orchestrator" }[t.source.kind] ?? t.source.kind) : null,
      sizeChip(t),
      h("span.grow"),
      cacheBadge(t),
      t.column === "running" && !t.waits ? h("span.pulse.live") : null,
      h("span", {}, ago(t.updatedAt)),
      more,
    ),
    folded ? null : taskText(t),
  );
  if (folded) {
    el.querySelector(".top .grow").replaceWith(taskText(t, "span.t.grow"));
    return el;
  }
  const about = promptStart(t.prompt);
  if (about) el.append(taskText(t, "div.about", about));
  // A proposal's note is its description's first line: the start above shows it already.
  const promptLine = t.column === "proposed" && t.note === String(t.prompt ?? "").split("\n")[0];
  if (t.note && !(about && promptLine)) el.append(h("div.note", {}, t.note));
  if (t.why === "question" || asks(t)) el.append(h("span.needs-dot"));
  const badges = cardBadges(t, ctx);
  el.append(badges);
  if (t.batch && t.members?.length) {
    const report = new Map((t.batchReport ?? []).map((r) => [r.number, r]));
    el.append(h("div.members", {}, t.members.map((m) => memberRow(ctx.byId?.[m.id] ?? m, t, ctx.onEdit, report))));
  }
  const pills = togglePills(t);
  if (pills) el.append(pills);
  el.append(cardActions(t, ctx));
  return el;
}

/**
 * The start of a task's description, as plain text, for its card: its first `max` characters (a longer one is cut at
 * a word, with "…"); "" when it has none.
 */
export function promptStart(text, max = 200) {
  const plain = String(text ?? "")
    .replace(/```[\s\S]*?(```|$)/g, " ")
    .replace(/!\[[^\]]*\]\([^)]*\)/g, " ")
    .replace(/\[([^\]]*)\]\([^)]*\)/g, "$1")
    .replace(/^\s{0,3}(#{1,6}|>|[-*+]|\d+\.)\s+/gm, "")
    .replace(/[*_`~]+/g, "")
    .replace(/\s+/g, " ")
    .trim();
  if (plain.length <= max) return plain;
  const cut = plain.slice(0, max);
  const space = cut.lastIndexOf(" ");
  return `${(space > max * 0.6 ? cut.slice(0, space) : cut).trimEnd()}…`;
}

/** What the two toggles mean, for their tooltips. */
export const TOGGLE_ABOUT = {
  plan: "📝 Plan: Run makes its worker plan and ask first. It stays in Proposed until you Approve; then the work starts.",
  whenAway: "🌙 When away: its work waits until you're Away (and the accounts have room). On a running thread, what you send it waits too. A toggle: nothing runs by itself.",
};

/** Flip one of a task's toggles (`which`: plan or whenAway). */
export const flipToggle = (t, which, on = !t.toggles?.[which]?.on) =>
  act(() => api("edit", { number: t.number, [which]: on }), which === "whenAway" ? (on ? "🌙 Waits for Away" : "🌙 When away off") : on ? "📝 Plans first" : "📝 Plan off");

/** One toggle as a pill: on, off, or not changeable now (its reason in the tooltip). */
export function togglePill(t, which, { label } = {}) {
  const g = t.toggles?.[which];
  if (!g) return null;
  const text = label ?? (which === "plan" ? "📝 Plan" : "🌙 When away");
  return h(`button.toggle-pill${g.on ? ".on" : ""}${which === "whenAway" ? ".away" : ".plan"}`, {
    type: "button",
    role: "switch",
    "aria-checked": String(g.on),
    disabled: !g.can,
    title: `${TOGGLE_ABOUT[which]}${g.can ? "" : `\nCan't change now: ${g.why}`}`,
    onclick: (e) => (e.stopPropagation(), flipToggle(t, which)),
  }, h("span.knob"), text);
}

/** A card's toggles: Plan on proposals (and a planning thread, to take it back); When away while it can change. */
export function togglePills(t) {
  const g = t.toggles;
  if (!g || t.inBatch || t.settledAt) return null;
  const plan = !t.threadId || g.plan.on ? togglePill(t, "plan") : null;
  const away = g.whenAway.can || g.whenAway.on ? togglePill(t, "whenAway") : null;
  if (!plan && !away) return null;
  return h("div.toggles", {}, plan, away);
}

/** A task's chips: its batch, who starts it, its chain, ◆ nodes, risks, the verifier, stakes, the lane, PR… */
export function cardBadges(t, ctx = {}) {
  const badges = h("div.badges");
  if (t.batch) badges.append(chip(`📦 batch · ${t.members?.length ?? 0}`, "accent"));
  if (t.tested) badges.append(chip("tested ✓", "success", `You tested it (${new Date(t.tested).toLocaleString()})`));
  if (t.controversial) badges.append(chip("🚩 controversial", "danger", `You marked it controversial (${new Date(t.controversial).toLocaleString()})`));
  if (t.skipped) badges.append(chip(`skipped by batch #${t.skipped.batch}`, "warning", t.skipped.why));
  const bg = t.thread?.missing ? [] : (t.thread?.background ?? []);
  if (bg.length) {
    const tip = bg.map((b) => `${b.agent ?? b.type ?? "task"}: ${b.description || b.id}`).join("\n");
    badges.append(chip(`⚙ ${bg.length} in background`, "info", tip));
  }
  if (!t.threadId && t.start === "agents") badges.append(chip("⚡ agents", "info"));
  if (!t.threadId && t.start === "manual") badges.append(chip("🔒 only you", "neutral"));
  if (t.after) {
    const parent = ctx.byId?.[t.after];
    badges.append(chip(`after #${parent?.number ?? t.after}${parent?.landed ? " ✓" : ""}`, "neutral"));
  }
  if (t.autoMerge && !t.landed) badges.append(chip("auto-merge", "info"));
  if (t.agentLands && !t.autoMerge && !t.landed) badges.append(chip(t.agentAskedLand && t.landing ? "🤖 agent landing" : "🤖 agent lands", "info", "Its agent starts the landing when it is done and everything went well"));
  if (t.noWorktree) badges.append(chip("no worktree", "neutral"));
  else if (t.worktreeGone && ctx.worktreeMark !== false) {
    badges.append(chip("⌀ worktree", "muted", "Its worktree was removed: its work is on the base branch. A message to its thread makes it again, from the newest base branch."));
  }
  if (t.worktreeProblem && !t.worktreeGone) badges.append(chip("worktree stays", "warning", `Its worktree couldn't be removed: ${t.worktreeProblem.text}`));
  if (!t.settledAt && (t.checkout?.files?.length || t.checkout?.branch)) badges.append(checkoutChip(t.checkout));
  const nodes = ctx.linked?.[t.id ?? String(t.number)];
  if (nodes?.length) badges.append(nodesChip(nodes));
  if (t.ask?.risks?.length || t.ask?.paths?.length) badges.append(chip(t.ask.risks.length ? t.ask.risks.join(", ") : "always ask", "danger", (t.ask.paths ?? []).join("\n")));
  if (t.verify) {
    const v = { queued: "verify queued", running: "verifying…", fixing: `verifier: fixes sent (${t.verify.rounds}/2)`, you: "verifier: needs you", passed: "verified ✓" }[t.verify.state];
    if (v) badges.append(chip(v, t.verify.state === "passed" ? "success" : t.verify.state === "you" ? "danger" : "accent"));
  }
  if (t.thread?.replyStatus?.risks?.length) badges.append(chip(`risk: ${t.thread.replyStatus.risks.join(", ")}`, "warning"));
  if (t.thread?.replyStatus?.try === "ready" && !t.landed && t.column === "stopped") badges.append(chip("ready to try", "success"));
  if (t.discarded) badges.append(chip("discarded", "muted"));
  else if (t.column === "settled" && t.threadId && !t.landed && !t.noWorktree) badges.append(chip("not landed", "muted"));
  if (t.held?.some((m) => m.failed)) badges.append(chip("sending failed: send again", "danger", t.held.find((m) => m.failed).failed));
  if (t.retryNote) badges.append(chip("tries again", "warning", t.retryNote));
  if (t.stakes && t.stakes.level !== "low") badges.append(chip(`ⓘ ${t.stakes.level} stakes`, STAKES_TONE[t.stakes.level], [t.brief ? `${t.brief.ask}\nIf wrong: ${t.brief.cost}` : "", ...t.stakes.reasons].filter(Boolean).join("\n")));
  else if (t.brief) badges.append(chip("ⓘ brief", "neutral", `${t.brief.what}\n${t.brief.ask}`));
  if (t.wake) badges.append(chip(`⏰ ${clock(t.wake.at)}`, "info", t.wake.note));
  if (t.attachments?.length) badges.append(chip([icon("clip"), `${t.attachments.length}`], "neutral", t.attachments.map((a) => a.name).join("\n")));
  if (ctx.lanes) {
    const lane = ctx.lanes[t.projectId];
    if (lane?.taskId === t.id) badges.append(chip(lane.offer ? "lane kept for it" : "🧪 has the lane", "accent"));
    else if (lane?.queue?.includes(t.id)) badges.append(chip(`🧪 waits for the lane (${lane.queue.indexOf(t.id) + 1})`, "info"));
  }
  if (t.landed?.pr) badges.append(chip(`PR #${t.landed.pr.number}`, "landed", t.landed.pr.url));
  if (t.hidden) badges.append(chip("hidden", "muted"));
  return badges;
}

const SIZE_BY = { you: "set by you", guess: "a small model's guess", refiner: "the refiner's", default: "not sized yet" };

/** The size (S/M/L) and pacing's guess of what is still needed: a click picks another size. */
export function sizeChip(t) {
  const e = t.estimate;
  const size = e?.size ?? t.size ?? "M";
  const text = e && !t.settledAt && e.pct ? `${size} · ~${e.pct}%` : size;
  const tip = [
    `Size ${size}${e ? ` (${SIZE_BY[e.by] ?? e.by})` : ""}`,
    e && !t.settledAt ? `Still needs about ${e.pct}% of a 5-hour window` : "",
    e?.spentPct ? `Spent so far: about ${e.spentPct}%` : "",
    t.settledAt ? "" : "Click to change the size",
  ].filter(Boolean).join("\n");
  if (t.settledAt) return h("span", { title: tip }, text);
  return h("button.size-chip", {
    title: tip,
    onclick: (ev) => {
      ev.stopPropagation();
      contextMenu(["S", "M", "L"].map((s) => ({ label: `${s === size ? "✓ " : ""}${s}: ${{ S: "small fix", M: "a feature", L: "large change" }[s]}`, run: () => act(() => api("edit", { number: t.number, size: s })) })), ev);
    },
  }, text);
}

/** A batch can still change until it starts: its tasks open in Edit and may leave it. */
export const batchOpen = (b) => !!b && !b.threadId && !b.held?.length;

/**
 * A task listed in a batch's card: a click opens the batch's Edit while the batch is open (its sub-tasks are edited
 * there), else taskView. While it is open an × deletes the sub-task (after asking).
 */
export function memberRow(m, batch, onEdit, report) {
  const r = report?.get(m.number);
  const editable = batchOpen(batch) && !!onEdit && m.prompt !== undefined;
  const remove = batchOpen(batch)
    ? h("button.icon-button.member-remove", {
      type: "button", title: "Delete this sub-task", "aria-label": "Delete this sub-task",
      onclick: async (e) => {
        e.stopPropagation();
        const asked = `Delete sub-task #${m.number} “${m.title}”?`;
        if (!(await confirmMenu(asked, { ok: "Delete", danger: true }))) return;
        await act(() => api("delete", { number: m.number }), `#${m.number} deleted`);
      },
    }, icon("x"))
    : null;
  return h("div.member", {
    title: editable ? "Edit it (in its batch)" : "See it",
    onclick: (e) => {
      e.stopPropagation();
      if (editable) onEdit(m);
      else taskView(m, batch);
    },
  }, h("span.num.dim", {}, `#${m.number}`), h("span.grow", {}, m.title),
  r ? chip(r.done ? "done" : "skipped", r.done ? "success" : "warning", r.why) : null, remove);
}

/**
 * A task read-only in a floating window: its title, description, files and a batch's sub-tasks. `batch`: the batch it
 * is listed in (a started batch's task, from its card).
 */
export function taskView(t, batch) {
  const close = () => back.remove();
  const back = h("div.backdrop", { onclick: (e) => e.target === back && close() });
  const files = t.attachments ?? [];
  const thread = batch ? batch.threadId : t.threadId;
  const dialog = h("div.dialog.member-view", { tabindex: -1, onkeydown: (e) => e.key === "Escape" && close() },
    h("h2", {}, `#${t.number} ${t.title}`),
    batch ? h("div.dim", {}, `In batch #${batch.number}${batchOpen(batch) ? "" : ", which has started: it can't change now"}.`) : null,
    markdown(t.prompt || "(no description)"),
    files.length ? h("div.field", {}, h("label", {}, "Files"), h("ul", {}, files.map((f) => h("li", {}, f.name ?? String(f))))) : null,
    !batch && t.members?.length
      ? h("div.field", {}, h("label", {}, "Sub-tasks"), h("ul", {}, t.members.map((m) => h("li", {}, `#${m.number} ${m.title}`))))
      : null,
    h("div.row", {},
      h("span.grow"),
      thread ? button(batch ? "Open the batch's thread" : "Open its thread", () => (close(), openThread(thread)), { small: false }) : null,
      button("Close", close, { kind: "primary", small: false }),
    ),
  );
  back.append(dialog);
  document.body.append(back);
  dialog.focus();
}

/** A task without a worktree left the project's checkout dirty or on another branch: ⚠, the files in its tooltip. */
export function checkoutChip(c) {
  const count = (c.files?.length ?? 0) + (c.more ?? 0);
  const text = [c.branch ? `on ${c.branch}` : "", count ? `${count} uncommitted` : ""].filter(Boolean).join(" · ");
  const tip = [
    c.branch ? `The project's checkout is on ${c.branch}, not the base branch.` : "",
    count ? "Uncommitted in the project's checkout:" : "",
    ...(c.files ?? []),
    c.more ? `…and ${c.more} more` : "",
  ].filter(Boolean).join("\n");
  return h("span.chip.tone.tone-warning.checkout", { title: tip }, `⚠ checkout ${text}`);
}

/** The concept nodes linked to a task (◆ N): a click opens the node, or a menu of them. */
export function nodesChip(nodes) {
  const open = (n) => layr.links.open(`layr://concepts/node/${n.id}`).catch((e) => layr.ui.notify(e.message ?? String(e), "error"));
  const label = (n) => String(n.text ?? "").split("\n")[0].slice(0, 60) || n.id.slice(0, 8);
  return h("button.chip.tone.tone-accent.nodes", {
    title: `On the concept map:\n${nodes.map(label).join("\n")}`,
    onclick: (e) => {
      e.stopPropagation();
      if (nodes.length === 1) return open(nodes[0]);
      return contextMenu(nodes.map((n) => ({ label: label(n), icon: "hub", run: () => open(n) })), e);
    },
  }, `◆ ${nodes.length}`);
}

/** What Run says on a proposal: it plans first with Plan on. */
export const runLabel = (t) => (t.plan ? (t.batch ? "Plan batch" : "Run plan") : t.batch ? "Run batch" : "Run");

/** A proposal's own buttons (Run, Edit): [{label, run, kind?, title?}]; none for a started task. */
export function proposalButtons(t, ctx = {}) {
  if (t.column !== "proposed" || t.threadId || t.inBatch) return [];
  const n = t.number;
  const out = [];
  // An empty batch has nothing to run yet.
  if (!t.held?.some((m) => m.kind === "launch") && !(t.batch && !t.members?.length)) {
    const title = t.plan
      ? `Its worker plans now and asks you; it stays in Proposed until you Approve${t.whenAway ? " (then the work waits for Away)" : ""}`
      : "It gets its own thread as soon as a running slot is free";
    out.push({ label: runLabel(t), run: () => act(() => api("run", { number: n })), kind: "primary", title });
  }
  out.push({ label: "Edit", run: () => ctx.onEdit?.(t) });
  return out;
}

/** A proposal's own buttons, then the backend's for its state. */
export function cardActions(t, ctx = {}) {
  const row = h("div.actions");
  const add = (label, fn, kind, title) => row.append(button(label, fn, { kind, title }));
  for (const b of proposalButtons(t, ctx)) add(b.label, b.run, b.kind ?? "", b.title);
  if (t.why === "question" && t.thread?.pending?.length && !ctx.inline) add("Answer", () => openThread(t.threadId), "primary", "In its Claude thread");
  for (const b of shownButtons(t)) add(b.label, () => press(t, b), b.kind ?? "");
  return row;
}

/**
 * A task's next step as one button (the table's Actions column): Run, Answer, or the backend's main button; null when
 * there is none. {label, run, kind, title}.
 */
export function nextStep(t, ctx = {}) {
  const own = proposalButtons(t, ctx);
  if (own.length) return own[0];
  if (t.why === "question" && t.thread?.pending?.length) return { label: "Answer", run: () => openThread(t.threadId), kind: "primary", title: "In its Claude thread" };
  if (asks(t)) return { label: "Answer", run: () => openThread(t.threadId), kind: "primary", title: "Its reply asks you: answer in its thread" };
  const shown = shownButtons(t);
  const b = shown.find((x) => x.kind === "primary") ?? shown[0];
  return b ? { label: b.label, run: () => press(t, b), kind: b.kind ?? "", title: b.confirm } : null;
}

/** Ask a reason, then drop (delete) a proposal. */
export async function dropProposal(t) {
  const reason = await promptMenu(`Drop #${t.number} “${t.title}”? It is deleted. Why (optional, kept in the answer):`, { ok: "Drop", danger: true, placeholder: "e.g. done another way" });
  if (reason === null) return;
  return act(() => api("act", { action: "drop", number: t.number, reason }), `Dropped #${t.number}`);
}

/** The ⋯ / right-click menu of a card (and of a table row). */
export function cardMenu(t, ctx, event) {
  event?.stopPropagation?.();
  const n = t.number;
  const edit = (patch, ok) => act(() => api("edit", { number: n, ...patch }), ok);
  const proposal = !t.threadId && t.column === "proposed" && !t.inBatch;
  const pc = !onPhone();
  const items = [];
  if (t.threadId) items.push({ label: "Open its thread", icon: "forum", run: () => openThread(t.threadId) });
  if (t.threadId) items.push({ label: "See it (description, files, sub-tasks)", icon: "visibility", run: () => taskView(t) });
  if (proposal) {
    const own = proposalButtons(t, ctx).filter((b) => b.label !== "Edit");
    items.push(...own.map((b) => ({ label: b.menuLabel ?? b.label, run: b.run })), { label: "Edit", icon: "edit", run: () => ctx.onEdit?.(t) });
  }
  if (pc) {
    items.push({ label: "Open in VS Code", icon: "code", run: () => act(() => api("open_in", { number: n, app: "vscode" })) });
    items.push({ label: "Open in File Explorer", icon: "folder_open", run: () => act(() => api("open_in", { number: n, app: "explorer" })) });
  }
  if (t.threadId && !t.settledAt) {
    items.push({
      label: "Message…",
      icon: "chat",
      run: async () => {
        const away = !!t.whenAway;
        const text = await promptMenu(away
          ? `Message #${n}'s thread. 🌙 When away is on: it waits in Ready until you go Away.`
          : `Message #${n}'s thread (it goes when a running slot is free; while its turn runs, at once).`, { ok: away ? "Send when away" : "Send", multiline: true });
        if (text?.trim()) act(() => api("send", { number: n, text }), away ? "Waits for Away" : "Sent");
      },
    });
  }
  const own = shownButtons(t);
  if (own.length) items.push("-", ...own.map((b) => ({ label: b.label, danger: b.kind === "danger", run: () => press(t, b) })));
  const more = [];
  const g = t.toggles;
  if (g && !t.inBatch && !t.settledAt) {
    if (g.plan.can && (!t.threadId || g.plan.on)) more.push({ label: "📝 Plan", checked: g.plan.on, run: () => flipToggle(t, "plan") });
    if (g.whenAway.can) more.push({ label: "🌙 When away", checked: g.whenAway.on, run: () => flipToggle(t, "whenAway") });
  }
  if (proposal && !t.batch) {
    more.push({ label: "🔒 Only you start it", checked: t.start === "manual", run: () => edit({ start: t.start === "manual" ? "either" : "manual" }) });
    more.push({ label: "⚡ Agents may start it", checked: t.start === "agents", run: () => edit({ start: t.start === "agents" ? "either" : "agents" }) });
  }
  if (t.inBatch && !t.threadId) more.push({ label: "📦 Take out of the batch", run: () => edit({ batch: false }) });
  if (t.autoMerge && !t.landed) more.push({ label: "Turn auto-merge off", run: () => edit({ autoMerge: false }) });
  if (!t.noWorktree && !t.landed) more.push({ label: "🤖 Agent lands it", checked: !!t.agentLands, run: () => edit({ agentLands: !t.agentLands }) });
  if (t.threadId) more.push({ label: "Tested ✓", checked: !!t.tested, run: () => edit({ tested: !t.tested }) });
  more.push({ label: "🚩 Controversial", checked: !!t.controversial, run: () => edit({ controversial: !t.controversial }) });
  if (String(t.prompt ?? "").trim()) more.push({ label: "✨ New title", run: () => edit({ retitle: true }, "A new title is being written") });
  if (t.threadId && t.column !== "running") more.push({ label: t.brief ? "Write the brief again" : "Write a brief", run: () => press(t, { id: "brief", label: "Brief" }) });
  if (ctx.onFold) more.push({ label: ctx.folded?.has(t.id) ? "Unfold" : "Fold to one line", run: () => ctx.onFold(t) });
  more.push({ label: t.hidden ? "Unhide" : "Hide", run: () => edit({ hidden: !t.hidden }, t.hidden ? "Back on the board" : `#${n} is hidden (⊘ in the header brings it back)`) });
  items.push("-", ...more, "-", { label: "Copy link", icon: "link", run: () => copyText(taskLink(t)) });
  const danger = [];
  // Any started task that isn't running now: also one planning in Proposed, or waiting in Ready (task #66).
  if (t.threadId && t.column !== "running" && !t.inBatch && !t.discarded && !t.landed && !t.landing) {
    const b = { id: "discard", label: "Discard", kind: "danger", confirm: discardText(t) };
    danger.push({ label: "Discard…", danger: true, run: () => press(t, b) });
  }
  if (proposal) {
    danger.push({ label: "Drop…", danger: true, run: () => dropProposal(t) });
    danger.push({
      label: "Delete",
      danger: true,
      run: async () => (await confirmMenu(`Delete proposal #${n} “${t.title}”?`, { ok: "Delete", danger: true })) && act(() => api("delete", { number: n })),
    });
  }
  if (danger.length) items.push("-", ...danger);
  return contextMenu(items, event);
}

/** Discard's text, as the backend's (backend/buttons.js discardText). */
function discardText(t) {
  if (t.noWorktree) return `Discard #${t.number}? Its thread is archived; the project's checkout stays as it is.`;
  return `Discard #${t.number}? Its worktree and branch are removed and its thread archived.${t.landed ? "" : " Its work isn't on the base branch: it's lost."}`;
}
