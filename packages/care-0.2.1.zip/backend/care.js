// Plugin care: hears the core's problems (`layr:problems`), tells about each one that opens, and per plugin reports,
// asks or fixes: a Claude thread on the plugin (claude__thread_start with a plugin or extension target), whose turn's
// commit is recorded, proven (backend restarted, self-test run, or the next pass) or undone when the problem comes
// back. Going back without AI, updates that keep your changes (updates.js) and the plugin page's overview are here too.
// docs/ARCHITECTURE.md › Problems (plugins that broke) › Plugin care. Everything outside comes in: `hub` (call,
// quiet), `store`, `readManifest`, `now`, `sleep`, so the tests drive it with fakes.
import {
  autoFixBlock,
  autoUpdateOf,
  CHANGED_UPDATES,
  connectsOf,
  dayOf,
  fixesToday,
  fixStateOf,
  goBackPlan,
  healthOf,
  jobOfPlugin,
  mergeStateOf,
  MODES,
  modeOf,
  ownAutoUpdate,
  placeOf,
  relatedUpdate,
  SETTLED,
  statusItem,
  threadIdOf,
  threadLink,
  turnOver,
  UPDATE_KEEP_MS,
  updateNote,
} from "./logic.js";
import { checksPrompt, fixPrompt } from "./prompts.js";
import { emptyRuntime } from "./store.js";
import { createUpdater } from "./updates.js";

const LONG = { timeout: 10 * 60_000 };
const TOPICS = ["layr:problems", "layr:packages", "claude:threads"];
/** Problems of layr itself (its crashes, source `crash`): shown, never fixed here. */
export const APP = "layr";
const APP_NAME = "layr (the app)";

export const DEFAULT_TIMING = {
  /** After a fix's turn ends, its commit (the claude plugin saves it after the turn) is looked for this long… */
  commitWaitMs: 30_000,
  /** …this often. */
  commitPollMs: 1_000,
  /** Fix and update threads are looked at this often, in case an event was missed (or care restarted). */
  pollMs: 60_000,
  /** The first look for updates after the start (store plugins update by themselves by default), then every… */
  firstUpdateMs: 20_000,
  updateEveryMs: 6 * 3_600_000,
  /** A backend is looked at this long after an update, to see whether it starts. */
  backendSettleMs: 8_000,
  /** The claude plugin commits a merge thread's work after its turn: waited this long before checking. */
  mergeSettleMs: 5_000,
  /** Turning "Update by itself" on looks for an update this much later. */
  autoUpdateFirstMs: 3_000,
  /** The repositories (layr__plugin_repos) are read again when older than this. */
  reposMaxAgeMs: 30_000,
};

export class Care {
  constructor({ hub, store, readManifest = () => null, now = Date.now, sleep, log = () => {}, timing = {} }) {
    this.hub = hub;
    this.store = store;
    this.readManifest = readManifest;
    this.now = now;
    this.sleep = sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
    this.log = log;
    this.timing = { ...DEFAULT_TIMING, ...timing };
    /** The core's problems we know (no `ok` ones): key → Problem. */
    this.problems = new Map();
    /** layr__plugin_repos' plugins: id → repo. */
    this.repos = new Map();
    this.reposAt = 0;
    this.settings = { dailyFixes: 5, defaultMode: "ask", changedUpdates: "ask", autoUpdate: true };
    this.prefs = {};
    this.rt = emptyRuntime();
    /** Keys and plugins being handled right now (a turn's end, an undo, a fix starting). */
    this.busy = new Set();
    /** Fixes told to work (`key@commit`), so the pass and care's own proof don't tell twice. */
    this.told = new Set();
    this.timers = [];
    this.lastStatus = "";
    this.claudeAt = 0;
    this.claudeUsable = null;
    this.updater = createUpdater(this);
  }

  // ---------------------------------------------------------------- start

  async start() {
    const { prefs, runtime } = await this.store.load().catch(() => ({}));
    this.prefs = prefs && typeof prefs === "object" ? prefs : {};
    this.rt = { ...emptyRuntime(), ...(runtime && typeof runtime === "object" ? runtime : {}) };
    await this.readSettings();
    await this.subscribe();
    await this.refreshRepos(true);
    await this.loadProblems();
    await this.tellOpenAtStart();
    this.status();
  }

  /** The timers: fix and update threads looked at, updates looked for. */
  run() {
    const every = (ms, fn) => {
      const t = setInterval(() => void this.safely(fn), ms);
      t.unref?.();
      this.timers.push(t);
    };
    const once = (ms, fn) => {
      const t = setTimeout(() => void this.safely(fn), ms);
      t.unref?.();
      this.timers.push(t);
    };
    once(1_000, () => this.pollThreads());
    every(this.timing.pollMs, () => this.pollThreads());
    once(this.timing.firstUpdateMs, () => this.updater.tick());
    every(this.timing.updateEveryMs, () => this.updater.tick());
  }

  stop() {
    for (const t of this.timers) {
      clearTimeout(t);
      clearInterval(t);
    }
    this.timers = [];
  }

  async safely(fn) {
    try {
      await fn();
    } catch (error) {
      this.log("error:", error);
    }
  }

  async subscribe() {
    for (const topic of TOPICS) {
      await this.hub.call("layr__events_subscribe", { topic }).catch((e) => this.log(`can't hear ${topic}:`, e));
    }
  }

  async readSettings(values) {
    const v = values ?? (await this.hub.call("layr__settings_get", {}).catch(() => null));
    if (!v || typeof v !== "object") return;
    if (Number.isFinite(Number(v.dailyFixes))) this.settings.dailyFixes = Math.max(0, Number(v.dailyFixes));
    if (MODES.includes(v.defaultMode)) this.settings.defaultMode = v.defaultMode;
    if (CHANGED_UPDATES.includes(v.changedUpdates)) this.settings.changedUpdates = v.changedUpdates;
    if (typeof v.autoUpdate === "boolean") this.settings.autoUpdate = v.autoUpdate;
  }

  async loadProblems() {
    const r = await this.hub.call("layr__problems", {}).catch((e) => {
      this.log("can't read the problems:", e);
      return null;
    });
    if (!r) return;
    this.problems = new Map((r.problems ?? []).filter((p) => p.state !== "ok").map((p) => [p.key, p]));
  }

  /** Problems open when care starts that it hasn't told about yet: one notification for all of them. */
  async tellOpenAtStart() {
    const fresh = [...this.problems.values()].filter((p) => p.state === "open" && !this.rt.notified[p.key]);
    if (!fresh.length) return;
    for (const p of fresh) this.rt.notified[p.key] = this.now();
    await this.save("runtime");
    const plugins = new Set(fresh.map((p) => p.plugin));
    const text =
      fresh.length === 1
        ? `${this.name(fresh[0].plugin)} needs care: ${clip(fresh[0].title || fresh[0].id)}`
        : `${plugins.size} plugin${plugins.size === 1 ? "" : "s"} need care (${fresh.length} problems): ` +
          "see Plugins";
    this.notify(text, "error");
  }

  async save(...keys) {
    for (const key of keys.length ? keys : ["prefs", "runtime"]) {
      await this.store.save(key, key === "prefs" ? this.prefs : this.rt).catch((e) => this.log(`saving ${key}:`, e));
    }
  }

  notify(text, kind = "info") {
    this.hub.quiet("layr__notify", { text, kind });
  }

  /** The plugin page hears this (and `layr:problems` itself) and asks for the overview again. */
  changed() {
    this.hub.quiet("layr__events_emit", { topic: "care:changed", data: { at: this.now() } });
    this.status();
  }

  status() {
    const item = statusItem([...this.problems.values()], this.names());
    const key = JSON.stringify(item);
    if (key === this.lastStatus) return;
    this.lastStatus = key;
    this.hub.quiet("layr__status_set", { id: "health", ...item });
  }

  // ---------------------------------------------------------------- plugins

  async refreshRepos(force = false) {
    if (!force && this.now() - this.reposAt < this.timing.reposMaxAgeMs) return;
    const r = await this.hub.call("layr__plugin_repos", {}).catch((e) => {
      this.log("can't read the plugins' repositories:", e);
      return null;
    });
    if (!r) return;
    const before = this.repos;
    this.repos = new Map((r.plugins ?? []).map((p) => [p.id, p]));
    this.reposAt = this.now();
    // Versions that moved up without care: an update by hand (the plugin page, the store) counts for the day after
    // it. A version changed by hand also ends an update applied by itself (its Undo) and one waiting to be applied.
    if (before.size) {
      for (const [id, repo] of this.repos) {
        const old = before.get(id);
        if (!old || !old.version || !repo.version || old.version === repo.version) continue;
        if (this.busy.has(`version:${id}`)) continue;
        const auto = this.rt.autoUpdated?.[id];
        if (auto && auto.to !== repo.version) void this.clearAutoUpdated(id);
        const job = this.rt.updateJobs?.[id];
        const reached = job && (job.to === repo.version || this.updater.isUp(job.to, repo.version));
        if ((job?.stage === "ready" || job?.stage === "failed") && reached) {
          delete this.rt.updateJobs[id];
          void this.save("runtime");
        }
        if (this.updater.isUp(old.version, repo.version)) {
          this.recordUpdate({
            plugin: id,
            from: old.version,
            to: repo.version,
            mine: repo.running === "mine",
            by: "you",
          });
        }
      }
    }
  }

  name(plugin) {
    if (plugin === APP) return APP_NAME;
    return this.repos.get(plugin)?.name ?? plugin;
  }

  names() {
    return Object.fromEntries([...this.repos].map(([id, r]) => [id, r.name ?? id]));
  }

  manifestOf(plugin) {
    return this.readManifest(this.repos.get(plugin)?.path) ?? null;
  }

  connectsTo(plugin) {
    return connectsOf(this.manifestOf(plugin));
  }

  placeOf(plugin) {
    return placeOf(this.repos.get(plugin));
  }

  modeOf(plugin) {
    return modeOf({ prefs: this.prefs, plugin, defaultMode: this.settings.defaultMode, place: this.placeOf(plugin) });
  }

  /** Does the plugin take new versions by itself (its own choice, else the setting `changedUpdates`)? */
  autoUpdateOf(plugin) {
    return autoUpdateOf({
      prefs: this.prefs,
      plugin,
      place: this.placeOf(plugin),
      changedUpdates: this.settings.changedUpdates,
      autoUpdate: this.settings.autoUpdate,
    });
  }

  /** An update applied by itself: remembered (runtime, and the data key the plugin page reads), with Undo. */
  async recordAutoUpdated(plugin, record) {
    this.rt.autoUpdated = { ...(this.rt.autoUpdated ?? {}), [plugin]: record };
    await this.save("runtime");
    await this.hub
      .call("layr__data_set", { key: `autoUpdated/${plugin}`, value: record })
      .catch((e) => this.log(`saving autoUpdated/${plugin}:`, e));
  }

  async clearAutoUpdated(plugin) {
    if (!this.rt.autoUpdated?.[plugin]) return;
    delete this.rt.autoUpdated[plugin];
    await this.save("runtime");
    await this.hub.call("layr__data_delete", { key: `autoUpdated/${plugin}` }).catch(() => {});
    this.changed();
  }

  recordUpdate(u) {
    const now = this.now();
    this.rt.updates = [...(this.rt.updates ?? []).filter((x) => now - x.at < UPDATE_KEEP_MS), { ...u, at: now }].slice(
      -50,
    );
    void this.save("runtime");
  }

  recentUpdate(plugin, at = this.now()) {
    return relatedUpdate({ plugin, updates: this.rt.updates, at, connectsTo: this.connectsTo(plugin) });
  }

  /** Is the claude plugin usable for care (its optional connection)? Asked at most every 30 s. */
  async claudeOk() {
    if (this.now() - this.claudeAt < 30_000 && this.claudeUsable !== null) return this.claudeUsable;
    const state = await this.hub.call("layr__connections", {}).catch(() => null);
    const c = (state?.connections ?? []).find((x) => x.plugin === "claude");
    // Unknown (an older core): calls decide.
    this.claudeUsable = c ? Boolean(c.installed) && c.state !== "missing" && c.state !== "blocked" : true;
    this.claudeAt = this.now();
    return this.claudeUsable;
  }

  // ---------------------------------------------------------------- events

  /** A `notifications/layr/event` from the hub. */
  async heard(topic, data) {
    if (topic === "layr:problems") return this.problemEvent(data);
    if (topic === "claude:threads" && data?.kind === "thread") return this.threadSeen(data.thread);
    if (topic === "layr:packages" && data?.phase === "done") {
      await this.refreshRepos(true);
      this.changed();
      return;
    }
    if (topic === "care:settings") {
      await this.readSettings(data?.values);
      this.changed();
    }
  }

  async problemEvent(data) {
    if (data?.op === "removed" && data.plugin) {
      for (const [key, p] of this.problems) if (p.plugin === data.plugin) this.problems.delete(key);
      for (const [key, j] of Object.entries(this.rt.jobs)) if (j.plugin === data.plugin) delete this.rt.jobs[key];
      await this.save("runtime");
      this.changed();
      return;
    }
    const p = data?.problem;
    if (!p?.key) return;
    if (p.state === "ok") this.problems.delete(p.key);
    else this.problems.set(p.key, p);
    await this.react(p);
    this.changed();
  }

  /** What a problem's change means for care. */
  async react(p) {
    if (SETTLED.has(p.state) && this.rt.notified[p.key]) {
      delete this.rt.notified[p.key];
      await this.save("runtime");
    }
    // A fix of care's that came back: undone.
    if (
      p.state === "open" &&
      p.recurred &&
      p.fix?.by === "care" &&
      p.fix.commit &&
      !p.fix.undone &&
      !p.fix.undoFailed
    ) {
      await this.undoFix(p, "It came back after Claude's fix");
      return;
    }
    // Proof that a fix of care's works.
    if (p.state === "fixed" && p.verified && p.fix?.by === "care" && p.fix.commit) {
      await this.fixWorks(p);
      return;
    }
    if (p.state === "open" && !this.rt.notified[p.key]) await this.opened(p);
  }

  /** A problem that opened: one notification, a note naming a recent update, and a fix when the plugin is `auto`. */
  async opened(p) {
    this.rt.notified[p.key] = this.now();
    await this.save("runtime");
    await this.refreshRepos();
    const update = this.recentUpdate(p.plugin, p.firstAt ?? this.now());
    if (update && !p.note) {
      await this.hub.call("layr__problem_set", { key: p.key, note: updateNote(update, this.names()) }).catch(() => {});
    }
    this.notify(`${this.name(p.plugin)} needs care: ${clip(p.title || p.id)}`, "error");
    const block = autoFixBlock({
      problem: p,
      mode: this.modeOf(p.plugin),
      place: this.placeOf(p.plugin),
      jobs: this.rt.jobs,
      noAuto: this.rt.noAuto,
      today: fixesToday(this.rt, this.now()),
      dailyFixes: this.settings.dailyFixes,
      claude: await this.claudeOk(),
    });
    if (block) {
      if (this.modeOf(p.plugin) === "auto") this.log(`not fixing ${p.key} by itself: ${block}`);
      return;
    }
    await this.fix(p.key, { auto: true }).catch((e) => this.log(`fixing ${p.key} by itself failed:`, e));
  }

  // ---------------------------------------------------------------- fixing

  /** Start a Claude thread fixing the problem `key`. Gives `{key, thread, link}`. */
  async fix(key, { auto = false } = {}) {
    const plugin = this.problems.get(key)?.plugin ?? String(key).split("/")[0];
    const name = this.name(plugin);
    if (jobOfPlugin(this.rt.jobs, plugin) || this.busy.has(`fix:${plugin}`)) {
      throw new Error(`Claude is fixing ${name} already: one fix per plugin at a time`);
    }
    this.busy.add(`fix:${plugin}`);
    try {
      await this.refreshRepos();
      const repo = this.repos.get(plugin);
      if (!repo) throw new Error(`${plugin} isn't installed`);
      if (placeOf(repo) === "inside") {
        throw new Error(
          `${name} lives inside a bigger repository (${repo.insideRepo}): fix it there; Plugin care only reports it`,
        );
      }
      const problem = await this.hub.call("layr__problem_get", { key });
      if (!problem?.key) throw new Error(`No problem ${key}`);
      if (problem.state === "fixing" && problem.fix?.thread) throw new Error(`Claude is fixing it already`);
      const manifest = this.readManifest(repo.path);
      const logs = manifest?.extension
        ? await this.hub.call("layr__extension_logs", { plugin, limit: 40 }).catch(() => null)
        : null;
      const base = await this.head(plugin);
      const prompt = fixPrompt({
        problem,
        name,
        place: placeOf(repo),
        manifest,
        logs,
        update: this.recentUpdate(plugin, problem.firstAt ?? this.now()),
        names: this.names(),
      });
      const started = await this.hub.call(
        "claude__thread_start",
        {
          target: { kind: manifest?.extension ? "extension" : "plugin", plugin },
          prompt,
          title: clip(`Fix ${name}: ${problem.title || problem.id}`, 100),
          permissionMode: "acceptEdits",
        },
        LONG,
      );
      const thread = threadIdOf(started);
      if (!thread) throw new Error("The claude plugin didn't say which thread it started");
      const at = this.now();
      this.rt.jobs[key] = { key, plugin, thread, base, at, auto, source: problem.source };
      if (auto) {
        const day = dayOf(at);
        this.rt.fixCount = this.rt.fixDay === day ? (this.rt.fixCount ?? 0) + 1 : 1;
        this.rt.fixDay = day;
      }
      this.rt.notified[key] ??= at;
      await this.save("runtime");
      const fix = { thread, at, by: "care" };
      const set = await this.hub
        .call("layr__problem_set", {
          key,
          state: "fixing",
          fix,
          note: auto ? "Claude is fixing it (by itself)" : "Claude is fixing it",
        })
        .catch((e) => this.log(`marking ${key} fixing:`, e));
      if (set?.key) this.problems.set(key, set);
      this.changed();
      if (auto) this.notify(`${name}: Claude is fixing "${clip(problem.title || problem.id)}" by itself`);
      return { key, thread, link: threadLink(thread) };
    } finally {
      this.busy.delete(`fix:${plugin}`);
    }
  }

  /** The newest commit of the plugin (layr__plugin_history), or null. */
  async head(plugin) {
    const h = await this.hub.call("layr__plugin_history", { plugin, limit: 1 }).catch(() => null);
    return h?.commits?.[0]?.sha ?? null;
  }

  /** The commit a fix's turn made (the claude plugin saves it right after the turn), or null when nothing changed. */
  async waitForCommit(plugin, base) {
    const until = this.now() + this.timing.commitWaitMs;
    for (;;) {
      const head = await this.head(plugin);
      if (head && head !== base) return head;
      if (this.now() >= until) return null;
      await this.sleep(this.timing.commitPollMs);
    }
  }

  /** A thread summary (claude:threads, or thread_status when looking): a fix's or an update's turn may be over. */
  async threadSeen(summary) {
    if (!summary?.id || !turnOver(summary)) return;
    const job = Object.values(this.rt.jobs).find((j) => j.thread === summary.id);
    if (job) return this.fixTurnEnded(job, summary);
    const update = this.resolving().find((j) => j.thread === summary.id);
    if (update) return this.updater.turnEnded(update, summary);
  }

  /** Updates Claude is combining with your changes right now (not ready or failed ones). */
  resolving() {
    return Object.values(this.rt.updateJobs ?? {}).filter((j) => j.stage === "merge" || j.stage === "fix");
  }

  /** Fix and update threads looked at, in case an event was missed. */
  async pollThreads() {
    const threads = [
      ...Object.values(this.rt.jobs).map((j) => j.thread),
      ...this.resolving().map((j) => j.thread),
    ].filter(Boolean);
    for (const thread of threads) {
      let r;
      try {
        r = await this.hub.call("claude__thread_status", { thread });
      } catch (error) {
        if (/no thread|not found|unknown thread/i.test(String(error?.message))) {
          await this.threadSeen({ id: thread, status: "failed", gone: true });
        }
        continue;
      }
      await this.threadSeen(r?.thread ?? r);
    }
  }

  async fixTurnEnded(job, summary) {
    const guard = `turn:${job.key}`;
    if (this.busy.has(guard)) return;
    this.busy.add(guard);
    try {
      if (summary.status !== "done") {
        const why = summary.gone
          ? "Claude's fix thread is gone"
          : summary.status === "failed"
            ? "Claude's fix thread failed"
            : "Claude's fix thread was stopped";
        await this.fixFailed(job, `${why}: nothing was changed`, null);
        return;
      }
      const commit = await this.waitForCommit(job.plugin, job.base);
      if (!commit) {
        await this.fixFailed(job, "Claude's turn ended without changing the plugin (its reply says why)", null);
        return;
      }
      const cur =
        this.problems.get(job.key) ?? (await this.hub.call("layr__problem_get", { key: job.key }).catch(() => null));
      const fix = { ...(cur?.fix ?? {}), thread: job.thread, at: job.at, by: "care", commit };
      delete this.rt.jobs[job.key];
      await this.save("runtime");
      let args;
      if (cur?.state === "ignored") args = { key: job.key, fix };
      else if (cur?.state === "fixed" && cur.verified)
        args = { key: job.key, fix, verified: true, note: "Claude fixed it" };
      else args = { key: job.key, state: "fixed", fix, note: "Claude fixed it; waiting for it to work again" };
      const set = await this.hub.call("layr__problem_set", args).catch((e) => this.log(`marking ${job.key} fixed:`, e));
      if (set?.key) this.problems.set(job.key, set);
      this.changed();
      await this.prove(job, set ?? { ...cur, ...args });
    } finally {
      this.busy.delete(guard);
    }
  }

  /** Proof that fits the problem's source: a backend restarted, the self-test run; others wait for the next pass. */
  async prove(job, p) {
    const source = p?.source ?? job.source;
    if (source === "backend") {
      const r = await this.hub.call("layr__plugin_restart", { plugin: job.plugin }, LONG).catch((e) => ({ error: e }));
      const status = typeof r === "string" ? r : (r?.status ?? r?.backend?.status);
      if (r?.error || status === "failed" || status === "blocked") {
        await this.undoFix({ ...p, key: job.key, plugin: job.plugin }, "Its backend still doesn't start");
      } else if (p?.id === "start" && status === "running") {
        await this.setVerified(job.key);
      }
    } else if (source === "check") {
      const r = await this.hub.call("layr__plugin_check", { plugin: job.plugin }, LONG).catch(() => null);
      if (r?.ran && !r.ok) await this.undoFix({ ...p, key: job.key, plugin: job.plugin }, "Its self-test still fails");
      else if (r?.ran && r.ok) await this.setVerified(job.key);
    }
  }

  async setVerified(key) {
    const cur = this.problems.get(key);
    if (cur?.state === "fixed" && cur.verified) return;
    const set = await this.hub.call("layr__problem_set", { key, verified: true }).catch(() => null);
    if (set?.key) {
      this.problems.set(key, set);
      if (set.verified && set.fix?.by === "care" && set.fix.commit) await this.fixWorks(set);
    }
    this.changed();
  }

  /** A fix of care's proved itself: told once (per commit), and the key may be fixed by itself again. */
  async fixWorks(p) {
    const told = `${p.key}@${p.fix.commit}`;
    if (this.told.has(told)) return;
    this.told.add(told);
    if (this.rt.noAuto.includes(p.key)) {
      this.rt.noAuto = this.rt.noAuto.filter((k) => k !== p.key);
      await this.save("runtime");
    }
    this.notify(`${this.name(p.plugin)}: Claude's fix works (${clip(p.title || p.id)})`, "success");
  }

  /** A fix that changed nothing, or whose thread failed: the problem is open again, and not fixed by itself again. */
  async fixFailed(job, note, commit) {
    delete this.rt.jobs[job.key];
    if (!this.rt.noAuto.includes(job.key)) this.rt.noAuto.push(job.key);
    this.rt.notified[job.key] = this.now();
    await this.save("runtime");
    const cur = this.problems.get(job.key);
    const fix = { ...(cur?.fix ?? {}), thread: job.thread, at: job.at, by: "care", ...(commit ? { commit } : {}) };
    const args =
      cur && cur.state !== "fixing" && cur.state !== "open"
        ? { key: job.key, fix, note }
        : { key: job.key, state: "open", fix, note };
    const set = await this.hub.call("layr__problem_set", args).catch((e) => this.log(`reopening ${job.key}:`, e));
    if (set?.key) this.problems.set(job.key, set);
    this.changed();
    this.notify(`${this.name(job.plugin)}: ${note}`, "error");
  }

  /** Take a fix of care's back (layr__plugin_undo of fix.commit): the problem is open again with a note. */
  async undoFix(p, why) {
    const guard = `undo:${p.key}`;
    if (this.busy.has(guard)) return;
    this.busy.add(guard);
    try {
      const fix = { ...(p.fix ?? {}) };
      let error = null;
      try {
        await this.hub.call("layr__plugin_undo", { plugin: p.plugin, commit: fix.commit }, LONG);
        fix.undone = true;
      } catch (e) {
        error = e;
        fix.undoFailed = true;
      }
      if (!error) await this.reload(p.plugin);
      if (!this.rt.noAuto.includes(p.key)) this.rt.noAuto.push(p.key);
      this.rt.notified[p.key] = this.now();
      delete this.rt.jobs[p.key];
      await this.save("runtime");
      const note = error
        ? `Claude's fix didn't work, and undoing it failed: ${error.message ?? error}`
        : "Claude's fix didn't work and was undone";
      const set = await this.hub
        .call("layr__problem_set", { key: p.key, state: "open", note, fix })
        .catch((e) => this.log(`reopening ${p.key}:`, e));
      if (set?.key) this.problems.set(p.key, set);
      this.changed();
      this.notify(`${this.name(p.plugin)}: ${note} (${why.charAt(0).toLowerCase()}${why.slice(1)})`, "error");
    } finally {
      this.busy.delete(guard);
    }
  }

  /** After its files changed under it: an extension is reloaded, a backend restarted (failures only logged). */
  async reload(plugin) {
    const manifest = this.manifestOf(plugin);
    if (manifest?.extension)
      await this.hub.call("layr__extension_reload", { plugin }).catch((e) => this.log("reload:", e));
    if (manifest?.backend?.kind === "process") {
      await this.hub.call("layr__plugin_restart", { plugin }, LONG).catch((e) => this.log("restart:", e));
    }
  }

  // ---------------------------------------------------------------- the plugin page's tools

  async problemOf(key) {
    const p = this.problems.get(key) ?? (await this.hub.call("layr__problem_get", { key }).catch(() => null));
    if (!p?.key) throw new Error(`No problem ${key}`);
    return p;
  }

  goBackPlanOf(p) {
    return goBackPlan(p, { updates: this.rt.updates, connectsTo: this.connectsTo(p.plugin), names: this.names() });
  }

  /** Go back to what worked, without AI (logic.goBackPlan). */
  async goBack(key) {
    await this.refreshRepos();
    const p = await this.problemOf(key);
    const plan = this.goBackPlanOf(p);
    if (!plan)
      throw new Error(
        "Nothing to go back to: it hasn't worked at another version or commit, and no update came just before it",
      );
    const target = plan.args.plugin;
    if (placeOf(this.repos.get(target)) === "inside") {
      throw new Error(`${this.name(target)} lives inside a bigger repository: go back with git there`);
    }
    this.busy.add(`version:${target}`);
    try {
      await this.hub.call(plan.tool, plan.args, LONG);
      if (plan.tool === "layr__plugin_restore") await this.reload(target);
      await this.refreshRepos(true);
    } finally {
      this.busy.delete(`version:${target}`);
    }
    if (plan.update) {
      // Not to that version again by itself; and the update no longer explains problems.
      this.rt.skip[plan.update.plugin] = plan.update.to;
      this.rt.updates = this.rt.updates.map((u) =>
        u === plan.update || (u.plugin === plan.update.plugin && u.at === plan.update.at)
          ? { ...u, wentBack: true }
          : u,
      );
      await this.save("runtime");
    }
    const fix = { ...(p.fix ?? {}), by: "care", at: this.now(), wentBack: plan.label };
    delete fix.commit;
    delete fix.undone;
    const set = await this.hub
      .call("layr__problem_set", { key, state: "fixed", note: plan.note, fix })
      .catch(() => null);
    if (set?.key) this.problems.set(key, set);
    this.changed();
    return { done: plan.note, tool: plan.tool, args: plan.args };
  }

  async ignore(key) {
    const p = await this.problemOf(key);
    const set = await this.hub.call("layr__problem_set", { key, state: "ignored" });
    if (set?.key) this.problems.set(key, set);
    if (this.rt.notified[p.key]) {
      delete this.rt.notified[p.key];
      await this.save("runtime");
    }
    this.changed();
    return { key, state: "ignored" };
  }

  async reopen(key) {
    await this.problemOf(key);
    this.rt.noAuto = this.rt.noAuto.filter((k) => k !== key);
    // Told about already (the user reopens it): no notification, no automatic fix.
    this.rt.notified[key] = this.now();
    delete this.rt.jobs[key];
    await this.save("runtime");
    const set = await this.hub.call("layr__problem_set", { key, state: "open", note: null });
    if (set?.key) this.problems.set(key, set);
    this.changed();
    return { key, state: "open" };
  }

  async setMode(plugin, mode) {
    if (mode !== null && !MODES.includes(mode)) throw new Error(`mode: one of ${MODES.join(", ")}, or null`);
    await this.refreshRepos();
    if (!this.repos.has(plugin)) throw new Error(`${plugin} isn't installed`);
    if (mode && mode !== "report" && this.placeOf(plugin) === "inside") {
      throw new Error(`${this.name(plugin)} lives inside a bigger repository: it is only reported`);
    }
    const own = { ...(this.prefs[plugin] ?? {}) };
    if (mode === null) delete own.mode;
    else own.mode = mode;
    this.prefs[plugin] = own;
    await this.save("prefs");
    this.changed();
    return { plugin, mode: this.modeOf(plugin) };
  }

  /** The plugin's own "Update by itself": true, false, or null (follow the setting `changedUpdates`). */
  async setAutoUpdate(plugin, on) {
    await this.refreshRepos();
    if (!this.repos.has(plugin)) throw new Error(`${plugin} isn't installed`);
    const place = this.placeOf(plugin);
    if (on === true && (place === "made" || place === "inside")) {
      throw new Error(`${this.name(plugin)} doesn't come from a store: there are no updates to take`);
    }
    const own = { ...(this.prefs[plugin] ?? {}) };
    if (on === null || on === undefined) delete own.autoUpdate;
    else own.autoUpdate = Boolean(on);
    this.prefs[plugin] = own;
    await this.save("prefs");
    this.changed();
    const effective = this.autoUpdateOf(plugin);
    if (effective) {
      const t = setTimeout(() => void this.safely(() => this.updater.update(plugin)), this.timing.autoUpdateFirstMs);
      t.unref?.();
    }
    return { plugin, autoUpdate: ownAutoUpdate(this.prefs, plugin), autoUpdateOn: effective };
  }

  /**
   * Undo an update applied by itself: back to the version before (with your changes as they stood there when it had
   * them), not taken by itself again. Gives the plugin's PluginInfo (layr__plugin_switch's answer).
   */
  async undoUpdate(plugin) {
    const record = this.rt.autoUpdated?.[plugin];
    if (!record?.from) throw new Error(`${this.name(plugin)} wasn't updated by itself: nothing to undo`);
    await this.refreshRepos();
    if (!this.repos.has(plugin)) throw new Error(`${plugin} isn't installed`);
    let info;
    this.busy.add(`version:${plugin}`);
    try {
      const args = { plugin, version: record.from };
      if (record.mine) args.mine = true;
      info = await this.hub.call("layr__plugin_switch", args, LONG);
      await this.reload(plugin);
      await this.refreshRepos(true);
    } finally {
      this.busy.delete(`version:${plugin}`);
    }
    this.rt.skip[plugin] = record.to;
    this.rt.updates = (this.rt.updates ?? []).map((u) =>
      u.plugin === plugin && u.to === record.to && !u.wentBack ? { ...u, wentBack: true } : u,
    );
    delete this.rt.autoUpdated[plugin];
    await this.save("runtime");
    await this.hub.call("layr__data_delete", { key: `autoUpdated/${plugin}` }).catch(() => {});
    this.changed();
    this.notify(`${this.name(plugin)} is back at ${record.from}`, "success");
    return info;
  }

  /** A Claude thread adding `layr.expect` checks and a `check` script to the plugin. */
  async addChecks(plugin) {
    await this.refreshRepos();
    const repo = this.repos.get(plugin);
    if (!repo) throw new Error(`${plugin} isn't installed`);
    const manifest = this.readManifest(repo.path);
    const started = await this.hub.call(
      "claude__thread_start",
      {
        target: { kind: manifest?.extension ? "extension" : "plugin", plugin },
        prompt: checksPrompt({ name: this.name(plugin), plugin, manifest }),
        title: clip(`Add checks to ${this.name(plugin)}`, 100),
        permissionMode: "acceptEdits",
      },
      LONG,
    );
    const thread = threadIdOf(started);
    return { plugin, thread, link: threadLink(thread) };
  }

  /** Everything the plugin page's Problems tab and the Plugins list need: plugins (with problems first), their
   * problems, modes, updates (applied by itself, being merged), fixes running, the day's fixes. */
  async overview({ plugin: only } = {}) {
    await this.refreshRepos();
    await this.loadProblems();
    this.status();
    const claude = await this.claudeOk();
    const now = this.now();
    const byPlugin = new Map();
    for (const p of this.problems.values()) {
      if (!byPlugin.has(p.plugin)) byPlugin.set(p.plugin, []);
      byPlugin.get(p.plugin).push(p);
    }
    const ids = new Set([...this.repos.keys(), ...byPlugin.keys()]);
    const plugins = [];
    for (const id of ids) {
      if (only && id !== only) continue;
      const repo = this.repos.get(id);
      const place = placeOf(repo);
      const manifest = repo ? this.readManifest(repo.path) : null;
      const problems = (byPlugin.get(id) ?? []).slice().sort((a, b) => (b.lastAt ?? 0) - (a.lastAt ?? 0));
      const job = jobOfPlugin(this.rt.jobs, id);
      const update = this.recentUpdate(id, now);
      plugins.push({
        id,
        name: this.name(id),
        app: id === APP,
        version: repo?.version ?? null,
        place,
        installed: Boolean(repo),
        reportOnly: place === "inside" || id === APP,
        extension: Boolean(manifest?.extension),
        check: manifest?.check ?? null,
        mode: this.modeOf(id),
        ownMode: this.prefs[id]?.mode ?? null,
        // 0.2.0: the plugin's own choice (true, false, or null: follows the setting changedUpdates) and the result.
        autoUpdate: ownAutoUpdate(this.prefs, id),
        autoUpdateOn: this.autoUpdateOf(id),
        changed: place === "changed",
        canUpdate: place === "store" || place === "changed",
        health: healthOf(problems),
        fixing: job
          ? { key: job.key, thread: job.thread, at: job.at, link: threadLink(job.thread), auto: job.auto }
          : null,
        updating: this.rt.updateJobs?.[id]
          ? { ...this.rt.updateJobs[id], link: threadLink(this.rt.updateJobs[id].thread) }
          : null,
        update,
        waiting: this.rt.waiting?.[id] ?? null,
        merge: mergeStateOf(this.rt.updateJobs?.[id]),
        autoUpdated: this.rt.autoUpdated?.[id] ?? null,
        skipped: this.rt.skip?.[id] ?? null,
        problems: problems.map((p) => {
          const plan = this.goBackPlanOf(p);
          return {
            ...p,
            fixState: fixStateOf(p),
            goBack: plan ? { label: plan.label, note: plan.note, tool: plan.tool, args: plan.args } : null,
            link: threadLink(p.fix?.thread),
            canFix: Boolean(repo) && place !== "inside" && claude !== false && !job,
          };
        }),
      });
    }
    const rank = { open: 0, fixing: 1, watching: 2, fixed: 3, ok: 4 };
    plugins.sort((a, b) => rank[a.health] - rank[b.health] || a.name.localeCompare(b.name));
    const today = fixesToday(this.rt, now);
    return {
      plugins,
      settings: { ...this.settings, fixesToday: today },
      budget: { dailyFixes: this.settings.dailyFixes, today, left: Math.max(0, this.settings.dailyFixes - today) },
      claude,
      updates: (this.rt.updates ?? []).slice().reverse(),
      lastUpdateCheck: this.rt.lastUpdateCheck || null,
    };
  }
}

function clip(text, max = 120) {
  const s = String(text ?? "")
    .replace(/\s+/g, " ")
    .trim();
  return s.length > max ? `${s.slice(0, max - 1)}…` : s;
}
