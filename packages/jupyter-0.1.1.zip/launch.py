"""Starts JupyterLab for layr: `uv run python launch.py <port> <token>` (layr fills in both).

Notebooks live in the plugin's data folder (LAYR_DATA_DIR). The server listens on 127.0.0.1 only and needs layr's
app token (the `{token}` argument, or LAYR_APP_TOKEN): the panel URL carries `?token=<token>`, which logs the panel
in and sets Jupyter's own cookie. Without it nothing answers but `/api` (layr's ready probe), so other web pages and
programs on the PC can't run code. XSRF checks stay on; cross-origin requests are allowed only from
`http://jupyter.localhost:<port>` (the phone's proxied page); it allows being shown inside layr's pages.
"""

from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main() -> int:
    if len(sys.argv) < 2 or not sys.argv[1].isdigit():
        print("usage: launch.py <port> <token>", file=sys.stderr)
        return 2
    port = sys.argv[1]
    token = (sys.argv[2] if len(sys.argv) > 2 else "") or os.environ.get("LAYR_APP_TOKEN", "")
    if not token or token == "{token}":
        print("launch.py: no app token (layr passes {token} or LAYR_APP_TOKEN)", file=sys.stderr)
        return 2
    root = Path(os.environ.get("LAYR_DATA_DIR") or HERE / ".layr-data")
    root.mkdir(parents=True, exist_ok=True)

    # First start: put the welcome notebook there.
    if not any(root.glob("*.ipynb")):
        for nb in (HERE / "notebooks").glob("*.ipynb"):
            shutil.copy(nb, root / nb.name)

    # JupyterLab's own settings live with the notebooks (hidden folder): no news or update prompts.
    settings = root / ".jupyter" / "lab" / "user-settings"
    note = settings / "@jupyterlab" / "apputils-extension" / "notification.jupyterlab-settings"
    if not note.exists():
        note.parent.mkdir(parents=True, exist_ok=True)
        note.write_text(json.dumps({"fetchNews": "false", "checkForUpdates": False}), "utf-8")
    os.environ.setdefault("JUPYTERLAB_SETTINGS_DIR", str(settings))
    os.environ.setdefault("JUPYTERLAB_WORKSPACES_DIR", str(root / ".jupyter" / "lab" / "workspaces"))

    frame_ancestors = "frame-ancestors 'self' http://localhost:* http://127.0.0.1:* http://*.localhost:*"
    tornado = {"headers": {"Content-Security-Policy": frame_ancestors}}
    argv = [
        "--no-browser",
        f"--port={port}",
        "--port-retries=0",
        "--ServerApp.ip=127.0.0.1",
        f"--IdentityProvider.token={token}",
        r"--ServerApp.allow_origin_pat=^http://jupyter\.localhost:\d+$",
        f"--ServerApp.root_dir={root}",
        f"--ServerApp.tornado_settings={json.dumps(tornado)}",
        "--LabApp.news_url=",  # no news fetched from the internet
        "--LabApp.check_for_updates_class=jupyterlab.NeverCheckForUpdate",
    ]
    print(f"JupyterLab on http://127.0.0.1:{port}/lab, notebooks in {root}", file=sys.stderr)

    from jupyterlab.labapp import LabApp

    LabApp.launch_instance(argv=argv)
    return 0


if __name__ == "__main__":
    sys.exit(main())
