// layr's side of the PDF viewer: PDF.js's generic viewer (vendor/pdfjs) opens and saves files through layr.files,
// the tab's title shows the file and unsaved edits, the page follows layr's theme and the panel remembers its page.
// Runs before PDF.js's viewer.mjs, so it can set PDF.js's options on its "webviewerloaded" event.
import { keyAction, saveName, saveTarget, startFile, titleFor } from "./lib.js";

let app = null; // PDFViewerApplication
let current = null; // the FileRef on show, null for none (or a file dropped onto the page)
let shownName = "";
let dirty = false;
let saving = false;
let pendingPage = null;
let stateTimer = 0;

const emptyBox = document.getElementById("layrEmpty") ?? null;

function onViewerLoaded() {
  if (app) return;
  app = window.PDFViewerApplication;
  const options = window.PDFViewerApplicationOptions;
  options.set("disablePreferences", true); // layr is the settings place; PDF.js's would live in localStorage
  options.set("defaultUrl", ""); // no sample document
  options.set("disableHistory", true); // a panel has no back button: don't push the page into its history
  options.set("enableSignatureEditor", true);

  // PDF.js's save/download button, Ctrl+S, the document's own "save as" and saving before another file opens.
  app.downloadOrSave = () => save(false);
  // PDF.js asks before the page unloads and marks the title while this is true: only for edits not saved yet.
  app._hasChanges = () => dirty;
  // PDF.js's open buttons click this hidden <input type="file">: open through layr instead.
  Object.defineProperty(app, "_openFileInput", { configurable: true, get: () => ({ click: pick }), set() {} });

  const initStorage = app._initializeAnnotationStorageCallbacks;
  app._initializeAnnotationStorageCallbacks = function (pdfDocument) {
    initStorage.call(this, pdfDocument);
    if (pdfDocument !== this.pdfDocument) return;
    const storage = pdfDocument.annotationStorage;
    const set = storage.onSetModified;
    const reset = storage.onResetModified;
    storage.onSetModified = () => {
      set?.();
      setDirty(true);
    };
    storage.onResetModified = () => {
      reset?.();
      if (!saving) setDirty(false); // saveDocument resets it before the bytes are written; save() decides then
    };
  };
}
document.addEventListener("webviewerloaded", onViewerLoaded);
try {
  if (parent !== window) parent.document.addEventListener("webviewerloaded", onViewerLoaded);
} catch {
  // a parent of another origin: PDF.js then dispatches on this document
}

// ---------- theme ----------

function followTheme() {
  const mode = document.documentElement.getAttribute("data-theme");
  if (mode !== "dark" && mode !== "light") return;
  document.documentElement.style.colorScheme = mode; // what PDF.js's viewerCssTheme does: viewer.css uses light-dark()
  document.documentElement.dataset.scheme = mode;
}
const themeObserver = new MutationObserver(followTheme);
themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
followTheme();

// ---------- keys ----------

function isEditable(el) {
  return !!el && (el.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(el.tagName));
}

// On document, so it runs before the window listeners of layr.js (which passes Ctrl keys to the shell) and PDF.js.
document.addEventListener("keydown", (e) => {
  if (e.defaultPrevented || e.isComposing) return;
  const action = keyAction(e);
  if (!action) return;
  if (action === "pdfjs") {
    // PDF.js handles these on window without looking at defaultPrevented; this only keeps them from the shell.
    if (!isEditable(e.target)) e.preventDefault();
    return;
  }
  e.preventDefault();
  e.stopPropagation();
  if (action === "open") pick();
  else save(action === "saveAs");
});

// ---------- title, state ----------

function updateTitle() {
  layr.panel.setTitle(titleFor(shownName, dirty)).catch(() => {});
}

function setDirty(value) {
  if (dirty === value) return;
  dirty = value;
  updateTitle();
  app?.setTitle?.();
}

function saveState() {
  clearTimeout(stateTimer);
  stateTimer = setTimeout(() => {
    const page = app?.pdfDocument ? app.page : null;
    layr.panel.setState(current ? { file: current, page } : {}).catch(() => {});
  }, 300);
}

function showEmpty(show) {
  if (emptyBox) emptyBox.hidden = !show;
}

// ---------- open ----------

async function openRef(ref, page = null) {
  current = ref;
  shownName = ref.name;
  pendingPage = page;
  showEmpty(false);
  updateTitle();
  saveState();
  try {
    const url = await layr.files.url(ref.id);
    await app.open({ url, originalUrl: ref.name, isEvalSupported: false });
  } catch (err) {
    layr.ui.notify(`Couldn't open ${ref.name}: ${err?.message ?? err}`, "error").catch(() => {});
  }
}

/** The open dialog; the file opens here when nothing is on show, else in a new tab (each PDF its own tab). */
async function pick() {
  try {
    const ref = await layr.files.open({ types: [".pdf"] });
    if (!ref) return;
    if (app.pdfDocument || app.pdfLoadingTask) await layr.panels.open("viewer", { file: ref });
    else await openRef(ref);
  } catch (err) {
    layr.ui.notify(`Couldn't open the file: ${err?.message ?? err}`, "error").catch(() => {});
  }
}

/** Opens a FileRef after checking it is still there; false when it is gone. */
async function openFresh(ref, page) {
  try {
    const fresh = await layr.files.info(ref.id);
    if (fresh && fresh.exists !== false) {
      await openRef(fresh, page);
      return true;
    }
  } catch {
    // no longer granted, or gone
  }
  return false;
}

// ---------- save ----------

async function save(as) {
  const pdfDocument = app?.pdfDocument;
  if (!pdfDocument || saving) return;
  const wasDirty = dirty;
  saving = true;
  const { classList } = app.appConfig.appContainer;
  classList.add("wait");
  try {
    app.pdfViewer._layerProperties.annotationEditorUIManager?.endCurrentEditing();
    let data;
    if (pdfDocument.annotationStorage.size > 0) {
      await app.pdfScriptingManager.dispatchWillSave();
      try {
        data = await pdfDocument.saveDocument();
      } finally {
        await app.pdfScriptingManager.dispatchDidSave();
      }
    } else {
      data = await pdfDocument.getData();
    }
    let written = null;
    const target = saveTarget(current, as);
    if (target) {
      try {
        written = await layr.files.write(target.id, data);
      } catch (err) {
        if (err?.code !== layr.errors.NOT_ALLOWED) throw err; // read-only after all: ask where to save
      }
    }
    if (!written) {
      const picked = await layr.files.saveAs({ name: saveName(current, app._docFilename), types: [".pdf"] });
      if (!picked) {
        dirty = wasDirty;
        return;
      }
      written = (await layr.files.write(picked.id, data)) || picked;
    }
    current = written;
    shownName = written.name;
    dirty = false;
    saveState();
    layr.ui.notify(`Saved ${written.name}`, "success").catch(() => {});
  } catch (err) {
    dirty = wasDirty;
    layr.ui.notify(`Couldn't save: ${err?.message ?? err}`, "error").catch(() => {});
  } finally {
    saving = false;
    classList.remove("wait");
    updateTitle();
    app.setTitle();
  }
}

// ---------- start ----------

async function start() {
  await layr.ready;
  // viewer.mjs evaluates after this module; wait for it, then for PDF.js to set itself up.
  while (!window.PDFViewerApplication) await new Promise((resolve) => setTimeout(resolve, 10));
  onViewerLoaded();
  await app.initializedPromise;
  const { eventBus } = app;

  eventBus.on("documentinit", () => {
    if (pendingPage && pendingPage <= app.pagesCount) app.page = pendingPage;
    pendingPage = null;
  });
  eventBus.on("pagechanging", () => {
    if (current) saveState();
  });
  // A PDF dropped onto the page opens in PDF.js as a blob: it has no FileRef, so saving it asks where.
  eventBus.on("fileinputchange", ({ fileInput }) => {
    current = null;
    shownName = fileInput?.files?.[0]?.name ?? "PDF";
    dirty = false;
    showEmpty(false);
    updateTitle();
    saveState();
  });
  document.getElementById("layrOpen")?.addEventListener("click", pick);

  const params = layr.info.params || {};
  const first = startFile(layr.info.state, params);
  let opened = false;
  if (first) {
    opened = await openFresh(first.file, first.page);
    if (!opened && first.fallback) opened = await openFresh(first.fallback, null);
    if (!opened) layr.ui.notify(`${first.file.name} is no longer there`, "error").catch(() => {});
  }
  if (!opened) {
    current = null;
    shownName = "";
    updateTitle();
    showEmpty(true);
    if (params.pick) pick();
  }

  layr.panel.onParams?.((next) => {
    if (next?.file) {
      if (app.pdfDocument || app.pdfLoadingTask) layr.panels.open("viewer", { file: next.file }).catch(() => {});
      else openFresh(next.file, null);
    } else if (next?.pick) pick();
  });
}

start().catch((err) => console.error("[pdf]", err));
