// The PDF panel's small decisions, kept free of the page so `node --test` can check them (test/lib.test.mjs).

/** The tab's title: the file's name, with a dot in front while there are unsaved edits. */
export function titleFor(name, dirty) {
  const base = name || "PDF";
  return dirty ? `• ${base}` : base;
}

/** What a key press means to the panel ("save", "saveAs", "open"), "pdfjs" for keys PDF.js handles, or null. */
export function keyAction(e) {
  const ctrl = (e.ctrlKey || e.metaKey) && !e.altKey;
  const key = (e.key || "").toLowerCase();
  if (ctrl && key === "s") return e.shiftKey ? "saveAs" : "save";
  if (ctrl && !e.shiftKey && key === "o") return "open";
  // PDF.js's own: find, find again, print, undo and redo of annotation edits; go to page, presentation mode.
  if (ctrl && ["f", "g", "p", "z", "y"].includes(key)) return "pdfjs";
  if ((e.ctrlKey || e.metaKey) && e.altKey && ["g", "p"].includes(key)) return "pdfjs";
  return null;
}

/** Where a save goes: the open file when it can be written (and not "save as"), else null (ask with saveAs). */
export function saveTarget(current, as) {
  return !as && current && current.writable ? current : null;
}

/** A name for "save as": the open file's, or PDF.js's guess, always ending in .pdf. */
export function saveName(current, guess) {
  const name = (current && current.name) || guess || "document.pdf";
  return /\.pdf$/i.test(name) ? name : `${name}.pdf`;
}

/**
 * Which file to show when the panel starts, in order: the one in its saved state (it may have been saved under a new
 * name since), then the one it was opened with. Returns {file, page, fallback} or null; fallback is the file it was
 * opened with, to try when the saved one is gone.
 */
export function startFile(state, params) {
  const saved = state && state.file && state.file.id ? state.file : null;
  const given = params && params.file && params.file.id ? params.file : null;
  if (saved) {
    const fallback = given && given.id !== saved.id ? given : null;
    return { file: saved, page: Number(state.page) || null, fallback };
  }
  if (given) return { file: given, page: null, fallback: null };
  return null;
}
