// End-to-end test of the PDF panel against a real `layr serve` in headless Chromium, with a temporary home and
// temporary PDFs: it opens a file, checks it renders without CSP errors, edits it, saves, saves as, falls back to
// "save as" for a read-only file, opens through the panel's dialog, and restores the page after a reload.
//
//   cargo build -p layr_cli          (in core/)
//   node plugins/pdf/test/viewer.e2e.mjs [--out <screenshot dir>] [--keep]
//
// The app's file dialogs are stubbed: window.__layrShell answers files.open / files.saveAs by granting temp files.
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(here, "..", "..", "..");
const arg = (name, dflt) => {
  const i = process.argv.indexOf(`--${name}`);
  return i > 0 ? process.argv[i + 1] : dflt;
};
const tmp = mkdtempSync(path.join(os.tmpdir(), "layr-pdf-"));
const OUT = path.resolve(arg("out", path.join(tmp, "shots")));
mkdirSync(OUT, { recursive: true });

function loadPlaywright() {
  const bases = [path.join(repoRoot, "plugins", "dev", "package.json"),
    path.join(os.homedir(), "pwtools", "package.json")];
  for (const base of bases) {
    try {
      return createRequire(base)("playwright");
    } catch {}
  }
  throw new Error("playwright not found (plugins/dev: npm install)");
}
const { chromium } = loadPlaywright();

const exe = path.join(repoRoot, "core", "target", "debug", process.platform === "win32" ? "layr.exe" : "layr");
if (!existsSync(exe)) throw new Error(`build the CLI first: cargo build -p layr_cli (no ${exe})`);

// ---------- test PDFs ----------

/** A small valid PDF with one line of text on each page. */
function makePdf(pages) {
  const objs = [];
  const kids = pages.map((_, i) => `${3 + i * 2} 0 R`).join(" ");
  objs.push("<< /Type /Catalog /Pages 2 0 R >>");
  objs.push(`<< /Type /Pages /Kids [${kids}] /Count ${pages.length} >>`);
  const font = 3 + pages.length * 2;
  pages.forEach((text, i) => {
    objs.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents ${4 + i * 2} 0 R ` +
      `/Resources << /Font << /F1 ${font} 0 R >> >> >>`);
    const stream = `BT /F1 24 Tf 72 700 Td (${text}) Tj ET`;
    objs.push(`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);
  });
  objs.push("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
  let out = "%PDF-1.4\n";
  const offsets = objs.map((body, i) => {
    const at = out.length;
    out += `${i + 1} 0 obj\n${body}\nendobj\n`;
    return at;
  });
  const xref = out.length;
  out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  for (const o of offsets) out += `${String(o).padStart(10, "0")} 00000 n \n`;
  out += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(out, "latin1");
}
const files = path.join(tmp, "files");
mkdirSync(files);
const mainPdf = path.join(files, "report.pdf");
const readOnlyPdf = path.join(files, "readonly.pdf");
const pickedPdf = path.join(files, "picked.pdf");
writeFileSync(mainPdf, makePdf(["Hello from layr", "Second page", "Third page"]));
writeFileSync(readOnlyPdf, makePdf(["Read only"]));
writeFileSync(pickedPdf, makePdf(["Picked in the dialog"]));
const mainSize = statSync(mainPdf).size;

// ---------- layr serve ----------

const PORT = 4300 + Math.floor(Math.random() * 500) + 600;
const home = path.join(tmp, "home");
const serveArgs = ["serve", "--port", String(PORT), "--token", "dev", "--home", home,
  "--link", path.join(repoRoot, "plugins", "pdf")];
const serve = spawn(exe, serveArgs, { env: { ...process.env, RUST_LOG: "warn" }, stdio: ["ignore", "pipe", "pipe"] });
let serveLog = "";
serve.stdout.on("data", (d) => (serveLog += d));
serve.stderr.on("data", (d) => (serveLog += d));
for (let i = 0; i < 100 && !serveLog.includes("shell:"); i++) await new Promise((r) => setTimeout(r, 200));
if (!serveLog.includes("shell:")) throw new Error(`layr serve didn't start:\n${serveLog}`);

let nextId = 1;
const pending = new Map();
const events = [];
const ws = new WebSocket(`ws://127.0.0.1:${PORT}/_layr/ws?token=dev`);
await new Promise((resolve, reject) => {
  ws.onopen = resolve;
  ws.onerror = reject;
});
ws.onmessage = (m) => {
  const msg = JSON.parse(m.data);
  if (msg.method === "event") events.push(msg.params);
  const p = pending.get(msg.id);
  if (!p) return;
  pending.delete(msg.id);
  msg.error ? p.reject(Object.assign(new Error(msg.error.message), msg.error)) : p.resolve(msg.result);
};
const call = (method, params = {}) =>
  new Promise((resolve, reject) => {
    const id = nextId++;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ jsonrpc: "2.0", id, method, params }));
  });
await call("settings.set", { key: "theme", value: { mode: "dark" } });

// ---------- the browser ----------

const browser = await chromium.launch(process.env.LAYR_PDF_EDGE ? { channel: "msedge" } : {});
const context = await browser.newContext({ viewport: { width: 1100, height: 800 } });
// What the stubbed dialogs answer next: a path to grant, or null for "cancelled".
const dialog = { open: null, saveAs: null, calls: [] };
await context.exposeFunction("__testShellCall", async (method, params) => {
  dialog.calls.push({ method, params });
  const pick = method === "files.open" ? dialog.open : dialog.saveAs;
  return pick ? call("files.grant", { plugin: "pdf", path: pick }) : null;
});
await context.addInitScript(() => {
  window.__layrShell = { call: (method, params) => window.__testShellCall(method, params) };
});

const problems = [];
let results = [];
const ok = (name) => {
  results.push(name);
  console.log(`ok - ${name}`);
};

async function openPanel(params) {
  const created = await call("panels.create", { plugin: "pdf", panel: "viewer", params });
  const page = await context.newPage();
  page.on("console", (m) => {
    if (m.type() !== "error" && !/Content.Security.Policy/i.test(m.text())) return;
    problems.push(`[console] ${m.text()} ${m.location()?.url ?? ""}`);
  });
  page.on("pageerror", (e) => problems.push(`[pageerror] ${e.message}`));
  page.on("response", (r) => {
    if (r.status() >= 400) problems.push(`[http ${r.status()}] ${r.url().replace(/layr=[^&]+/, "layr=…")}`);
  });
  await page.goto(created.url);
  return { page, created };
}
const title = async (instance) => (await call("panels.get", { instance })).title;
const waitTitle = async (instance, want) => {
  for (let i = 0; i < 50; i++) {
    if ((await title(instance)) === want) return;
    await new Promise((r) => setTimeout(r, 100));
  }
  assert.equal(await title(instance), want);
};
const rendered = (page, text) =>
  page.waitForFunction((t) => {
    const app = window.PDFViewerApplication;
    return app?.pdfDocument && document.querySelector(".page canvas") && document.querySelector(".textLayer")
      ?.textContent.includes(t);
  }, text, { timeout: 20000 });

/** Adds a FreeText annotation on the first page through PDF.js's toolbar. */
async function addText(page, text) {
  await page.click("#editorFreeTextButton");
  const box = await page.locator('.page[data-page-number="1"]').boundingBox();
  await page.mouse.click(box.x + 150, box.y + 250);
  await page.keyboard.type(text);
  await page.mouse.click(box.x + 400, box.y + 500); // commits the text
  await page.click("#editorFreeTextButton"); // leaves the editing mode
}

try {
  // 1. A file the panel was opened with renders, titled with its name.
  const ref = await call("files.grant", { plugin: "pdf", path: mainPdf });
  assert.equal(ref.name, "report.pdf");
  const { page, created } = await openPanel({ file: ref });
  await rendered(page, "Hello from layr");
  await waitTitle(created.instance, "report.pdf");
  assert.equal(await page.locator("#layrEmpty").isHidden(), true);
  ok("renders the file it was opened with, title = file name");

  // Dark theme from layr, light when the theme changes.
  assert.equal(await page.evaluate(() => document.documentElement.style.colorScheme), "dark");
  await page.screenshot({ path: path.join(OUT, "dark.png") });
  await page.evaluate(() => document.documentElement.setAttribute("data-theme", "light"));
  assert.equal(await page.evaluate(() => document.documentElement.style.colorScheme), "light");
  await page.screenshot({ path: path.join(OUT, "light.png") });
  await page.evaluate(() => document.documentElement.setAttribute("data-theme", "dark"));
  ok("follows layr's theme");

  // 2. An edit marks the title; Ctrl+S writes it back into the file.
  await addText(page, "Added in layr");
  await waitTitle(created.instance, "• report.pdf");
  ok("an annotation edit puts • in the title");
  await page.keyboard.press("Control+s");
  await waitTitle(created.instance, "report.pdf");
  const saved = readFileSync(mainPdf, "latin1");
  assert.ok(statSync(mainPdf).size > mainSize, "the file grew");
  assert.match(saved, /\/FreeText/);
  assert.equal(dialog.calls.length, 0, "no dialog for a writable file");
  ok("Ctrl+S saves the annotation into the file (no dialog)");
  await page.screenshot({ path: path.join(OUT, "edited.png") });

  // 3. Ctrl+Shift+S asks where and writes a copy; the panel then follows the copy.
  const copy = path.join(files, "copy.pdf");
  dialog.saveAs = copy;
  await page.keyboard.press("Control+Shift+s");
  for (let i = 0; i < 50 && !existsSync(copy); i++) await new Promise((r) => setTimeout(r, 100));
  assert.ok(existsSync(copy), "save as wrote the copy");
  assert.equal(dialog.calls.at(-1).method, "files.saveAs");
  assert.equal(dialog.calls.at(-1).params.name, "report.pdf");
  assert.deepEqual(dialog.calls.at(-1).params.types, [".pdf"]);
  await waitTitle(created.instance, "copy.pdf");
  ok("Ctrl+Shift+S saves as a new file and the tab follows it");

  // 4. The page is remembered across a reload (a restart of the tab).
  await page.evaluate(() => (window.PDFViewerApplication.page = 3));
  await new Promise((r) => setTimeout(r, 800));
  await page.reload();
  await rendered(page, "Hello from layr");
  await page.waitForFunction(() => window.PDFViewerApplication.page === 3, null, { timeout: 5000 });
  await waitTitle(created.instance, "copy.pdf");
  ok("reopens the file it showed last on the page it was on");

  // PDF.js's own Open button and Ctrl+O use layr's dialog; with a file on show the picked one goes to a new tab.
  dialog.open = null;
  const calls = dialog.calls.length;
  await page.click("#secondaryToolbarToggleButton");
  await page.click("#secondaryOpenFile");
  for (let i = 0; i < 30 && dialog.calls.length === calls; i++) await new Promise((r) => setTimeout(r, 100));
  assert.equal(dialog.calls.at(-1)?.method, "files.open");
  await page.keyboard.press("Control+o");
  for (let i = 0; i < 30 && dialog.calls.length === calls + 1; i++) await new Promise((r) => setTimeout(r, 100));
  assert.equal(dialog.calls.length, calls + 2);
  dialog.open = pickedPdf;
  await page.keyboard.press("Control+o");
  const isOpen = (e) => e.topic === "shell:open" && e.data?.plugin === "pdf" && e.data?.from === created.instance;
  for (let i = 0; i < 50 && !events.some(isOpen); i++) await new Promise((r) => setTimeout(r, 100));
  assert.ok(events.some(isOpen), `a shell:open for a new tab (events: ${events.map((e) => e.topic).join(", ")})`);
  assert.ok(await page.evaluate(() => document.querySelector(".textLayer")?.textContent.includes("Hello from layr")),
    "the file on show stays");
  ok("PDF.js's Open button and Ctrl+O go through layr's open dialog, keeping the file on show");

  // 5. A read-only file: Ctrl+S falls back to save as.
  const ro = await call("files.grant", { plugin: "pdf", path: readOnlyPdf, writable: false });
  const before = readFileSync(readOnlyPdf);
  const second = await openPanel({ file: ro });
  await rendered(second.page, "Read only");
  await addText(second.page, "Note");
  await waitTitle(second.created.instance, "• readonly.pdf");
  const roCopy = path.join(files, "readonly-copy.pdf");
  dialog.saveAs = roCopy;
  await second.page.keyboard.press("Control+s");
  for (let i = 0; i < 50 && !existsSync(roCopy); i++) await new Promise((r) => setTimeout(r, 100));
  assert.ok(existsSync(roCopy), "the read-only file was saved as a copy");
  assert.deepEqual(readFileSync(readOnlyPdf), before, "the read-only file is unchanged");
  await waitTitle(second.created.instance, "readonly-copy.pdf");
  ok("a read-only file saves as a new one and stays unchanged");
  await second.page.close();

  // 6. Opened without a file: the empty state; params.pick opens the dialog right away.
  dialog.open = null;
  const empty = await openPanel({ pick: true });
  await empty.page.waitForSelector("#layrEmpty:not([hidden])");
  for (let i = 0; i < 50 && dialog.calls.at(-1)?.method !== "files.open"; i++) {
    await new Promise((r) => setTimeout(r, 100));
  }
  assert.equal(dialog.calls.at(-1).method, "files.open");
  assert.deepEqual(dialog.calls.at(-1).params.types, [".pdf"]);
  await empty.page.screenshot({ path: path.join(OUT, "empty.png") });
  ok("without a file: empty state, and pick opens the dialog at once");
  dialog.open = pickedPdf;
  await empty.page.click("#layrOpen");
  await rendered(empty.page, "Picked in the dialog");
  await waitTitle(empty.created.instance, "picked.pdf");
  ok("the empty state's Open PDF… opens the picked file in place");
  await empty.page.close();

  const csp = problems.filter((p) => /Content.Security.Policy|Refused/i.test(p));
  assert.deepEqual(csp, [], "no CSP errors");
  ok("no CSP errors in the console");
  if (problems.length) console.log(`other console errors:\n  ${problems.join("\n  ")}`);
} catch (err) {
  console.error(`FAILED: ${err.stack || err}`);
  if (problems.length) console.error(`console:\n  ${problems.join("\n  ")}`);
  process.exitCode = 1;
} finally {
  console.log(`${results.length} passed; screenshots in ${OUT}`);
  await browser.close();
  ws.close();
  serve.kill();
  if (!process.argv.includes("--keep") && !arg("out")) {
    await new Promise((r) => setTimeout(r, 500));
    rmSync(tmp, { recursive: true, force: true });
  }
}
