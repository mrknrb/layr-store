// node --test plugins/pdf/test/lib.test.mjs
import assert from "node:assert/strict";
import { test } from "node:test";
import { keyAction, saveName, saveTarget, startFile, titleFor } from "../panels/lib.js";

const ref = (id, more = {}) => ({ id, name: `${id}.pdf`, size: 10, writable: true, exists: true, ...more });

test("the title is the file's name, with a dot while edits are unsaved", () => {
  assert.equal(titleFor("a.pdf", false), "a.pdf");
  assert.equal(titleFor("a.pdf", true), "• a.pdf");
  assert.equal(titleFor("", false), "PDF");
});

test("keys: save, save as, open, and PDF.js's own", () => {
  assert.equal(keyAction({ ctrlKey: true, key: "s" }), "save");
  assert.equal(keyAction({ ctrlKey: true, shiftKey: true, key: "S" }), "saveAs");
  assert.equal(keyAction({ ctrlKey: true, key: "o" }), "open");
  assert.equal(keyAction({ ctrlKey: true, shiftKey: true, key: "O" }), null);
  assert.equal(keyAction({ ctrlKey: true, key: "f" }), "pdfjs");
  assert.equal(keyAction({ ctrlKey: true, altKey: true, key: "g" }), "pdfjs");
  assert.equal(keyAction({ ctrlKey: true, altKey: true, key: "s" }), null); // AltGr and Ctrl+Alt keys stay the shell's
  assert.equal(keyAction({ key: "s" }), null);
  assert.equal(keyAction({ ctrlKey: true, key: "w" }), null);
});

test("saving writes back to a writable file, else asks", () => {
  assert.equal(saveTarget(ref("a"), false).id, "a");
  assert.equal(saveTarget(ref("a"), true), null);
  assert.equal(saveTarget(ref("a", { writable: false }), false), null);
  assert.equal(saveTarget(null, false), null);
  assert.equal(saveName(ref("a"), "x.pdf"), "a.pdf");
  assert.equal(saveName(null, "report"), "report.pdf");
  assert.equal(saveName(null, ""), "document.pdf");
});

test("the start file: the saved one first, then the one the panel was opened with", () => {
  assert.equal(startFile({}, {}), null);
  assert.equal(startFile(null, undefined), null);
  assert.deepEqual(startFile({}, { file: ref("a") }), { file: ref("a"), page: null, fallback: null });
  const moved = startFile({ file: ref("b"), page: 4 }, { file: ref("a") });
  assert.deepEqual(moved, { file: ref("b"), page: 4, fallback: ref("a") });
  const same = startFile({ file: ref("a"), page: "2" }, { file: ref("a") });
  assert.deepEqual(same, { file: ref("a"), page: 2, fallback: null });
});
