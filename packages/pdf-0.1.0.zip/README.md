# PDF

Reads, annotates and saves PDF files in a layr tab, with Mozilla's [PDF.js](https://github.com/mozilla/pdf.js)
generic viewer (Apache-2.0, `vendor/pdfjs/LICENSE`).

- Opens the files layr gives it (the shell's "Open file…" for `.pdf`, or "PDF: Open PDF…"), each in its own tab.
- PDF.js's open button and Ctrl+O use layr's open dialog; with a file on show, the picked one opens in a new tab.
- Its save button and Ctrl+S write the file back (annotations included); a read-only file, or Ctrl+Shift+S, asks
  where to save. The tab's title shows `•` while there are unsaved edits.
- Highlight, text, ink, stamp and signature editing are PDF.js's own; so are find, print and the sidebar.
- Follows layr's dark and light theme, and reopens the file it showed last on the page it was on.

## Files

| Path | What it is |
| --- | --- |
| `panels/viewer.html` | A copy of PDF.js's `web/viewer.html`: its `<body>` unchanged plus the empty state, its `<head>` replaced |
| `panels/viewer.js` | The layr side: options, open and save through `layr.files`, title, theme, keys, panel state |
| `panels/lib.js` | Its small decisions, tested with `node --test` |
| `panels/viewer.css` | The empty state, hidden buttons, the theme |
| `vendor/pdfjs/` | PDF.js 6.5.438, the prebuilt generic viewer |

## PDF.js

`vendor/pdfjs` is `pdfjs-6.5.438-dist.zip` from https://github.com/mozilla/pdf.js/releases/tag/v6.5.438
(sha256 `fcbe9ba21d9911843e3502adc178a7f549a524a4055f887bedc942e5490c6ba1`). No PDF.js file is edited. Left out:
- the source maps (`*.map`, 9.5 MB); the files still name them in a `sourceMappingURL` comment, which only the
  browser's developer tools read;
- the sample document `web/compressed.tracemonkey-pldi-09.pdf`.

How it is wired in, without editing PDF.js:
- `panels/viewer.html` sets `<base href="../vendor/pdfjs/web/">`, so the viewer's relative paths (worker, wasm,
  fonts, cmaps, locales) resolve as in the original. The original's `<meta>` CSP is left out (layr sends the page's
  CSP; the original's `base-uri 'none'` would forbid the `<base>`). It loads `/_layr/layr.js` and then
  `panels/viewer.js` before `viewer.mjs`.
- `viewer.js` sets PDF.js's options on its `webviewerloaded` event: no preferences in localStorage, no sample
  document, no browser history, the signature editor on. It replaces three of `PDFViewerApplication`'s members:
  `downloadOrSave` (save through `layr.files`), `_hasChanges` (unsaved edits only, so the leave-page warning and
  the title stop after a save) and `_openFileInput` (the open buttons call layr's dialog), and wraps
  `_initializeAnnotationStorageCallbacks` to hear `onSetModified` / `onResetModified`. Documents open with
  `isEvalSupported: false`.
- The theme sets the page's `color-scheme`, which is what PDF.js's `viewerCssTheme` does (`viewer.css` uses
  `light-dark()`).

These are PDF.js internals: check them when updating. To update, unzip the new `pdfjs-<ver>-dist.zip` over
`vendor/pdfjs` (without the maps and the sample), copy the new `web/viewer.html` `<body>` into `panels/viewer.html`,
and run the tests.

## Tests

```powershell
node --test plugins/pdf/test/lib.test.mjs
cargo build -p layr_cli --manifest-path core/Cargo.toml
node plugins/pdf/test/viewer.e2e.mjs
```
The end-to-end test runs a `layr serve` with this folder linked and a temporary home, stubs the app's file dialogs,
and checks in headless Chromium (`LAYR_PDF_EDGE=1` for Edge) that a file renders without CSP errors, the theme,
editing, saving, saving as, read-only files, the open dialog, the empty state and the remembered page. It needs
Playwright from `plugins/dev` (`npm install` there).
